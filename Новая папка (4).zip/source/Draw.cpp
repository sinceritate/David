#include "Cheat.h"

HFont F::ESP;
HFont F::MenuCon;
HFont F::Panel;
HFont F::HitMarker;
HFont F::Watermark;

void D::SetupFonts()
{
	I::Surface->SetFontGlyphSet(F::ESP = I::Surface->Create_Font(), ("Arial"), 13, FW_NORMAL, NULL, NULL, FONTFLAG_OUTLINE);
	I::Surface->SetFontGlyphSet(F::MenuCon = I::Surface->Create_Font(), ("Arial"), 16, FW_EXTRALIGHT, NULL, NULL, FONTFLAG_DROPSHADOW);
	I::Surface->SetFontGlyphSet(F::Panel = I::Surface->Create_Font(), ("Tahoma"), 12/*15*/, FW_NORMAL, NULL, NULL, FONTFLAG_DROPSHADOW);
	I::Surface->SetFontGlyphSet(F::HitMarker = I::Surface->Create_Font(), ("Arial"), 25, FW_NORMAL, NULL, NULL, FONTFLAG_ANTIALIAS | FONTFLAG_OUTLINE);
	I::Surface->SetFontGlyphSet(F::Watermark = I::Surface->Create_Font(), ("MS Sans Serif"), 18, FW_DONTCARE, NULL, NULL, FONTFLAG_OUTLINE);
}

void D::DrawString(HFont font, int x, int y, Color Color, DWORD alignment, const char* msg, ...)
{
	va_list va_alist;
	char buf[1024];
	va_start(va_alist, msg);
	_vsnprintf(buf, sizeof(buf), msg, va_alist);
	va_end(va_alist);
	wchar_t wbuf[1024];
	MultiByteToWideChar(CP_UTF8, 0, buf, 256, wbuf, 256);

	int r = 255, g = 255, b = 255, a = 255;
	Color.GetColor(r, g, b, a);

	int Width, Height;
	I::Surface->GetTextSize(font, wbuf, Width, Height);

	if (alignment & FONT_RIGHT)
	{
		x -= Width;
	}
		
	if (alignment & FONT_CENTER)
	{
		x -= Width / 2;
	}
	
	I::Surface->DrawSetTextFont(font);
	I::Surface->DrawSetTextColor(r, g, b, a);
	I::Surface->DrawSetTextPos(x, y - Height / 2);
	I::Surface->DrawPrintText(wbuf, wcslen(wbuf));
}

void D::DrawLine(int x0, int y0, int x1, int y1, Color pColor)
{
	I::Surface->DrawSetColor(pColor);
	I::Surface->DrawLine(x0, y0, x1, y1);
}

void D::DrawCircle3D(Vector position, float points, float radius, Color Color)
{
	float Step = (float)M_PI * 2.0f / points;

	std::vector<Vector> points3d;

	for (float a = 0; a < (M_PI * 2.0f); a += Step)
	{
		Vector Start(radius * cosf(a) + position.x, radius * sinf(a) + position.y, position.z);
		Vector End(radius * cosf(a + Step) + position.x, radius * sinf(a + Step) + position.y, position.z);

		Vector start2d, end2d;

		if (!D::WorldToScreen(Start, start2d) || !D::WorldToScreen(End, end2d))
			return;

		D::DrawLine(start2d.x, start2d.y, end2d.x, end2d.y, Color);
	}
}

bool D::ScreenTransform(const Vector& point, Vector& screen) 
{
	float w;
	const VMatrix& worldToScreen = I::Engine->WorldToScreenMatrix();

	screen.x = worldToScreen[0][0] * point[0] + worldToScreen[0][1] * point[1] + worldToScreen[0][2] * point[2] + worldToScreen[0][3];
	screen.y = worldToScreen[1][0] * point[0] + worldToScreen[1][1] * point[1] + worldToScreen[1][2] * point[2] + worldToScreen[1][3];
	w = worldToScreen[3][0] * point[0] + worldToScreen[3][1] * point[1] + worldToScreen[3][2] * point[2] + worldToScreen[3][3];
	screen.z = 0.0f;

	bool behind = false;

	if (w < 0.001f)
	{
		behind = true;
		screen.x *= 100000;
		screen.y *= 100000;
	}
	else
	{
		behind = false;
		float invw = 1.0f / w;
		screen.x *= invw;
		screen.y *= invw;
	}

	return behind;
}

bool D::WorldToScreen(const Vector& origin, Vector& screen)
{
	auto LWorldToScreen = [&]()->bool
	{
		if (!std::isfinite(origin.x) && !std::isfinite(origin.y) && !std::isfinite(origin.z))
			return false;

		const auto screenTransform = [&origin, &screen]() -> bool
		{
			static std::uintptr_t pViewMatrix;
			if (!pViewMatrix)
			{
				pViewMatrix = static_cast<std::uintptr_t>(U::FindPattern(rxs("client_panorama.dll"), rxs("0F 10 05 ? ? ? ? 8D 85 ? ? ? ? B9")));
				pViewMatrix += 3;
				pViewMatrix = *reinterpret_cast<std::uintptr_t*>(pViewMatrix);
				pViewMatrix += 176;

				return true;
			}
			else
			{
				const VMatrix& w2sMatrix = *reinterpret_cast<VMatrix*>(pViewMatrix);
				screen.x = w2sMatrix.m[0][0] * origin.x + w2sMatrix.m[0][1] * origin.y + w2sMatrix.m[0][2] * origin.z + w2sMatrix.m[0][3];
				screen.y = w2sMatrix.m[1][0] * origin.x + w2sMatrix.m[1][1] * origin.y + w2sMatrix.m[1][2] * origin.z + w2sMatrix.m[1][3];
				screen.z = 0.0f;

				float w = w2sMatrix.m[3][0] * origin.x + w2sMatrix.m[3][1] * origin.y + w2sMatrix.m[3][2] * origin.z + w2sMatrix.m[3][3];

				if (w < 0.001f)
				{
					screen.x *= 100000;
					screen.y *= 100000;
					return true;
				}

				float invw = 1.f / w;
				screen.x *= invw;
				screen.y *= invw;

				return false;
			}
		};

		if (!screenTransform())
		{
			screen.x = (G::ScreenWidth * 0.5f) + (screen.x * G::ScreenWidth) * 0.5f;
			screen.y = (G::ScreenHeight * 0.5f) - (screen.y * G::ScreenHeight) * 0.5f;

			return true;
		}

		return false;
	};
	return LWorldToScreen();
}
