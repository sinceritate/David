#pragma once

namespace Autowall
{
	struct FireBulletData
	{
		Vector src;
		trace_t enter_trace;
		Vector direction;
		CTraceFilter filter;
		float trace_length;
		float trace_length_remaining;
		float current_damage;
		int penetrate_count;
	};

	extern float GetDamage(const Vector &vecPoint, CBaseEntity* entity);
	extern void  ScaleDamage(int hitgroup, CBaseEntity *player, float weapon_armor_ratio, float &current_damage);
	extern bool  SimulateFireBullet(CBaseCombatWeapon *weap, FireBulletData &data, CBaseEntity* entity);
	extern bool  HandleBulletPenetration(CSWeaponInfo *wpn_data, FireBulletData &data);
	extern bool  TraceToExit(Vector& end, trace_t& tr, float x, float y, float z, float x2, float y2, float z2, trace_t* trace);
	extern void  ClipTraceToPlayers(const Vector &vecAbsStart, const Vector &vecAbsEnd, unsigned int mask, ITraceFilter *filter, trace_t *tr);
	extern bool  IsArmored(CBaseEntity *player, int hitgroup);
}