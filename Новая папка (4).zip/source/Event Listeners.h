#pragma once

namespace Listener
{
	namespace Damage
	{
		extern void WeaponFired(IGameEvent* pEvent);
		extern void PlayerHurt(IGameEvent* pEvent);
		extern void PlayerDeath(IGameEvent* pEvent);
		extern GetListener* WeaponFiredListener;
		extern GetListener* PlayerHurtListener;
		extern GetListener* PlayerDeathListener;
	}

	namespace Item
	{
		extern void Purchase(IGameEvent* pEvent);
		extern GetListener* PurchaseListener;
	}

	namespace Bullet
	{
		extern void Impact(IGameEvent* pEvent);
		extern GetListener* ImpactListener;
	}

	namespace Bomb
	{
		extern void BeginDefuse(IGameEvent* pEvent);
		extern void AbortDefuse(IGameEvent* pEvent);
		extern void Defused(IGameEvent* pEvent);
		extern void Planted(IGameEvent* pEvent);
		extern void Exploded(IGameEvent* pEvent);
		extern GetListener* DefusedListener;
		extern GetListener* BeginDefuseListener;
		extern GetListener* AbortDefuseListener;
		extern GetListener* PlantedListener;
		extern GetListener* ExplodedListener;
	}

	namespace Round
	{
		extern void Start(IGameEvent* pEvent);
		extern GetListener* StartListener;
	}

	extern void Get();
}