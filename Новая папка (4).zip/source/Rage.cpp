#include "Cheat.h"

float Rage::AimBot::BestDMG = 180.f;
int Rage::AimBot::PlayerID = -1;
std::vector <int> Rage::AimBot::hitbox_list;
bool Rage::AimBot::baim_work = false;

int Rage::AimBot::current_weapon_index = 0;
int Rage::AimBot::old_weapon_index = 0;
int Rage::AimBot::current_weapon_type = 0;
int Rage::AimBot::old_weapon_type = 0;

int Rage::AimBot::target_player = 0;

bool bBAimHealth;
int iBAimHealth;
bool bBAimMiss;
int iBAimMiss;
int iBone;
float fHitChance;
float fMinDamage;

void Rage::UpdateRageSettings()
{
	if (Opts.RageBot.AimBot.SettingMode == 0)
	{
		bBAimHealth = Opts.RageBot.AimBot.All_Rage.bBAimHealth;
		iBAimHealth = Opts.RageBot.AimBot.All_Rage.iBAimHealth;
		bBAimMiss = Opts.RageBot.AimBot.All_Rage.bBAimMiss;
		iBAimMiss = Opts.RageBot.AimBot.All_Rage.iBAimMiss;
		iBone = Opts.RageBot.AimBot.All_Rage.Bone;
		fHitChance = Opts.RageBot.AimBot.All_Rage.HitChance;
		fMinDamage = Opts.RageBot.AimBot.All_Rage.MinDamage;
	}
	else if (Opts.RageBot.AimBot.SettingMode == 1)
	{
		bBAimHealth = Opts.RageBot.AimBot.WT_Rage[Rage::AimBot::current_weapon_type].bBAimHealth;
		iBAimHealth = Opts.RageBot.AimBot.WT_Rage[Rage::AimBot::current_weapon_type].iBAimHealth;
		bBAimMiss = Opts.RageBot.AimBot.WT_Rage[Rage::AimBot::current_weapon_type].bBAimMiss;
		iBAimMiss = Opts.RageBot.AimBot.WT_Rage[Rage::AimBot::current_weapon_type].iBAimMiss;
		iBone = Opts.RageBot.AimBot.WT_Rage[Rage::AimBot::current_weapon_type].Bone;
		fHitChance = Opts.RageBot.AimBot.WT_Rage[Rage::AimBot::current_weapon_type].HitChance;
		fMinDamage = Opts.RageBot.AimBot.WT_Rage[Rage::AimBot::current_weapon_type].MinDamage;
	}
	else
	{
		bBAimHealth = Opts.RageBot.AimBot.EW_Rage[Rage::AimBot::current_weapon_index].bBAimHealth;
		iBAimHealth = Opts.RageBot.AimBot.EW_Rage[Rage::AimBot::current_weapon_index].iBAimHealth;
		bBAimMiss = Opts.RageBot.AimBot.EW_Rage[Rage::AimBot::current_weapon_index].bBAimMiss;
		iBAimMiss = Opts.RageBot.AimBot.EW_Rage[Rage::AimBot::current_weapon_index].iBAimMiss;
		iBone = Opts.RageBot.AimBot.EW_Rage[Rage::AimBot::current_weapon_index].Bone;
		fHitChance = Opts.RageBot.AimBot.EW_Rage[Rage::AimBot::current_weapon_index].HitChance;
		fMinDamage = Opts.RageBot.AimBot.EW_Rage[Rage::AimBot::current_weapon_index].MinDamage;
	}
}

void Rage::AimBot::HitboxList(CBaseEntity* Entity)
{
	hitbox_list.clear();
	
	if (bBAimHealth && Entity->GetHealth() < iBAimHealth)
	{
		hitbox_list.push_back(BONE_CHEST);
		hitbox_list.push_back(BONE_PELVIS);
		hitbox_list.push_back(BONE_UPPER_CHEST);
		hitbox_list.push_back(BONE_LOWER_CHEST);
		hitbox_list.push_back(BONE_STOMACH);
		hitbox_list.push_back(BONE_LEFT_THIGH);
		hitbox_list.push_back(BONE_RIGHT_THIGH);
	
		Rage::AimBot::baim_work = true;
		return;
	}
	else if (bBAimMiss && iBAimMiss <= (G::shots_fired[G::target] - G::shots_hit[G::target]))
	{
		hitbox_list.push_back(BONE_CHEST);
		hitbox_list.push_back(BONE_PELVIS);
		hitbox_list.push_back(BONE_UPPER_CHEST);
		hitbox_list.push_back(BONE_LOWER_CHEST);
		hitbox_list.push_back(BONE_STOMACH);
		hitbox_list.push_back(BONE_LEFT_THIGH);
		hitbox_list.push_back(BONE_RIGHT_THIGH);

		Rage::AimBot::baim_work = true;
		return;
	}
	else if (GetAsyncKeyState(Opts.RageBot.AimBot.BAimKey))
	{
		hitbox_list.push_back(BONE_CHEST);
		hitbox_list.push_back(BONE_PELVIS);
		hitbox_list.push_back(BONE_UPPER_CHEST);
		hitbox_list.push_back(BONE_LOWER_CHEST);
		hitbox_list.push_back(BONE_STOMACH);
		hitbox_list.push_back(BONE_LEFT_THIGH);
		hitbox_list.push_back(BONE_RIGHT_THIGH);
	
		Rage::AimBot::baim_work = true;
		return;
	}
	
	if (iBone & (1 << 0))
	{
		hitbox_list.push_back(BONE_HEAD);
	}
	if (iBone & (1 << 1))
	{
		hitbox_list.push_back(BONE_NECK);
		hitbox_list.push_back(BONE_LOWER_NECK);
	}
	if (iBone & (1 << 2))
	{
		hitbox_list.push_back(BONE_UPPER_CHEST);
		hitbox_list.push_back(BONE_CHEST);
	}
	if (iBone & (1 << 3))
	{
		hitbox_list.push_back(BONE_PELVIS);
		hitbox_list.push_back(BONE_STOMACH);
	}
	if (iBone & (1 << 4))
	{
		hitbox_list.push_back(BONE_LEFT_FOREARM);
		hitbox_list.push_back(BONE_RIGHT_FOREARM);
		hitbox_list.push_back(BONE_LEFT_CUBIT);
		hitbox_list.push_back(BONE_RIGHT_CUBIT);
	}
	if (iBone & (1 << 5))
	{
		hitbox_list.push_back(BONE_LEFT_FOOT);
		hitbox_list.push_back(BONE_RIGHT_FOOT);
		hitbox_list.push_back(BONE_LEFT_THIGH);
		hitbox_list.push_back(BONE_RIGHT_THIGH);
		hitbox_list.push_back(BONE_LEFT_KNEE);
		hitbox_list.push_back(BONE_RIGHT_KNEE);
	}

	Rage::AimBot::baim_work = false;
}

int Rage::AimBot::GetHitbox(int ID)
{
	CBaseEntity* entity = I::ClientEntList->GetClientEntity(ID);
	Rage::AimBot::HitboxList(entity);

	int pBone = -1;
	
	float BestDamage = Rage::AimBot::baim_work ? iBAimHealth : fMinDamage;
	
	for (int i = 0; i < hitbox_list.size(); ++i)
	{
		Vector pPosition = entity->GetBonePosition(hitbox_list[i]);
	
		if (pPosition.IsZero())
			continue;
		
		if (!Opts.RageBot.AimBot.AutoWall && !entity->IsVisible(hitbox_list[i]))
			continue;
	
		float pDamage = Autowall::GetDamage(pPosition, G::LocalPlayer);
	
		if (pDamage > BestDamage)
		{
			BestDamage = pDamage;
			pBone = hitbox_list[i];
		}
	}
	
	return pBone;
}

bool Rage::AimBot::HitChance(float flHitChance)
{
	if (!G::LocalPlayer->GetWeapon())
		return false;

	if (flHitChance > 0 && *G::LocalPlayer->GetWeapon()->GetItemDefinitionIndex() != WEAPON_REVOLVER)
	{
		float inaccuracy = G::LocalPlayer->GetWeapon()->GetInaccuracy();

		if (inaccuracy <= 0)
			inaccuracy = 0.0000001;

		inaccuracy = 1 / inaccuracy;

		return ((flHitChance <= inaccuracy) ? true : false);
	}

	return true;
}

bool Rage::AimBot::DropTarget()
{
	CBaseEntity* Player = I::ClientEntList->GetClientEntity(PlayerID);
	return !Rage::AimBot::CheckTarget(Player);
}

int iHitbox;

void Rage::AimBot::FindTarget()
{
	BestDMG = 0;

	for (int i = 0; i < 64; ++i)
	{
		CBaseEntity* entity = I::ClientEntList->GetClientEntity(i);

		if (!Rage::AimBot::CheckTarget(entity))
			continue;

		int Hitbox = GetHitbox(i);
		if (Hitbox == -1) continue;

		float NewDMG = Autowall::GetDamage(entity->GetBonePosition(Hitbox), G::LocalPlayer);
		if (NewDMG > BestDMG)
		{
			iHitbox = Hitbox;
			BestDMG = NewDMG;
			PlayerID = i;
		}
	}

	G::target = PlayerID;
}

int autoRevolerDelay = 0;

void AutoShoot(CBaseEntity* player, CUserCmd* cmd)
{
	CBaseEntity* localplayer = (CBaseEntity*)I::ClientEntList->GetClientEntity(I::Engine->GetLocalPlayer());
	CBaseCombatWeapon* activeWeapon = localplayer->GetWeapon();

	if (!player || !activeWeapon)
		return;

	float nextPrimaryAttack = activeWeapon->GetNextPrimaryAttack();
	
	if ((nextPrimaryAttack - (G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick)) > 0)
	{
		cmd->buttons &= ~IN_ATTACK;
	}
	else
	{
		if (Opts.RageBot.AimBot.AutoScope && localplayer->GetWeapon()->IsSniper() && !localplayer->IsScoped())
		{
			cmd->buttons |= IN_ATTACK2;
		}
		if (Rage::AimBot::HitChance(fHitChance))
		{
			//cmd->buttons &= ~IN_ATTACK2;

			if (Rage::AimBot::current_weapon_index == WAI_REVOLVER)
			{
				if (autoRevolerDelay == 15)
				{
					G::UserCmd->buttons |= IN_ATTACK;
					autoRevolerDelay -= 1;
				}
			}
			else if (G::LocalPlayer->GetWeapon()->GetType() != WT_PISTOLS)
			{
				static bool fire = false;
				fire = !fire;

				if (fire)
				{
					G::UserCmd->buttons |= IN_ATTACK;
				}
				else
				{
					G::UserCmd->buttons &= ~IN_ATTACK;
				}
			}
			else
			{
				static int fire = 0;

				if (fire <= 2)
				{
					G::UserCmd->buttons |= IN_ATTACK;
					fire += 1;
				}
				else
				{
					G::UserCmd->buttons &= ~IN_ATTACK;
					fire = 0;
				}
			}
		}
	}
}

void Rage::AimBot::GoToTarget()
{
	CBaseEntity* Player = I::ClientEntList->GetClientEntity(PlayerID);
	
	if (Opts.RageBot.AimBot.AutoStop && !G::LocalPlayer->GetWeapon()->IsEmpty() && !G::LocalPlayer->GetWeapon()->IsReloading() && G::LocalPlayer->GetWeapon()->GetNextPrimaryAttack() - (G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick) <= 0)
	{
	//	int Speed = 40;
	//
	//	float min_speed = (float)(FastSqrt(G::UserCmd->forwardmove * G::UserCmd->forwardmove + G::UserCmd->sidemove * G::UserCmd->sidemove + G::UserCmd->upmove * G::UserCmd->upmove));
	//
	//	if (min_speed <= 0.f)
	//		return;
	//
	//	if (G::UserCmd->buttons & IN_DUCK)
	//		Speed *= 2.94117647f;
	//
	//	if (min_speed <= Speed)
	//		return;
	//
	//	float speed = Speed / min_speed;

		G::UserCmd->forwardmove = 0;// speed;
		G::UserCmd->sidemove = 0;// speed;
		G::UserCmd->upmove = 0;// speed;

		G::UserCmd->buttons |= IN_DUCK;
	//	FixMove::OldForward = G::UserCmd->forwardmove;
	//	FixMove::OldSideMove = G::UserCmd->sidemove;
	//
	//	if (G::LocalPlayer->GetVelocity().Length() > Speed)
	//		G::UserCmd->buttons &= ~IN_ATTACK;
	}

	//QAngle Calced = M::CalcAngle(G::LocalPlayer->GetEyePosition(), Player->GetPredicted(Player->GetBonePosition(iHitbox)));
	QAngle Calced = M::CalcAngle(G::LocalPlayer->GetEyePosition(), Player->GetBonePosition(iHitbox));
	if ((G::LocalPlayer->GetWeapon()->GetNextPrimaryAttack() - (G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick)) < 0)
	{
		AutoShoot(Player, G::UserCmd);

		if (G::UserCmd->buttons & IN_ATTACK)
		{
			G::SendPacket = false;

			ConVar* recoil_scale = I::Cvar->FindVar("weapon_recoil_scale");
			Calced -= G::LocalPlayer->GetPunchAngles() * recoil_scale->GetFloat();

			G::UserCmd->viewangles = Calced.Normalized();
		}
	}
}

bool Rage::AimBot::CheckTarget(CBaseEntity* entity)
{
	if (!entity || entity->GetHealth() <= 0)
		return false;
	else if (entity == G::LocalPlayer || entity->GetDormant())
		return false;
	else if (!entity->IsEnemy() && !Opts.RageBot.AimBot.FriendlyFire)
		return false;
	else if (entity->GetImmune())
		return false;
	if (Autowall::GetDamage(entity->GetBonePosition(iHitbox), G::LocalPlayer) < BestDMG)
		return false;

	return true;
}

void Rage::AimBot::Start()
{
	//if (DropTarget())
	//{
		PlayerID = -1;
	//}
	//
	//if (PlayerID == -1)
	//{
		FindTarget();
	//}

	if (PlayerID != -1)
	{
		GoToTarget();
	}
}

void Rage::Start()
{
	Rage::AimBot::current_weapon_index = G::LocalPlayer->GetWeapon()->GetAimIndex();
	if (Rage::AimBot::current_weapon_index == WAI_UNKNOW)
	{
		G::SendPacket = true;
		return;
	}

	Rage::AimBot::current_weapon_type = G::LocalPlayer->GetWeapon()->GetType() - 4;

	if (Rage::AimBot::current_weapon_index == WAI_REVOLVER && Opts.RageBot.AimBot.AutoRevolver)
	{
		autoRevolerDelay += 1;

		if (autoRevolerDelay <= 15) G::UserCmd->buttons |= IN_ATTACK;
		else autoRevolerDelay = 0;
	}
	else
	{
		autoRevolerDelay = 0;
	}

	if (G::RageUpdate || Rage::AimBot::old_weapon_index != Rage::AimBot::current_weapon_index)
	{
		Rage::UpdateRageSettings();

		Rage::AimBot::old_weapon_index = Rage::AimBot::current_weapon_index;
		G::RageUpdate = false;
	}

	static int ticks = 0;
	if (Rage::AimBot::current_weapon_index == WAI_REVOLVER && G::UserCmd->buttons & IN_ATTACK)
	{
		if (ticks == 16)
			ticks = 0;
		else
			ticks += 1;
	}
	else
		ticks = 0;

	FixMovement::Start();
	{
		if (Opts.RageBot.AimBot.Enabled && Rage::AimBot::current_weapon_index != WAI_TASER)
		{
			Rage::AimBot::Start();
		}

		if (Opts.RageBot.AntiAims.Enabled && (Rage::AimBot::current_weapon_index == WAI_REVOLVER && ticks <= 15) || (G::LocalPlayer->GetWeapon()->GetNextPrimaryAttack() - G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick > MIN_ZERO_D || !(G::UserCmd->buttons & IN_ATTACK)))
		{
			Rage::AntiAims::RageAA();
		}
	}
	FixMovement::End();
}