#include "Cheat.h"

// Skins ------------------------------------------------------
// BloodHound
#define BloodHound_Black_Silver    10006
#define BloodHound_SnakeSkin_Brass 10007
#define BloodHound_Metallic        10008
#define BloodHound_Querrilla       10039

// Sporty
#define Sporty_Light_Blue             10018
#define Sporty_Military               10019
#define Sporty_Purple                 10037
#define Sporty_Green                  10038
#define Sporty_Poison_Frog_Blue_White 10045
#define Sporty_Poison_Frog_Red_Green  10046
#define Sporty_Black_Webbing_Yellow   10047
#define Sporty_Blue_Pink              10048

// Slick
#define Slick_Black                 10013
#define Slick_Military              10015
#define Slick_Red                   10016
#define Slick_SnakeSkin_Yellow      10040
#define Slick_SnakeSkin_White       10041
#define Slick_Plaid_Purple          10042
#define Slick_Stitched_Black_Orange 10043
#define Slick_Stitched_Green_Grey   10044

// HandWrap
#define HandWrap_Leathery                    10009
#define HandWrap_Camo_Grey                   10010
#define HandWrap_Red_Slaughter               10021
#define HandWrap_Fabric_Orange_Camo          10036
#define HandWrap_Leathery_Fabric_Blue_Skulls 10053
#define HandWrap_Leathery_Fabric_Blue        10054
#define HandWrap_Leathery_Ducttape           10055
#define HandWrap_Leathery_Fabric_Green_Camo  10056

// Motocycle
#define Motorcycle_Basic_Black        10024
#define Motorcycle_Mint_Triangle      10026
#define Motorcycle_Mono_Boom          10027
#define Motorcycle_Triangle_Blue      10028
#define Motorcycle_Choco_Boom         10049
#define Motorcycle_Basic_Green_Orange 10050
#define Motorcycle_Yellow_Camo        10051
#define Motorcycle_Trigrid_Blue       10052

// Specialist
#define Specialist_Kimono_Diamonds_Red 10030
#define Specialist_Emerald_Web         10033
#define Specialist_Orange_White        10034
#define Specialist_DDpat_Green_Camo    10035
#define Specialist_Webs_Red            10061
#define Specialist_Forest_Brown        10062
#define Specialist_Fade                10063
#define Specialist_Winterhex           10064

// Hydra
#define Hydra_Black_Green              10057
#define Hydra_Green_Leather_Mesh_Brass 10058
#define Hydra_SnakeSkin_Brass          10059
#define Hydra_Case_Hardened            10060

enum Models : int
{
	Glove_Default = 0,
	Glove_HardKnuckle, // CT
	Glove_Fingerless, // TT
	Glove_BloodHound,
	Glove_Sporty,
	Glove_Slick,
	Glove_HandWrap,
	Glove_Motorcycle,
	Glove_Specialist,
	Glove_Hydra
};

enum Skins : int
{
	Skin_Default = 0,

	Skin_BloodHound_Black_Silver,
	Skin_BloodHound_SnakeSkin_Brass,
	Skin_BloodHound_Metallic,
	Skin_BloodHound_Querrilla,

	Skin_Sporty_Light_Blue,
	Skin_Sporty_Military,
	Skin_Sporty_Purple,
	Skin_Sporty_Green,
	Skin_Sporty_Poison_Frog_Blue_White,
	Skin_Sporty_Poison_Frog_Red_Green,
	Skin_Sporty_Black_Webbing_Yellow,
	Skin_Sporty_Blue_Pink,

	Skin_Slick_Black,
	Skin_Slick_Military,
	Skin_Slick_Red,
	Skin_Slick_SnakeSkin_Yellow,
	Skin_Slick_SnakeSkin_White,
	Skin_Slick_Plaid_Purple,
	Skin_Slick_Stitched_Black_Orange,
	Skin_Slick_Stitched_Green_Grey,

	Skin_HandWrap_Leathery,
	Skin_HandWrap_Camo_Grey,
	Skin_HandWrap_Red_Slaughter,
	Skin_HandWrap_Fabric_Orange_Camo,
	Skin_HandWrap_Leathery_Fabric_Blue_Skulls,
	Skin_HandWrap_Leathery_Fabric_Blue,
	Skin_HandWrap_Leathery_Ducttape,
	Skin_HandWrap_Leathery_Fabric_Green_Camo,

	Skin_Motorcycle_Basic_Black,
	Skin_Motorcycle_Mint_Triangle,
	Skin_Motorcycle_Mono_Boom,
	Skin_Motorcycle_Triangle_Blue,
	Skin_Motorcycle_Choco_Boom,
	Skin_Motorcycle_Basic_Green_Orange,
	Skin_Motorcycle_Yellow_Camo,
	Skin_Motorcycle_Trigrid_Blue,

	Skin_Specialist_Kimono_Diamonds_Red,
	Skin_Specialist_Emerald_Web,
	Skin_Specialist_Orange_White,
	Skin_Specialist_DDpat_Green_Camo,
	Skin_Specialist_Webs_Red,
	Skin_Specialist_Forest_Brown,
	Skin_Specialist_Fade,
	Skin_Specialist_Winterhex,

	Skin_Hydra_Black_Green,
	Skin_Hydra_Green_Leather_Mesh_Brass,
	Skin_Hydra_SnakeSkin_Brass,
	Skin_Hydra_Case_Hardened
};

void GloveChanger()
{
	//player_info_t localPlayerInfo;
	//if (!I::Engine->GetPlayerInfo(I::Engine->GetLocalPlayer(), &localPlayerInfo)) return;

	DWORD* hMyWearables = (DWORD*)((size_t)G::LocalPlayer + offsets.m_hMyWearables);

	if (!I::ClientEntList->GetClientEntityFromHandle((DWORD)hMyWearables[0]))
	{
		static ClientClass* pClass;

		if (!pClass)
		{
			pClass = I::Client->GetAllClasses();

			while (strcmp(pClass->m_pNetworkName, xs("CEconWearable")))
				pClass = pClass->m_pNext;
		}

		int iEntry = I::ClientEntList->GetHighestEntityIndex() + 1;
		int iSerial = rand() % 0x1000;

		pClass->m_pCreateFn(iEntry, iSerial);

		//static auto set_abs_origin_addr = U::FindPattern(xs("client_panorama.dll"), xs("55 8B EC 83 E4 F8 51 53 56 57 8B F1"));
		//const auto set_abs_origin_fn = reinterpret_cast<void(__thiscall*)(void*, const std::array<float, 3>&)>(set_abs_origin_addr);
		//static constexpr std::array<float, 3> new_pos = { 10000.f, 10000.f, 10000.f };
		//set_abs_origin_fn(new_glove, new_pos);

		hMyWearables[0] = iEntry | iSerial << 16;

		CBaseEntity* new_glove = I::ClientEntList->GetClientEntity(iEntry);

		if (new_glove)
		{
			//new_glove->SetModelIndexVirtual(-1);

			static int ModelNameIndex;
			static int ModelIndex;
			static int PaintKitIndex;

			static int model;
			static int old_model;
			static int skin;
			static int old_skin;

			static int wear;
			static int seed;

			if (Opts.Misc.Changer.Skins.SettingsForTeams)
			{
				if (G::LocalPlayer->GetTeam() == 3) // if ct
				{
					model = Opts.Misc.Changer.Skins.Gloves[0].ModelIndex;
					skin = Opts.Misc.Changer.Skins.Gloves[0].SkinIndex;
					wear = Opts.Misc.Changer.Skins.Gloves[0].Wear;
					seed = Opts.Misc.Changer.Skins.Gloves[0].Seed;
				}
				else // if tt
				{
					model = Opts.Misc.Changer.Skins.Gloves[1].ModelIndex;
					skin = Opts.Misc.Changer.Skins.Gloves[1].SkinIndex;
					wear = Opts.Misc.Changer.Skins.Gloves[1].Wear;
					seed = Opts.Misc.Changer.Skins.Gloves[1].Seed;
				}
			}
			else
			{
				model = Opts.Misc.Changer.Skins.Gloves[2].ModelIndex;
				skin = Opts.Misc.Changer.Skins.Gloves[2].SkinIndex;
				wear = Opts.Misc.Changer.Skins.Gloves[2].Wear;
				seed = Opts.Misc.Changer.Skins.Gloves[2].Seed;
			}

			switch (model)
			{
			case Glove_Default: { return; }
			case Glove_HardKnuckle: { ModelNameIndex = I::ModelInfo->GetModelIndex(GLOVE_VMODEL_CT.c_str()); ModelIndex = GLOVE_CT; break; }
			case Glove_Fingerless: { ModelNameIndex = I::ModelInfo->GetModelIndex(GLOVE_VMODEL_T.c_str()); ModelIndex = GLOVE_T; break; }
			case Glove_BloodHound: { ModelNameIndex = I::ModelInfo->GetModelIndex(GLOVE_VMODEL_BLOODHOUND.c_str()); ModelIndex = GLOVE_BLOODHOUND; break; }
			case Glove_Sporty: {  ModelNameIndex = I::ModelInfo->GetModelIndex(GLOVE_VMODEL_SPORTY.c_str()); ModelIndex = GLOVE_SPORTY; break; }
			case Glove_Slick: { ModelNameIndex = I::ModelInfo->GetModelIndex(GLOVE_VMODEL_SLICK.c_str()); ModelIndex = GLOVE_SLICK; break; }
			case Glove_HandWrap: { ModelNameIndex = I::ModelInfo->GetModelIndex(GLOVE_VMODEL_HANDWRAP.c_str()); ModelIndex = GLOVE_HANDWRAP; break; }
			case Glove_Motorcycle: { ModelNameIndex = I::ModelInfo->GetModelIndex(GLOVE_VMODEL_MOTOCYCLE.c_str()); ModelIndex = GLOVE_MOTOCYCLE; break; }
			case Glove_Specialist: { ModelNameIndex = I::ModelInfo->GetModelIndex(GLOVE_VMODEL_SPECIALIST.c_str()); ModelIndex = GLOVE_SPECIALIST; break; }
			case Glove_Hydra: { ModelNameIndex = I::ModelInfo->GetModelIndex(GLOVE_VMODEL_HYDRA.c_str()); ModelIndex = GLOVE_HYDRA; break; }

			default: return;
			}

			switch (skin)
			{
			case Skin_Default: { PaintKitIndex = 0; break; }

			case Skin_BloodHound_Black_Silver: { PaintKitIndex = BloodHound_Black_Silver; break; }
			case Skin_BloodHound_SnakeSkin_Brass: { PaintKitIndex = BloodHound_SnakeSkin_Brass; break; }
			case Skin_BloodHound_Metallic: { PaintKitIndex = BloodHound_Metallic; break; }
			case Skin_BloodHound_Querrilla: { PaintKitIndex = BloodHound_Querrilla; break; }

			case Skin_Sporty_Light_Blue: { PaintKitIndex = Sporty_Light_Blue; break; }
			case Skin_Sporty_Military: { PaintKitIndex = Sporty_Military; break; }
			case Skin_Sporty_Purple: { PaintKitIndex = Sporty_Purple; break; }
			case Skin_Sporty_Green: { PaintKitIndex = Sporty_Green; break; }
			case Skin_Sporty_Poison_Frog_Blue_White: { PaintKitIndex = Sporty_Poison_Frog_Blue_White; break; }
			case Skin_Sporty_Poison_Frog_Red_Green: { PaintKitIndex = Sporty_Poison_Frog_Red_Green; break; }
			case Skin_Sporty_Black_Webbing_Yellow: { PaintKitIndex = Sporty_Black_Webbing_Yellow; break; }
			case Skin_Sporty_Blue_Pink: { PaintKitIndex = Sporty_Blue_Pink; break; }

			case Skin_Slick_Black: { PaintKitIndex = Slick_Black; break; }
			case Skin_Slick_Military: { PaintKitIndex = Slick_Military; break; }
			case Skin_Slick_Red: { PaintKitIndex = Slick_Red; break; }
			case Skin_Slick_SnakeSkin_Yellow: { PaintKitIndex = Slick_SnakeSkin_Yellow; break; }
			case Skin_Slick_SnakeSkin_White: { PaintKitIndex = Slick_SnakeSkin_White; break; }
			case Skin_Slick_Plaid_Purple: { PaintKitIndex = Slick_Plaid_Purple; break; }
			case Skin_Slick_Stitched_Black_Orange: { PaintKitIndex = Slick_Stitched_Black_Orange; break; }
			case Skin_Slick_Stitched_Green_Grey: { PaintKitIndex = Slick_Stitched_Green_Grey; break; }

			case Skin_HandWrap_Leathery: { PaintKitIndex = HandWrap_Leathery; break; }
			case Skin_HandWrap_Camo_Grey: { PaintKitIndex = HandWrap_Camo_Grey; break; }
			case Skin_HandWrap_Red_Slaughter: { PaintKitIndex = HandWrap_Red_Slaughter; break; }
			case Skin_HandWrap_Fabric_Orange_Camo: { PaintKitIndex = HandWrap_Fabric_Orange_Camo; break; }
			case Skin_HandWrap_Leathery_Fabric_Blue_Skulls: { PaintKitIndex = HandWrap_Leathery_Fabric_Blue_Skulls; break; }
			case Skin_HandWrap_Leathery_Fabric_Blue: { PaintKitIndex = HandWrap_Leathery_Fabric_Blue; break; }
			case Skin_HandWrap_Leathery_Ducttape: { PaintKitIndex = HandWrap_Leathery_Ducttape; break; }
			case Skin_HandWrap_Leathery_Fabric_Green_Camo: { PaintKitIndex = HandWrap_Leathery_Fabric_Green_Camo; break; }

			case Skin_Motorcycle_Basic_Black: { PaintKitIndex = Motorcycle_Basic_Black; break; }
			case Skin_Motorcycle_Mint_Triangle: { PaintKitIndex = Motorcycle_Mint_Triangle; break; }
			case Skin_Motorcycle_Mono_Boom: { PaintKitIndex = Motorcycle_Mono_Boom; break; }
			case Skin_Motorcycle_Triangle_Blue: { PaintKitIndex = Motorcycle_Triangle_Blue; break; }
			case Skin_Motorcycle_Choco_Boom: { PaintKitIndex = Motorcycle_Choco_Boom; break; }
			case Skin_Motorcycle_Basic_Green_Orange: { PaintKitIndex = Motorcycle_Basic_Green_Orange; break; }
			case Skin_Motorcycle_Yellow_Camo: { PaintKitIndex = Motorcycle_Yellow_Camo; break; }
			case Skin_Motorcycle_Trigrid_Blue: { PaintKitIndex = Motorcycle_Trigrid_Blue; break; }

			case Skin_Specialist_Kimono_Diamonds_Red: { PaintKitIndex = Specialist_Kimono_Diamonds_Red; break; }
			case Skin_Specialist_Emerald_Web: { PaintKitIndex = Specialist_Emerald_Web; break; }
			case Skin_Specialist_Orange_White: { PaintKitIndex = Specialist_Orange_White; break; }
			case Skin_Specialist_DDpat_Green_Camo: { PaintKitIndex = Specialist_DDpat_Green_Camo; break; }
			case Skin_Specialist_Webs_Red: { PaintKitIndex = Specialist_Webs_Red; break; }
			case Skin_Specialist_Forest_Brown: { PaintKitIndex = Specialist_Forest_Brown; break; }
			case Skin_Specialist_Fade: { PaintKitIndex = Specialist_Fade; break; }
			case Skin_Specialist_Winterhex: { PaintKitIndex = Specialist_Winterhex; break; }

			case Skin_Hydra_Black_Green: { PaintKitIndex = Hydra_Black_Green; break; }
			case Skin_Hydra_Green_Leather_Mesh_Brass: { PaintKitIndex = Hydra_Green_Leather_Mesh_Brass; break; }
			case Skin_Hydra_SnakeSkin_Brass: { PaintKitIndex = Hydra_SnakeSkin_Brass; break; }
			case Skin_Hydra_Case_Hardened: { PaintKitIndex = Hydra_Case_Hardened; break; }

			default: return;
			}

			*(int*)((DWORD)new_glove + offsets.m_iItemIDHigh) = -1;
			*(int*)((DWORD)new_glove + offsets.m_iEntityQuality) = 0;
			//*(int*)((DWORD)new_glove + offsets.m_iAccountID) = localPlayerInfo.xuidlow;
			*(float*)((DWORD)new_glove + offsets.m_flFallbackWear) = wear + 0.0000000001f;
			*(int*)((DWORD)new_glove + offsets.m_nFallbackSeed) = seed;
			*(int*)((DWORD)new_glove + offsets.m_nFallbackPaintKit) = PaintKitIndex;

			*(int*)((DWORD)new_glove + offsets.m_iItemDefinitionIndex) = ModelIndex;
			new_glove->SetModelIndexVirtual(ModelNameIndex);
			((IClientEntity*)new_glove)->PreDataUpdate(DATA_UPDATE_CREATED);
		}
	}
}