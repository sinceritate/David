#pragma once

namespace F
{
	extern HFont ESP;
	extern HFont MenuCon;
	extern HFont Panel;
	extern HFont HitMarker;
	extern HFont Watermark;
}

namespace D
{
	extern void SetupFonts();
	extern void DrawString(HFont font, int x, int y, Color Color, DWORD alignment, const char* msg, ...);
	extern void DrawLine(int x0, int y0, int x1, int y1, Color pColor);
	extern void DrawCircle3D(Vector position, float points, float radius, Color Color);
	extern bool ScreenTransform(const Vector& point, Vector& screen);
	extern bool WorldToScreen(const Vector& origin, Vector& screen);
}
