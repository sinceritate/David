#include "Cheat.h"

void inline M::SinCos(float radians, float* sine, float* cosine)
{
	*sine = sin(radians);
	*cosine = cos(radians);
}

inline Vector M::ExtrapolateTick(Vector p0, Vector v0)
{
	return p0 + (v0 * I::Globals->interval_per_tick);
}

FORCEINLINE float M::DotProduct(const Vector& a, const Vector& b)
{
	return (a.x * b.x + a.y * b.y + a.z * b.z);
}

void M::AngleVectors(const Vector &angles, Vector *forward)
{
	//Assert(s_bMathlibInitialized);
	//Assert(forward);

	float	sp, sy, cp, cy;

	//sy = sin(DEG2RAD(angles[1]));
	//cy = cos(DEG2RAD(angles[1]));
	//
	//sp = sin(DEG2RAD(angles[0]));
	//cp = cos(DEG2RAD(angles[0]));

	M::SinCos(DEG2RAD(angles[YAW]), &sy, &cy);
	M::SinCos(DEG2RAD(angles[PITCH]), &sp, &cp);

	forward->x = cp * cy;
	forward->y = cp * sy;
	forward->z = -sp;
}

void M::AngleVectors(const QAngle& angles, Vector* forward)
{
	float sp, sy, cp, cy;

	M::SinCos(DEG2RAD(angles[PITCH]), &sp, &cp);
	M::SinCos(DEG2RAD(angles[YAW]), &sy, &cy);

	forward->x = cp * cy;
	forward->y = cp * sy;
	forward->z = -sp;
}

void M::VectorAngles(const Vector& forward, QAngle& angles)
{
	if (forward[0] == 0.0f && forward[1] == 0.0f)
	{
		angles[0] = (forward[2] > 0.0f) ? 270.0f : 90.0f;
		angles[1] = 0.0f;
	}
	else
	{
		angles[0] = atan2(-forward[2], forward.Length2D()) * -180 / M_PI;
		angles[1] = atan2(forward[1], forward[0]) * 180 / M_PI;

		if (angles[1] > 90)
		{
			angles[1] -= 180;
		}		
		else if (angles[1] < 90)
		{
			angles[1] += 180;
		}		
		else if (angles[1] == 90)
		{
			angles[1] = 0;
		}	
	}

	angles[2] = 0.0f;
}

QAngle M::CalcAngle(Vector src, Vector dst)
{
	QAngle angles;
	Vector delta = src - dst;
	VectorAngles(delta, angles);
	delta.Normalize();
	return angles;
}

float M::GetFov(const QAngle& viewAngle, const QAngle& aimAngle)
{
	Vector ang, Aim;

	M::AngleVectors(viewAngle, &Aim);
	M::AngleVectors(aimAngle, &ang);

	return RAD2DEG(acos(Aim.Dot(ang) / Aim.LengthSqr()));
	// return Aim.LengthSqr();
	//DEG2RAD(RAD2DEG(acos(Aim.Dot(ang) / Aim.LengthSqr())));
}

void M::angleVectors(const QAngle& angles, Vector& forward)
{
	Assert(s_bMathlibInitialized);
	Assert(forward);

	float sp, sy, cp, cy;

	sy = sin(DEG2RAD(angles[1]));
	cy = cos(DEG2RAD(angles[1]));

	sp = sin(DEG2RAD(angles[0]));
	cp = cos(DEG2RAD(angles[0]));

	forward.x = cp * cy;
	forward.y = cp * sy;
	forward.z = -sp;
}

void M::VectorTransform(Vector& in1, matrix3x4_t& in2, Vector& out)
{
	out[0] = in1.Dot(in2[0]) + in2[0][3];
	out[1] = in1.Dot(in2[1]) + in2[1][3];
	out[2] = in1.Dot(in2[2]) + in2[2][3];
	//out.x = in1.Dot( in2.m_flMatVal[ 0 ] ) + in2.m_flMatVal[ 0 ][ 3 ];
	//out.y = in1.Dot( in2.m_flMatVal[ 1 ] ) + in2.m_flMatVal[ 1 ][ 3 ];
	//out.z = in1.Dot( in2.m_flMatVal[ 2 ] ) + in2.m_flMatVal[ 2 ][ 3 ];
}

void M::VectorSubtract(const Vector& a, const Vector& b, Vector& c)
{
	c.x = a.x - b.x;
	c.y = a.y - b.y;
	c.z = a.z - b.z;
}

void M::NormalizeNum(Vector &vIn, Vector &vOut)
{
	float flLen = vIn.Length();
	if (flLen == 0) {
		vOut.Init(0, 0, 1);
		return;
	}
	flLen = 1 / flLen;
	vOut.Init(vIn.x * flLen, vIn.y * flLen, vIn.z * flLen);
}

float M::NormalizeYaw(float yaw)
{
	if (yaw > 180)
	{
		yaw -= (round(yaw / 360) * 360.f);
	}
	else if (yaw < -180)
	{
		yaw += (round(yaw / 360) * -360.f);
	}
	return yaw;
}

float M::YawDistance(float firstangle, float secondangle)
{
	if ((firstangle < 0 && secondangle < 0) || (firstangle > 0 && secondangle > 0))
		return abs(firstangle - secondangle);
	if ((firstangle < 0 && secondangle > 0) || (firstangle > 0 && secondangle < 0))
		return abs(firstangle + secondangle);

	if (firstangle == 0) return abs(secondangle);
	if (secondangle == 0) return abs(firstangle);

	return 0;
}

QAngle M::NormalizeAngle(QAngle angle)
{
	while (angle.x > 89) angle.x -= 178;
	while (angle.x < -89) angle.x += 178;

	while (angle.y > 180) angle.y -= 360;
	while (angle.y < -180) angle.y += 360;

	angle.z = 0;

	return angle;
}

QAngle M::ClampAngle(QAngle angle)
{
	if (angle.x > 89) angle.x = 89;
	if (angle.x < -89) angle.x = -89;

	if (angle.y > 180) angle.x = 180;
	if (angle.y < -180) angle.x = -180;

	angle.z = 0;

	return angle;
}

Vector M::QAngleToVector(QAngle angle)
{
	return Vector(angle.x, angle.y, angle.z);
}

QAngle M::VectorToQAngle(Vector angle)
{
	return QAngle(angle.x, angle.y, angle.z);
}

float M::VectorDistance(Vector v1, Vector v2)
{
	return FASTSQRT(pow(v1.x - v2.x, 2) + pow(v1.y - v2.y, 2) + pow(v1.z - v2.z, 2));
}