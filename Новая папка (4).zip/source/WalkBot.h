#pragma once

class WalkBot
{
public:

private:

};