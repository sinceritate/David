#include "Cheat.h"

ViewModelViewFn oViewModelView;
float __stdcall Hooks::ViewModelView()
{
	if (Opts.Visuals.Players.Global.ScreenShotBypass && I::Engine->IsTakingScreenshot())
	{
		return oViewModelView();
	}

	if (Opts.Misc.Changer.View.bModelFOV && G::LocalPlayer && G::LocalPlayer->GetHealth() > 0)
	{
		return Opts.Misc.Changer.View.fModelFOV;
	}
	
	return oViewModelView();
}