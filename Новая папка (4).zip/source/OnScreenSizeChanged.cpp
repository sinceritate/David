#include "Cheat.h"

OnScreenSizeChangedFn oOnScreenSizeChanged;
void __stdcall Hooks::OnScreenSizeChanged(int oldWidth, int oldHeight)
{
	oOnScreenSizeChanged(I::Surface, oldWidth, oldHeight);

	//I::Engine->GetScreenSize(G::ScreenWidth, G::ScreenHeight);
	//G::ScreenWidthHalf = G::ScreenWidth / 2;
	//G::ScreenHeightHalf = G::ScreenHeight / 2;

	D::SetupFonts();
}