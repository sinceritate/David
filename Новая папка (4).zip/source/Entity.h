#pragma once

class CSWeaponInfo
{
public:

public:
	char _0x0000[20];
	__int32 max_clip;			//0x0014 
	char _0x0018[12];
	__int32 max_reserved_ammo;	//0x0024 
	char _0x0028[96];
	char* hud_name;				//0x0088 
	char* weapon_name;			//0x008C 
	char _0x0090[60];
	__int32 m_WeaponType;				//0x00CC 
	__int32 price;				//0x00D0 
	__int32 reward;				//0x00D4 
	char _0x00D8[20];
	BYTE full_auto;				//0x00EC 
	char _0x00ED[3];
	__int32 m_Damage;				//0x00F0 
	float m_ArmorRatio;			//0x00F4 
	__int32 bullets;			//0x00F8 
	float m_Penetration;			//0x00FC 
	char _0x0100[8];
	float m_Range;				//0x0108 
	float m_RangeModifier;		//0x010C 
	char _0x0110[16];
	BYTE m_HasSilencer;				//0x0120 
	char _0x0121[15];
	float max_speed;			//0x0130 
	float max_speed_alt;		//0x0134 
	char _0x0138[76];
	__int32 recoil_seed;		//0x0184 
	char _0x0188[32];
};

class CBaseCombatWeapon
{
public:
	char __pad[0x64];
	int index;
	float& GetNextPrimaryAttack();
	int* GetXUIDLow();
	int* GetXUIDHigh();
	bool CanFire();
	void preDataUpdate(int updateType);
	int* GetEntityQuality();
	int* GetAccountID();
	int* GetItemIDHigh();
	short* GetItemDefinitionIndex();
	int* GetFallbackPaintKit();
	int* GetFallbackStatTrak();
	float* GetFallbackWear();
	int* GetFallbackSeed();
	bool IsEmpty();
	int GetAmmo();
	bool IsReloading();
	std::string GetWeaponName();
	int GetAimIndex();
	//void release();
	//void setDestroyedOnRecreateEntities();

	bool IsGun();
	bool IsSniper();
	bool IsPistol();
	bool IsGrenade();
	bool IsKnife();
	float GetInaccuracy();
	float GetWeaponSpread();
	int GetType();
	bool IsFiredWeaponType();

	CSWeaponInfo* GetCSWpnData();

	int* GetItemIDLow();
	int* ModelIndex();
	int* ViewModelIndex();
	HANDLE m_hWeaponWorldModel();
	char* GetCustomName();
	CSWeaponInfo* get_full_info();
};

class CBaseAnimState
{
public:
	void* pThis;
	char pad2[91];
	void* pBaseEntity; //0x60
	void* pActiveWeapon; //0x64
	void* pLastActiveWeapon; //0x68
	float m_flLastClientSideAnimationUpdateTime; //0x6C
	int m_iLastClientSideAnimationUpdateFramecount; //0x70
	float m_flEyePitch; //0x74
	float m_flEyeYaw; //0x78
	float m_flPitch; //0x7C
	float m_flGoalFeetYaw; //0x80
	float m_flCurrentFeetYaw; //0x84
	float m_flCurrentTorsoYaw; //0x88
	float m_flUnknownVelocityLean; //0x8C //changes when moving/jumping/hitting ground
	float m_flLeanAmount; //0x90
	char pad4[4]; //NaN
	float m_flFeetCycle; //0x98 0 to 1
	float m_flFeetYawRate; //0x9C 0 to 1
	float m_fUnknown2;
	float m_fDuckAmount; //0xA4
	float m_fLandingDuckAdditiveSomething; //0xA8
	float m_fUnknown3; //0xAC
	Vector m_vOrigin; //0xB0, 0xB4, 0xB8
	Vector m_vLastOrigin; //0xBC, 0xC0, 0xC4
	float m_vVelocityX; //0xC8
	float m_vVelocityY; //0xCC
	char pad5[4];
	float m_flUnknownFloat1; //0xD4 Affected by movement and direction
	char pad6[8];
	float m_flUnknownFloat2; //0xE0 //from -1 to 1 when moving and affected by direction
	float m_flUnknownFloat3; //0xE4 //from -1 to 1 when moving and affected by direction
	float m_unknown; //0xE8
	float speed_2d; //0xEC
	float flUpVelocity; //0xF0
	float m_flSpeedNormalized; //0xF4 //from 0 to 1
	float m_flFeetSpeedForwardsOrSideWays; //0xF8 //from 0 to 2. something  is 1 when walking, 2.something when running, 0.653 when crouch walking
	float m_flFeetSpeedUnknownForwardOrSideways; //0xFC //from 0 to 3. something
	float m_flTimeSinceStartedMoving; //0x100
	float m_flTimeSinceStoppedMoving; //0x104
	unsigned char m_bOnGround; //0x108
	unsigned char m_bInHitGroundAnimation; //0x109
	char pad7[10];
	float m_flLastOriginZ; //0x114
	float m_flHeadHeightOrOffsetFromHittingGroundAnimation; //0x118 from 0 to 1, is 1 when standing
	float m_flStopToFullRunningFraction; //0x11C from 0 to 1, doesnt change when walking or crouching, only running
	char pad8[4]; //NaN
	float m_flUnknownFraction; //0x124 affected while jumping and running, or when just jumping, 0 to 1
	char pad9[4]; //NaN
	float m_flUnknown3;
	char pad10[528];
};

class CAnimationLayer
{
public:
	float m_flLayerAnimtime; //0
	float m_flLayerFadeOuttime;
	float m_flBlendIn;
	float m_flBlendOut;
	int Unknown1;
	int m_nOrder; //20
	int m_nSequence; //24
	float m_flPrevCycle;
	float m_flWeight; //32
	float m_flWeightDeltaRate;
	float m_flPlaybackRate;
	float m_flCycle; //44
	CBaseEntity *m_pOwner; //48
	int	m_nInvalidatePhysicsBits;
};

class CBaseAnimating
{
public:
	model_t* GetModel();
	void SetBoneMatrix(matrix3x4_t* boneMatrix);
	void GetDirectBoneMatrix(matrix3x4_t* boneMatrix);
};

class CBaseEntity : public IClientUnknown
{
public:
	char __pad[0x64];
	int index;
	int GetHealth();
	int GetTeam();
	int GetFlags();
	int GetTickBase();
	int GetShotsFired();
	int GetMoveType();
	int GetHitboxSet();
	int GetArmor();
	int GetIndex();
	bool GetAlive();
	void ResetAnimationState(CBaseAnimState *state);
	float m_flSpawnTime();
	bool GetDormant();
	bool GetImmune();
	int* GetWeapons();

	Vector GetMins();
	Vector GetMaxs();
	QAngle GetPunchAngles();

	bool IsValid();
	bool IsDefusing();
	bool* IsSpotted();
	bool IsEnemy();
	bool IsVisible(int Bone);
	bool HasHelmet();
	bool IsFlashed();
	bool IsScoped();
	float GetFlashDuration();
	float GetBombTimer();
	DWORD GetObserverTargetHandle();
	QAngle GetViewPunch();
	QAngle GetEyeAngles();
	Vector GetOrigin();
	Vector GetEyePosition();
	Vector GetBonePosition(int iBone);
	Vector GetBonePositionSimple(int iBone);
	Vector GetVelocity();
	ICollideable* GetCollideable();
	player_info_t GetPlayerInfo();
	model_t* GetModel();
	std::string GetName();
	CBaseCombatWeapon* GetWeapon();
	ClientClass* GetClientClass();
	Vector GetVecViewOffset();
	matrix3x4_t& m_rgflCoordinateFrame();
	Vector& GetAbsOrigin();
	void SetAbsOrigin(Vector ArgOrigin);

	CUserCmd*& m_pCurrentCommand();

	CBaseAnimState* GetAnimState();
	//void SetAnimState(CBaseAnimState* state);
	matrix3x4_t GetBoneMatrix(int BoneID);
	float GetSimTime();

	CAnimationLayer& GetAnimOverlay(int Index);
	void SetAnimOverlay(int Index, CAnimationLayer layer);
	CAnimationLayer* GetAnimOverlays();
	int GetNumAnimOverlays();
	bool& GetClientSideAnimation();
	std::array<float, 24>& get_ragdoll_pos();
	Vector* GetEyeAnglesPointer();

	template< class T >
	inline T GetFieldValue(int offset);

	float GetSimulationTime();
	void UpdateClientSideAnimation();

	float& ModulateFlashAlpha();
	int GetWearables();
	void SetModelIndexVirtual(int index);
	//void PreDataUpdate(int updateType);
	Vector* GetEyeAnglesPtr();
	bool SetupBones(matrix3x4_t* pBoneToWorldOut, int nMaxBones, int boneMask, float currentTime);
	void SetEyeAngles(Vector angles);

	bool  BombTicking();
	float BombTimerLength();
	float BombDefuseLength();
	float BombDefuseCountdown();

	Vector GetPredicted(Vector p0);

	float GetLBY();

	QAngle* GetVAngles();

	void SetAngle2(Vector wantedang);
	Vector& GetAbsAngles();
	int DrawModel(int flags, uint8_t alpha);
	IClientRenderable* GetRenderable();

	int GetMoney();

	int GetIntByOffset(DWORD offest);
	float GetFloatByOffset(DWORD offest);
	bool GetBoolByOffset(DWORD offest);

	void SetIntByOffset(DWORD offest, int value);
	void SetFloatByOffset(DWORD offest, float value);
	void SetBoolByOffset(DWORD offest, bool value);

	unsigned long* hGetWeapon() { return (unsigned long*)((uintptr_t)this + 0x2DF8); }
};

class CHudTexture
{
public:
	char type[64]; //0x0000
	char subtype[64]; //0x0040
	char unknowndata00[2]; //0x0080
	char charinFont; //0x0082
	char unknowndata01[1]; //0x0083
};//Size=0x00AC

class INetworkStringTable;

typedef void(*pfnStringChanged)(void* object, INetworkStringTable* stringTable, int stringNumber, char const* newString, void const* newData);

class INetworkStringTable
{
public:

	virtual                    ~INetworkStringTable(void) {};

	// Table Info
	virtual const char* GetTableName(void) const = 0;
	virtual int            GetTableId(void) const = 0;
	virtual int                GetNumStrings(void) const = 0;
	virtual int                GetMaxStrings(void) const = 0;
	virtual int                GetEntryBits(void) const = 0;

	// Networking
	virtual void            SetTick(int tick) = 0;
	virtual bool            ChangedSinceTick(int tick) const = 0;

	// Accessors (length -1 means don't change user data if string already exits)
	virtual int                AddString(bool bIsServer, const char* value, int length = -1, const void* userdata = 0) = 0;

	virtual const char* GetString(int stringNumber) = 0;
	virtual void            SetStringUserData(int stringNumber, int length, const void* userdata) = 0;
	virtual const void* GetStringUserData(int stringNumber, int* length) = 0;
	virtual int                FindStringIndex(char const* string) = 0; // returns INVALID_STRING_INDEX if not found

	// Callbacks
	virtual void            SetStringChangedCallback(void* object, pfnStringChanged changeFunc) = 0;
};