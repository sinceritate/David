#include "SDK.h"
#include "Cvars.h"

#define GETFLOAT					12
#define GETMODEL					8
#define GETCLIENTCLASS				2
#define GETABSORIGIN				10
#define UPDATECLIENTSIDEANIMATION	223
#define PREDATAUPDATE				6
#define SETVIRTUALINDEX				75
#define GETINACCURACY				482
#define GETWEAPONSPREAD				452
#define GETFULLINFO					460 // cs_weapon_data
#define DRAWMODEL					9

float ConVar::GetFloat()
{
	return U::GetVFunc<float(__thiscall*)(void*)>(this, GETFLOAT)(this);
}

model_t* CBaseAnimating::GetModel()
{
	void* pRenderable = reinterpret_cast<void*>(uintptr_t(this) + 0x4);
	return U::GetVFunc<model_t*(__thiscall*)(void*)>(pRenderable, GETMODEL)(pRenderable);
}

void CBaseAnimating::SetBoneMatrix(matrix3x4_t* boneMatrix)
{
	const auto model = this->GetModel();
	if (!model)
		return;

	matrix3x4_t* matrix = *(matrix3x4_t**)((DWORD)this + 9880);
	studiohdr_t *hdr = I::ModelInfo->GetStudioModel(model);
	if (!hdr)
		return;
	int size = hdr->numbones;
	if (matrix) {
		for (int i = 0; i < size; i++)
			memcpy(matrix + i, boneMatrix + i, sizeof(matrix3x4_t));
	}
}

void CBaseAnimating::GetDirectBoneMatrix(matrix3x4_t* boneMatrix)
{
	const auto model = this->GetModel();
	if (!model)
		return;

	matrix3x4_t* matrix = *(matrix3x4_t**)((DWORD)this + 9880);
	studiohdr_t *hdr = I::ModelInfo->GetStudioModel(model);
	if (!hdr)
		return;
	int size = hdr->numbones;
	if (matrix) {
		for (int i = 0; i < size; i++)
			memcpy(boneMatrix + i, matrix + i, sizeof(matrix3x4_t));
	}
}

int CBaseEntity::GetHealth()
{
	return *(int*)((DWORD)this + offsets.m_iHealth);
}

int CBaseEntity::GetTeam()
{
	return *(int*)((DWORD)this + offsets.m_iTeamNum);
}

int CBaseEntity::GetFlags()
{
	return *(int*)((DWORD)this + offsets.m_fFlags);
}

int CBaseEntity::GetTickBase()
{
	return *(int*)((DWORD)this + offsets.m_nTickBase);
}

int CBaseEntity::GetShotsFired()
{
	return *(int*)((DWORD)this + offsets.m_iShotsFired);
}

int CBaseEntity::GetMoveType()
{
	return *(int*)((DWORD)this + offsets.m_nMoveType);
}

int CBaseEntity::GetHitboxSet()
{
	return *(int*)((DWORD)this + offsets.m_nHitboxSet);
}

int CBaseEntity::GetArmor()
{
	return *(int*)((DWORD)this + offsets.m_ArmorValue);
}

float CBaseEntity::GetBombTimer()
{
	float bombTime = *(float*)((DWORD)this + offsets.m_flC4Blow);
	float returnValue = bombTime - I::Globals->curtime;
	return (returnValue < 0) ? 0.f : returnValue;
}

float CBaseEntity::GetFlashDuration()
{
	return *(float*)((DWORD)this + offsets.m_flFlashDuration);
}

bool CBaseEntity::IsFlashed()
{
	return GetFlashDuration() > 1.f ? true : false;
}

bool CBaseEntity::GetAlive()
{
	return (bool)(*(int*)((DWORD)this + offsets.m_lifeState) == 0);
}

void CBaseEntity::ResetAnimationState(CBaseAnimState *state) {
	using ResetAnimState_t = void(__thiscall*)(CBaseAnimState*);
	static auto ResetAnimState = (ResetAnimState_t)U::FindPattern(("client_panorama.dll"), "56 6A 01 68 ? ? ? ? 8B F1");
	if (!ResetAnimState)
		return;

	ResetAnimState(state);
}

float CBaseEntity::m_flSpawnTime() {
	// 0xA360
	//static auto m_iAddonBits = NetvarSys::Get( ).GetOffset( "DT_CSPlayer", "m_iAddonBits" );
	//return *( float_t* )( ( uintptr_t )this + m_iAddonBits - 0x4 );
	return *(float*)((uintptr_t)this + 0xA360);
}

Vector CBaseEntity::GetMins() {
	return *(Vector*)((uintptr_t)this + offsets.m_vecMins);
}

Vector CBaseEntity::GetMaxs() {
	return *(Vector*)((uintptr_t)this + offsets.m_vecMaxs);
}

QAngle CBaseEntity::GetPunchAngles()
{
	return *(QAngle*)(uintptr_t(this) + offsets.m_aimPunchAngle);
}

bool CBaseEntity::GetDormant()
{
	return *(bool*)((DWORD)this + offsets.m_bDormant);
}

bool CBaseEntity::GetImmune()
{
	return *(bool*)((DWORD)this + offsets.m_bGunGameImmunity);
}

bool CBaseEntity::HasHelmet()
{
	return *(bool*)((DWORD)this + offsets.m_bHasHelmet);
}

model_t* CBaseEntity::GetModel()
{
	return *(model_t**)((DWORD)this + 0x6C);
}

bool CBaseEntity::IsEnemy()
{
	if (G::IsInDangerZone)
	{
		int team_stat_local = *(int*)((DWORD)G::LocalPlayer + offsets.m_nSurvivalTeam);
	
		if (team_stat_local == -1 || team_stat_local != *(int*)((DWORD)this + offsets.m_nSurvivalTeam))
			return true;
	
		return false;
	}

	return this->GetTeam() != G::LocalPlayer->GetTeam();
}

bool CBaseEntity::IsVisible(int Bone)
{
	Ray_t ray;
	ray.Init(G::LocalPlayer->GetEyePosition(), this->GetBonePosition(Bone));

	CTraceFilter filter;
	filter.pSkip = G::LocalPlayer;

	trace_t trace;

	I::EngineTrace->TraceRay(ray, PlayerVisibleMask, &filter, &trace);

	return (trace.m_pEnt == this && !trace.allsolid) ? true : false;
}

QAngle CBaseEntity::GetViewPunch()
{
	return *(QAngle*)((DWORD)this + offsets.m_viewPunchAngle);
}

QAngle CBaseEntity::GetEyeAngles()
{
	return *reinterpret_cast<QAngle*>(uintptr_t(this) + offsets.m_angEyeAngles);
}

Vector CBaseEntity::GetOrigin()
{
	return *(Vector*)((DWORD)this + offsets.m_vecOrigin);
}

Vector CBaseEntity::GetEyePosition()
{
	return(*(Vector*)((DWORD)this + offsets.m_vecOrigin) + *(Vector*)((DWORD)this + offsets.m_vecViewOffset));
}

Vector CBaseEntity::GetBonePosition(int iBone)
{
	model_t* model = this->GetModel();

	const char* model_name = model->Name;

	if (strstr(model_name, "bbs_93x_net_2016") || strstr(model_name, "kuristaja") || strstr(model_name, "voikanaa"))
	{
		if (iBone == BONE_HEAD)
			iBone = BONE_UPPER_CHEST;

		studiohdr_t* pStudioModel = I::ModelInfo->GetStudioModel(this->GetModel());
		if (pStudioModel)
		{
			mstudiobone_t* pBone = pStudioModel->pBone(iBone);
			for (int i = 0; !pBone || !(pBone->flags & 256) || pBone->parent == -1; ++i)
			{
				iBone = i;
				pBone = pStudioModel->pBone(iBone);
			}
		}
	}

	matrix3x4_t boneMatrixes[256];

	if (this->SetupBones(boneMatrixes, 256, 256, 0))
	{
		if (iBone == BONE_UPPER_HEAD)
		{
			matrix3x4_t boneMatrix = boneMatrixes[8];
			return Vector(boneMatrix.m_flMatVal[0][3], boneMatrix.m_flMatVal[1][3], this->GetOrigin().z + this->GetCollideable()->OBBMaxs().z - 1.15f);
		}
		else
		{
			matrix3x4_t boneMatrix = boneMatrixes[iBone];
			return Vector(boneMatrix.m_flMatVal[0][3], boneMatrix.m_flMatVal[1][3], boneMatrix.m_flMatVal[2][3]);
		}
	}

	else
		return Vector(0, 0, 0);
}

Vector CBaseEntity::GetBonePositionSimple(int iBone)
{
	matrix3x4_t boneMatrixes[256];

	if (this->SetupBones(boneMatrixes, 256, 256, 0))
	{
		if (iBone == BONE_UPPER_HEAD)
		{
			matrix3x4_t boneMatrix = boneMatrixes[8];
			return Vector(boneMatrix.m_flMatVal[0][3], boneMatrix.m_flMatVal[1][3], this->GetOrigin().z + this->GetCollideable()->OBBMaxs().z - 1.15f);
		}
		else
		{
			matrix3x4_t boneMatrix = boneMatrixes[iBone];
			return Vector(boneMatrix.m_flMatVal[0][3], boneMatrix.m_flMatVal[1][3], boneMatrix.m_flMatVal[2][3]);
		}
	}

	else
		return Vector(0, 0, 0);
}

bool CBaseEntity::SetupBones(matrix3x4_t* pBoneToWorldOut, int nMaxBones, int boneMask, float currentTime)
{
	__asm
	{
		mov edi, this
		lea ecx, dword ptr ds : [edi + 0x4]
		mov edx, dword ptr ds : [ecx]
		push currentTime
		push boneMask
		push nMaxBones
		push pBoneToWorldOut
		call dword ptr ds : [edx + 0x34]
	}
}

void CBaseEntity::SetEyeAngles(Vector angles)
{
	*reinterpret_cast<Vector*>(uintptr_t(this) + offsets.m_angEyeAngles) = angles;
}

Vector CBaseEntity::GetVelocity()
{
	return *(Vector*)((DWORD)this + offsets.m_vecVelocity);
}

ICollideable* CBaseEntity::GetCollideable()
{
	return (ICollideable*)((DWORD)this + offsets.m_CollisionGroup);
}

player_info_t CBaseEntity::GetPlayerInfo()
{
	player_info_t pinfo;
	I::Engine->GetPlayerInfo(this->index, &pinfo);
	return pinfo;
}

std::string CBaseEntity::GetName()
{
	return this->GetPlayerInfo().Name;
}

CBaseCombatWeapon* CBaseEntity::GetWeapon()
{
	DWORD weaponData = *(DWORD*)((DWORD)this + offsets.m_hActiveWeapon);
	return (CBaseCombatWeapon*)I::ClientEntList->GetClientEntityFromHandle(weaponData);
}

ClientClass* CBaseEntity::GetClientClass()
{
	void* pNetworkable = (void*)((DWORD)(this) + 0x8);
	return U::GetVFunc<ClientClass*(__thiscall*)(void*)>(pNetworkable, GETCLIENTCLASS)(pNetworkable);
}

Vector CBaseEntity::GetVecViewOffset()
{
	return *(Vector*)((DWORD)this + offsets.m_vecViewOffset);
}

matrix3x4_t& CBaseEntity::m_rgflCoordinateFrame()
{
	return *(matrix3x4_t*)((uintptr_t)this + offsets.m_CollisionGroup);
}

Vector& CBaseEntity::GetAbsOrigin()
{
	return U::GetVFunc<Vector&(__thiscall*)(void*)>(this, GETABSORIGIN)(this);
}

typedef void(__thiscall* TypeSetAbsOrigin)(CBaseEntity*, const Vector&);
void CBaseEntity::SetAbsOrigin(Vector ArgOrigin)
{
	static TypeSetAbsOrigin absOrigin = (TypeSetAbsOrigin)U::FindPattern(rxs("client_panorama.dll"), rxs("55 8B EC 83 E4 F8 51 53 56 57 8B F1 E8 ?? ??"));
	absOrigin(this, ArgOrigin);
}

CUserCmd*& CBaseEntity::m_pCurrentCommand() {
	static auto currentCommand = *(uint32_t*)(U::FindPattern(rxs("client_panorama.dll"), rxs("89 BE ? ? ? ? E8 ? ? ? ? 85 FF")) + 2);
	return *(CUserCmd**)((uintptr_t)this + currentCommand);
}

CBaseAnimState* CBaseEntity::GetAnimState()
{
	return *reinterpret_cast<CBaseAnimState**>(uintptr_t(this) + 0x3900);
}

//void CBaseEntity::SetAnimState(CBaseAnimState* state)
//{
//	*(uintptr_t(this) + 0x3900) = state;
//}

matrix3x4_t CBaseEntity::GetBoneMatrix(int BoneID)
{
	matrix3x4_t matrix;

	auto offset = *reinterpret_cast<uintptr_t*>(uintptr_t(this) + 0x26A8);
	if (offset)
		matrix = *reinterpret_cast<matrix3x4_t*>(offset + 0x30 * BoneID);

	return matrix;
}

float CBaseEntity::GetSimTime()
{
	return *reinterpret_cast<float*>(uintptr_t(this) + offsets.m_flSimulationTime);
}

CAnimationLayer& CBaseEntity::GetAnimOverlay(int Index)
{
	return (*(CAnimationLayer**)((DWORD)this + 0x2980))[Index];
}

void CBaseEntity::SetAnimOverlay(int Index, CAnimationLayer layer)
{
	(*(CAnimationLayer**)((DWORD)this + 0x2980))[Index] = layer;
}

CAnimationLayer* CBaseEntity::GetAnimOverlays()
{
	return *(CAnimationLayer**)((DWORD)this + 0x2980);
}

int CBaseEntity::GetNumAnimOverlays()
{
	return *(int*)((DWORD)this + 0x298C);
}

bool& CBaseEntity::GetClientSideAnimation()
{
	return *reinterpret_cast<bool*>((DWORD)this + offsets.m_bClientSideAnimation);
}

std::array<float, 24>& CBaseEntity::get_ragdoll_pos()
{
	return *reinterpret_cast<std::array<float, 24>*>((DWORD)this + offsets.m_ragPos);
}

Vector* CBaseEntity::GetEyeAnglesPointer()
{
	return reinterpret_cast<Vector*>((DWORD)this + offsets.m_angEyeAnglesX);
}

template< class T >
inline T CBaseEntity::GetFieldValue(int offset)
{
	return *(T*)((DWORD)this + offset);
}

float CBaseEntity::GetSimulationTime()
{
	return GetFieldValue< float >(offsets.m_flSimulationTime);
}

void CBaseEntity::UpdateClientSideAnimation()
{
	U::GetVFunc<void(__thiscall*)(void*)>(this, UPDATECLIENTSIDEANIMATION)(this);
}

float& CBaseCombatWeapon::GetNextPrimaryAttack()
{
	return *(float*)((DWORD)this + offsets.m_flNextPrimaryAttack);
}

int* CBaseCombatWeapon::GetXUIDLow()
{
	return (int*)((DWORD)this + offsets.m_OriginalOwnerXuidLow);
}

int* CBaseCombatWeapon::GetXUIDHigh()
{
	return (int*)((DWORD)this + offsets.m_OriginalOwnerXuidHigh);
}

bool CBaseCombatWeapon::CanFire()
{
	static decltype(this) stored_weapon = nullptr;
	static auto stored_tick = 0;
	if (stored_weapon != this || stored_tick >= G::LocalPlayer->GetTickBase()) {
		stored_weapon = this;
		stored_tick = G::LocalPlayer->GetTickBase();
		return false; //cannot shoot first tick after switch
	}

	if (GetAmmo() <= 0 || !G::LocalPlayer)
		return false;

	auto flServerTime = G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick;

	return GetNextPrimaryAttack() <= flServerTime;
}

void CBaseCombatWeapon::preDataUpdate(int updateType)
{
	PVOID pNetworkable = (PVOID)((DWORD)(this) + 0x8);
	return U::GetVFunc<void(__thiscall*)(void*, int)>(pNetworkable, PREDATAUPDATE)(pNetworkable, updateType);
}

int* CBaseCombatWeapon::GetEntityQuality()
{
	return (int*)((DWORD)this + offsets.m_iEntityQuality);
}

int* CBaseCombatWeapon::GetAccountID()
{
	return (int*)((DWORD)this + offsets.m_iAccountID);
}

int* CBaseCombatWeapon::GetItemIDLow()
{
	return (int*)((DWORD)this + offsets.m_iItemIDLow);
}

int* CBaseCombatWeapon::GetItemIDHigh()
{
	return (int*)((DWORD)this + offsets.m_iItemIDHigh);
}

short* CBaseCombatWeapon::GetItemDefinitionIndex()
{
	return ( short* ) ( (uintptr_t)this + offsets.m_iItemDefinitionIndex);
}

float& CBaseEntity::ModulateFlashAlpha()
{
	return *(float*)((DWORD)this + offsets.m_flFlashMaxAlpha);
}

int* CBaseCombatWeapon::GetFallbackPaintKit()
{
	return (int*)((DWORD)this + offsets.m_nFallbackPaintKit);
}

int* CBaseCombatWeapon::GetFallbackStatTrak()
{
	return (int*)((DWORD)this + offsets.m_nFallbackStatTrak);
}

float* CBaseCombatWeapon::GetFallbackWear()
{
	return (float*)((DWORD)this + offsets.m_flFallbackWear);
}

int* CBaseCombatWeapon::GetFallbackSeed()
{
	return (int*)((DWORD)this + offsets.m_nFallbackSeed);
}

DWORD CBaseEntity::GetObserverTargetHandle()
{
	return *(DWORD*)((DWORD)this + offsets.m_hObserverTarget);
}

bool CBaseEntity::IsValid()
{
	if (!this)
		return false;

	if (this->GetHealth() < 1)
		return false;

	if (this->GetDormant())
		return false;

	return true;
}

int CBaseEntity::GetIndex()
{
	return *reinterpret_cast<int*>(uintptr_t(this) + 0x64);
}

bool CBaseEntity::IsDefusing()
{
	return *(bool*)((DWORD)this + offsets.m_bIsDefusing);
}

bool* CBaseEntity::IsSpotted()
{
	return (bool*)((DWORD)this + offsets.m_bSpotted);
}

int CBaseEntity::GetWearables()
{
	return *(int*)((DWORD)this + offsets.m_hMyWearables);
}

void CBaseEntity::SetModelIndexVirtual(int index)
{
	typedef void(__thiscall * oSetModelIndex)(PVOID, int);
	return  U::GetVFunc<oSetModelIndex>(this, SETVIRTUALINDEX)(this, index);
}

//void CBaseEntity::PreDataUpdate(int updateType)
//{
//	PVOID pNetworkable = (PVOID)((DWORD)(this) + 0x8);
//	typedef void(__thiscall* OriginalFn)(PVOID, int);
//	return U::GetVFunc<OriginalFn>(pNetworkable, 6)(pNetworkable, updateType);
//}

Vector* CBaseEntity::GetEyeAnglesPtr()
{
	return reinterpret_cast<Vector*>((DWORD)this + offsets.m_angEyeAngles);
}

int* CBaseEntity::GetWeapons()
{
	return reinterpret_cast<int*>(uintptr_t(this) + offsets.m_hMyWeapons);
}

float CBaseCombatWeapon::GetInaccuracy()
{
	return U::GetVFunc<float(__thiscall*)(void*)>(this, GETINACCURACY)(this);
}

float CBaseCombatWeapon::GetWeaponSpread()
{
	return U::GetVFunc<float(__thiscall*)(void*)>(this, GETWEAPONSPREAD)(this);
}

int CBaseCombatWeapon::GetType()
{
	if (!this) return WT_INVALID;

	int id = *this->GetItemDefinitionIndex();

	if (id == WEAPON_DEAGLE
	|| id == WEAPON_P250
	|| id == WEAPON_USPS
	|| id == WEAPON_P2000
	|| id == WEAPON_GLOCK
	|| id == WEAPON_FIVESEVEN
	|| id == WEAPON_TEC9
	|| id == WEAPON_DUALBERETTA
	|| id == WEAPON_REVOLVER
	|| id == WEAPON_CZ75) return WT_PISTOLS;

	if (id == WEAPON_MP9
	|| id == WEAPON_MP7
	|| id == WEAPON_MP5SD
	|| id == WEAPON_UMP45
	|| id == WEAPON_BIZON
	|| id == WEAPON_P90
	|| id == WEAPON_MAC10) return WT_SUBMACHINEGUNS;

	if (id == WEAPON_AK47
	|| id == WEAPON_M4A4
	|| id == WEAPON_M4A1S
	|| id == WEAPON_GALIL
	|| id == WEAPON_FAMAS
	|| id == WEAPON_AUG
	|| id == WEAPON_SG553) return WT_RIFLERS;

	if (id == WEAPON_SCAR20
	|| id == WEAPON_G3SG1
	|| id == WEAPON_SSG08
	|| id == WEAPON_AWP) return WT_SNIPERS;

	if (id == WEAPON_SAWEDOFF
	|| id == WEAPON_XM1014
	|| id == WEAPON_MAG7
	|| id == WEAPON_NOVA) return WT_SHOTGUNS;

	if (id == WEAPON_M249
	|| id == WEAPON_NEGEV) return WT_MACHINEGUNS;

	if (id == WEAPON_HEGRENADE
	|| id == WEAPON_FLASHBANG
	|| id == WEAPON_DECOY
	|| id == WEAPON_SMOKEGRENADE
	|| id == WEAPON_INCGRENADE
	|| id == WEAPON_MOLOTOV) return WT_GRENADES;

	if (id == WEAPON_KNIFE_BAYONET
	|| id == WEAPON_KNIFE_CSS
	|| id == WEAPON_KNIFE_SURVIVAL_BOWIE
	|| id == WEAPON_KNIFE_BUTTERFLY
	|| id == WEAPON_KNIFE
	|| id == WEAPON_KNIFE_FALCHION
	|| id == WEAPON_KNIFE_FLIP
	|| id == WEAPON_KNIFE_GUT
	|| id == WEAPON_KNIFE_KARAMBIT
	|| id == WEAPON_KNIFE_M9_BAYONET
	|| id == WEAPON_KNIFE_PUSH
	|| id == WEAPON_KNIFE_TACTICAL
	|| id == WEAPON_KNIFE_T
	|| id == WEAPON_KNIFE_CORD
	|| id == WEAPON_KNIFE_CANIS
	|| id == WEAPON_KNIFE_URSUS
	|| id == WEAPON_KNIFE_GYPSY_JACKKNIFE
	|| id == WEAPON_KNIFE_OUTDOOR
	|| id == WEAPON_KNIFE_STILETTO
	|| id == WEAPON_KNIFE_WIDOWMAKER
	|| id == WEAPON_KNIFE_SKELETON) return WT_KNIFES;

	if (id == WEAPON_ZEUSX27
	|| id == WEAPON_C4) return WT_MISC;

	return WT_INVALID;
}

bool CBaseCombatWeapon::IsFiredWeaponType()
{
	if (!this) return false;

	int WType = this->GetType();

	switch (WType)
	{
	case WT_PISTOLS:
	case WT_SUBMACHINEGUNS:
	case WT_RIFLERS:
	case WT_SNIPERS:
	case WT_SHOTGUNS:
	case WT_MACHINEGUNS:
		return true;
	default:
		return false;
	}
}

bool CBaseEntity::BombTicking()
{
	return *(bool*)((DWORD)this + offsets.m_bBombTicking);
}

float CBaseEntity::BombTimerLength()
{
	return *(float*)((DWORD)this + offsets.m_flTimerLength);
}

float CBaseEntity::BombDefuseLength()
{
	return *(float*)((DWORD)this + offsets.m_flDefuseLength);
}

float CBaseEntity::BombDefuseCountdown()
{
	return *(float*)((DWORD)this + offsets.m_flDefuseCountDown);
}

bool CBaseCombatWeapon::IsEmpty()
{
	int clip = *(int*)((DWORD)this + offsets.m_iClip1);
	return clip == 0;
}

int CBaseCombatWeapon::GetAmmo()
{
	return *(int*)((DWORD)this + offsets.m_iClip1);
}

bool CBaseCombatWeapon::IsReloading()
{
	if ( !this ) return false;

	int type = GetType();

	if ( type == WT_INVALID || type == WT_GRENADES || type == WT_KNIFES || type == WT_MISC )
		return false;

	if ( !IsEmpty() )
		return false;

	return true;
}

std::string CBaseCombatWeapon::GetWeaponName()
{
	if ( !this ) return "";

	int id = *this->GetItemDefinitionIndex();

	if (id == WEAPON_DEAGLE)
		return xs("Deagle");
	else if (id == WEAPON_DUALBERETTA)
		return xs("Dual Berettas");
	else if (id == WEAPON_FIVESEVEN)
		return xs("Five-Seven");
	else if (id == WEAPON_GLOCK)
		return xs("Glock-18");
	else if (id == WEAPON_AK47)
		return xs("AK-47");
	else if (id == WEAPON_AUG)
		return xs("AUG");
	else if (id == WEAPON_AWP)
		return xs("AWP");
	else if (id == WEAPON_FAMAS)
		return xs("FAMAS");
	else if (id == WEAPON_G3SG1)
		return xs("G3SG1");
	else if (id == WEAPON_GALIL)
		return xs("Galil");
	else if (id == WEAPON_M249)
		return xs("M249");
	else if (id == WEAPON_M4A4)
		return xs("M4A4");
	else if (id == WEAPON_MAC10)
		return xs("MAC-10");
	else if (id == WEAPON_P90)
		return xs("P90");
	else if (id == WEAPON_MP5SD)
		return xs("MP5SD");
	else if (id == WEAPON_UMP45)
		return xs("UMP-45");
	else if (id == WEAPON_XM1014)
		return xs("XM1014");
	else if (id == WEAPON_BIZON)
		return xs("PP-Bizon");
	else if (id == WEAPON_MAG7)
		return xs("MAG-7");
	else if (id == WEAPON_NEGEV)
		return xs("Negev");
	else if (id == WEAPON_SAWEDOFF)
		return xs("Sawed-Off");
	else if (id == WEAPON_TEC9)
		return xs("Tec-9");
	else if (id == WEAPON_ZEUSX27)
		return xs("Taser");
	else if (id == WEAPON_P2000)
		return xs("P2000");
	else if (id == WEAPON_MP7)
		return xs("MP7");
	else if (id == WEAPON_MP9)
		return xs("MP9");
	else if (id == WEAPON_NOVA)
		return xs("Nova");
	else if (id == WEAPON_P250)
		return xs("P250");
	else if (id == WEAPON_SCAR20)
		return xs("SCAR-20");
	else if (id == WEAPON_SG553)
		return xs("SG 553");
	else if (id == WEAPON_SSG08)
		return xs("SSG 08");
	else if (id == WEAPON_FLASHBANG)
		return xs("Flashbang");
	else if (id == WEAPON_HEGRENADE)
		return xs("HE Grenade");
	else if (id == WEAPON_SMOKEGRENADE)
		return xs("Smoke");
	else if (id == WEAPON_MOLOTOV)
		return xs("Molotov");
	else if (id == WEAPON_DECOY)
		return xs("Decoy");
	else if (id == WEAPON_INCGRENADE)
		return xs("Molotov");
	else if (id == WEAPON_C4)
		return xs("C4");
	else if (id == WEAPON_M4A1S)
		return xs("M4A1-S");
	else if (id == WEAPON_USPS)
		return xs("USP-S");
	else if (id == WEAPON_CZ75)
		return xs("CZ75-Auto");
	else if (id == WEAPON_REVOLVER)
		return xs("R8 Revolver");
	else
		return xs("Knife");
}

int CBaseCombatWeapon::GetAimIndex()
{
	if (!this)
		return false;

	int id = *this->GetItemDefinitionIndex();

	if (id == WEAPON_USPS) return WAI_USPS;
	if (id == WEAPON_REVOLVER) return WAI_REVOLVER;
	if (id == WEAPON_CZ75) return WAI_CZ75;
	if (id == WEAPON_DEAGLE) return WAI_DEAGLE;
	if (id == WEAPON_DUALBERETTA) return WAI_DUALBERETTA;
	if (id == WEAPON_FIVESEVEN) return WAI_FIVESEVEN;
	if (id == WEAPON_GLOCK) return WAI_GLOCK;
	if (id == WEAPON_P2000) return WAI_P2000;
	if (id == WEAPON_P250) return WAI_P250;
	if (id == WEAPON_TEC9) return WAI_TEC9;

	if (id == WEAPON_MAC10) return WAI_MAC10;
	if (id == WEAPON_MP7) return WAI_MP7;
	if (id == WEAPON_MP9) return WAI_MP9;
	if (id == WEAPON_MP5SD) return WAI_MP5SD;
	if (id == WEAPON_BIZON) return WAI_BIZON;
	if (id == WEAPON_P90) return WAI_P90;
	if (id == WEAPON_UMP45) return WAI_UMP45;

	if (id == WEAPON_AK47) return WAI_AK47;
	if (id == WEAPON_FAMAS) return WAI_FAMAS;
	if (id == WEAPON_GALIL) return WAI_GALIL;
	if (id == WEAPON_M4A1S) return WAI_M4A1S;
	if (id == WEAPON_M4A4) return WAI_M4A4;
	if (id == WEAPON_AUG) return WAI_AUG;
	if (id == WEAPON_SG553) return WAI_SG553;

	if (id == WEAPON_AWP) return WAI_AWP;
	if (id == WEAPON_G3SG1) return WAI_G3SG1;
	if (id == WEAPON_SCAR20) return WAI_SCAR20;
	if (id == WEAPON_SSG08) return WAI_SSG08;
	
	if (id == WEAPON_MAG7) return WAI_MAG7;
	if (id == WEAPON_NOVA) return WAI_NOVA;
	if (id == WEAPON_SAWEDOFF) return WAI_SAWEDOFF;
	if (id == WEAPON_XM1014) return WAI_XM1014;

	if (id == WEAPON_M249) return WAI_M249;
	if (id == WEAPON_NEGEV) return WAI_NEGEV;

	if (id == WEAPON_ZEUSX27) return WAI_TASER;

	return WAI_UNKNOW;
}

//void CBaseCombatWeapon::release()
//{
//	PVOID pNetworkable = (PVOID)((DWORD)(this) + 0x8);
//	return U::GetVFunc<void(__thiscall*)(void*)>(pNetworkable, 1)(pNetworkable);
//}
//
//void CBaseCombatWeapon::setDestroyedOnRecreateEntities()
//{
//	PVOID pNetworkable = (PVOID)((DWORD)(this) + 0x8);
//	return U::GetVFunc<void(__thiscall*)(void*)>(pNetworkable, 13)(pNetworkable);
//}

bool CBaseCombatWeapon::IsGun()
{
	if (!this)
		return false;

	int id = *this->GetItemDefinitionIndex();

	if ( id == WEAPON_DEAGLE
		|| id == WEAPON_DUALBERETTA
		|| id == WEAPON_FIVESEVEN
		|| id == WEAPON_GLOCK
		|| id == WEAPON_AK47
		|| id == WEAPON_AUG
		|| id == WEAPON_AWP
		|| id == WEAPON_FAMAS
		|| id == WEAPON_G3SG1
		|| id == WEAPON_GALIL
		|| id == WEAPON_M249
		|| id == WEAPON_M4A4
		|| id == WEAPON_MAC10
		|| id == WEAPON_P90
		|| id == WEAPON_MP5SD
		|| id == WEAPON_UMP45
		|| id == WEAPON_XM1014
		|| id == WEAPON_BIZON
		|| id == WEAPON_MAG7
		|| id == WEAPON_NEGEV
		|| id == WEAPON_SAWEDOFF
		|| id == WEAPON_TEC9
		|| id == WEAPON_P2000
		|| id == WEAPON_MP7
		|| id == WEAPON_MP9
		|| id == WEAPON_NOVA
		|| id == WEAPON_P250
		|| id == WEAPON_SCAR20
		|| id == WEAPON_SG553
		|| id == WEAPON_SSG08
		|| id == WEAPON_M4A1S
		|| id == WEAPON_USPS
		|| id == WEAPON_CZ75
		|| id == WEAPON_REVOLVER )
		return true;

	return false;
}

bool CBaseCombatWeapon::IsSniper()
{
	if (!this)
		return false;

	int id = *this->GetItemDefinitionIndex();

	if (id == WEAPON_AWP || id == WEAPON_G3SG1 || id == WEAPON_SCAR20 || id == WEAPON_SSG08 || id == WEAPON_SG553 || id == WEAPON_AUG)
		return true;

	return false;
}

bool CBaseCombatWeapon::IsPistol()
{
	if (!this)
		return false;

	int id = *this->GetItemDefinitionIndex();

	if (id == WEAPON_DEAGLE || id == WEAPON_DUALBERETTA || id == WEAPON_FIVESEVEN || id == WEAPON_GLOCK || id == WEAPON_TEC9 ||
		id == WEAPON_P2000 || id == WEAPON_P250 || id == WEAPON_USPS || id == WEAPON_CZ75 || id == WEAPON_REVOLVER)
		return true;

	return false;
}

bool CBaseCombatWeapon::IsGrenade()
{
	if (!this)
		return false;

	int id = *this->GetItemDefinitionIndex();

	if (id == WEAPON_SMOKEGRENADE || id == WEAPON_HEGRENADE || id == WEAPON_INCGRENADE ||
		id == WEAPON_FLASHBANG || id == WEAPON_MOLOTOV || id == WEAPON_DECOY)
		return true;

	return false;
}

bool CBaseCombatWeapon::IsKnife()
{
	if (!this)
		return false;

	int id = *this->GetItemDefinitionIndex();

	if ( id == WEAPON_KNIFE
	 || id == WEAPON_KNIFE_T
	 || id == WEAPON_KNIFE_GG
	 || id == WEAPON_KNIFE_GHOST
	 || id == WEAPON_KNIFE_BAYONET
	 || id == WEAPON_KNIFE_FLIP
	 || id == WEAPON_KNIFE_GUT
	 || id == WEAPON_KNIFE_KARAMBIT
	 || id == WEAPON_KNIFE_M9_BAYONET
	 || id == WEAPON_KNIFE_TACTICAL
	 || id == WEAPON_KNIFE_FALCHION
	 || id == WEAPON_KNIFE_SURVIVAL_BOWIE
	 || id == WEAPON_KNIFE_BUTTERFLY
	 || id == WEAPON_KNIFE_PUSH
	 || id == WEAPON_KNIFE_URSUS
	 || id == WEAPON_KNIFE_GYPSY_JACKKNIFE
	 || id == WEAPON_KNIFE_STILETTO
	 || id == WEAPON_KNIFE_WIDOWMAKER
	 || id == WEAPON_KNIFE_CORD
	 || id == WEAPON_KNIFE_CANIS
	 || id == WEAPON_KNIFE_OUTDOOR
	 || id == WEAPON_KNIFE_SKELETON
	 || id == WEAPON_KNIFE_CSS )
		return true;
	
	 return false;
}

bool CBaseEntity::IsScoped()
{
	return *(bool*)((DWORD)this + offsets.m_bIsScoped);
}

CSWeaponInfo* CBaseCombatWeapon::GetCSWpnData()
{
	using Fn = CSWeaponInfo * (__thiscall*)(void*);
	return reinterpret_cast<Fn>(offsets.CSWpnData)(this);
}

int* CBaseCombatWeapon::ModelIndex()
{
	return (int *)((uintptr_t)this + offsets.m_nModelIndex);
}

int* CBaseCombatWeapon::ViewModelIndex()
{
	return (int *)((uintptr_t)this + offsets.m_iViewModelIndex);
}

HANDLE CBaseCombatWeapon::m_hWeaponWorldModel()
{
	return *(HANDLE*)((uintptr_t)this + offsets.m_hWeaponWorldModel);
}

char* CBaseCombatWeapon::GetCustomName()
{
	return reinterpret_cast<char*>((uintptr_t)this + offsets.m_szCustomName);
}

CSWeaponInfo* CBaseCombatWeapon::get_full_info()
{
	if (!this) return nullptr;
	return U::GetVFunc<CSWeaponInfo*(__thiscall*)(void*)>(this, GETFULLINFO)(this);
}

Vector CBaseEntity::GetPredicted(Vector p0)
{
	return M::ExtrapolateTick(p0, this->GetVelocity());
}

float CBaseEntity::GetLBY()
{
	return *(float*)((DWORD)this + offsets.m_flLowerBodyYawTarget);
}

QAngle* CBaseEntity::GetVAngles()
{
	return (QAngle*)((uintptr_t)this + offsets.deadflag + 0x4);
}

void CBaseEntity::SetAngle2(Vector wantedang)
{
	typedef void(__thiscall* SetAngleFn)(void*, const Vector &);
	static SetAngleFn SetAngle = (SetAngleFn)((DWORD)U::FindPattern(xs("client_panorama.dll"), xs("55 8B EC 83 E4 F8 83 EC 64 53 56 57 8B F1")));
	SetAngle(this, wantedang);
}

Vector& CBaseEntity::GetAbsAngles()
{
	return U::GetVFunc<Vector & (__thiscall*)(void*)>(this, 11)(this);
}

int CBaseEntity::DrawModel(int flags, uint8_t alpha)
{
	using fn = int(__thiscall*)(void*, int, uint8_t);
	return U::GetVFunc< fn >(GetRenderable(), 9)(GetRenderable(), flags, alpha);
}

IClientRenderable* CBaseEntity::GetRenderable()
{
	return reinterpret_cast<IClientRenderable*>((DWORD)this + 0x4);
}

int CBaseEntity::GetMoney()
{
	return *(int*)((DWORD)this + offsets.m_iAccount);
}

int CBaseEntity::GetIntByOffset(DWORD offest)
{
	return *(int*)((DWORD)this + offest);
}

float CBaseEntity::GetFloatByOffset(DWORD offest)
{
	return *(float*)((DWORD)this + offest);
}

bool CBaseEntity::GetBoolByOffset(DWORD offest)
{
	return *(bool*)((DWORD)this + offest);
}

void CBaseEntity::SetIntByOffset(DWORD offest, int value)
{
	*(int*)((DWORD)this + offest) = value;
}

void CBaseEntity::SetFloatByOffset(DWORD offest, float value)
{
	*(float*)((DWORD)this + offest) = value;
}

void CBaseEntity::SetBoolByOffset(DWORD offest, bool value)
{
	*(bool*)((DWORD)this + offest) = value;
}