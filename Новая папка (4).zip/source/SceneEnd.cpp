#include "Cheat.h"
#include "NewChams.h"
#include <intrin.h>

SceneEndFn oSceneEnd;
void __fastcall Hooks::SceneEnd(void* thisptr, void* edx)
{
	oSceneEnd(thisptr, edx);

	if (Opts.Visuals.Players.Global.ScreenShotBypass && I::Engine->IsTakingScreenshot())
	{
		return;
	}

	static bool mat_init = false;
	if (!mat_init)
	{
		Materials::InitializationMaterials();
		mat_init = true;
	}

	if (I::Engine->IsInGame() && I::Engine->IsConnected() && G::LocalPlayer)
	{
		if (Opts.Visuals.Players.Chams.Enabled)
		{
			IMaterial* vis_material = nullptr;
			IMaterial* invis_material = nullptr;
			Color Visible = 0;
			Color Invisible = 0;

			static float alpha = 0;
			static bool swith = false;

			for (int i = 0; i < 64; ++i)
			{
				CBaseEntity* Entity = I::ClientEntList->GetClientEntity(i);

				if (Entity && Entity->GetHealth() > 0 && Entity->GetClientClass()->m_ClassID == CCSPlayer && Entity != G::LocalPlayer && !Entity->GetDormant())
				{
					if (Opts.Visuals.Players.Chams.Blinking)
					{
						if (alpha < 1.0f && !swith) alpha += 0.0005f;
						else if (alpha > 0.0f) { alpha -= 0.0005f; swith = true; }
						else swith = false;
					}

					//static BYTE chams_type = 0;

					//if (chams_type != Opts.Visuals.Players.Chams.Type || material == nullptr)
					//{
					switch (Opts.Visuals.Players.Chams.VisType)
					{
					case 0: { vis_material = Materials::materialFlat; break; }
					case 1: { vis_material = Materials::materialTexture; break; }
					case 2: { vis_material = Materials::materialWireFrame; break; }
					case 3: { vis_material = Materials::materialMetalic; break; }
					case 4: { vis_material = Materials::materialAnimated; break; }
					case 5: { vis_material = Materials::materialPlatinum; break; }
					case 6: { vis_material = Materials::materialGlass; break; }
					case 7: { vis_material = Materials::materialCrystal; break; }
					case 8: { vis_material = Materials::materialChrome; break; }
					case 9: { vis_material = Materials::materialSilver; break; }
					case 10: { vis_material = Materials::materialGold; break; }
					case 11: { vis_material = Materials::materialPlastic; break; }
					case 12: { vis_material = Materials::materialGlowOverlay; break; }
					case 13: { vis_material = Materials::materialdog_tags_lightray; break; }
					case 14: { vis_material = Materials::materialdog_dogtags_outline; break; }
					case 15: { vis_material = Materials::materialdog_dreamhack_star_blur; break; }
					case 16: { vis_material = Materials::materialdog_crystal_blue; break; }
					case 17: { vis_material = Materials::materialdog_fishing_net01; break; }
					case 18: { vis_material = Materials::materialdog_contributor_charset_color; break; }
					case 19: { vis_material = Materials::materialdog_urban_tree03_branches; break; }
					case 20: { vis_material = Materials::materialdog_speech_info; break; }
					case 21: { vis_material = Materials::materialdog_mp3_detail; break; }
					default: return;
					}

					if (vis_material == 0) return;

					switch (Opts.Visuals.Players.Chams.InvisType)
					{
					case 0: { invis_material = Materials::materialFlat; break; }
					case 1: { invis_material = Materials::materialTexture; break; }
					case 2: { invis_material = Materials::materialWireFrame; break; }
					case 3: { invis_material = Materials::materialMetalic; break; }
					case 4: { invis_material = Materials::materialAnimated; break; }
					case 5: { invis_material = Materials::materialPlatinum; break; }
					case 6: { invis_material = Materials::materialGlass; break; }
					case 7: { invis_material = Materials::materialCrystal; break; }
					case 8: { invis_material = Materials::materialChrome; break; }
					case 9: { invis_material = Materials::materialSilver; break; }
					case 10: { invis_material = Materials::materialGold; break; }
					case 11: { invis_material = Materials::materialPlastic; break; }
					case 12: { invis_material = Materials::materialGlowOverlay; break; }
					case 13: { invis_material = Materials::materialdog_tags_lightray; break; }
					case 14: { invis_material = Materials::materialdog_dogtags_outline; break; }
					case 15: { invis_material = Materials::materialdog_dreamhack_star_blur; break; }
					case 16: { invis_material = Materials::materialdog_crystal_blue; break; }
					case 17: { invis_material = Materials::materialdog_fishing_net01; break; }
					case 18: { invis_material = Materials::materialdog_contributor_charset_color; break; }
					case 19: { invis_material = Materials::materialdog_urban_tree03_branches; break; }
					case 20: { invis_material = Materials::materialdog_speech_info; break; }
					case 21: { invis_material = Materials::materialdog_mp3_detail; break; }
					default: return;
					}

					if (invis_material == 0) return;

					//	chams_type = Opts.Visuals.Players.Chams.Type;
					//}



					if (Entity->IsEnemy())
					{
						Visible = Opts.Colors.Visuals.PlayersChamsEnemyVisible;
						Invisible = Opts.Colors.Visuals.PlayersChamsEnemyInvisible;
					}
					else if (!Opts.Visuals.Players.Chams.EnemyOnly)
					{
						Visible = Opts.Colors.Visuals.PlayersChamsTeammateVisible;
						Invisible = Opts.Colors.Visuals.PlayersChamsTeammateInvisible;
					}
					else
					{
						continue;
					}

					// Invisible
					if (!Opts.Visuals.Players.Chams.VisibleOnly)
					{
						invis_material->ColorModulate(Invisible.rBase(), Invisible.gBase(), Invisible.bBase());
						invis_material->SetMaterialVarFlag(MATERIAL_VAR_IGNOREZ, true);
						I::ModelRender->ForcedMaterialOverride(invis_material);

						I::RenderView->SetColorModulation(Invisible.Base());
						I::RenderView->SetBlend(Opts.Visuals.Players.Chams.Blinking ? alpha : Invisible.aBase());

						Entity->DrawModel(0x1, 255);
						I::ModelRender->ForcedMaterialOverride(nullptr);
					}

					// Visible
					if (!U::IsInSmoke(Entity->GetBonePositionSimple(BONE_CHEST)))
					{
						vis_material->ColorModulate(Visible.rBase(), Visible.gBase(), Visible.bBase());
						vis_material->SetMaterialVarFlag(MATERIAL_VAR_IGNOREZ, false);
						I::ModelRender->ForcedMaterialOverride(vis_material);

						I::RenderView->SetColorModulation(Visible.Base());
						I::RenderView->SetBlend(Opts.Visuals.Players.Chams.Blinking ? alpha : Visible.aBase());

						Entity->DrawModel(0x1, 255);
						I::ModelRender->ForcedMaterialOverride(nullptr);
					}
				}
			}
		}

		if (G::LocalPlayer->GetAlive() && I::Input->m_fCameraInThirdPerson && Opts.Misc.Globals.LegitDesync)
		{
			IMaterial* materialRegular = nullptr;
			materialRegular = I::MaterialSystem->FindMaterial("simple_regular", TEXTURE_GROUP_MODEL);

			Vector OrigAng = G::LocalPlayer->GetAbsAngles();
			G::LocalPlayer->SetAngle2(Vector(0, G::LocalPlayer->GetAnimState()->m_flEyeYaw, 0)); //around 90% accurate
			I::ModelRender->ForcedMaterialOverride(materialRegular);
			I::RenderView->SetColorModulation(Color(1.0f, 0.0f, 0.0f, 1.0f).Base());
			G::LocalPlayer->DrawModel(0x1, 255);
			G::LocalPlayer->SetAngle2(OrigAng);
		}
	}
}