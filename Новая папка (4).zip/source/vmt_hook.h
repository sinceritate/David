#pragma once

/* ����� �������� �������, ��� ����� ���� ������ */

class VMTHookManager
{
public:
	VMTHookManager() {}
	VMTHookManager(void* instance) { Initiosise(instance); }
	~VMTHookManager() { Restore(); }

	void Initiosise(void* instance)
	{
		m_vtable = *static_cast<void***>(instance);

		for(;;++m_size)
		{
			DWORD oProtection;
			VirtualProtect(&m_vtable[m_size], sizeof(DWORD), PAGE_EXECUTE_READWRITE, &oProtection);

			if (IS_INTRESOURCE((FARPROC)m_vtable[m_size])) break;
			m_original_funcs.push_back(m_vtable[m_size]);
		}
	}

	void Restore()
	{
		for (int index = 0; index < m_size; ++index)
		{
			DWORD oProtection;
			VirtualProtect(&m_vtable[index], sizeof(DWORD), PAGE_EXECUTE_READWRITE, &oProtection);
			m_vtable[index] = m_original_funcs[index];
		}
	}

	template <class T>
	T HookFunction(int index, void* func)
	{
		DWORD oProtection;
		VirtualProtect(&m_vtable[index], sizeof(DWORD), PAGE_EXECUTE_READWRITE, &oProtection);
		m_vtable[index] = func;

		return reinterpret_cast<T>(m_original_funcs[index]);
	}

	void UnHookFunction(int index)
	{
		DWORD oProtection;
		VirtualProtect(&m_vtable[index], sizeof(DWORD), PAGE_EXECUTE_READWRITE, &oProtection);
		m_vtable[index] = m_original_funcs[index];
	}

	template <class T>
	T GetOriginalFunction(int index)
	{
		return reinterpret_cast<T>(m_original_funcs[index]);
	}

private:
	std::vector<void*> m_original_funcs;

	void** m_vtable = 0;
	int m_size = 0;
};