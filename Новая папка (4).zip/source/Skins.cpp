#include <algorithm>
#include <fstream>

#include "Cheat.h"
#include "Skins.h"
#include "ItemSchema.h"

std::vector<SkinChanger::PaintKit> SkinChanger::skinKits{ {0, "None"} };
std::vector<SkinChanger::PaintKit> SkinChanger::gloveKits{ {0, "None"} };
std::vector<SkinChanger::PaintKit> SkinChanger::stickerKits{ {0, "None"} };

std::add_pointer_t<ItemSchema*()> itemSchema;

template <typename T>
static constexpr auto relativeToAbsolute(int* address) noexcept
{
	return reinterpret_cast<T>(reinterpret_cast<char*>(address + 1) + *address);
}

std::vector <std::string> name_strs;
std::vector <std::string> paints_strs;

void items_parser()
{
	std::vector <std::string> items_game;

	std::ifstream items_game_file("csgo/scripts/items/items_game.txt");

	if (items_game_file.is_open())
	{
		std::string temp_str;
		while (getline(items_game_file, temp_str))
		{
			items_game.push_back(temp_str);
		}

		items_game_file.close();
	}
	else
	{
		MessageBox(0, "Error 404 [Not found items_game.txt]", "Error 404", 0);

		__asm
		{
			MOV eax, 0
			DIV ebx
		}
	}

	int alternate_icons_pos = 0;
	for (int i = 0; i < items_game.size() - 100000; ++i)
	{
		if (alternate_icons_pos != 0)
		{
			int weapon_pos = 0, paint_pos = 0, light_pos = 0;

			if (items_game[i].find("prefabs") != std::string::npos) { break; }

			light_pos = items_game[i].find("_light");
			if (light_pos != -1)
			{
				std::string temp_str = "", temp_str2 = "";

				weapon_pos = items_game[i].find("/weapon_");
				if (weapon_pos != -1)
				{
					if (items_game[i].find("knife") != std::string::npos)
					{
						paint_pos = items_game[i].find("_", weapon_pos + 14) + 1;

						if ((items_game[i].find("_", paint_pos) - paint_pos) == 2)
						{
							temp_str.append(items_game[i], paint_pos, light_pos - paint_pos);
							paints_strs.push_back(temp_str);
							temp_str2.append(items_game[i], weapon_pos + 8, paint_pos - weapon_pos - 9);

							if (temp_str2 == "bayonet")
								temp_str2 = "knife_bayonet";

							name_strs.push_back(temp_str2);
						}
						else
						{
							paint_pos = items_game[i].find("_", paint_pos) + 1;
							temp_str.append(items_game[i], paint_pos, light_pos - paint_pos);
							paints_strs.push_back(temp_str);
							temp_str2.append(items_game[i], weapon_pos + 8, paint_pos - weapon_pos - 9);

							if (temp_str2 == "bayonet")
								temp_str2 = "knife_bayonet";

							name_strs.push_back(temp_str2);
						}
					}
					else
					{
						paint_pos = items_game[i].find("_", weapon_pos + 9) + 1;

						if ((items_game[i].find("_", paint_pos) - paint_pos) == 2)
						{
							temp_str.append(items_game[i], paint_pos, light_pos - paint_pos);
							paints_strs.push_back(temp_str);
							temp_str2.append(items_game[i], weapon_pos + 8, paint_pos - weapon_pos - 9);

							if (temp_str2 == "bayonet")
								temp_str2 = "knife_bayonet";

							name_strs.push_back(temp_str2);
						}
						else
						{
							paint_pos = items_game[i].find("_", paint_pos) + 1;
							temp_str.append(items_game[i], paint_pos, light_pos - paint_pos);
							paints_strs.push_back(temp_str);
							temp_str2.append(items_game[i], weapon_pos + 8, paint_pos - weapon_pos - 9);

							if (temp_str2 == "bayonet")
								temp_str2 = "knife_bayonet";

							name_strs.push_back(temp_str2);
						}
					}

					i += 11;
					continue;
				}
			}
		}
		else if (items_game[i].find("weapon_icons") != std::string::npos)
		{
			alternate_icons_pos = i;
		}
	}

	items_game.clear();
}

void SkinChanger::initializeKits()
{
	itemSchema = relativeToAbsolute<decltype(itemSchema)>(reinterpret_cast<int*>(U::FindPattern(rxs("client_panorama.dll"), rxs("E8 ?? ?? ?? ?? 0F B7 0F")) + 1));

	const auto V_UCS2ToUTF8 = reinterpret_cast<int(*)(const wchar_t* ucs2, char* utf8, int len)>(GetProcAddress(GetModuleHandle("vstdlib"), "V_UCS2ToUTF8"));

	items_parser();

	std::ifstream items( rxs("csgo/scripts/items/items_game_cdn.txt") );
	std::string gameItems = std::string( std::istreambuf_iterator<char>( items ), std::istreambuf_iterator<char>( ) );
	items.close();

	for (int i = 0; i <= itemSchema()->paintKits.lastElement; i++)
	{
		const auto paint_kit = itemSchema()->paintKits.memory[i].value;

		if (paint_kit->id == 9001)
			continue;

		const auto wide_name = I::pLocalize->find(paint_kit->itemName.buffer + 1);
		char name[256];
		V_UCS2ToUTF8(wide_name, name, sizeof(name));

		if (paint_kit->id < 10000)
		{
			if (auto pos = gameItems.find('_' + std::string{ paint_kit->name.buffer } + '='); pos != std::string::npos)
			{
				if (auto weaponName = gameItems.rfind("weapon_", pos); weaponName != std::string::npos)
				{
					for (int j = 0; j < paints_strs.size(); ++j)
					{
						std::string name_test = name;

						if (paint_kit->name.buffer == paints_strs[j])
						{
							if (name_strs[j] == "m4a1") name_strs[j] = "m4a4";

							name_test += " (" + name_strs[j] + ')';

							skinKits.emplace_back(paint_kit->id, name_test.c_str());
						}
					}
				}
			}
		}
		else
		{
			std::string_view gloveName{ paint_kit->name.buffer };
			sprintf_s(name + strlen(name), 255 - strlen(name), (" (" + std::string{ gloveName.substr(0, gloveName.find('_')) } +')').c_str());
			gloveKits.emplace_back(paint_kit->id, name);
		}
	}

	for (int i = 0; i <= itemSchema()->stickerKits.lastElement; ++i)
	{
		const auto sticker_kit = itemSchema()->stickerKits.memory[i].value;
		const auto wide_name = I::pLocalize->find(sticker_kit->itemName.buffer + 1);

		char name[256];
		V_UCS2ToUTF8(wide_name, name, sizeof(name));

		stickerKits.emplace_back(sticker_kit->id, name);
	}

	std::sort(skinKits.begin() + 1, skinKits.end());
	std::sort(gloveKits.begin() + 1, gloveKits.end());
	std::sort(std::next(stickerKits.begin()), stickerKits.end());

	name_strs.clear();
	paints_strs.clear();
}