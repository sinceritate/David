#include "Cheat.h"
#include "ISteamClient.h"

#include "Protobuf_compiled/cstrike15_gcmessages.pb.h"
#include "Protobuf_compiled/econ_gcmessages.pb.h"
#include "Protobuf_compiled/base_gcmessages.pb.h"
#include "Protobuf_compiled/gcsdk_gcmessages.pb.h"
#include "Protobuf_compiled/gcsystemmsgs.pb.h"

void ApplyMedals(CMsgSOCacheSubscribed::SubscribedType* pInventoryCacheObject);
void ApplySkins(CMsgSOCacheSubscribed::SubscribedType* pInventoryCacheObject);

RetrieveMessageFn oRetrieveMessage;
EGCResults __fastcall Hooks::RetrieveMessage(void* ecx, void* edx, uint32_t *punMsgType, void *pubDest, uint32_t cubDest, uint32_t *pcubMsgSize)
{
	EGCResults status = oRetrieveMessage(ecx, edx, punMsgType, pubDest, cubDest, pcubMsgSize);

	if (status != k_EGCResultOK) return status;

	uint32_t messageType = *punMsgType & 0x7FFFFFFF;

	static DWORD xuid_low = 0;
	//if (messageType == k_EMsgGCClientWelcome)
	//{
	//	CMsgClientWelcome Message;
	//	try
	//	{
	//		if (!Message.ParsePartialFromArray((void*)((DWORD)pubDest + 8), *pcubMsgSize - 8))
	//			return status;
	//	}
	//	catch (...) {
	//		return status;
	//	}
	//
	//	if (Message.outofdate_subscribed_caches_size() <= 0)
	//		return status;
	//
	//	CMsgSOCacheSubscribed* Cache = Message.mutable_outofdate_subscribed_caches(0);
	//	for (int i = 0; i < Cache->objects_size(); i++)
	//	{
	//		CMsgSOCacheSubscribed::SubscribedType* Object = Cache->mutable_objects(i);
	//		if (!Object->has_type_id())
	//			continue;
	//
	//		switch (Object->type_id())
	//		{
	//		case 1: // Inventory
	//		{
	//			for (int j = 0; j < Object->object_data_size(); j++)
	//			{
	//				std::string* ObjectData = Object->mutable_object_data(j);
	//
	//				CSOEconItem Item;
	//
	//				if (!Item.ParseFromArray((void*)const_cast<char*>(ObjectData->data()), ObjectData->size()))
	//				{
	//					continue;
	//				}
	//				if (Item.equipped_state_size() <= 0) {
	//					continue;
	//				}
	//
	//				CSOEconItemEquipped* EquippedState = Item.mutable_equipped_state(0);
	//
	//				if (EquippedState->new_class() == 0 && EquippedState->new_slot() == 55)
	//				{
	//					Item.clear_equipped_state();
	//
	//					ObjectData->resize(Item.ByteSize());
	//					Item.SerializeToArray((void*)const_cast<char*>(ObjectData->data()), Item.ByteSize());
	//				}
	//
	//				ObjectData->resize(Item.ByteSize());
	//				Item.SerializeToArray((void*)const_cast<char*>(ObjectData->data()), Item.ByteSize());
	//			}
	//
	//			ApplyMedals(Object);
	//			//ApplySkins(Object);
	//		}
	//		break;
	//		}
	//	}
	//
	//	if ((uint32_t)Message.ByteSize() <= cubDest - 8)
	//	{
	//		Message.SerializeToArray((void*)((DWORD)pubDest + 8), Message.ByteSize());
	//
	//		*pcubMsgSize = Message.ByteSize() + 8;
	//	}
	//}
	//else if (messageType == k_EMsgGCCStrike15_v2_MatchmakingGC2ClientHello)
	if (messageType == k_EMsgGCCStrike15_v2_MatchmakingGC2ClientHello)
	{
		CMsgGCCStrike15_v2_MatchmakingGC2ClientHello Message;

		try
		{
			if (!Message.ParsePartialFromArray((void*)((DWORD)pubDest + 8), *pcubMsgSize - 8))
				return status;
		}
		catch (...)
		{
			return status;
		}

		xuid_low = Message.account_id();

		if (Opts.Misc.Changer.Profile.Enabled)
		{
			Message.set_player_level(Opts.Misc.Changer.Profile.Level);
			Message.set_player_cur_xp(Opts.Misc.Changer.Profile.Experience);

			PlayerRankingInfo* Ranking = Message.mutable_ranking();
			Ranking->set_account_id(I::SteamUser->GetSteamID().GetAccountID());
			Ranking->set_rank_id(Opts.Misc.Changer.Profile.MMRank);
			Ranking->set_wins(Opts.Misc.Changer.Profile.MMWins);

			PlayerCommendationInfo* Commendation = Message.mutable_commendation();
			Commendation->set_cmd_friendly(Opts.Misc.Changer.Profile.Friendly);
			Commendation->set_cmd_leader(Opts.Misc.Changer.Profile.Leader);
			Commendation->set_cmd_teaching(Opts.Misc.Changer.Profile.Teacher);

			if (Opts.Misc.Changer.Profile.Ban != 0 && Opts.Misc.Changer.Profile.BanTime != 0)
			{
				Message.set_penalty_reason(Opts.Misc.Changer.Profile.Ban);
				Message.set_penalty_seconds(Opts.Misc.Changer.Profile.BanTime);
			}
		}

		if ((uint32_t)Message.ByteSize() <= cubDest - 8)
		{
			Message.SerializeToArray((void*)((DWORD)pubDest + 8), Message.ByteSize());
			*pcubMsgSize = Message.ByteSize() + 8;
		}
	}
	else if (messageType == k_EMsgGCCStrike15_v2_ClientGCRankUpdate)
	{
		CMsgGCCStrike15_v2_ClientGCRankUpdate Message;
		try
		{
			if (!Message.ParsePartialFromArray((void*)((DWORD)pubDest + 8), *pcubMsgSize - 8))
				return status;
		}
		catch (...) {
			return status;
		}

		for (size_t i = 0; i < Message.mutable_rankings()->size(); ++i)
		{
			auto Ranking = Message.mutable_rankings()->Mutable(i);

			switch (Ranking->rank_type_id())
			{
				case 7:
				{
					PlayerRankingInfo* Ranking = Message.mutable_rankings()->Mutable(i);
					Ranking->set_account_id(xuid_low);
					Ranking->set_rank_id(Opts.Misc.Changer.Profile.WMRank);
					Ranking->set_wins(Opts.Misc.Changer.Profile.WMWins);
					break;
				}
				case 10:
				{
					PlayerRankingInfo* Ranking = Message.mutable_rankings()->Mutable(i);
					Ranking->set_account_id(xuid_low);
					Ranking->set_rank_id(Opts.Misc.Changer.Profile.DZRank);
					Ranking->set_wins(Opts.Misc.Changer.Profile.DZWins);
					break;
				}
			}
		}

		if ((uint32_t)Message.ByteSize() <= cubDest - 8)
		{
			Message.SerializeToArray((void*)((DWORD)pubDest + 8), Message.ByteSize());
			*pcubMsgSize = Message.ByteSize() + 8;
		}
	}

	return status;
}

void ApplySkins(CMsgSOCacheSubscribed::SubscribedType* pInventoryCacheObject)
{
	int i = 20000;
	//for (auto weapon : Opts.Misc.Changer.Inventory.weapons) {
		CSOEconItem Skin;
	
		//MessageBoxA(0, Skin.SerializeAsString().c_str(), "6", 0);
		//MessageBoxA(0, "asd", "3", 0);
	
		Skin.set_id(20000 + 500);
		Skin.set_account_id(I::SteamUser->GetSteamID().GetAccountID());
		Skin.set_def_index(500);
		Skin.set_inventory(i++);
		Skin.set_origin(24);
		Skin.set_rarity(6);
		Skin.set_quantity(4);
		Skin.set_level(1);
		Skin.set_style(0);
		Skin.set_flags(0);
		Skin.set_in_use(false);
		Skin.set_original_id(0);
		//Skin.set_custom_name("123");
	
		auto PaintKitAttribute = Skin.add_attribute();
		float PaintKitAttributeValue = (float)0;
		PaintKitAttribute->set_def_index(6);
		PaintKitAttribute->set_value_bytes(&PaintKitAttributeValue, 4);
	
		auto SeedAttribute = Skin.add_attribute();
		float SeedAttributeValue = (float)0;
		SeedAttribute->set_def_index(7);
		SeedAttribute->set_value_bytes(&SeedAttributeValue, 4);
	
		auto WearAttribute = Skin.add_attribute();
		float WearAttributeValue = 0.5;
		WearAttribute->set_def_index(8);
		WearAttribute->set_value_bytes(&WearAttributeValue, 4);
	
		//MessageBoxA(0, "asd", "4", 0);
	
		for (int j = 0; j < 5; j++)
		{
			// Sticker Kit
			CSOEconItemAttribute* StickerKitAttribute = Skin.add_attribute();
			uint32_t StickerKitAttributeValue = 0;
		
			StickerKitAttribute->set_def_index(113 + 4 * j);
		
			StickerKitAttribute->set_value_bytes(&StickerKitAttributeValue, 4);
		
			// Sticker Wear
			CSOEconItemAttribute* StickerWearAttribute = Skin.add_attribute();
			float StickerWearAttributeValue = 0.001f;
		
			StickerWearAttribute->set_def_index(114 + 4 * j);
		
			StickerWearAttribute->set_value_bytes(&StickerWearAttributeValue, 4);
		
			// Sticker Scale
			CSOEconItemAttribute* StickerScaleAttribute = Skin.add_attribute();
			float StickerScaleAttributeValue = 1.f;
		
			StickerScaleAttribute->set_def_index(115 + 4 * j);
		
			StickerScaleAttribute->set_value_bytes(&StickerScaleAttributeValue, 4);
		
			// Sticker Rotation
			CSOEconItemAttribute* StickerRotationAttribute = Skin.add_attribute();
			float StickerRotationAttributeValue = 0.f;
		
			StickerRotationAttribute->set_def_index(116 + 4 * j);

			StickerRotationAttribute->set_value_bytes(&StickerRotationAttributeValue, 4);
		}
	
		//MessageBoxA(0, "asd", "5", 0);
	
		//MessageBoxA(0, Skin.SerializeAsString().c_str(), "6", 0);
		auto testtest = pInventoryCacheObject->mutable_object_data(0);
		*testtest = Skin.SerializeAsString();
		//c++;
	//}
}

void ApplyMedals(CMsgSOCacheSubscribed::SubscribedType* pInventoryCacheObject)
{
	int c = 10000;
	//for (uint32_t MedalIndex : Opts.Misc.Changer.Inventory.medals)
	//{
		CSOEconItem Medal;
		Medal.set_account_id(I::SteamUser->GetSteamID().GetAccountID());
		Medal.set_origin(9);
		Medal.set_rarity(6);
		Medal.set_quantity(1);
		Medal.set_quality(4);
		Medal.set_level(1);

		CSOEconItemAttribute* TimeAcquiredAttribute = Medal.add_attribute();
		uint32_t TimeAcquiredAttributeValue = 0;
		TimeAcquiredAttribute->set_def_index(222);
		TimeAcquiredAttribute->set_value_bytes(&TimeAcquiredAttributeValue, 4);

		for (int i = 1; i < 6; ++i)
		{
			Medal.set_def_index(1000+i);
			Medal.set_inventory(c);
			Medal.set_id(c);

			pInventoryCacheObject->add_object_data(Medal.SerializeAsString());
			++c;
		}

		//if (Opts.Misc.Changer.Inventory.equipped_medal_override && Opts.Misc.Changer.Inventory.equipped_medal == MedalIndex)
		//{
		//Medal.set_def_index(1000);
		//Medal.set_inventory(c);
		//Medal.set_id(c);
		//
		//CSOEconItemEquipped* EquippedState = Medal.add_equipped_state();
		//
		//EquippedState->set_new_class(0);
		//EquippedState->set_new_slot(55);
		//}
	
		pInventoryCacheObject->add_object_data(Medal.SerializeAsString());
	//	c++;
	//}
}