#pragma once

template<typename T, typename ...Args>
constexpr auto callVirtualMethod(void* classBase, int index, Args... args) noexcept
{
	return ((*reinterpret_cast<T(__thiscall***)(void*, Args...)>(classBase))[index])(classBase, args...);
}

class Localize {
public:
	constexpr auto find(const char* tokenName) noexcept
	{
		return callVirtualMethod<wchar_t*, const char*>(this, 11, tokenName);
	}
};