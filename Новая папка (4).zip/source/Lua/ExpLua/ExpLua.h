#pragma once

#include "../Lua/sol.hpp"
#include "../Lua/ExpLua/LuaEventManager.h"

class CExpLua
{
public:

	void Initiolize();

	sol::state lua;

	std::vector <std::string> scripts;
	std::vector <bool> enabled;

	size_t GetScriptId(std::string name);

}; extern CExpLua ExpLua;