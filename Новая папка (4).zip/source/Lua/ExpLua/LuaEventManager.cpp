#include "LuaEventManager.h"

void cLuaEventManager::AddScriptEvents(std::string eventName, size_t scriptId, sol::protected_function func)
{
	sctEvent hk = { scriptId, func };
	events[eventName].push_back(hk);
}

void cLuaEventManager::RemoveScriptEvents(size_t scriptId)
{
	for (auto& ev : events)
	{
		int pos = 0;
		for (auto& hk : ev.second)
		{
			if (hk.scriptId == scriptId)
				ev.second.erase(ev.second.begin() + pos);

			++pos;
		}
	}
}

std::vector<sctEvent> cLuaEventManager::GetEvents(std::string eventName)
{
	return events[eventName];
}

cLuaEventManager LuaEventManager;