#include "../Cheat.h"

#include "ExpLua.h"

#include <filesystem>

CExpLua ExpLua;

void lua_panic(sol::optional<std::string> message)
{
	I::Cvar->ConsoleColorPrintf(Color(255, 0, 0), "Lua panic!\n");
	
	if (message) {
		std::string error_val = message.value();
		I::Cvar->ConsoleColorPrintf(Color(255, 0, 0), "\nError is %s", error_val.c_str());
	}
}

namespace lua_cheat
{
	void set_event(sol::this_state s, std::string eventname, sol::function func)
	{
		sol::state_view lua_state(s);
		sol::table rs = lua_state["debug"]["getinfo"](2, ("S"));
		std::string source = rs["source"];
		std::string filename = std::filesystem::path(source.substr(1)).filename().string();

		LuaEventManager.AddScriptEvents(eventname, ExpLua.GetScriptId(filename), func);
	}

	QAngle VectorToQAngle(Vector vec)
	{
		QAngle ang = QAngle(vec.x, vec.y, vec.z);
		return ang;
	}

	Vector QAngleToVector(QAngle ang)
	{
		Vector vec = Vector(ang.x, ang.y, ang.z);
		return vec;
	}
}

namespace lua_surface
{
	void DrawSetColor(Color pColor)
	{
		I::Surface->DrawSetColor(pColor);
	}

	void DrawFilledRect(int x0, int y0, int x1, int y1)
	{
		I::Surface->DrawFilledRect(x0, y0, x1, y1);
	}

	void DrawOutlinedRect(int x0, int y0, int x1, int y1)
	{
		I::Surface->DrawOutlinedRect(x0, y0, x1, y1);
	}

	void DrawLine(int x0, int y0, int x1, int y1)
	{
		I::Surface->DrawLine(x0, y0, x1, y1);
	}

	void DrawPolyLine(int* px, int* py, int numPoints)
	{
		I::Surface->DrawPolyLine(px, py, numPoints);
	}

	void DrawSetTextFont(unsigned int font)
	{
		I::Surface->DrawSetTextFont(font);
	}

	void DrawSetTextColor(Color pColor)
	{
		I::Surface->DrawSetTextColor(pColor);
	}

	void DrawSetTextPos(int x, int y)
	{
		I::Surface->DrawSetTextPos(x, y);
	}

	void DrawPrintText(const wchar_t* text, int textLen, FontDrawType_t drawType)
	{
		I::Surface->DrawPrintText(text, textLen, drawType);
	}

	void DrawSetTextureRGBA(int ID, const unsigned char* rgba, int wide, int tall)
	{
		I::Surface->DrawSetTextureRGBA(ID, rgba, wide, tall);
	}

	void DrawSetTexture(int ID)
	{
		I::Surface->DrawSetTexture(ID);
	}

	int CreateNewTextureID(bool procedural)
	{
		return I::Surface->CreateNewTextureID(procedural);
	}

	unsigned int Create_Font()
	{
		return I::Surface->Create_Font();
	}
	
	bool SetFontGlyphSet(unsigned long font, const char* windowsFontName, int tall, int weight, int blur, int scanlines, int flags)
	{
		return I::Surface->SetFontGlyphSet(font, windowsFontName, tall, weight, blur, scanlines, flags);
	}

	Vector GetTextSize(unsigned long font, const char* text)
	{
		va_list va_alist;
		char buf[1024];
		va_start(va_alist, text);
		_vsnprintf(buf, sizeof(buf), text, va_alist);
		va_end(va_alist);
		wchar_t wbuf[1024];
		MultiByteToWideChar(CP_UTF8, 0, buf, 256, wbuf, 256);

		int Width, Height;
		I::Surface->GetTextSize(font, wbuf, Width, Height);

		return Vector(Width, Height, 0);
	}

	void DrawOutlinedCircle(int x, int y, int radius, int segments)
	{
		I::Surface->DrawOutlinedCircle(x, y, radius, segments);
	}

	void DrawCircle3D(Vector position, float points, float radius, Color Color)
	{
		D::DrawCircle3D(position, points, radius, Color);
	}

	void DrawString(HFont font, int x, int y, Color Color, DWORD alignment, const char* msg, ...)
	{
		D::DrawString(font, x, y, Color, alignment, msg);
	}

	Vector WorldToScreen(Vector origin)
	{
		Vector o1 = origin, o2;
		D::WorldToScreen(o1, o2);

		return o2;
	}
}

namespace lua_engine
{
	Vector GetScreenSize()
	{
		int width, height;
		I::Engine->GetScreenSize(width, height);

		return Vector(width, height, 0);
	}

	int GetClientVersion()
	{
		return I::Engine->GetClientVersion();
	}

	bool IsActiveApp()
	{
		return I::Engine->IsActiveApp();
	}

	bool IsInGame()
	{
		return I::Engine->IsInGame();
	}

	bool IsConnected()
	{
		return I::Engine->IsConnected();
	}

	bool IsTakingScreenshot()
	{
		return I::Engine->IsTakingScreenshot();
	}
}

namespace lua_cvar
{
	ConVar* FindVar(const char* name)
	{
		return I::Cvar->FindVar(name);
	}

	void ChangeCallback(ConVar* cur_var, DWORD offset, int value)
	{
		*(int*)((DWORD)&cur_var->fnChangeCallback + offset) = value; // 0xC, NULL
	}
}

namespace lua_entity_list
{
	CBaseEntity* GetClientEntity(int index)
	{
		return I::ClientEntList->GetClientEntity(index);
	}

	CBaseEntity* GetClientEntityFromHandle(unsigned int handle)
	{
		return I::ClientEntList->GetClientEntityFromHandle(handle);
	}

	int GetMaxEntities()
	{
		return I::ClientEntList->GetMaxEntities();
	}

	int GetHighestEntityIndex()
	{
		return I::ClientEntList->GetHighestEntityIndex();
	}

	int GetLocalPlayer()
	{
		return I::Engine->GetLocalPlayer();
	}
}

namespace lua_offset_manager
{
	int GetOffest(std::string base, std::string name)
	{
		return U::NetVars->GetOffset(base.c_str(), name.c_str());;
	}

	int FindPatternV1(std::string _module, std::string _pattern)
	{
		return U::FindPattern(_module, _pattern);
	}
}

void CExpLua::Initiolize()
{
	lua = sol::state(sol::c_call<decltype(&lua_panic), &lua_panic>);
	lua.open_libraries(sol::lib::base, sol::lib::string, sol::lib::table, sol::lib::math, sol::lib::debug);

	lua["collectgarbage"] = sol::nil;
	lua["dofile"] = sol::nil;
	lua["load"] = sol::nil;
	lua["loadfile"] = sol::nil;
	lua["pcall"] = sol::nil;
	lua["xpcall"] = sol::nil;
	lua["getmetatable"] = sol::nil;
	lua["setmetatable"] = sol::nil;
	lua["__nil_callback"] = []() {};

	lua["print"] = [](std::string s) { I::Cvar->ConsoleColorPrintf(Color(255, 255, 255, 255), (s + '\n').c_str()); };
	lua["error"] = [](std::string s) { I::Cvar->ConsoleColorPrintf(Color(255, 0, 0, 255), (s + '\n').c_str()); };

	lua.new_enum("offsets",
		"m_bDormant", offsets.m_bDormant,
		"m_iHealth", offsets.m_iHealth,
		"m_iTeamNum", offsets.m_iTeamNum,
		"m_ArmorValue", offsets.m_ArmorValue,
		"m_lifeState", offsets.m_lifeState,
		"m_fFlags", offsets.m_fFlags,
		"m_nTickBase", offsets.m_nTickBase,
		"m_angEyeAngles", offsets.m_angEyeAngles,
		"m_flFlashDuration", offsets.m_flFlashDuration,
		"m_viewPunchAngle", offsets.m_viewPunchAngle,
		"m_aimPunchAngle", offsets.m_aimPunchAngle,
		"m_vecOrigin", offsets.m_vecOrigin,
		"m_vecViewOffset", offsets.m_vecViewOffset,
		"m_vecVelocity", offsets.m_vecVelocity,
		"m_hActiveWeapon", offsets.m_hActiveWeapon,
		"m_Collision", offsets.m_Collision,
		"m_CollisionGroup", offsets.m_CollisionGroup,
		"m_iShotsFired", offsets.m_iShotsFired,
		"m_nMoveType", offsets.m_nMoveType,
		"m_nHitboxSet", offsets.m_nHitboxSet,
		"m_flC4Blow", offsets.m_flC4Blow,
		"m_bBombTicking", offsets.m_bBombTicking,
		"m_flTimerLength", offsets.m_flTimerLength,
		"m_flDefuseLength", offsets.m_flDefuseLength,
		"m_flDefuseCountDown", offsets.m_flDefuseCountDown,
		"m_hMyWearables", offsets.m_hMyWearables,
		"m_flNextPrimaryAttack", offsets.m_flNextPrimaryAttack,
		"m_nFallbackPaintKit", offsets.m_nFallbackPaintKit,
		"m_nFallbackSeed", offsets.m_nFallbackSeed,
		"m_flFallbackWear", offsets.m_flFallbackWear,
		"m_nFallbackStatTrak", offsets.m_nFallbackStatTrak,
		"m_iItemIDHigh", offsets.m_iItemIDHigh,
		"m_iItemIDLow", offsets.m_iItemIDLow,
		"m_iAccountID", offsets.m_iAccountID,
		"m_iAccount", offsets.m_iAccount,
		"m_iEntityQuality", offsets.m_iEntityQuality,
		"m_iClip1", offsets.m_iClip1,
		"m_OriginalOwnerXuidLow", offsets.m_OriginalOwnerXuidLow,
		"m_OriginalOwnerXuidHigh", offsets.m_OriginalOwnerXuidHigh,
		"m_iItemDefinitionIndex", offsets.m_iItemDefinitionIndex,
		"m_hObserverTarget", offsets.m_hObserverTarget,
		"m_bIsDefusing", offsets.m_bIsDefusing,
		"m_bSpotted", offsets.m_bSpotted,
		"m_flFlashMaxAlpha", offsets.m_flFlashMaxAlpha,
		"m_flLowerBodyYawTarget", offsets.m_flLowerBodyYawTarget,
		"m_angEyeAnglesX", offsets.m_angEyeAnglesX,
		"m_angEyeAnglesY", offsets.m_angEyeAnglesY,
		"m_vecMaxs", offsets.m_vecMaxs,
		"m_vecMins", offsets.m_vecMins,
		"m_iViewModelIndex", offsets.m_iViewModelIndex,
		"m_flPoseParameter", offsets.m_flPoseParameter,
		"m_bClientSideAnimation", offsets.m_bClientSideAnimation,
		"m_flSimulationTime", offsets.m_flSimulationTime,
		"m_bIsScoped", offsets.m_bIsScoped,
		"m_nModelIndex", offsets.m_nModelIndex,
		"m_hWeaponWorldModel", offsets.m_hWeaponWorldModel,
		"m_szCustomName", offsets.m_szCustomName,
		"m_ragPos", offsets.m_ragPos,
		"m_hMyWeapons", offsets.m_hMyWeapons,
		"m_hOwner", offsets.m_hOwner,
		"deadflag", offsets.deadflag,
		"m_nSurvivalTeam", offsets.m_nSurvivalTeam,
		"m_hViewModel", offsets.m_hViewModel,
		"CSWpnData", offsets.CSWpnData);

	lua.new_usertype<Color>("Color",
		sol::constructors<Color(), Color(int, int, int), Color(int, int, int, int)>(),
		"r", &Color::r,
		"g", &Color::g,
		"b", &Color::b,
		"a", &Color::a,
		"rBase", &Color::rBase,
		"gBase", &Color::gBase,
		"bBase", &Color::bBase,
		"aBase", &Color::aBase,
		"Base", &Color::Base,
		"FromHSB", &Color::FromHSB,
		"GetRawColor", &Color::GetRawColor,
		"GetU32", &Color::GetU32 );

	lua.new_usertype<Vector>("Vector",
		sol::constructors<Vector(), Vector(float, float, float)>(),
		"x", &Vector::x,
		"y", &Vector::y,
		"z", &Vector::z,
		"Length", &Vector::Length,
		"Length2D", &Vector::Length2D,
		"LengthSqr", &Vector::LengthSqr,
		"Length2DSqr", &Vector::Length2DSqr,
		"DistTo", &Vector::DistTo );

	lua.new_usertype<QAngle>("QAngle",
		sol::constructors<QAngle(), QAngle(float, float, float)>(),
		"x", &QAngle::x,
		"y", &QAngle::y,
		"z", &QAngle::z,
		"NormalizeAngle", &QAngle::Normalized,
		"ClampAngle", &QAngle::Clamp );

	lua.new_usertype<CBaseEntity>("CBaseEntity",
		"IsAlive", &CBaseEntity::GetAlive,
		"IsDormant", &CBaseEntity::GetDormant,
		"GetHealth", &CBaseEntity::GetHealth,
		"GetArmor", &CBaseEntity::GetArmor,
		"GetOrigin", &CBaseEntity::GetOrigin,

		"GetIntByOffset", &CBaseEntity::GetIntByOffset,
		"GetFloatByOffset", &CBaseEntity::GetFloatByOffset,
		"GetBoolByOffset", &CBaseEntity::GetBoolByOffset,

		"SetIntByOffset", &CBaseEntity::SetIntByOffset,
		"SetFloatByOffset", &CBaseEntity::SetFloatByOffset,
		"SetBoolByOffset", &CBaseEntity::SetBoolByOffset,

		"index", &CBaseEntity::index );

	lua.new_usertype<ConVar>("ConVar",
		"GetDefault", &ConVar::GetDefault,
		"GetFloat", &ConVar::GetFloat,
		"GetName", &ConVar::GetName,
		"szSetValue", &ConVar::szSetValue,
		"flSetValue", &ConVar::flSetValue,
		"iSetValue", &ConVar::iSetValue );

	auto cheat = this->lua.create_table();
	cheat["set_event"] = lua_cheat::set_event;
	cheat["VectorToQAngle"] = lua_cheat::VectorToQAngle;
	cheat["QAngleToVector"] = lua_cheat::QAngleToVector;

	lua.new_enum("surfase_fonts",
		"Arial_13", F::ESP,
		"Arial_16", F::MenuCon,
		"Tahoma_12", F::Panel,
		"Arial_25", F::HitMarker,
		"MS_Sans_Serif_18", F::Watermark );

	auto surface = this->lua.create_table();
	surface["DrawSetColor"] = lua_surface::DrawSetColor;
	surface["DrawFilledRect"] = lua_surface::DrawFilledRect;
	surface["DrawOutlinedRect"] = lua_surface::DrawOutlinedRect;
	surface["DrawLine"] = lua_surface::DrawLine;
	surface["DrawPolyLine"] = lua_surface::DrawPolyLine;
	surface["DrawSetTextFont"] = lua_surface::DrawSetTextFont;
	surface["DrawSetTextColor"] = lua_surface::DrawSetTextColor;
	surface["DrawSetTextPos"] = lua_surface::DrawSetTextPos;
	surface["DrawPrintText"] = lua_surface::DrawPrintText;
	surface["DrawSetTextureRGBA"] = lua_surface::DrawSetTextureRGBA;
	surface["DrawSetTexture"] = lua_surface::DrawSetTexture;
	surface["CreateNewTextureID"] = lua_surface::CreateNewTextureID;
	surface["Create_Font"] = lua_surface::Create_Font;
	surface["SetFontGlyphSet"] = lua_surface::SetFontGlyphSet;
	surface["GetTextSize"] = lua_surface::GetTextSize;
	surface["DrawOutlinedCircle"] = lua_surface::DrawOutlinedCircle;
	surface["DrawString"] = lua_surface::DrawString;
	surface["DrawCircle3D"] = lua_surface::DrawCircle3D;
	surface["WorldToScreen"] = lua_surface::WorldToScreen;

	auto engine = this->lua.create_table();
	engine["GetScreenSize"] = lua_engine::GetScreenSize;
	engine["GetClientVersion"] = lua_engine::GetClientVersion;
	engine["IsActiveApp"] = lua_engine::IsActiveApp;
	engine["IsInGame"] = lua_engine::IsInGame;
	engine["IsConnected"] = lua_engine::IsConnected;
	engine["IsTakingScreenshot"] = lua_engine::IsTakingScreenshot;

	auto cvar = this->lua.create_table();
	cvar["FindVar"] = lua_cvar::FindVar;
	cvar["ChangeCallback"] = lua_cvar::ChangeCallback;

	auto entity_list = this->lua.create_table();
	entity_list["GetClientEntity"] = lua_entity_list::GetClientEntity;
	entity_list["GetClientEntityFromHandle"] = lua_entity_list::GetClientEntityFromHandle;
	entity_list["GetMaxEntities"] = lua_entity_list::GetMaxEntities;
	entity_list["GetHighestEntityIndex"] = lua_entity_list::GetHighestEntityIndex;
	entity_list["GetLocalPlayer"] = lua_entity_list::GetLocalPlayer;

	auto offset_manager = this->lua.create_table();
	offset_manager["GetOffset"] = lua_offset_manager::GetOffest;
	offset_manager["FindPatternV1"] = lua_offset_manager::FindPatternV1;

	lua["cheat"] = cheat;
	lua["surface"] = surface;
	lua["engine"] = engine;
	lua["cvar"] = cvar;
	lua["entity_list"] = entity_list;
	lua["offset_manager"] = offset_manager;
}

size_t CExpLua::GetScriptId(std::string name)
{
	for (size_t i = 0; i < scripts.size(); ++i)
	{
		if (scripts[i] == name)
			return i;
	}

	return std::string::npos;
}