#pragma once

#include "ExpLua.h"

#include <map>

struct sctEvent {
	size_t scriptId;
	sol::protected_function func;
};

class cLuaEventManager
{
public:

	void AddScriptEvents(std::string eventName, size_t scriptId, sol::protected_function func);
	void RemoveScriptEvents(size_t scriptId);

	std::vector<sctEvent> GetEvents(std::string eventName);

private:

	std::map<std::string, std::vector<sctEvent>> events;

}; extern cLuaEventManager LuaEventManager;