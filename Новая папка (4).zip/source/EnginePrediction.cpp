#include "EnginePrediction.h"

float _curtime_backup;
float _frametime_backup;
CMoveData _movedata;
CUserCmd* _prevcmd;
int _fixedtick;

int32_t* _prediction_seed;
CBaseEntity*** _prediction_player;

void CEnginePred::run_prediction()
{
	_curtime_backup = I::Globals->curtime;
	_frametime_backup = I::Globals->frametime;

	if (!_prevcmd || _prevcmd->hasbeenpredicted) {
		_fixedtick = G::LocalPlayer->GetTickBase();
	}
	else {
		_fixedtick++;
	}

	if (!_prediction_seed || !_prediction_player) {
		_prediction_seed = *(int32_t**)(U::FindPattern(rXor("client_panorama.dll"), "8B 0D ? ? ? ? BA ? ? ? ? E8 ? ? ? ? 83 C4 04") + 0x2);
		_prediction_player = (CBaseEntity***)(U::FindPattern(rXor("client_panorama.dll"), "89 35 ? ? ? ? F3 0F 10 48 20") + 0x2);
	}

	if (_prediction_seed) {
		*_prediction_seed = G::UserCmd->random_seed;
	}

	if (_prediction_player) {
		**_prediction_player = G::LocalPlayer;
	}

	G::LocalPlayer->m_pCurrentCommand() = G::UserCmd;

	I::Globals->curtime = static_cast<float>(_fixedtick) * I::Globals->interval_per_tick;
	I::Globals->frametime = I::Globals->interval_per_tick;

	bool _inpred_backup = *(bool*)((uintptr_t)I::pPrediction + 0x8);

	*(bool*)((uintptr_t)I::pPrediction + 0x8) = true;

	I::pMoveHelper->SetHost(G::LocalPlayer);

	I::GameMovement->StartTrackPredictionErrors(G::LocalPlayer);
	I::pPrediction->SetupMove(G::LocalPlayer, G::UserCmd, I::pMoveHelper, &_movedata);
	I::GameMovement->ProcessMovement(G::LocalPlayer, &_movedata);
	I::pPrediction->FinishMove(G::LocalPlayer, G::UserCmd, &_movedata);
	I::GameMovement->FinishTrackPredictionErrors(G::LocalPlayer);

	*(bool*)((uintptr_t)I::pPrediction + 0x8) = _inpred_backup;

	I::pMoveHelper->SetHost(nullptr);

	if (_prediction_seed) {
		*_prediction_seed = -1;
	}

	if (_prediction_player) {
		**_prediction_player = nullptr;
	}

	G::LocalPlayer->m_pCurrentCommand() = nullptr;

	_prevcmd = G::UserCmd;
}

void CEnginePred::end_prediction()
{
	I::Globals->curtime = _curtime_backup;
	I::Globals->frametime = _frametime_backup;
}

CEnginePred* prediction = new CEnginePred();