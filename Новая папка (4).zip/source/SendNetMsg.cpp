#include "Cheat.h"
#include "ISteamClient.h"

#include "Protobuf_compiled/cstrike15_gcmessages.pb.h"
#include "Protobuf_compiled/econ_gcmessages.pb.h"
#include "Protobuf_compiled/base_gcmessages.pb.h"
#include "Protobuf_compiled/gcsdk_gcmessages.pb.h"
#include "Protobuf_compiled/gcsystemmsgs.pb.h"

#define START_MUSICKIT_INDEX 1500000
#define START_ITEM_INDEX     2000000

static bool inventory_changer_presend(void* pubData, uint32_t &cubData)
{
	CMsgAdjustItemEquippedState Message;

	try
	{
		if (!Message.ParsePartialFromArray((void*)((DWORD)pubData + 8), cubData - 8))
			return true;
	}
	catch (...)
	{
		return true;
	}
	
	// Change music kit check
	if (Message.has_item_id() && (Message.has_new_class() == 0 || Message.new_slot() == 54))
	{
		auto ItemIndex = Message.item_id() - START_MUSICKIT_INDEX;

		if (ItemIndex > 38 || ItemIndex < 3)
			return true;

		Message.set_new_slot(0xFFFF ? 0 : ItemIndex - 2);

		return false;
	}

	// Change weapon skin check
	if (!Message.has_item_id() || !Message.has_new_class() || !Message.has_new_slot())
		return true;

	return false;
}

bool PreSendMessage(uint32_t &unMsgType, void* pubData, uint32_t &cubData)
{
	uint32_t MessageType = unMsgType & 0x7FFFFFFF;

	if (MessageType == k_EMsgGCAdjustItemEquippedState)
	{
		return inventory_changer_presend(pubData, cubData);
	}

	return true;
}

SendNetMsgFn oSendNetMsg;
EGCResults __fastcall Hooks::SendNetMsg(void* ecx, void* edx, uint32_t unMsgType, const void* pubData, uint32_t cubData)
{
	bool status = PreSendMessage(unMsgType, const_cast<void*>(pubData), cubData);
	
	if (!status)
		return k_EGCResultOK;

	return oSendNetMsg(ecx, edx, unMsgType, pubData, cubData);
}