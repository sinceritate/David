#pragma once
#include "Event Listeners.h"
#include "Recv.h"

struct paint_kits
{
	std::string name;
	int skin_id;
};

extern int current_last_esp_preview_id;
extern int current_active_esp_preview_id;

extern bool panic_key_time;

extern std::vector <paint_kits> skinPaints;
extern std::vector <paint_kits> stickerPaints;
extern std::vector <paint_kits> KnifesPaints;

extern bool Eng;

extern ImFont* font_std;
extern ImFont* font_big;
extern ImFont* font_cherry;
extern ImFont* font_undefeated;

#define ER(eng, rus) Eng ? eng : rus
#define SetTooltip(text) if (ImGui::IsItemHovered()) ImGui::SetTooltip(text)
#define SetTooltipER(en, ru) SetTooltip(ER(en, ru))

inline void DrawSubTabsEx(const char* const name_mass[], int size_mass, int& tab_active, bool for_active, int size_x)
{
	if (for_active)
	{
		size_mass /= 2;
	}

	//CPhysPropAmmoBox // ammo box
	//CPhysPropLootCrate // blue box
	//CItemCash // cash
	//CPhysPropWeaponUpgrade // exo jump

	//I::ModelInfo

	for (auto i = 0; i < size_mass; i++)
	{
		ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));

		if (tab_active == i)
		{
			static ImGuiStyle& style = ImGui::GetStyle();
			if (for_active)
			{
				ImGui::PushFont(font_std);
				ImGui::ColButton(name_mass[i + size_mass], style.Colors[ImGuiCol_ButtonActive], ImVec2(size_x / (size_mass * 1.05), 24));
				ImGui::PopFont();
			}
			else
			{
				ImGui::ColButton(name_mass[i], style.Colors[ImGuiCol_ButtonActive], ImVec2(size_x / (size_mass * 1.05), 24));
			}
		}
		if (tab_active != i)
		{
			if (ImGui::Button(name_mass[i], ImVec2(size_x / (size_mass * 1.05), 24)))
			{
				tab_active = i;
			}
		}

		if (i < size_mass - 1)
		{
			ImGui::SameLine();
		}

		ImGui::PopStyleVar();
	}
}

inline void DrawSubTabs(const char* const name_mass[], int size_mass, int& tab_active, bool for_active = false, int size_x = 666, bool line = true)
{
	if (for_active == true)
	{
		ImGui::PushFont(font_undefeated);
		DrawSubTabsEx(name_mass, size_mass, tab_active, for_active, size_x);
		ImGui::PopFont();
	}
	else
	{
		DrawSubTabsEx(name_mass, size_mass, tab_active, for_active, size_x);
	}

	if (line)
	{
		ImGui::Spacing();
		ImGui::Separator();
	}
}

enum draw_sub_tabs {
	dst_draw_line = 1 << 0,
	dst_font_std = 1 << 1,
	dst_font_cherry = 1 << 2,
	dst_font_undefeated = 1 << 3,
	dst_draw_same_line = 1 << 4,
	dst_push_style_item_spacing = 1 << 5,
};

inline void DrawSubTabsExTest(const char* const name_mass[], int size_mass, int& tab_active, unsigned char flags, int size_x)
{
	if (!(flags & dst_font_std)) size_mass /= 2;

	for (auto i = 0; i < size_mass; ++i)
	{
		if (flags & dst_push_style_item_spacing) ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));

		if (tab_active == i)
		{
			static ImGuiStyle& style = ImGui::GetStyle();
			if (!(flags & dst_font_std))
			{
				ImGui::PushFont(font_std);
				ImGui::ColButton(name_mass[i + size_mass], style.Colors[ImGuiCol_ButtonActive], ImVec2(size_x == -1 ? -1 : size_x / (size_mass * 1.05), 24));
				ImGui::PopFont();
			}
			else
			{
				ImGui::ColButton(name_mass[i], style.Colors[ImGuiCol_ButtonActive], ImVec2(size_x == -1 ? -1 : size_x / (size_mass * 1.05), 24));
			}
		}
		if (tab_active != i)
		{
			if (ImGui::Button(name_mass[i], ImVec2(size_x == -1 ? -1 : size_x / (size_mass * 1.05), 24)))
			{
				tab_active = i;
			}
		}

		if (i < size_mass - 1 && flags & dst_draw_same_line)
		{
			ImGui::SameLine();
		}

		if (flags & dst_push_style_item_spacing) ImGui::PopStyleVar();
	}
}

inline void DrawSubTabsTest(const char* const name_mass[], int size_mass, int& tab_active, unsigned char flags = 0, int size_x = 700)
{
	if (flags & dst_font_cherry) {

		ImGui::PushFont(font_cherry);
		DrawSubTabsExTest(name_mass, size_mass, tab_active, flags, size_x);
		ImGui::PopFont();

	}
	else if (flags & dst_font_undefeated) {

		ImGui::PushFont(font_undefeated);
		DrawSubTabsExTest(name_mass, size_mass, tab_active, flags, size_x);
		ImGui::PopFont();

	}
	else { DrawSubTabsExTest(name_mass, size_mass, tab_active, flags | dst_font_std, size_x); }

	ImGui::Spacing();
	if (flags & dst_draw_line) ImGui::Separator();
}

inline void KeyButtonEx(const char* text, int& key_new)
{
	std::string label = AllKeys[key_new];
	label = "<< " + label + " >> ";

	if (ImGui::KeyButton(label.c_str(), text, ImVec2(label.size() * 8, 20)))
	{
		key_new = 7;

		for (int i = 1; i < 125; i++)
		{
			G::PressedKeys[i] = false;
		}
	}

	if (key_new == 7)
	{
		for (int i = 1; i < 125; i++)
		{
			if (G::PressedKeys[i])
			{
				if (i == 0x1B) // VK_ESCAPE
				{
					key_new = 0;
					break;
				}
				else
				{
					key_new = i;
					break;
				}
			}
		}
	}
}

inline void ByteKeyButton(const char* name, BYTE& byte)
{
	int temporary = byte;
	KeyButtonEx(name, temporary);
	byte = temporary;
}

inline void ColorEdit(const char* label, Color& color, bool alpha)
{
	float col_rgb[3] = { color.rBase(), color.gBase(), color.bBase() };
	float col_rgba[4] = { color.rBase(), color.gBase(), color.bBase(), color.aBase() };

	if (!alpha)
	{
		ImGui::ColorEdit3(label, col_rgb);
		color = Color(col_rgb[0] * 255, col_rgb[1] * 255, col_rgb[2] * 255);
	}
	else if (alpha)
	{
		ImGui::ColorEdit4(label, col_rgba);
		color = Color(col_rgba[0] * 255, col_rgba[1] * 255, col_rgba[2] * 255, col_rgba[3] * 255);
	}
}

inline inline void SpacingX(int x)
{
	for (int i = 0; i < x; i++)
	{
		ImGui::Spacing();
	}
}

inline inline void SelectedText(const char* text)
{
	ImGui::Separator();
	ImGui::Text(text);
	ImGui::Separator();
}

inline void ByteSlider(const char* name, BYTE& byte, int min, int max, const char* format = "%d")
{
	int temporary = byte;
	ImGui::SliderInt(name, &temporary, min, max, format);
	byte = temporary;
}

inline void ByteSlider(const char* name, char& byte, int min, int max, const char* format = "%d")
{
	int temporary = byte;
	ImGui::SliderInt(name, &temporary, min, max, format);
	byte = temporary;
}

inline void ByteCombo(const char* label, BYTE& byte, const char* const items[], int items_count)
{
	int temporary = byte;
	ImGui::Combo(label, &temporary, items, items_count);
	byte = temporary;
}

inline void ByteCombo(const char* label, BYTE& byte, char* const items, int items_count = -1)
{
	int temporary = byte;
	ImGui::Combo(label, &temporary, items, items_count);
	byte = temporary;
}

inline void BoxListCustom(const char* const name_mass[], int names_size, int& flags, int in_line = 1, int in_same_line = 0)
{
	bool cur_flag = false;

	for (int i = 0, cur = 0; i < names_size; ++i, ++cur) // fix this
	{
		if ((int)(i / in_line) != (float)i / (float)in_line) ImGui::SameLine(in_same_line * cur);
		else cur = 0;

		cur_flag = flags & (1 << i);
		ImGui::Checkbox(name_mass[i], &cur_flag);
		cur_flag ? flags |= 1 << i : flags &= ~(1 << i);
	}
}

inline std::string GetCorrectCurrentTime()
{
	time_t seconds = time(NULL);
	auto timeee = localtime(&seconds);

	std::string cur_time = "   "; // for correct draw

	if (timeee->tm_hour < 10) cur_time += "0" + to_str(timeee->tm_hour);
	else cur_time += to_str(timeee->tm_hour);

	cur_time += ":";

	if (timeee->tm_min < 10) cur_time += "0" + to_str(timeee->tm_min);
	else cur_time += to_str(timeee->tm_min);

	cur_time += ":";

	if (timeee->tm_sec < 10) cur_time += "0" + to_str(timeee->tm_sec);
	else cur_time += to_str(timeee->tm_sec);

	return cur_time;
}

inline void SetDefaultMenuColors(ImVec4* colors)
{
	colors[ImGuiCol_Text] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
	colors[ImGuiCol_TextDisabled] = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);
	colors[ImGuiCol_WindowBg] = ImVec4(0.13f, 0.14f, 0.17f, 1.00f);
	colors[ImGuiCol_ChildBg] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
	colors[ImGuiCol_PopupBg] = ImVec4(0.08f, 0.08f, 0.08f, 0.94f);
	colors[ImGuiCol_Border] = ImVec4(0.39f, 0.17f, 0.84f, 0.59f);
	colors[ImGuiCol_BorderShadow] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
	colors[ImGuiCol_FrameBg] = ImVec4(0.361f, 0.259f, 0.980f, 0.414f);
	colors[ImGuiCol_FrameBgHovered] = ImVec4(0.36f, 0.26f, 0.98f, 0.51f);
	colors[ImGuiCol_FrameBgActive] = ImVec4(0.36f, 0.26f, 0.98f, 0.66f);
	colors[ImGuiCol_TitleBg] = colors[ImGuiCol_Border];
	colors[ImGuiCol_TitleBgActive] = colors[ImGuiCol_Border];
	colors[ImGuiCol_TitleBgCollapsed] = colors[ImGuiCol_Border];
	colors[ImGuiCol_MenuBarBg] = ImVec4(0.14f, 0.14f, 0.14f, 1.00f);
	colors[ImGuiCol_ScrollbarBg] = ImVec4(0.02f, 0.02f, 0.02f, 0.53f);
	colors[ImGuiCol_ScrollbarGrab] = colors[ImGuiCol_FrameBg];
	colors[ImGuiCol_ScrollbarGrabHovered] = colors[ImGuiCol_FrameBgHovered];
	colors[ImGuiCol_ScrollbarGrabActive] = colors[ImGuiCol_FrameBgActive];
	colors[ImGuiCol_CheckMark] = ImVec4(0.36f, 0.26f, 0.98f, 0.84f);
	colors[ImGuiCol_SliderGrab] = ImVec4(0.24f, 0.52f, 0.88f, 1.00f);
	colors[ImGuiCol_SliderGrabActive] = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
	colors[ImGuiCol_Button] = ImVec4(0.36f, 0.26f, 0.98f, 0.42f);
	colors[ImGuiCol_ButtonHovered] = ImVec4(0.36f, 0.26f, 0.98f, 0.63f);
	colors[ImGuiCol_ButtonActive] = ImVec4(0.36f, 0.26f, 0.98f, 0.84f);
	colors[ImGuiCol_Header] = ImVec4(0.26f, 0.59f, 0.98f, 0.31f);
	colors[ImGuiCol_HeaderHovered] = ImVec4(0.26f, 0.59f, 0.98f, 0.80f);
	colors[ImGuiCol_HeaderActive] = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
	colors[ImGuiCol_Separator] = colors[ImGuiCol_Border];
	colors[ImGuiCol_SeparatorHovered] = ImVec4(0.10f, 0.40f, 0.75f, 0.78f);
	colors[ImGuiCol_SeparatorActive] = ImVec4(0.10f, 0.40f, 0.75f, 1.00f);
	colors[ImGuiCol_ResizeGrip] = ImVec4(0.26f, 0.59f, 0.98f, 0.25f);
	colors[ImGuiCol_ResizeGripHovered] = ImVec4(0.26f, 0.59f, 0.98f, 0.67f);
	colors[ImGuiCol_ResizeGripActive] = ImVec4(0.26f, 0.59f, 0.98f, 0.95f);
	colors[ImGuiCol_PlotLines] = ImVec4(0.61f, 0.61f, 0.61f, 1.00f);
	colors[ImGuiCol_PlotLinesHovered] = ImVec4(1.00f, 0.43f, 0.35f, 1.00f);
	colors[ImGuiCol_PlotHistogram] = ImVec4(0.00f, 0.35f, 0.00f, 1.00f);
	colors[ImGuiCol_PlotHistogramHovered] = ImVec4(1.00f, 0.60f, 0.00f, 1.00f);
	colors[ImGuiCol_TextSelectedBg] = ImVec4(0.26f, 0.59f, 0.98f, 0.35f);
	colors[ImGuiCol_DragDropTarget] = ImVec4(1.00f, 1.00f, 0.00f, 0.90f);
	colors[ImGuiCol_NavHighlight] = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
	colors[ImGuiCol_NavWindowingHighlight] = ImVec4(1.00f, 1.00f, 1.00f, 0.70f);
	colors[ImGuiCol_NavWindowingDimBg] = ImVec4(0.80f, 0.80f, 0.80f, 0.20f);
	colors[ImGuiCol_ModalWindowDimBg] = ImVec4(0.80f, 0.80f, 0.80f, 0.35f);
}

inline void D3Dinit(IDirect3DDevice9* pDevice)
{
	ImGui::CreateContext();

	ImGui_ImplWin32_Init(G::Window);
	ImGui_ImplDX9_Init(pDevice);

	ImGuiIO& io = ImGui::GetIO();
	font_std = io.Fonts->AddFontFromMemoryTTF(verdana_bytes_data, asize(verdana_bytes_data), 14.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());
	font_big = io.Fonts->AddFontFromMemoryTTF(arialbd_bytes_data, asize(arialbd_bytes_data), 24.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());
	font_cherry = io.Fonts->AddFontFromMemoryTTF(cherry_bytes_data, asize(cherry_bytes_data), 16.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());
	font_undefeated = io.Fonts->AddFontFromMemoryTTF(undefeated_bytes_data, asize(undefeated_bytes_data), 18.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());

	ImGuiStyle& style = ImGui::GetStyle();
	style.Alpha = 1.0f;
	style.WindowRounding = 0.0f;
	style.AntiAliasedLines = true;
	style.AntiAliasedFill = true;
	style.ScrollbarSize = 12.0f;
	style.ButtonTextAlign = ImVec2(0.5f, 0.5f);
	style.WindowTitleAlign = ImVec2(0.5f, 0.5f);
	style.ColumnsMinSpacing = 0.0f;

	SetDefaultMenuColors(style.Colors);

	Config->SetUpSettings();
	LManager.SetUpSettings();

	I::Engine->ClientCmd_Unrestricted("toggleconsole", nullptr);
	I::Engine->ClientCmd_Unrestricted("clear", nullptr);

	I::Engine->ClientCmd_Unrestricted("echo \";   ..:,.;;;L;L;F...:,;;L;L;FyjjEhK5hKOO8S8SESpObb8OBOpb88bbpO8bb8BbQBQBQQgQQBQBQBQBQbbGpOGnzLrL;,  ,,:.... ..:L;;,;;;;,;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";      .;;;;;;;;L:;;;rzyyZFFZGOpG8OQ8Bbb8QBB8bBQBgg8OBbBOBBQBQQGGGGGG@G@G@G@@@@@@@@@@@G@GGQb5yL;;;:. .         ,zc;;;L;;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \",     . ;;;;;;;;,;;;cLFzjFzyh3hKShS5OGES88bpGEOhGGGnGhEEOE8bQQQBQBQQgQgQgQQQgQQBQQgQgQQQQBQbOyL:: .,:.  ,;;;;   ;:;;;;;;;,;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \",      . ..,:::,,;;L;rLLF7cyZE5SSGoE5GE8pbbBSGEOpGhOp85O8BBgQgQgggQgQgggQgQgQQQgQQQgQQQQQQQQQBKr;:   .;cz5ShSL ...;L,;;;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";       ....,;;,;;;;LLrrzrzLyyZK55OE5hp8bBQpG5hOOhGE8bBbQQQBQQgQgQgggggggQgQgQQQgQgQQQgQQQQBgQQpn;;.  .,.:rF7y,   .;;;;;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";.   . .   ..,;;,;,;;LLz;7zcznZhoOGOE8bBbQQBEEKOGOE88QQBBBbQBgQgggQgggQgQgQgQgQgQgggBQQQBQBQBQQgB5LL;;.. . :;;;c;L;;:;;;;;,\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \"L.    .   ..,,;,;,;;;;;;L;cLjnhK558OGEBbBQQQbGpEOO8pbQQOBbQQgggggg@ggQgQgBQQggggQQgQQBQQQQQBQBQQgQby,,7  .   ;z8@g@h.:;;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;   .   ..::;;;,;,;;;;;,;;rzZKEhEObG8pbbQQgb8ObOGpBbQb8pbpQQgg@ggggQQ8BBB8QQQQQBQQgQQQQBQQQQQQg@@gO  :      3j;;LE@7.,;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";L,   .   ..,,;;;;;;;;L;;;;;zzZoS5O8b8bEbbQgQGpOB8SOOS5j5nh5ych53SpGOGESOSEoOOO5O8BbQBQQgQgg@@@gS::;K8G,,;L,nQQoy. Sg:,,;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;       .,:,,;,;;;;;;L;LLLLyoESOOp8bO8bbBg83SpGB5ncr;;;;;L:,;,,;,,,;rnnpphnKKS5OOpQgQgg@@@b7   ;p@BQbKLjQbQgQb8Z.c@L:;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;L,      ..,:,,;,;;;;;;LLrLzcyZhGOEp5hpb8QBOcKEOE5;LLL;L,,;;,:.,:,:;,;;;ro8gQgBQQQQgg@gQZ.   rb@ggQBOQbObQggQgBBO;,@F:;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;r:      ::,.,:,,L;L;L;;;;,;;;;;;j3oy3KOGBn;yOO8pSz7LFryjL;zKGE88BBgg@@@B8EB@@BQg@QG;   .ng@@@QQBB8pBQBg@@ggggB8;L@c.;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;;L.    ..:::.::,;;,;;;,:....   .:,;;;Ljhn;,yhBQ@ggbGzZ3Lnb88OpG88BBQggg@gg3yKppF.   ,8@@g@gQBQbB88ObQgoy8BBQBQBzOb.,,;,;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;;;L     .:::,:. ....,.. ..,:,,;,:...;;c;:,LzSb@@@g@bp7.jSKSKF      ;. ,,;;yc;oE.:Lb@@@@QQBQBQbBbb888QE .zSb8BQgGgL.,;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;;LL.     :,,,,.      .,LFhOb8BQQO8h3z7;;..,L,;;;FOphByhy,;:.       ;:;FZEbBQ8QBQQ@ggQQQgBBbQBQBb8B88bbz:;noOOBgQQ,.;,;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;;,,:.     .:,;,.....;LFjKZ5SShjLF7zrL;. c.  ,r7KBB8LLr8S7;;;;LcLcrjSQg@@@gQ8bpbbbQgQgQQQQBbbBBBbBbB88Q@bz;LyohQQQ::,;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;;: ......    :::.. ;,;;;:      y.:       . .ZbE8Q@@g.,y38BhjyyFZZES8p8pB8bbQbbQQQQQQQQQQBQbbbQBQbBbbO8g@g5L7ZOQgQ;.;,;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;L.    . . :.      :,;;;;      .zLcr;;;:... :yKEbQQ@@B.p5,3bOOSGhOOOSOGppbQgBBQgQQQQBQQQQQbb8BQQBBbBbbhBg8c;zObgBg,,,;,;,\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;;;      ...,::..  ,czyn3oZnczzyn3oZnc;.... ,;ypbQQg@gg;Go3ZohOEO5OOO8b8ObQBBQQBQQQQQQQBQBB8bpQBQQQBBb8SShppQQQpgS.:;;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;;;;.    ...:::,,;:.K;.,,;Lz7yyyzyrrLL;;....;;jbBgggg@@@8ggbhEhhK5ZEGOSKySGb8bbBbQQgQgQQQQbQBBpQQQQQBB8phbQgQQpB@z.,;;,;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;;;;r;.   ....:,;;;:;OF.:,;;LrrLr;L;L;;::::;;;GBgggggggg@@@ggbbOOEEhhoh5OObbBBQQQQQQgQQQQQQQQBBBQQQBB8BpOQgBQbQg8c;,;;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;;;;;LL;.......:,;;r;;hG7L;L;rLLLc;r;;,,,;;;,;nbQgggQgggg@g@QQ8B88p8O8OBbbbBBQQgggQgQQQQQQBQQQbQbQQQbQbBEbQQQQQ8;,;;;;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;;;;;;;;r:  ...:;,;;;;;75hKFyzyFzLc;;;L;L;;;;;yGbQgQgQgQgggQQOo3ESSG8O8pb8QBQBgQgQgQgBQBQBQBQBbBQBQQQbBBbOQbbbgn .;;;;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;;;;;;;;;L.. ..::;:;;L;L;LcjyZyZFyzFzzL;,,;;,rjEpQQgQQBgQQBBBQ5r;;LFnK5OOb8bbQBQQgggQQBQBQQQQQbBBQbQQQBB8p8BbQ@O .;;;;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;;;;;;;;;;;...:.::;,;;LLyZShGGESEKKjz;,..:;;;;ZSbQgQQQQQQ8bbQQQn;,::;;7ySEppbbBQgQQBQQQbQQQQQQQbBQQBQBQbBObg@@@.::;;;;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \",;;;;;;;;;;;;,...:.::;,;;zF535oEo5jycL,.  :;,;,;yppQQgQgQQQQQgggQ8GGy;::,;roS8p88QQQQQBBBQ8QQQBQQQ8QQQBQBB8bObEc  ;;;;;;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;;;;;;;;;;;;,.:...::;;L7zj5K5K5ZyrL,.   L;;;;;ch8bQggQgQgggQbObBQBbEj;;:;;ynEE88BBQBQBQQBBQQQBQbQBQBQBBbB8B;    :,LLL;;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;;;;;;;;;;;L;..:...::;;z7jZ5noK5Zz;;.  :;;;;;zFS8BQgg@QgBbOEnOQgQgBBpOycLL;c7yKGO88BbQBQBQBQQQQQBQBQbQBQbbbO,    ..::,;L;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";,;,;;;;;;;;;;;.......,,LLz7Z333oKEnz;;:;,,:::;LKSp8QggggBbQQQQbQQgQQ8b8b53nc7KK3opOBBQBQBQbBBQBQBQQQBQbQbB8bpby        ;;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \",;,;;;;;;;;;;;;: :.,.::;;LLyy5ZKKh5oFF;;;;;;.. .;ynhObBBZ3SOpBbQQQQQbB8bBQ8QE3KO88ObBQQQBQB8BQQgBQQQbBbBBB8b8pOQO.       ;;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";;;,;,;;;,;;;;L, ..::..:;;rFZZo3ESh3ncrLL;;;;.....,;znhz;zny5O8bQQQBQQQBQQgB8ozy55nhQBQBQBQbBBQQQBQBBb88b8b8bpEOB8.       ;\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \",;,;;;,;;;;;;;;L...::...:;;cLjZ5oSo53F;;;;,;,;;;;LLyyh5SS5nEOBbgg@@@@@@@Q8Sy7y7y;;LSBQbQBQQQbQBQQQBB8bpB8Bbb88SEGbb;      .\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";,;;;;;;;;;,;;;;; ..:....,;;zjSo5KoZ5jL;;;;;;;L;zFE8BQQBQBb88p8OGo3jz;;;73EKno8EF;38QQQBQQQQB8BBQbQbb8bbb8b8bpEKGObBL     .\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \",;;;;;,;,;;;,;;;;. ..:...,,;rno3j3ZKjzL;;;;;;r7jn35G5Oh5KKjZL; ,...::LhQggggbbO5y5GBBQQQQQBQBQbQBB8b8b8B8B8bpbSEGOGbQ;    .\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";,;;;;;;;;;;;;;;L,........,;FFLLnjjynFL,,,;;L;;;;;        ,LjnKGBQgg@@@gQQQQQBbhoEbBQBQBQBBBQBQBB8bpb888bbb888S58EpO8pL.  .\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \",;,;,;,;;;;;;;;;;L. ...:...;zS;LnonK3KL;:......        jcFZpbQg@ggggQgQQbQQQQQbbG88BBQBQBBbQbBbB8bO8pb8BbB888boSpOOpO8cL: .\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";,;,;,;,;;;,;;;;;;;. ...,. :7nZzohpGOE5y;,......;;;;;;888O88BBQQQQQBQQQbQbQQQQQBB8B8bpB8BBB8Q8b8bOp8b8BbBbbO8Ohh8O8ObEz;; .\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \",;,;,;,;,;;;;;;;;;;; ...:;. :LjyrSObpGhSzL;L;;;,.,;FjooEhOE5KEG8bQBQQQQQBBQQQgQQBQbb8b88bQ888Bp8O88bpb8b88O88OnGE8EOOEL;: .\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";,;,;,;,;;;,;,;;;;;;,  ..:;. .Lz77SpbpOZF7c;L;,...:,LcnzLLKn3n5OBBQBQQgBQBBbQQgQQBQ8b8QbBBB8b8bO888pb8b88pb8853EOOOGOK;.. .\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \",,,;,;;;,;,;;;,;;;;;;:   .,;. .;;LyhhphS7Lr7LL;;,,:;;jK5zyKOEGS88bBQBBbb8BbQBQBQQQQQbbbb8bbbp8p8O8Ob8bpb88ObGSKEGpSpSj.   .\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";,;,;,;,;,;,;,;,;;;;;L.   .:;.  ,;7y35Go5;Lc7L7;L;Lco5Go53EEShOG88bO8OppbbQbBQQBQQQbBbB8B8b888b88Ob8B8b8pp8GpSS5pGOGS;.   .\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \",;,;,;,;,;,;,;;;;;,;;;;.   ..,.. .,LLFzyyF;rLrcyzyz3nKojFF7yjKoEObGESpO88QBQQQBQQQBBbBbBbb88Ob8b8b8B88pbObGOOGEOOGoOy.    .\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \";,;,;,;,;,;,;,;;;,;,;,;;. .   ... .:::;;L;rcz;nZ33on7;;;LLnKSSpG8p88b8BbQBQQQBQBQBB8bpb8b88Ob8b8bbBpb8b88G888GOGOEG3;     .\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \",;,;,;,;,;,;,;,;,;;;,;;L;. .   ........:,;;rLcz3h5rL;;;Fzo5OS8Ep8bpBBBBQBQBQBBbB8b8b8bpbO88b8B8b8b8bOb88O8O8pGG8SG3L     ..\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \",,;,;,,,;,;,;,;,;;;,;,;;;;. . . ..... . .:;;L;LLycL;LLynSSOEEhO8B8bbQBQBQQQBQ8bppO88b8b8b8B88pb88pBpbO8O8p8O8E8hE57.     ..\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \",,,;,;,;,;,;,;,;,;,;,;,;;;;. ... . ..... ..,,;;;;cL;;7nhZOEEEpO8bB8BbQQQQQbQb8EpO88bO8p88B8b88p8p8pbpbpbp8O8O8OpEj.    . . \"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \",:,,;,;,;,,,;,;,;,;,;,;,;;c;  ... . ....  ..,,;;;;L;LLyjoEOhSOpObOb8BbQbBbbpphGO8pB8b8pb8bbp8O8O8O8p888p8Opp8ObOo.    . . .\"", nullptr);
	I::Engine->ClientCmd_Unrestricted("echo \":,:,,,,,,;,;,;,,,;,;,;,;;LL   .. ... . ...  .::;,;;L;LLzyOK5oGSOGOpb8bO8GOGhASDADSDSDSDASDSDASDASDASVXVEWETJ%676.    . . ..\"", nullptr);

	G::d3dinit = true;
}

inline void UnloadCheat()
{
	I::Engine->ClientCmd_Unrestricted("crosshair 1", nullptr);

	Materials::DeleteMaterials();
	for (ClientClass* pClass = I::Client->GetAllClasses(); pClass; pClass = pClass->m_pNext)
	{
		if (!strcmp(pClass->m_pNetworkName, ("CBaseViewModel")))
		{
			RecvTable* pClassTable = pClass->m_pRecvTable;

			for (int i = 0; i < pClassTable->m_nProps; ++i)
			{
				RecvProp* pProp = &pClassTable->m_pProps[i];

				if (pProp && !strcmp(pProp->m_pVarName, ("m_nSequence")))
				{
					pProp->m_ProxyFn = reinterpret_cast<RecvVarProxyFn>(oSequenceProxy);
					oSequenceProxy = nullptr;
					break;
				}
			}
		}

		if (!strcmp(pClass->m_pRecvTable->m_pNetTableName, ("DT_BaseViewModel")))
		{
			RecvTable* pClassTable = pClass->m_pRecvTable;

			for (int i = 0; i < pClassTable->m_nProps; ++i)
			{
				RecvProp *pProp = &(pClassTable->m_pProps[i]);

				if (pProp && !strcmp(pProp->m_pVarName, ("m_nModelIndex")))
				{
					pProp->m_ProxyFn = reinterpret_cast<RecvVarProxyFn>(oRecvnModelIndex);
					oRecvnModelIndex = nullptr;
					break;
				}
			}
		}

		if (oSequenceProxy == nullptr && oRecvnModelIndex == nullptr)
			break;
	}

	vmt::vguipanel.Restore();
	vmt::client_mode.Restore();
	vmt::client.Restore();
	vmt::model_render.Restore();
	vmt::surface.Restore();
	vmt::sound_engine.Restore();
	vmt::bsp_query.Restore();
	vmt::render_view.Restore();
	vmt::model_cache.Restore();
	vmt::steam_game_coordinator.Restore();
	vmt::d3d9.Restore();
	vmt::sv_cheats.Restore();

	//BASS_Free();

	// damage
	I::GameEventManager->RemoveListener(Listener::Damage::WeaponFiredListener);
	I::GameEventManager->RemoveListener(Listener::Damage::PlayerHurtListener);
	I::GameEventManager->RemoveListener(Listener::Damage::PlayerDeathListener);

	// item
	I::GameEventManager->RemoveListener(Listener::Item::PurchaseListener);

	// bullet
	I::GameEventManager->RemoveListener(Listener::Bullet::ImpactListener);

	// bomb
	I::GameEventManager->RemoveListener(Listener::Bomb::DefusedListener);
	I::GameEventManager->RemoveListener(Listener::Bomb::BeginDefuseListener);
	I::GameEventManager->RemoveListener(Listener::Bomb::AbortDefuseListener);
	I::GameEventManager->RemoveListener(Listener::Bomb::PlantedListener);
	I::GameEventManager->RemoveListener(Listener::Bomb::ExplodedListener);

	// round
	I::GameEventManager->RemoveListener(Listener::Round::StartListener);

	U::SendCSGOMessages();
	U::ForceFullUpdate();

	if (G::OldZoomSensitivityRatio != 1000) G::ZoomSensitivityRatioConVar->SetValue(-G::OldZoomSensitivityRatio);
	if (G::OldRagdollGravity != 1000) G::RagdollGravityConVar->SetValue(-G::OldRagdollGravity);
	if (G::PostProcessingDisable != 0) *G::PostProcessingDisable = G::OldPostProcessingDisable;

	if (G::old_viewmodel_offset_x != 1000) G::viewmodel_offset_convar_x->SetValue(-G::old_viewmodel_offset_x);
	if (G::old_viewmodel_offset_y != 1000) G::viewmodel_offset_convar_y->SetValue(-G::old_viewmodel_offset_y);
	if (G::old_viewmodel_offset_z != 1000) G::viewmodel_offset_convar_z->SetValue(-G::old_viewmodel_offset_z);

	if (G::old_r_modelAmbientMin != 1000) G::r_modelAmbientMin_convar->SetValue(-G::old_r_modelAmbientMin);
	if (G::old_mat_force_tonemap_scale != 1000) G::mat_force_tonemap_scale_convar->SetValue(-G::old_mat_force_tonemap_scale);

#ifdef DBG_ENABLED

	FreeConsole();

#endif

	I::InputSystem->EnableInput(true);
	SetWindowLongPtr(G::Window, GWL_WNDPROC, (LONG_PTR)Hooks::oldWindowProc);
	Sleep(1);
	FreeLibrary(G::Dll);
}

inline void DrawDynamicRect(ImDrawList* draw_list, ImVec4 def_pos, ImVec4& new_pos, ImColor& color, int item_id, ImVec2& unk1, ImVec4& unk2)
{
	//  def_pos - Left, Top, Left, Bottom

	ImGuiIO& io = ImGui::GetIO();

	draw_list->AddRect(ImVec2(def_pos.x + new_pos.x, def_pos.y + new_pos.y), ImVec2(def_pos.z + new_pos.z, def_pos.w + new_pos.w), ImColor(color));


	if (io.MouseClicked[0])
	{
		//ImGui::Text("clicked - ");
		if ((io.MouseClickedPos->x >= (def_pos.x + new_pos.x) && io.MouseClickedPos->x <= (def_pos.z + new_pos.z)) && (io.MouseClickedPos->y >= (def_pos.y + new_pos.y) && io.MouseClickedPos->y <= (def_pos.w + new_pos.w)))
		{
			current_last_esp_preview_id = item_id;
			current_active_esp_preview_id = item_id;
		}

		unk1.x = io.MouseClickedPos->x;
		unk1.y = io.MouseClickedPos->y;
	}

	if (io.MouseDown[0])
	{
		//ImGui::Text(str(str("pressed - ") + to_str(current_esp_preview_id)).c_str());
		if (current_active_esp_preview_id == item_id)
		{
			draw_list->AddLine(ImVec2(def_pos.x + new_pos.x - 2048, def_pos.y + new_pos.y), ImVec2(def_pos.x + new_pos.x + 2048, def_pos.y + new_pos.y), ImColor(255, 255, 255, 255));
			draw_list->AddLine(ImVec2(def_pos.z + new_pos.z - 2048, def_pos.w + new_pos.w - 1), ImVec2(def_pos.z + new_pos.z + 2048, def_pos.w + new_pos.w - 1), ImColor(255, 255, 255, 255));
			draw_list->AddLine(ImVec2(def_pos.x + new_pos.x, def_pos.y + new_pos.y - 2048), ImVec2(def_pos.x + new_pos.x, def_pos.y + new_pos.y + 2048), ImColor(255, 255, 255, 255));
			draw_list->AddLine(ImVec2(def_pos.z + new_pos.z - 1, def_pos.w + new_pos.w - 2048), ImVec2(def_pos.z + new_pos.z - 1, def_pos.w + new_pos.w + 2048), ImColor(255, 255, 255, 255));

			new_pos.x = io.MousePos.x - unk1.x + unk2.x;
			new_pos.y = io.MousePos.y - unk1.y + unk2.y;
			new_pos.z = io.MousePos.x - unk1.x + unk2.z;
			new_pos.w = io.MousePos.y - unk1.y + unk2.w;
		}
	}
	else
	{
		current_active_esp_preview_id = 0;
		unk2.x = new_pos.x;
		unk2.y = new_pos.y;
		unk2.z = new_pos.z;
		unk2.w = new_pos.w;
	}
}

inline void DrawEspPreview()
{
	static ImVec2 PreviewPos;

	static bool init_pos = false;
	if (!init_pos)
	{
		ImGui::SetNextWindowPos(ImVec2(0, 0));
		init_pos = true;
	}

	ImGui::SetNextWindowSize(ImVec2(300, 500));

	static bool no_move_preview = false;

	if (ImGui::Begin(xs("ESP Preview"), nullptr, no_move_preview ? (ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoMove) : (ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoNav)))
	{
		ImGui::Checkbox(Eng ? xs("No move") : xs(u8"��� ��������"), &no_move_preview);

		PreviewPos = ImGui::GetWindowPos();
		static ImDrawList* DrawList = ImGui::GetWindowDrawList();
		ImVec2 WindowCenter = ImVec2(PreviewPos.x + 150, PreviewPos.y + 250);

		ImColor LinesColor = ImColor(1.0f, 1.0f, 1.0f, 1.0f);
		DrawList->AddLine(ImVec2(PreviewPos.x + 150, PreviewPos.y), ImVec2(PreviewPos.x + 150, PreviewPos.y + 500), LinesColor);
		DrawList->AddLine(ImVec2(PreviewPos.x, PreviewPos.y + 250), ImVec2(PreviewPos.x + 300, PreviewPos.y + 250), LinesColor);

		if (Opts.Visuals.Players.Global.Enabled)
		{
			float Left = WindowCenter.x - 75;
			float Top = WindowCenter.y - 150;
			float Right = WindowCenter.x + 75;
			float Bottom = WindowCenter.y + 150;

			/*

			150
			300

			1/2
			0.5

			*/

			switch (Opts.Visuals.Players.Global.BoxMode)
			{
				/*

				+------+
				|      |
				|      |
				|      |
				|      |
				+------+

				*/

			case 1:
			{
				DrawList->AddRect(ImVec2(Left, Top), ImVec2(Right, Bottom), ImColor(0, 255, 0, 255));
				//if (Opts.Visuals.Players.Global.Outline)
				//{
				//	DrawList->AddRect(ImVec2(WindowCenter.x - 74, WindowCenter.y - 149), ImVec2(WindowCenter.x + 74, WindowCenter.y + 149), ImColor(0, 0, 0, 255));
				//	DrawList->AddRect(ImVec2(WindowCenter.x - 76, WindowCenter.y - 151), ImVec2(WindowCenter.x + 76, WindowCenter.y + 151), ImColor(0, 0, 0, 255));
				//}

				break;
			}
			case 2:
			{
				DrawList->AddLine(ImVec2(Left, Top), ImVec2(Left, WindowCenter.y - 50), ImColor(0, 255, 0, 255));
				DrawList->AddLine(ImVec2(Left, Top), ImVec2(WindowCenter.x - 25, Top), ImColor(0, 255, 0, 255));

				DrawList->AddLine(ImVec2(Right, Bottom), ImVec2(Right, WindowCenter.y + 50), ImColor(0, 255, 0, 255));
				DrawList->AddLine(ImVec2(Right, Bottom), ImVec2(WindowCenter.x + 25, Bottom), ImColor(0, 255, 0, 255));

				DrawList->AddLine(ImVec2(Right, Top), ImVec2(Right, WindowCenter.y - 50), ImColor(0, 255, 0, 255));
				DrawList->AddLine(ImVec2(Right, Top), ImVec2(WindowCenter.x + 25, Top), ImColor(0, 255, 0, 255));

				DrawList->AddLine(ImVec2(Left, Bottom), ImVec2(Left, WindowCenter.y + 50), ImColor(0, 255, 0, 255));
				DrawList->AddLine(ImVec2(Left, Bottom), ImVec2(WindowCenter.x - 25, Bottom), ImColor(0, 255, 0, 255));

				//if (Opts.Visuals.Players.Global.Outline)
				//{

				//}

				break;
			}
			case 3:
			{
				DrawList->AddLine(ImVec2(Left, Top), ImVec2(Left, Bottom), ImColor(0, 255, 0, 255));

				DrawList->AddLine(ImVec2(Left, Top), ImVec2(WindowCenter.x - 25, Top), ImColor(0, 255, 0, 255));
				DrawList->AddLine(ImVec2(Right, Bottom), ImVec2(WindowCenter.x + 25, Bottom), ImColor(0, 255, 0, 255));

				DrawList->AddLine(ImVec2(Right, Top), ImVec2(Right, Bottom), ImColor(0, 255, 0, 255));

				DrawList->AddLine(ImVec2(Right, Top), ImVec2(WindowCenter.x + 25, Top), ImColor(0, 255, 0, 255));
				DrawList->AddLine(ImVec2(Left, Bottom), ImVec2(WindowCenter.x - 25, Bottom), ImColor(0, 255, 0, 255));

				//if (Opts.Visuals.Players.Global.Outline)
				//{

				//}

				break;
			}
			case 4:
			{
				DrawList->AddLine(ImVec2(Left, Top), ImVec2(Left, WindowCenter.y - 50), ImColor(0, 255, 0, 255));
				DrawList->AddLine(ImVec2(Right, Bottom), ImVec2(Right, WindowCenter.y + 50), ImColor(0, 255, 0, 255));

				DrawList->AddLine(ImVec2(Left, Top), ImVec2(Right, Top), ImColor(0, 255, 0, 255));

				DrawList->AddLine(ImVec2(Right, Top), ImVec2(Right, WindowCenter.y - 50), ImColor(0, 255, 0, 255));
				DrawList->AddLine(ImVec2(Left, Bottom), ImVec2(Left, WindowCenter.y + 50), ImColor(0, 255, 0, 255));

				DrawList->AddLine(ImVec2(Left, Bottom), ImVec2(Right, Bottom), ImColor(0, 255, 0, 255));

				//if (Opts.Visuals.Players.Global.Outline)
				//{

				//}

				break;
			}
			case 5:
			{
				DrawList->AddRect(ImVec2(Left, Top), ImVec2(Right, Bottom), ImColor(0, 255, 0, 255));
				DrawList->AddRectFilled(ImVec2(WindowCenter.x - 74, WindowCenter.y - 149), ImVec2(WindowCenter.x + 74, WindowCenter.y + 149), ImColor(0, 255, 0, 60));

				//if (Opts.Visuals.Players.Global.Outline)
				//{

				//}

				break;
			}
			}

			if (Opts.Visuals.Players.Global.Health.Enable)
			{
				static ImVec2 unk1;
				static ImVec4 unk2;

				char width_hp = Opts.Visuals.Players.Global.Health.Width;
				char height_hp = abs(Opts.Visuals.Players.Global.Health.Height);

				if (Opts.Visuals.Players.Global.Health.Type == 0)
				{
					DrawDynamicRect(DrawList, ImVec4(Left - width_hp, Top - height_hp, Left, Bottom), Opts.Visuals.Players.Global.Health.DefaulPos, Opts.Visuals.Players.Global.Health.Outline ? ImColor(Opts.Visuals.Players.Global.Health.Outline_Color.r(), Opts.Visuals.Players.Global.Health.Outline_Color.g(), Opts.Visuals.Players.Global.Health.Outline_Color.b(), Opts.Visuals.Players.Global.Health.Outline_Color.a()) : ImColor(0, 0, 0, 0), 1, unk1, unk2);

					DrawList->AddRectFilled(ImVec2(Left - width_hp + Opts.Visuals.Players.Global.Health.DefaulPos.x + 1, Top - height_hp + Opts.Visuals.Players.Global.Health.DefaulPos.y + 51), ImVec2(Left + Opts.Visuals.Players.Global.Health.DefaulPos.z - 1, Bottom + Opts.Visuals.Players.Global.Health.DefaulPos.w - 1), ImColor(Opts.Visuals.Players.Global.Health.Health_Color.r(), Opts.Visuals.Players.Global.Health.Health_Color.g(), Opts.Visuals.Players.Global.Health.Health_Color.b(), Opts.Visuals.Players.Global.Health.Health_Color.a()));
					DrawList->AddRectFilled(ImVec2(Left - width_hp + Opts.Visuals.Players.Global.Health.DefaulPos.x + 1, Top - height_hp + Opts.Visuals.Players.Global.Health.DefaulPos.y + 1), ImVec2(Left + Opts.Visuals.Players.Global.Health.DefaulPos.z - 1, Top - height_hp + Opts.Visuals.Players.Global.Health.DefaulPos.w + 49), Opts.Visuals.Players.Global.Health.Background ? ImColor(Opts.Visuals.Players.Global.Health.Background_Color.r(), Opts.Visuals.Players.Global.Health.Background_Color.g(), Opts.Visuals.Players.Global.Health.Background_Color.b(), Opts.Visuals.Players.Global.Health.Background_Color.a()) : ImColor(0, 0, 0, 0));

					if (Opts.Visuals.Players.Global.Health.Division > 0)
					{
						float divisions = (Top - height_hp - Bottom) / (Opts.Visuals.Players.Global.Health.Division);

						for (int i = 1; i < Opts.Visuals.Players.Global.Health.Division; ++i)
						{
							DrawList->AddLine(ImVec2(Left - width_hp + Opts.Visuals.Players.Global.Health.DefaulPos.x, Top - height_hp + Opts.Visuals.Players.Global.Health.DefaulPos.y - divisions * i), ImVec2(Left + Opts.Visuals.Players.Global.Health.DefaulPos.z - 1, Top - height_hp + Opts.Visuals.Players.Global.Health.DefaulPos.y - divisions * i), ImColor(0, 0, 0, 255));
						}
					}
				}
				else if (Opts.Visuals.Players.Global.Health.Type == 1)
				{
					DrawDynamicRect(DrawList, ImVec4(Left - width_hp, Bottom - height_hp, Right, Bottom), Opts.Visuals.Players.Global.Health.DefaulPos2, Opts.Visuals.Players.Global.Health.Outline ? ImColor(Opts.Visuals.Players.Global.Health.Outline_Color.r(), Opts.Visuals.Players.Global.Health.Outline_Color.g(), Opts.Visuals.Players.Global.Health.Outline_Color.b(), Opts.Visuals.Players.Global.Health.Outline_Color.a()) : ImColor(0, 0, 0, 0), 1, unk1, unk2);

					DrawList->AddRectFilled(ImVec2(Left - width_hp + Opts.Visuals.Players.Global.Health.DefaulPos2.x + 51, Bottom - height_hp + Opts.Visuals.Players.Global.Health.DefaulPos2.y + 1), ImVec2(Right + Opts.Visuals.Players.Global.Health.DefaulPos2.z - 1, Bottom + Opts.Visuals.Players.Global.Health.DefaulPos2.w - 1), ImColor(Opts.Visuals.Players.Global.Health.Health_Color.r(), Opts.Visuals.Players.Global.Health.Health_Color.g(), Opts.Visuals.Players.Global.Health.Health_Color.b(), Opts.Visuals.Players.Global.Health.Health_Color.a()));
					DrawList->AddRectFilled(ImVec2(Left - width_hp + Opts.Visuals.Players.Global.Health.DefaulPos2.x + 1, Bottom - height_hp + Opts.Visuals.Players.Global.Health.DefaulPos2.y + 1), ImVec2(Right - width_hp + Opts.Visuals.Players.Global.Health.DefaulPos2.z - 101, Bottom + Opts.Visuals.Players.Global.Health.DefaulPos2.w - 1), Opts.Visuals.Players.Global.Health.Background ? ImColor(Opts.Visuals.Players.Global.Health.Background_Color.r(), Opts.Visuals.Players.Global.Health.Background_Color.g(), Opts.Visuals.Players.Global.Health.Background_Color.b(), Opts.Visuals.Players.Global.Health.Background_Color.a()) : ImColor(0, 0, 0, 0));

					if (Opts.Visuals.Players.Global.Health.Division > 0)
					{
						float divisions = (Left - width_hp - Right) / (Opts.Visuals.Players.Global.Health.Division);

						for (int i = 1; i < Opts.Visuals.Players.Global.Health.Division; ++i)
						{
							DrawList->AddLine(ImVec2(Left - width_hp + Opts.Visuals.Players.Global.Health.DefaulPos2.x - divisions * i, Bottom - height_hp + Opts.Visuals.Players.Global.Health.DefaulPos2.y), ImVec2(Left - width_hp + Opts.Visuals.Players.Global.Health.DefaulPos2.x - divisions * i, Bottom + Opts.Visuals.Players.Global.Health.DefaulPos2.w - 1), ImColor(0, 0, 0, 255));
						}
					}
				}
			}

			//if (Opts.Visuals.Players.Global.Armor.Enable)
			//{
			//	static ImVec2 unk1;
			//	static ImVec4 unk2;
			//
			//	char width_hp = Opts.Visuals.Players.Global.Armor.Width;
			//	char height_hp = abs(Opts.Visuals.Players.Global.Armor.Height);
			//
			//	if (Opts.Visuals.Players.Global.Armor.Type == 0)
			//	{
			//		DrawDynamicRect(DrawList, ImVec4(Right + width_hp, Bottom + height_hp, Right, Top), Opts.Visuals.Players.Global.Armor.DefaulPos, Opts.Visuals.Players.Global.Armor.Outline ? ImColor(Opts.Visuals.Players.Global.Armor.Outline_Color.r(), Opts.Visuals.Players.Global.Armor.Outline_Color.g(), Opts.Visuals.Players.Global.Armor.Outline_Color.b(), Opts.Visuals.Players.Global.Armor.Outline_Color.a()) : ImColor(0, 0, 0, 0), 2, unk1, unk2);
			//
			//		DrawList->AddRectFilled(ImVec2(Right + width_hp + Opts.Visuals.Players.Global.Armor.DefaulPos.x + 1, Bottom + height_hp + Opts.Visuals.Players.Global.Armor.DefaulPos.y + 51), ImVec2(Right + Opts.Visuals.Players.Global.Armor.DefaulPos.z - 1, Top + Opts.Visuals.Players.Global.Armor.DefaulPos.w - 1), ImColor(Opts.Visuals.Players.Global.Armor.Armor_Color.r(), Opts.Visuals.Players.Global.Armor.Armor_Color.g(), Opts.Visuals.Players.Global.Armor.Armor_Color.b(), Opts.Visuals.Players.Global.Armor.Armor_Color.a()));
			//		DrawList->AddRectFilled(ImVec2(Right + width_hp + Opts.Visuals.Players.Global.Armor.DefaulPos.x + 1, Bottom + height_hp + Opts.Visuals.Players.Global.Armor.DefaulPos.y + 1), ImVec2(Right + Opts.Visuals.Players.Global.Armor.DefaulPos.z - 1, Bottom + height_hp + Opts.Visuals.Players.Global.Armor.DefaulPos.w + 49), Opts.Visuals.Players.Global.Armor.Background ? ImColor(Opts.Visuals.Players.Global.Armor.Background_Color.r(), Opts.Visuals.Players.Global.Armor.Background_Color.g(), Opts.Visuals.Players.Global.Armor.Background_Color.b(), Opts.Visuals.Players.Global.Armor.Background_Color.a()) : ImColor(0, 0, 0, 0));
			//
			//		if (Opts.Visuals.Players.Global.Armor.Division > 0)
			//		{
			//			float divisions = (Bottom - height_hp - Top) / (Opts.Visuals.Players.Global.Armor.Division);
			//
			//			for (int i = 1; i < Opts.Visuals.Players.Global.Armor.Division; ++i)
			//			{
			//				DrawList->AddLine(ImVec2(Right - width_hp + Opts.Visuals.Players.Global.Armor.DefaulPos.x, Bottom - height_hp + Opts.Visuals.Players.Global.Armor.DefaulPos.y - divisions * i), ImVec2(Right + Opts.Visuals.Players.Global.Armor.DefaulPos.z - 1, Bottom - height_hp + Opts.Visuals.Players.Global.Armor.DefaulPos.y - divisions * i), ImColor(0, 0, 0, 255));
			//			}
			//		}
			//	}
			//	else if (Opts.Visuals.Players.Global.Armor.Type == 1)
			//	{
			//		DrawDynamicRect(DrawList, ImVec4(Right - width_hp, Top - height_hp, Right, Top), Opts.Visuals.Players.Global.Armor.DefaulPos2, Opts.Visuals.Players.Global.Armor.Outline ? ImColor(Opts.Visuals.Players.Global.Armor.Outline_Color.r(), Opts.Visuals.Players.Global.Armor.Outline_Color.g(), Opts.Visuals.Players.Global.Armor.Outline_Color.b(), Opts.Visuals.Players.Global.Armor.Outline_Color.a()) : ImColor(0, 0, 0, 0), 1, unk1, unk2);
			//
			//		DrawList->AddRectFilled(ImVec2(Right - width_hp + Opts.Visuals.Players.Global.Armor.DefaulPos2.x + 51, Top - height_hp + Opts.Visuals.Players.Global.Armor.DefaulPos2.y + 1), ImVec2(Right + Opts.Visuals.Players.Global.Armor.DefaulPos2.z - 1, Top + Opts.Visuals.Players.Global.Armor.DefaulPos2.w - 1), ImColor(Opts.Visuals.Players.Global.Armor.Armor_Color.r(), Opts.Visuals.Players.Global.Armor.Armor_Color.g(), Opts.Visuals.Players.Global.Armor.Armor_Color.b(), Opts.Visuals.Players.Global.Armor.Armor_Color.a()));
			//		DrawList->AddRectFilled(ImVec2(Right - width_hp + Opts.Visuals.Players.Global.Armor.DefaulPos2.x + 1, Top - height_hp + Opts.Visuals.Players.Global.Armor.DefaulPos2.y + 1), ImVec2(Right - width_hp + Opts.Visuals.Players.Global.Armor.DefaulPos2.z - 101, Top + Opts.Visuals.Players.Global.Armor.DefaulPos2.w - 1), Opts.Visuals.Players.Global.Armor.Background ? ImColor(Opts.Visuals.Players.Global.Armor.Background_Color.r(), Opts.Visuals.Players.Global.Armor.Background_Color.g(), Opts.Visuals.Players.Global.Armor.Background_Color.b(), Opts.Visuals.Players.Global.Armor.Background_Color.a()) : ImColor(0, 0, 0, 0));
			//
			//		if (Opts.Visuals.Players.Global.Armor.Division > 0)
			//		{
			//			float divisions = (Right - width_hp - Right) / (Opts.Visuals.Players.Global.Armor.Division);
			//
			//			for (int i = 1; i < Opts.Visuals.Players.Global.Armor.Division; ++i)
			//			{
			//				DrawList->AddLine(ImVec2(Right - width_hp + Opts.Visuals.Players.Global.Armor.DefaulPos2.x - divisions * i, Top - height_hp + Opts.Visuals.Players.Global.Armor.DefaulPos2.y), ImVec2(Right - width_hp + Opts.Visuals.Players.Global.Armor.DefaulPos2.x - divisions * i, Top + Opts.Visuals.Players.Global.Armor.DefaulPos2.w - 1), ImColor(0, 0, 0, 255));
			//			}
			//		}
			//	}
			//}
		}

		/*

		name
		money
		weapon

		hp bar
		armor bar

		*/

		ImGui::End();
	}

	ImGui::SetNextWindowPos(ImVec2(PreviewPos.x, PreviewPos.y + 500));
	ImGui::SetNextWindowSize(ImVec2(300, 100));

	if (ImGui::Begin(xs("PreviewDop"), nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoTitleBar))
	{
		switch (current_last_esp_preview_id)
		{
			// ImGui::Text(Eng ? xs("���� 1 ���� 2 ���� 3 ���� 4 ���� 5 ���� 6 ���� 7 �")); // max 50

		case 1: // health bar
		{
			if (Opts.Visuals.Players.Global.Health.Enable)
			{
				ImGui::Text(Eng ? xs("Health bar settings") : xs(u8"��������� ������� �����"));

				ImGui::Checkbox(Eng ? xs("Outline") : xs(u8"������"), &Opts.Visuals.Players.Global.Health.Outline);
				ImGui::SameLine();
				ImGui::Checkbox(Eng ? xs("Background") : xs(u8"���"), &Opts.Visuals.Players.Global.Health.Background);
				ImGui::SameLine();
				if (ImGui::Button(Eng ? xs("Reset") : xs(u8"��������")))
				{
					if (Opts.Visuals.Players.Global.Health.Type == 0)
					{
						Opts.Visuals.Players.Global.Health.DefaulPos = ImVec4(-6, -1, -2, +1);
					}
					else if (Opts.Visuals.Players.Global.Health.Type == 1)
					{
						Opts.Visuals.Players.Global.Health.DefaulPos2 = ImVec4(-1, +2, +1, +6);
					}
				}

				ByteCombo(Eng ? xs("Type") : xs(u8"���"), Opts.Visuals.Players.Global.Health.Type, Eng ? BarType : BarTypeRus, asize(BarType));

				ByteSlider(Eng ? xs("Division") : xs(u8"�������"), Opts.Visuals.Players.Global.Health.Division, 1, 10);

				ByteSlider(Eng ? xs("Width") : xs(u8"������"), Opts.Visuals.Players.Global.Health.Width, 0, 10);
				ByteSlider(Eng ? xs("Height") : xs(u8"������"), Opts.Visuals.Players.Global.Health.Height, 0, 10);

				ColorEdit(Eng ? xs("Outline color") : xs(u8"���� �������"), Opts.Visuals.Players.Global.Health.Outline_Color, true);
				ColorEdit(Eng ? xs("Back color") : xs(u8"���� ����"), Opts.Visuals.Players.Global.Health.Background_Color, true);
				ColorEdit(Eng ? xs("Health color") : xs(u8"���� �����"), Opts.Visuals.Players.Global.Health.Health_Color, true);
			}

			break;
		}
		//case 2: // armor bar
		//{
		//	if (Opts.Visuals.Players.Global.Armor.Enable)
		//	{
		//		ImGui::Text(Eng ? xs("Armor bar settings") : xs(u8"��������� ������� �����"));
		//
		//		ImGui::Checkbox(Eng ? xs("Outline") : xs(u8"������"), &Opts.Visuals.Players.Global.Armor.Outline);
		//		ImGui::SameLine();
		//		ImGui::Checkbox(Eng ? xs("Background") : xs(u8"���"), &Opts.Visuals.Players.Global.Armor.Background);
		//		ImGui::SameLine();
		//		if (ImGui::Button(Eng ? xs("Reset") : xs(u8"��������")))
		//		{
		//			if (Opts.Visuals.Players.Global.Armor.Type == 0)
		//			{
		//				Opts.Visuals.Players.Global.Armor.DefaulPos = ImVec4(+6, +1, +2, -1);
		//			}
		//			else if (Opts.Visuals.Players.Global.Armor.Type == 1)
		//			{
		//				Opts.Visuals.Players.Global.Armor.DefaulPos2 = ImVec4(+1, -2, -1, -6);
		//			}
		//		}
		//
		//		ByteCombo(Eng ? xs("Type") : xs(u8"���"), Opts.Visuals.Players.Global.Armor.Type, Eng ? BarType : BarTypeRus, asize(BarType));
		//
		//		ByteSlider(Eng ? xs("Division") : xs(u8"�������"), Opts.Visuals.Players.Global.Armor.Division, 1, 10);
		//
		//		ByteSlider(Eng ? xs("Width") : xs(u8"������"), Opts.Visuals.Players.Global.Armor.Width, 0, 10);
		//		ByteSlider(Eng ? xs("Height") : xs(u8"������"), Opts.Visuals.Players.Global.Armor.Height, 0, 10);
		//
		//		ColorEdit(Eng ? xs("Outline color") : xs(u8"���� �������"), Opts.Visuals.Players.Global.Armor.Outline_Color, true);
		//		ColorEdit(Eng ? xs("Back color") : xs(u8"���� ����"), Opts.Visuals.Players.Global.Armor.Background_Color, true);
		//		ColorEdit(Eng ? xs("Armor color") : xs(u8"���� �����"), Opts.Visuals.Players.Global.Armor.Armor_Color, true);
		//	}
		//
		//	break;
		//}
		default:
			break;
		}

		ImGui::End();
	}
}

inline void MenuV1()
{
	ImGui::PushFont(font_std);
	ImGui::SetNextWindowSize(ImVec2(800, 40));

	static bool old_eng = false;
	static ImVec2 pos = ImVec2((G::ScreenWidth - 700) / 2, (G::ScreenHeight - 500) / 2);

	if (old_eng != Eng)
	{
		old_eng = Eng;
		ImGui::SetNextWindowPos(pos, 0);
	}

	static int ActiveSubTab = 0;

	if (ImGui::Begin(xs("Title"), nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar, 10, ImDrawCornerFlags_Top))
	{
		ImGui::PushFont(font_big);
		static float r = 1.00f, g = 0.00f, b = 1.00f;
		ImGui::TextColored(ImVec4(r, g, b, 1.00f), xs("  Nikitapidor.cc  "));
		ImGui::PopFont();

		static int cases = 0;

		switch (cases)
		{
		case 0: { r -= 0.005f; if (r <= 0) cases += 1; break; }
		case 1: { g += 0.005f; b -= 0.005f; if (g >= 1) cases += 1; break; }
		case 2: { r += 0.005f; if (r >= 1) cases += 1; break; }
		case 3: { b += 0.005f; g -= 0.005f; if (b >= 1) cases = 0; break; }
		default: { r = 1.00f; g = 0.00f; b = 1.00f; break; }
		}

		ImGui::SameLine();

		static int OldMainTabIndex = G::MainTabIndex;

		if (OldMainTabIndex != G::MainTabIndex)
		{
			OldMainTabIndex = G::MainTabIndex;
			ActiveSubTab = 0;
		}

		switch (G::MainTabIndex)
		{
		case 0: { DrawSubTabsTest(Eng ? RageSubTabs : RageSubTabsRus, ARRAYSIZE(RageSubTabs), ActiveSubTab, dst_font_std | dst_push_style_item_spacing | dst_draw_same_line, 632);  break; }
		case 1: { DrawSubTabsTest(Eng ? LegitSubTabs : LegitSubTabsRus, ARRAYSIZE(LegitSubTabs), ActiveSubTab, dst_font_std | dst_push_style_item_spacing | dst_draw_same_line, 632);  break; }
		case 2: { DrawSubTabsTest(Eng ? VisualsSubTabs : VisualsSubTabsRus, ARRAYSIZE(VisualsSubTabs), ActiveSubTab, dst_font_std | dst_push_style_item_spacing | dst_draw_same_line, 632);  break; }
		case 3: { DrawSubTabsTest(Eng ? ChangerSubTabs : ChangerSubTabsRus, ARRAYSIZE(ChangerSubTabs), ActiveSubTab, dst_font_std | dst_push_style_item_spacing | dst_draw_same_line, 632);  break; }
		case 4: { DrawSubTabsTest(Eng ? MiscSubTabs : MiscSubTabsRus, ARRAYSIZE(MiscSubTabs), ActiveSubTab, dst_font_std | dst_push_style_item_spacing | dst_draw_same_line, 632);  break; }
		default: return;
		}

		pos = ImGui::GetWindowPos();

		ImGui::End();
	}

	ImGui::SetNextWindowSize(ImVec2(100, 400));
	ImGui::SetNextWindowPos(ImVec2(pos.x, pos.y + 50), 0);
	if (ImGui::Begin(xs("MainTabs"), nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoMove, 10, ImDrawCornerFlags_BotLeft))
	{
		DrawSubTabsTest(Eng ? TopSubTabs : TopSubTabsRus, ARRAYSIZE(TopSubTabs), G::MainTabIndex, dst_font_cherry, -1);

		static bool Rus = !Eng;

		bool cur_eng = Eng;

		ImGui::Checkbox(xs("En"), &Eng);
		ImGui::SameLine();
		ImGui::Checkbox(xs("Ru"), &Rus);

		if (cur_eng != Rus || Eng == Rus)
		{
			if (cur_eng && Rus) { Rus = true; Eng = false; }
			else if (!cur_eng && !Rus) { Rus = true; Eng = false; }
			else if (cur_eng && !Eng) { Rus = false; Eng = true; }
			else if (!cur_eng && Eng) { Rus = false; Eng = true; }
		}

		ImGui::PushItemWidth(-1.f);
		ImGui::Combo("##menu_style", &Opts.Menu.Style, Eng ? MenuStyleVars : MenuStyleVarsRus, asize(MenuStyleVars));
		ImGui::PopItemWidth();

#ifdef TEST_FULL_MODE
		SpacingX(36);
		ImGui::Text(std::string(rXor("   Test ver ") + std::string(TEST_FULL_MODE_CURRENT_VERSION)).c_str());
#else
		SpacingX(40);
#endif


		ImGui::Text(GetCorrectCurrentTime().c_str());

		static bool init_vesion = false;

		if (!init_vesion)
		{
			init_vesion = true;
		}

		static std::string ver = rXor("  ver. - ");
		static std::string version = rXor(CURRENT_VERSION);

		ImGui::Text(std::string(ver + version).c_str());

		ImGui::End();
	}

	ImGui::SetNextWindowSize(ImVec2(690, 400));
	ImGui::SetNextWindowPos(ImVec2(pos.x + 110, pos.y + 50), 0);
	if (ImGui::Begin(xs("Functions"), nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoMove, 10, ImDrawCornerFlags_BotRight))
	{
		static int LegitWeapon = 0;

		if (G::MainTabIndex == 0) // selected RageSubTub
		{
			G::RageUpdate = true;

			static int Type = 0;
			static int Weapon = 0;
			static int weapon = 0;

			if (ActiveSubTab == 0)
			{

				if (Opts.RageBot.AimBot.SettingMode != 0)
				{
					DrawSubTabs(Eng ? WeaponTypes : WeaponTypesRus, ARRAYSIZE(WeaponTypes), Type, true, 602, false);

					if (G::LocalPlayer && G::LocalPlayer->GetWeapon()->IsFiredWeaponType())
					{
						ImGui::SameLine();
						if (ImGui::Button(Eng ? xs("Current") : xs(u8"�������"), ImVec2(93, 24)))
						{
							Type = G::LocalPlayer->GetWeapon()->GetType() - 4;

							if (Opts.RageBot.AimBot.SettingMode == 2)
							{
								switch (Type)
								{
								case 0: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex(); break;
								case 1: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 10; break;
								case 2: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 17; break;
								case 3: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 24; break;
								case 4: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 28; break;
								case 5: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 32; break;
								default: break;
								}
							}
						}
					}

					ImGui::Spacing();

					// setting for every gun
					if (Opts.RageBot.AimBot.SettingMode == 2)
					{
						switch (Type)
						{
						case 0:
							if (weapon < 0) weapon = 0;
							if (weapon > 9) weapon = 9;
							ImGui::Combo(Eng ? xs(" weapon") : xs(u8" ������"), &weapon, Pistols, asize(Pistols));
							Weapon = weapon; break;
						case 1:
							if (weapon < 0) weapon = 0;
							if (weapon > 6) weapon = 6;
							ImGui::Combo(Eng ? xs(" weapon") : xs(u8" ������"), &weapon, SMG, asize(SMG));
							Weapon = 10 + weapon; break;
						case 2:
							if (weapon < 0) weapon = 0;
							if (weapon > 6) weapon = 6;
							ImGui::Combo(Eng ? xs(" weapon") : xs(u8" ������"), &weapon, Rifler, asize(Rifler));
							Weapon = 17 + weapon; break;
						case 3:
							if (weapon < 0) weapon = 0;
							if (weapon > 3) weapon = 3;
							ImGui::Combo(Eng ? xs(" weapon") : xs(u8" ������"), &weapon, Snipers, asize(Snipers));
							Weapon = 24 + weapon; break;
						case 4:
							if (weapon < 0) weapon = 0;
							if (weapon > 3) weapon = 3;
							ImGui::Combo(Eng ? xs(" weapon") : xs(u8" ������"), &weapon, Shotguns, asize(Shotguns));
							Weapon = 28 + weapon; break;
						case 5:
							if (weapon < 0) weapon = 0;
							if (weapon > 1) weapon = 1;
							ImGui::Combo(Eng ? xs(" weapon") : xs(u8" ������"), &weapon, Machinguns, asize(Machinguns));
							Weapon = 32 + weapon; break;
						default: break;
						}
					}
				}

				ByteCombo(Eng ? xs(" setting mode") : xs(u8" ����� ���������"), Opts.RageBot.AimBot.SettingMode, Eng ? SettingRageMode : SettingRageModeRus, asize(SettingRageMode));

				ImGui::Separator();

				ImGui::Checkbox(Eng ? xs("Enable aim") : xs(u8"�������� ���"), &Opts.RageBot.AimBot.Enabled);
				ImGui::SameLine();
				ByteKeyButton(Eng ? xs("BAim key") : xs(u8"������ �����"), Opts.RageBot.AimBot.BAimKey);

				ImGui::Spacing();

				ImGui::Checkbox(Eng ? xs("Shoot the team") : xs(u8"�������� �� �������"), &Opts.RageBot.AimBot.FriendlyFire);

				ImGui::Spacing();

				if (Opts.RageBot.AimBot.SettingMode == 0)
				{
					BoxListCustom(Eng ? list_bones : list_bones_rus, 6, Opts.RageBot.AimBot.All_Rage.Bone, 3, 100);
				}
				else if (Opts.RageBot.AimBot.SettingMode == 1)
				{
					BoxListCustom(Eng ? list_bones : list_bones_rus, 6, Opts.RageBot.AimBot.WT_Rage[Type].Bone, 3, 100);
				}
				else if (Opts.RageBot.AimBot.SettingMode == 2)
				{
					BoxListCustom(Eng ? list_bones : list_bones_rus, 6, Opts.RageBot.AimBot.EW_Rage[Weapon].Bone, 3, 100);
				}
				ImGui::Spacing();

				ImGui::Checkbox(Eng ? xs("Resolver") : xs(u8"���� ��"), &Opts.RageBot.AimBot.Resolver);
				ImGui::Checkbox(Eng ? xs("Override") : xs(u8"����������� ���� ��"), &Opts.RageBot.AimBot.Override);
				if (Opts.RageBot.AimBot.Override)
				{
					ImGui::SameLine();
					ByteKeyButton(Eng ? xs(" key") : xs(u8" ������"), Opts.RageBot.AimBot.OverrideKey);
				}

				ImGui::Spacing();

				ImGui::Checkbox(Eng ? xs("Auto revolver") : xs(u8"����. ���������"), &Opts.RageBot.AimBot.AutoRevolver);
				ImGui::Checkbox(Eng ? xs("Auto wall") : xs(u8"�������� ����� �����"), &Opts.RageBot.AimBot.AutoWall);
				ImGui::SameLine();
				ImGui::Checkbox(Eng ? xs("Auto scope") : xs(u8"����. ����"), &Opts.RageBot.AimBot.AutoScope);
				ImGui::SameLine();
				ImGui::Checkbox(Eng ? xs("Auto stop") : xs(u8"����. ������������"), &Opts.RageBot.AimBot.AutoStop);

				ImGui::Spacing();

				if (Opts.RageBot.AimBot.SettingMode == 0) // for all weapons //////////////////////////////////////////////
				{
					ImGui::Checkbox(Eng ? xs("BAim health") : xs(u8"�������� ��� �����"), &Opts.RageBot.AimBot.All_Rage.bBAimHealth);
					if (Opts.RageBot.AimBot.All_Rage.bBAimHealth)
					{
						ImGui::SameLine();
						ByteSlider(xs("##Health"), Opts.RageBot.AimBot.All_Rage.iBAimHealth, 1, 100, Eng ? xs("Health: %d") : xs(u8"��������: %d"));
					}

					ImGui::Checkbox(Eng ? xs("BAim miss") : xs(u8"������� ��� �����"), &Opts.RageBot.AimBot.All_Rage.bBAimMiss);
					if (Opts.RageBot.AimBot.All_Rage.bBAimMiss)
					{
						ImGui::SameLine();
						ByteSlider(xs("##Miss"), Opts.RageBot.AimBot.All_Rage.iBAimMiss, 1, 20, Eng ? xs("Miss: %d") : xs(u8"�������: %d"));
					}

					ImGui::Spacing();

					ImGui::SliderFloat(xs("##Hitchance"), &Opts.RageBot.AimBot.All_Rage.HitChance, 1.f, 100.f, Eng ? xs("Hitchance: %.2f") : xs(u8"�������: %.2f"));
					ImGui::SliderFloat(xs("##Min_damage"), &Opts.RageBot.AimBot.All_Rage.MinDamage, 1.f, 100.f, Eng ? xs("Min damage: %.2f") : xs(u8"���. ����: %.2f"));
				}
				else if (Opts.RageBot.AimBot.SettingMode == 1) // every weapon group //////////////////////////////////////////////
				{
					ImGui::Checkbox(Eng ? xs("BAim health") : xs(u8"�������� ��� �����"), &Opts.RageBot.AimBot.WT_Rage[Type].bBAimHealth);
					if (Opts.RageBot.AimBot.WT_Rage[Type].bBAimHealth)
					{
						ImGui::SameLine();
						ByteSlider(xs("##Health"), Opts.RageBot.AimBot.WT_Rage[Type].iBAimHealth, 1, 100, Eng ? xs("Health: %d") : xs(u8"��������: %d"));
					}

					ImGui::Checkbox(Eng ? xs("BAim miss") : xs(u8"������� ��� �����"), &Opts.RageBot.AimBot.WT_Rage[Type].bBAimMiss);
					if (Opts.RageBot.AimBot.WT_Rage[Type].bBAimMiss)
					{
						ImGui::SameLine();
						ByteSlider(xs("##Miss"), Opts.RageBot.AimBot.WT_Rage[Type].iBAimMiss, 1, 20, Eng ? xs("Miss: %d") : xs(u8"�������: %d"));
					}

					ImGui::Spacing();

					ImGui::SliderFloat(xs("##Hitchance"), &Opts.RageBot.AimBot.WT_Rage[Type].HitChance, 1.f, 100.f, Eng ? xs("Hitchance: %.2f") : xs(u8"�������: %.2f"));
					ImGui::SliderFloat(xs("##Min_damage"), &Opts.RageBot.AimBot.WT_Rage[Type].MinDamage, 1.f, 100.f, Eng ? xs("Min damage: %.2f") : xs(u8"���. ����: %.2f"));
				}
				else if (Opts.RageBot.AimBot.SettingMode == 2) // every weapon //////////////////////////////////////////////
				{
					ImGui::Checkbox(Eng ? xs("BAim health") : xs(u8"�������� ��� �����"), &Opts.RageBot.AimBot.EW_Rage[Weapon].bBAimHealth);
					if (Opts.RageBot.AimBot.EW_Rage[Weapon].bBAimHealth)
					{
						ImGui::SameLine();
						ByteSlider(xs("##Health"), Opts.RageBot.AimBot.EW_Rage[Weapon].iBAimHealth, 1, 100, Eng ? xs("Health: %d") : xs(u8"��������: %d"));
					}

					ImGui::Checkbox(Eng ? xs("BAim miss") : xs(u8"������� ��� �����"), &Opts.RageBot.AimBot.EW_Rage[Weapon].bBAimMiss);
					if (Opts.RageBot.AimBot.EW_Rage[Weapon].bBAimMiss)
					{
						ImGui::SameLine();
						ByteSlider(xs("##Miss"), Opts.RageBot.AimBot.EW_Rage[Weapon].iBAimMiss, 1, 20, Eng ? xs("Miss: %d") : xs(u8"�������: %d"));
					}

					ImGui::Spacing();

					ImGui::SliderFloat(xs("##Hitchance"), &Opts.RageBot.AimBot.EW_Rage[Weapon].HitChance, 1.f, 100.f, Eng ? xs("Hitchance: %.2f") : xs(u8"�������: %.2f"));
					ImGui::SliderFloat(xs("##Min_damage"), &Opts.RageBot.AimBot.EW_Rage[Weapon].MinDamage, 1.f, 100.f, Eng ? xs("Min damage: %.2f") : xs(u8"���. ����: %.2f"));
				}
			}
			else if (ActiveSubTab == 1)
			{
				ImGui::Checkbox(Eng ? xs("Enable") : xs(u8"��������"), &Opts.RageBot.AntiAims.Enabled);

				static BYTE setting_mode = 0; // 0 - ground // 1 - air // 2 - in run
				ByteCombo(Eng ? xs(" setting mode") : xs(u8" ����� ���������"), setting_mode, Eng ? rage_aa_set_mode : rage_aa_set_mode_rus, asize(rage_aa_set_mode));
				ImGui::Separator();
				ImGui::Checkbox(Eng ? xs("Custom angles") : xs(u8"���� ����"), &Opts.RageBot.AntiAims.CustomAngles);

				if (Opts.RageBot.AntiAims.CustomAngles)
				{
					ImGui::SliderInt(Eng ? xs("Custom pith") : xs(u8"���� ����"), &Opts.RageBot.AntiAims.Custom[setting_mode * 2], -89, 89);
					ImGui::SliderInt(Eng ? xs("Custom yaw") : xs(u8"���� ���"), &Opts.RageBot.AntiAims.Custom[setting_mode * 2 + 1], -180, 180);
				}
				else
				{
					ByteCombo(Eng ? xs("Real pitch") : xs(u8"����. ����"), Opts.RageBot.AntiAims.Real[setting_mode * 2], AntiAimPitch, asize(AntiAimPitch));
					ByteCombo(Eng ? xs("Real yaw") : xs(u8"����. ���"), Opts.RageBot.AntiAims.Real[setting_mode * 2 + 1], AntiAimYaw, asize(AntiAimYaw));

					if (Opts.RageBot.AntiAims.Real[setting_mode * 2 + 1] == 12)
					{
						ByteKeyButton(Eng ? xs("Left key") : xs(u8"������ ������"), Opts.RageBot.AntiAims.ManualKey[setting_mode * 3]);
						ByteKeyButton(Eng ? xs("Back key") : xs(u8"������ �����"), Opts.RageBot.AntiAims.ManualKey[setting_mode * 3 + 1]);
						ByteKeyButton(Eng ? xs("Right key") : xs(u8"������ �������"), Opts.RageBot.AntiAims.ManualKey[setting_mode * 3 + 2]);

					}
				}

				ByteCombo(Eng ? xs("Desync type") : xs(u8"��� ��������"), Opts.RageBot.AntiAims.DesyncType[setting_mode], DesyncYaw, asize(DesyncYaw));
			}
		}
		else if (G::MainTabIndex == 1) // selected LegitSubTub
		{
			G::LegitUpdate = true;

			static int Type = 0;
			static int Weapon = 0;
			static int weapon = 0;

			if (Opts.LegitBot.SettingMode != 0)
			{
				DrawSubTabs(Eng ? WeaponTypes : WeaponTypesRus, ARRAYSIZE(WeaponTypes), Type, true, 602, false);

				if (G::LocalPlayer && G::LocalPlayer->GetWeapon()->IsFiredWeaponType())
				{
					ImGui::SameLine();
					if (ImGui::Button(Eng ? xs("Current") : xs(u8"�������"), ImVec2(93, 24)))
					{
						Type = G::LocalPlayer->GetWeapon()->GetType() - 4;

						if (Opts.LegitBot.SettingMode == 2)
						{
							switch (Type)
							{
							case 0: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex(); break;
							case 1: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 10; break;
							case 2: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 17; break;
							case 3: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 24; break;
							case 4: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 28; break;
							case 5: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 32; break;
							default: break;
							}
						}
					}
				}

				ImGui::Spacing();

				// setting for every gun
				if (Opts.LegitBot.SettingMode != 1)
				{
					switch (Type)
					{
					case 0:
						if (weapon < 0) weapon = 0;
						if (weapon > 9) weapon = 9;
						ImGui::Combo(Eng ? xs(" weapon") : xs(u8" ������"), &weapon, Pistols, asize(Pistols));
						Weapon = weapon; break;
					case 1:
						if (weapon < 0) weapon = 0;
						if (weapon > 6) weapon = 6;
						ImGui::Combo(Eng ? xs(" weapon") : xs(u8" ������"), &weapon, SMG, asize(SMG));
						Weapon = 10 + weapon; break;
					case 2:
						if (weapon < 0) weapon = 0;
						if (weapon > 6) weapon = 6;
						ImGui::Combo(Eng ? xs(" weapon") : xs(u8" ������"), &weapon, Rifler, asize(Rifler));
						Weapon = 17 + weapon; break;
					case 3:
						if (weapon < 0) weapon = 0;
						if (weapon > 3) weapon = 3;
						ImGui::Combo(Eng ? xs(" weapon") : xs(u8" ������"), &weapon, Snipers, asize(Snipers));
						Weapon = 24 + weapon; break;
					case 4:
						if (weapon < 0) weapon = 0;
						if (weapon > 3) weapon = 3;
						ImGui::Combo(Eng ? xs(" weapon") : xs(u8" ������"), &weapon, Shotguns, asize(Shotguns));
						Weapon = 28 + weapon; break;
					case 5:
						if (weapon < 0) weapon = 0;
						if (weapon > 1) weapon = 1;
						ImGui::Combo(Eng ? xs(" weapon") : xs(u8" ������"), &weapon, Machinguns, asize(Machinguns));
						Weapon = 32 + weapon; break;
					default: break;
					}

					LegitWeapon = Weapon;
				}
			}

			ByteCombo(Eng ? xs(" setting mode") : xs(u8" ����� ���������"), Opts.LegitBot.SettingMode, Eng ? SettingLegitMode : SettingLegitModeRus, asize(SettingLegitMode));

			//ImGui::Separator();

			if (ActiveSubTab == 0)
			{
				ImGui::Columns(2, nullptr, false);
				ImGui::PushItemWidth(-1);

				ImGui::BeginChild(xs("##Aim_Bot"), ImVec2(0, 0), true);

				ImGui::Text(Eng ? xs("Aim bot") : xs(u8"��� ���"));
				ImGui::Separator();

				ImGui::Checkbox(Eng ? xs("Enable") : xs(u8"��������"), &Opts.LegitBot.AimBot.Enabled);

				ImGui::SameLine();
				ByteKeyButton(Eng ? xs(" key") : xs(u8" ������"), Opts.LegitBot.AimBot.AimBotKey);

				ImGui::Spacing();

				ImGui::Checkbox(Eng ? xs("Shoot the team") : xs(u8"�������� �� �������"), &Opts.LegitBot.AimBot.FriendlyFire);
				ImGui::Checkbox(Eng ? xs("Flash check") : xs(u8"��. ����������"), &Opts.LegitBot.AimBot.FlashCheck);
				ImGui::SameLine();
				ImGui::Checkbox(Eng ? xs("Smoke check") : xs(u8"��. ����"), &Opts.LegitBot.AimBot.SmokeCheck);
				ImGui::SameLine();
				ImGui::Checkbox(Eng ? xs("Jump check") : xs(u8"��. ������"), &Opts.LegitBot.AimBot.JumpCheck);

				ImGui::Spacing();

				if (Opts.LegitBot.SettingMode == 0) // setting for all weapon
				{
					ByteCombo(Eng ? xs(" bone") : xs(u8" �����"), Opts.LegitBot.All_Legit.AimBot.TargetBone, Eng ? AimbotBone : AimbotBoneRus, asize(AimbotBone));

					ImGui::SliderFloat(xs("##Fov"), &Opts.LegitBot.All_Legit.AimBot.Fov, 0.01f, 25, Eng ? xs("Fov: %.2f") : xs(u8"�������: %.2f"));
					ImGui::SliderFloat(xs("##Smooth"), &Opts.LegitBot.All_Legit.AimBot.Smooth, 1, 50, Eng ? xs("Smooth: %.2f") : xs(u8"���������: %.2f"));

					ImGui::Spacing();

					ImGui::Checkbox(Eng ? xs("Silent") : xs(u8"�������"), &Opts.LegitBot.All_Legit.AimBot.pSilent);
					if (Opts.LegitBot.All_Legit.AimBot.pSilent)
					{
						ImGui::SameLine();
						ImGui::SliderFloat(xs("##pSilent_fov"), &Opts.LegitBot.All_Legit.AimBot.pSilentFov, 0.001f, 15, Eng ? xs("Silent fov: %.3f") : xs(u8"������� ��������: %.3f"));
					}

					ImGui::Spacing();

					ImGui::Checkbox(Eng ? xs("Enable delay") : xs(u8"�������� ��������"), &Opts.LegitBot.All_Legit.AimBot.Delay);

					if (Opts.LegitBot.All_Legit.AimBot.Delay)
					{
						ImGui::SliderFloat(xs("##Shot_delay"), &Opts.LegitBot.All_Legit.AimBot.ShotDelay, 0, 50, Eng ? xs("Shot delay: %.1f") : xs(u8"�������� ��������: %.1f"));
						ImGui::SliderFloat(xs("##Kill_delay"), &Opts.LegitBot.All_Legit.AimBot.KillDelay, 0, 50, Eng ? xs("Kill delay: %.1f") : xs(u8"�������� ����� ��������: %.1f"));
					}

					ImGui::EndChild();
					ImGui::NextColumn();
					ImGui::BeginChild(xs("##Recoil_Control_System"), ImVec2(0, 130), true);

					ImGui::Text(Eng ? xs("Recoil Control System") : xs(u8"�������� ������"));
					ImGui::Separator();

					ImGui::Checkbox(Eng ? xs("Enable ") : xs(u8"�������� "), &Opts.LegitBot.RCS.Enabled);

					ByteCombo(Eng ? xs(" type") : xs(u8" ���"), Opts.LegitBot.All_Legit.RCS.Type, Eng ? RCSType : RCSTypeRus, asize(RCSType));

					ImGui::SliderInt(xs("##X"), &Opts.LegitBot.All_Legit.RCS.X, 0, 100, xs("X: %d"));
					ImGui::SliderInt(xs("##Y"), &Opts.LegitBot.All_Legit.RCS.Y, 0, 100, xs("Y: %d"));

					ImGui::EndChild();
					ImGui::BeginChild(xs("##Trigger_bot"), ImVec2(0, 0), true);

					ImGui::Text(Eng ? xs("Trigger bot") : xs(u8"������� ���"));
					ImGui::Separator();

					ImGui::Checkbox(Eng ? xs("Enable  ") : xs(u8"��������  "), &Opts.LegitBot.Trigger.Enabled);
					ImGui::SameLine();
					ByteKeyButton(Eng ? xs(" key") : xs(u8"������"), Opts.LegitBot.Trigger.TriggerKey);

					ImGui::Spacing();

					ImGui::Checkbox(Eng ? xs("Shoot the team") : xs(u8"�������� �� �������"), &Opts.LegitBot.Trigger.FriendlyFire);
					ImGui::Checkbox(Eng ? xs("Flash check") : xs(u8"��. ����������"), &Opts.LegitBot.Trigger.FlashCheck);
					ImGui::SameLine();
					ImGui::Checkbox(Eng ? xs("Smoke check") : xs(u8"��. ����"), &Opts.LegitBot.Trigger.SmokeCheck);
					ImGui::SameLine();
					ImGui::Checkbox(Eng ? xs("Jump check") : xs(u8"��. ������"), &Opts.LegitBot.Trigger.JumpCheck);

					ImGui::Spacing();

					ImGui::Checkbox(Eng ? xs("Head") : xs(u8"������"), &Opts.LegitBot.All_Legit.Trigger.Head);
					ImGui::SameLine();
					ImGui::Checkbox(Eng ? xs("Body") : xs(u8"����"), &Opts.LegitBot.All_Legit.Trigger.Body);
					ImGui::SameLine();
					ImGui::Checkbox(Eng ? xs("Misc") : xs(u8"������"), &Opts.LegitBot.All_Legit.Trigger.Misc);
					ImGui::SliderFloat(xs("##ShotDelay"), &Opts.LegitBot.All_Legit.Trigger.Delay, 0, 20, Eng ? xs("Shot delay: %.1f") : xs(u8"�������� ��������: %.1f"));

					ImGui::EndChild();
				}
				else if (Opts.LegitBot.SettingMode == 1) // setting for weapon type
				{
					ByteCombo(Eng ? xs(" bone") : xs(u8" �����"), Opts.LegitBot.WT_Legit[Type].AimBot.TargetBone, Eng ? AimbotBone : AimbotBoneRus, asize(AimbotBone));

					ImGui::SliderFloat(xs("##Fov"), &Opts.LegitBot.WT_Legit[Type].AimBot.Fov, 0.01f, 25, Eng ? xs("Fov: %.2f") : xs(u8"�������: %.2f"));
					ImGui::SliderFloat(xs("##Smooth"), &Opts.LegitBot.WT_Legit[Type].AimBot.Smooth, 1, 50, Eng ? xs("Smooth: %.2f") : xs(u8"���������: %.2f"));

					ImGui::Spacing();

					ImGui::Checkbox(Eng ? xs("Silent") : xs(u8"�������"), &Opts.LegitBot.WT_Legit[Type].AimBot.pSilent);
					if (Opts.LegitBot.WT_Legit[Type].AimBot.pSilent)
					{
						ImGui::SameLine();
						ImGui::SliderFloat(xs("##pSilent_fov"), &Opts.LegitBot.WT_Legit[Type].AimBot.pSilentFov, 0.001f, 15, Eng ? xs("Silent fov: %.3f") : xs(u8"������� ��������: %.3f"));
					}

					ImGui::Spacing();

					ImGui::Checkbox(Eng ? xs("Enable delay") : xs(u8"�������� ��������"), &Opts.LegitBot.WT_Legit[Type].AimBot.Delay);

					if (Opts.LegitBot.WT_Legit[Type].AimBot.Delay)
					{
						ImGui::SliderFloat(xs("##Shot_delay"), &Opts.LegitBot.WT_Legit[Type].AimBot.ShotDelay, 0, 50, Eng ? xs("Shot delay: %.1f") : xs(u8"�������� ��������: %.1f"));
						ImGui::SliderFloat(xs("##Kill_delay"), &Opts.LegitBot.WT_Legit[Type].AimBot.KillDelay, 0, 50, Eng ? xs("Kill delay: %.1f") : xs(u8"�������� ����� ��������: %.1f"));
					}

					ImGui::EndChild();
					ImGui::NextColumn();
					ImGui::BeginChild(xs("##Recoil_Control_System"), ImVec2(0, 130), true);

					ImGui::Text(Eng ? xs("Recoil Control System") : xs(u8"�������� ������"));
					ImGui::Separator();

					ImGui::Checkbox(Eng ? xs("Enable ") : xs(u8"�������� "), &Opts.LegitBot.RCS.Enabled);

					ByteCombo(Eng ? xs(" type") : xs(u8" ���"), Opts.LegitBot.WT_Legit[Type].RCS.Type, Eng ? RCSType : RCSTypeRus, asize(RCSType));

					ImGui::SliderInt(xs("##X"), &Opts.LegitBot.WT_Legit[Type].RCS.X, 0, 100, xs("X: %d"));
					ImGui::SliderInt(xs("##Y"), &Opts.LegitBot.WT_Legit[Type].RCS.Y, 0, 100, xs("Y: %d"));

					ImGui::EndChild();
					ImGui::BeginChild(xs("##Trigger_bot"), ImVec2(0, 0), true);

					ImGui::Text(Eng ? xs("Trigger bot") : xs(u8"������� ���"));
					ImGui::Separator();

					ImGui::Checkbox(Eng ? xs("Enable  ") : xs(u8"��������  "), &Opts.LegitBot.Trigger.Enabled);
					ImGui::SameLine();
					ByteKeyButton(Eng ? xs(" key") : xs(u8"������"), Opts.LegitBot.Trigger.TriggerKey);

					ImGui::Spacing();

					ImGui::Checkbox(Eng ? xs("Shoot the team") : xs(u8"�������� �� �������"), &Opts.LegitBot.Trigger.FriendlyFire);
					ImGui::Checkbox(Eng ? xs("Flash check") : xs(u8"��. ����������"), &Opts.LegitBot.Trigger.FlashCheck);
					ImGui::SameLine();
					ImGui::Checkbox(Eng ? xs("Smoke check") : xs(u8"��. ����"), &Opts.LegitBot.Trigger.SmokeCheck);
					ImGui::SameLine();
					ImGui::Checkbox(Eng ? xs("Jump check") : xs(u8"��. ������"), &Opts.LegitBot.Trigger.JumpCheck);

					ImGui::Spacing();

					ImGui::Checkbox(Eng ? xs("Head") : xs(u8"������"), &Opts.LegitBot.WT_Legit[Type].Trigger.Head);
					ImGui::SameLine();
					ImGui::Checkbox(Eng ? xs("Body") : xs(u8"����"), &Opts.LegitBot.WT_Legit[Type].Trigger.Body);
					ImGui::SameLine();
					ImGui::Checkbox(Eng ? xs("Misc") : xs(u8"������"), &Opts.LegitBot.WT_Legit[Type].Trigger.Misc);
					ImGui::SliderFloat(xs("##ShotDelay"), &Opts.LegitBot.WT_Legit[Type].Trigger.Delay, 0, 20, Eng ? xs("Shot delay: %.1f") : xs(u8"�������� ��������: %.1f"));

					ImGui::EndChild();
				}
				else if (Opts.LegitBot.SettingMode == 2) // setting for every weapon
				{
					ByteCombo(Eng ? xs(" bone") : xs(u8" �����"), Opts.LegitBot.EW_Legit[LegitWeapon].AimBot.TargetBone, Eng ? AimbotBone : AimbotBoneRus, asize(AimbotBone));  // AIM

					ImGui::SliderFloat(xs("##Fov"), &Opts.LegitBot.EW_Legit[LegitWeapon].AimBot.Fov, 0.01f, 25, Eng ? xs("Fov: %.2f") : xs(u8"�������: %.2f"));
					ImGui::SliderFloat(xs("##Smooth"), &Opts.LegitBot.EW_Legit[LegitWeapon].AimBot.Smooth, 1, 50, Eng ? xs("Smooth: %.2f") : xs(u8"���������: %.2f"));

					ImGui::Spacing();

					ImGui::Checkbox(Eng ? xs("Silent") : xs(u8"�������"), &Opts.LegitBot.EW_Legit[LegitWeapon].AimBot.pSilent);
					if (Opts.LegitBot.EW_Legit[LegitWeapon].AimBot.pSilent)
					{
						ImGui::SameLine();
						ImGui::SliderFloat(xs("##pSilent_fov"), &Opts.LegitBot.EW_Legit[LegitWeapon].AimBot.pSilentFov, 0.001f, 15, Eng ? xs("Silent fov: %.3f") : xs(u8"������� ��������: %.3f"));
					}

					ImGui::Spacing();

					ImGui::Checkbox(Eng ? xs("Enable delay") : xs(u8"�������� ��������"), &Opts.LegitBot.EW_Legit[LegitWeapon].AimBot.Delay);

					if (Opts.LegitBot.EW_Legit[LegitWeapon].AimBot.Delay)
					{
						ImGui::SliderFloat(xs("##Shot_delay"), &Opts.LegitBot.EW_Legit[LegitWeapon].AimBot.ShotDelay, 0, 50, Eng ? xs("Shot delay: %.1f") : xs(u8"�������� ��������: %.1f"));
						ImGui::SliderFloat(xs("##Kill_delay"), &Opts.LegitBot.EW_Legit[LegitWeapon].AimBot.KillDelay, 0, 50, Eng ? xs("Kill delay: %.1f") : xs(u8"�������� ����� ��������: %.1f"));
					}

					ImGui::EndChild();
					ImGui::NextColumn();
					ImGui::BeginChild(xs("##Recoil_Control_System"), ImVec2(0, 130), true); // RCS

					ImGui::Text(Eng ? xs("Recoil Control System") : xs(u8"�������� ������"));
					ImGui::Separator();

					ImGui::Checkbox(Eng ? xs("Enable ") : xs(u8"�������� "), &Opts.LegitBot.RCS.Enabled);

					ByteCombo(Eng ? xs(" type") : xs(u8" ���"), Opts.LegitBot.EW_Legit[LegitWeapon].RCS.Type, Eng ? RCSType : RCSTypeRus, asize(RCSType));

					ImGui::SliderInt(xs("##X"), &Opts.LegitBot.EW_Legit[LegitWeapon].RCS.X, 0, 100, xs("X: %d"));
					ImGui::SliderInt(xs("##Y"), &Opts.LegitBot.EW_Legit[LegitWeapon].RCS.Y, 0, 100, xs("Y: %d"));

					ImGui::EndChild();
					ImGui::BeginChild(xs("##Trigger_bot"), ImVec2(0, 0), true); // TRIGGER

					ImGui::Text(Eng ? xs("Trigger bot") : xs(u8"������� ���"));
					ImGui::Separator();

					ImGui::Checkbox(Eng ? xs("Enable  ") : xs(u8"��������  "), &Opts.LegitBot.Trigger.Enabled);
					ImGui::SameLine();
					ByteKeyButton(Eng ? xs(" key") : xs(u8"������"), Opts.LegitBot.Trigger.TriggerKey);

					ImGui::Spacing();

					ImGui::Checkbox(Eng ? xs("Shoot the team") : xs(u8"�������� �� �������"), &Opts.LegitBot.Trigger.FriendlyFire);
					ImGui::Checkbox(Eng ? xs("Flash check") : xs(u8"��. ����������"), &Opts.LegitBot.Trigger.FlashCheck);
					ImGui::SameLine();
					ImGui::Checkbox(Eng ? xs("Smoke check") : xs(u8"��. ����"), &Opts.LegitBot.Trigger.SmokeCheck);
					ImGui::SameLine();
					ImGui::Checkbox(Eng ? xs("Jump check") : xs(u8"��. ������"), &Opts.LegitBot.Trigger.JumpCheck);

					ImGui::Spacing();

					ImGui::Checkbox(Eng ? xs("Head") : xs(u8"������"), &Opts.LegitBot.EW_Legit[LegitWeapon].Trigger.Head);
					ImGui::SameLine();
					ImGui::Checkbox(Eng ? xs("Body") : xs(u8"����"), &Opts.LegitBot.EW_Legit[LegitWeapon].Trigger.Body);
					ImGui::SameLine();
					ImGui::Checkbox(Eng ? xs("Misc") : xs(u8"������"), &Opts.LegitBot.EW_Legit[LegitWeapon].Trigger.Misc);
					ImGui::SliderFloat(xs("##ShotDelay"), &Opts.LegitBot.EW_Legit[LegitWeapon].Trigger.Delay, 0, 20, Eng ? xs("Shot delay: %.1f") : xs(u8"�������� ��������: %.1f"));

					ImGui::EndChild();
				}

				ImGui::Columns(1, nullptr, false);

				ImGui::PopItemWidth();
			}
			else if (ActiveSubTab == 1) // LegitRage
			{
				G::LegitRageUpdate = true;

				ImGui::Checkbox(Eng ? xs("Enable LegitRage") : xs(u8"�������� ����������"), &Opts.LegitRageBot.Enabled);

				ImGui::Checkbox(Eng ? xs("Auto fire on key") : xs(u8"����. �������� �� ������"), &Opts.LegitRageBot.AimBotAutoFireOnKey);
				if (Opts.LegitRageBot.AimBotAutoFireOnKey)
				{
					ImGui::SameLine();
					ByteKeyButton(Eng ? xs(" key") : xs(u8"������"), Opts.LegitRageBot.AimBotAutoFireKey);
				}

				ImGui::Spacing();

				ImGui::Checkbox(Eng ? xs("Shoot the team") : xs(u8"�������� �� �������"), &Opts.LegitRageBot.AimBot.FriendlyFire);
				ImGui::Checkbox(Eng ? xs("Flash check") : xs(u8"��. ����������"), &Opts.LegitRageBot.AimBot.FlashCheck);
				ImGui::SameLine();
				ImGui::Checkbox(Eng ? xs("Smoke check") : xs(u8"��. ����"), &Opts.LegitRageBot.AimBot.SmokeCheck);
				ImGui::SameLine();
				ImGui::Checkbox(Eng ? xs("Jump check") : xs(u8"��. ������"), &Opts.LegitRageBot.AimBot.JumpCheck);

				ImGui::Spacing();

				ImGui::Checkbox(Eng ? xs("Auto revolver") : xs(u8"����. ���������"), &Opts.LegitRageBot.AimBot.AutoRevolver);

				ImGui::Checkbox(Eng ? xs("Auto wall") : xs(u8"�������� ����� �����"), &Opts.LegitRageBot.AimBot.AutoWall);
				ImGui::SameLine();
				ImGui::Checkbox(Eng ? xs("Auto stop") : xs(u8"����. ���������"), &Opts.LegitRageBot.AimBot.AutoStop);
				ImGui::SameLine();
				ImGui::Checkbox(Eng ? xs("Auto scope") : xs(u8"����. ����"), &Opts.LegitRageBot.AimBot.AutoScope);

				ImGui::Spacing();

				if (Opts.LegitBot.SettingMode == 0) // setting for all weapons
				{
					ByteCombo(Eng ? xs(" bone") : xs(u8" �����"), Opts.LegitRageBot.All_Legit.AimBot.TargetBone, Eng ? AimbotBone : AimbotBoneRus, asize(AimbotBone));

					ImGui::PushItemWidth(-1);

					ImGui::Checkbox(Eng ? xs("Enable silent") : xs(u8"�������� �������"), &Opts.LegitRageBot.All_Legit.AimBot.pSilent);
					ImGui::SameLine();
					ImGui::SliderFloat(xs("##Fov"), &Opts.LegitRageBot.All_Legit.AimBot.Fov, 0.01f, 30, Eng ? xs("Fov: %.2f") : xs(u8"�������: %.2f"));

					ImGui::Spacing();

					ImGui::SliderFloat(xs("##Hitchance"), &Opts.LegitRageBot.All_Legit.AimBot.HitChance, 1.f, 100.f, Eng ? xs("Hitchance: %.2f") : xs(u8"�������: %.2f"));
					ImGui::SliderFloat(xs("##Min_damage"), &Opts.LegitRageBot.All_Legit.AimBot.MinDamage, 1.f, 100.f, Eng ? xs("Min damage: %.2f") : xs(u8"���. ����: %.2f"));

					ImGui::PopItemWidth();
				}
				else if (Opts.LegitBot.SettingMode == 1) // setting for weapon type
				{
					ByteCombo(Eng ? xs(" bone") : xs(u8" �����"), Opts.LegitRageBot.WT_Legit[Type].AimBot.TargetBone, Eng ? AimbotBone : AimbotBoneRus, asize(AimbotBone));

					ImGui::PushItemWidth(-1);

					ImGui::Checkbox(Eng ? xs("Enable silent") : xs(u8"�������� �������"), &Opts.LegitRageBot.WT_Legit[Type].AimBot.pSilent);
					ImGui::SameLine();
					ImGui::SliderFloat(xs("##Fov"), &Opts.LegitRageBot.WT_Legit[Type].AimBot.Fov, 0.01f, 30, Eng ? xs("Fov: %.2f") : xs(u8"�������: %.2f"));

					ImGui::SliderFloat(xs("##Hitchance"), &Opts.LegitRageBot.WT_Legit[Type].AimBot.HitChance, 1.f, 100.f, Eng ? xs("Hitchance: %.2f") : xs(u8"�������: %.2f"));
					ImGui::SliderFloat(xs("##Min_damage"), &Opts.LegitRageBot.WT_Legit[Type].AimBot.MinDamage, 1.f, 100.f, Eng ? xs("Min damage: %.2f") : xs(u8"���. ����: %.2f"));

					ImGui::PopItemWidth();
				}
				else if (Opts.LegitBot.SettingMode == 2) // setting for every weapons
				{
					ByteCombo(Eng ? xs(" bone") : xs(u8" �����"), Opts.LegitRageBot.EW_Legit[Weapon].AimBot.TargetBone, Eng ? AimbotBone : AimbotBoneRus, asize(AimbotBone));

					ImGui::PushItemWidth(-1);

					ImGui::Checkbox(Eng ? xs("Enable silent") : xs(u8"�������� �������"), &Opts.LegitRageBot.EW_Legit[Weapon].AimBot.pSilent);
					ImGui::SameLine();
					ImGui::SliderFloat(xs("##Fov"), &Opts.LegitRageBot.EW_Legit[Weapon].AimBot.Fov, 0.01f, 30, Eng ? xs("Fov: %.2f") : xs(u8"�������: %.2f"));

					ImGui::SliderFloat(xs("##Hitchance"), &Opts.LegitRageBot.EW_Legit[Weapon].AimBot.HitChance, 1.f, 100.f, Eng ? xs("Hitchance: %.2f") : xs(u8"�������: %.2f"));
					ImGui::SliderFloat(xs("##Min_damage"), &Opts.LegitRageBot.EW_Legit[Weapon].AimBot.MinDamage, 1.f, 100.f, Eng ? xs("Min damage: %.2f") : xs(u8"���. ����: %.2f"));

					ImGui::PopItemWidth();
				}
			}
		}
		else if (G::MainTabIndex == 2) // selected VisualsSubTab
		{
			static bool visible_esp_preview = false;

			if (visible_esp_preview)
				DrawEspPreview();

			if (ActiveSubTab == 0)
			{
				ImGui::Columns(2, nullptr, false);
				ImGui::BeginChild(xs("##Globals"), ImVec2(0, 250), true);

				ImGui::Text(Eng ? xs("Global") : xs(u8"����������"));
				ImGui::Separator();

				ImGui::Checkbox(Eng ? xs("Enable") : xs(u8"��������"), &Opts.Visuals.Players.Global.Enabled);
				ImGui::SameLine();
				ByteKeyButton(Eng ? xs(" key") : xs(u8" ������"), Opts.Visuals.Players.Global.VisualsKey);

				ImGui::Checkbox(Eng ? xs("Ingame screenshot bypass") : xs(u8"����� ������������� ����������"), &Opts.Visuals.Players.Global.ScreenShotBypass);

				ImGui::Checkbox(Eng ? xs("Enemy only") : xs(u8"������ ����������"), &Opts.Visuals.Players.Global.EnemyOnly);
				ImGui::SameLine();
				ImGui::Checkbox(Eng ? xs("Visible only") : xs(u8"������ �������"), &Opts.Visuals.Players.Global.VisibleOnly);

				ImGui::Spacing();

				ByteCombo(Eng ? xs("Box type") : xs(u8"��� ������"), Opts.Visuals.Players.Global.BoxMode, Eng ? ESPBox : ESPBoxRus, asize(ESPBox));
				ImGui::Checkbox(Eng ? xs("Box outline") : xs(u8"������� ������"), &Opts.Visuals.Players.Global.Outline);

				//ImGui::Checkbox(Eng ? xs("Danger zone") : xs(u8"������� ����"), &Opts.Visuals.Players.Global.DangerZone);

				ImGui::Spacing();

				ImGui::Checkbox(Eng ? xs("Health") : xs(u8"�����"), &Opts.Visuals.Players.Global.Health.Enable);
				//ImGui::SameLine();
				//ImGui::Checkbox(Eng ? xs("Armor") : xs(u8"�����"), &Opts.Visuals.Players.Global.Armor.Enable);

				//ByteCombo(Eng ? xs("Armor type") : xs(u8"��� �����"), Opts.Visuals.Players.Global.ArmorType, Eng ? LBType : LBTypeRus, asize(LBType));
				//ByteCombo(Eng ? xs("Armor style") : xs(u8"����� �����"), Opts.Visuals.Players.Global.ArmorStyle, Eng ? StyleHP : StyleHPRus, asize(StyleHP));

				ImGui::Checkbox(Eng ? xs("Sound esp") : xs(u8"����� ���"), &Opts.Visuals.Players.Global.SoundEsp);
				ImGui::SameLine(105);
				ImGui::Checkbox(Eng ? xs("Snipe line") : xs(u8"�����"), &Opts.Visuals.Players.Global.SnipeLine);
				ImGui::SameLine(210);
				ImGui::Checkbox(Eng ? xs("Skeleton") : xs(u8"������"), &Opts.Visuals.Players.Global.Skeleton);

				ImGui::Checkbox(Eng ? xs("Head dot") : xs(u8"����� �� ������"), &Opts.Visuals.Players.Global.HeadDot);

				ImGui::Checkbox(Eng ? xs("Info") : xs(u8"����"), &Opts.Visuals.Players.Global.Info);
				ImGui::SameLine(105);
				ImGui::Checkbox(Eng ? xs("Name") : xs(u8"���"), &Opts.Visuals.Players.Global.Name);
				ImGui::SameLine(210);
				ImGui::Checkbox(Eng ? xs("Weapon") : xs(u8"������"), &Opts.Visuals.Players.Global.Weapon);
				ImGui::Checkbox(Eng ? xs("Money") : xs(u8"������"), &Opts.Visuals.Players.Global.Money);
				ImGui::SameLine(105);
				ImGui::Checkbox(Eng ? xs("Distance") : xs(u8"���������"), &Opts.Visuals.Players.Global.Distance);

				ImGui::EndChild();
				ImGui::BeginChild(xs("##Weapons"), ImVec2(0, 0), true);

				ImGui::Text(Eng ? xs("Weapons") : xs(u8"Weapons"));
				ImGui::Separator();

				ImGui::Checkbox(Eng ? xs("Enable ") : xs(u8"�������� "), &Opts.Visuals.Weapons.Enabled);

				ImGui::Spacing();

				ByteCombo(Eng ? xs("Box type") : xs(u8"��� ������"), Opts.Visuals.Weapons.BoxMode, Eng ? ESPBoxW : ESPBoxWRus, asize(ESPBoxW));
				ImGui::Checkbox(Eng ? xs("Outline") : xs(u8"�������"), &Opts.Visuals.Weapons.Outline);

				ImGui::Separator();

				ImGui::Checkbox(Eng ? xs("Enable glow") : xs(u8"�������� ����"), &Opts.Visuals.Weapons.Glow);
				ByteCombo(xs("##Glow_type"), Opts.Visuals.Weapons.GlowType, Eng ? GlowType : GlowTypeRus, asize(GlowType));

				ImGui::Separator();

				ImGui::Checkbox(Eng ? xs("Weapons ") : xs(u8"������"), &Opts.Visuals.Weapons.Weapons);
				ImGui::SameLine();
				ImGui::Checkbox(Eng ? xs("Grenades") : xs(u8"�������"), &Opts.Visuals.Weapons.Grenades);
				ImGui::SameLine();
				ImGui::Checkbox(Eng ? xs("Bomb") : xs(u8"�����"), &Opts.Visuals.Weapons.Bomb);

				ImGui::EndChild();
				ImGui::NextColumn();
				ImGui::BeginChild(xs("##Chams"), ImVec2(0, 250), true);

				ImGui::Text(Eng ? xs("Chams") : xs(u8"�����"));
				ImGui::Separator();

				ImGui::Spacing();

				ImGui::Checkbox(Eng ? xs("Enable  ") : xs(u8"��������  "), &Opts.Visuals.Players.Chams.Enabled);

				ImGui::Checkbox(Eng ? xs("Enemy only ") : xs(u8"������ ���������� "), &Opts.Visuals.Players.Chams.EnemyOnly);
				ImGui::SameLine();
				ImGui::Checkbox(Eng ? xs("Visible only ") : xs(u8"������ ������� "), &Opts.Visuals.Players.Chams.VisibleOnly);

				ByteCombo(Eng ? xs("Vis type") : xs(u8"��� ���"), Opts.Visuals.Players.Chams.VisType, Eng ? ChamsType : ChamsTypeRus, asize(ChamsType));
				ByteCombo(Eng ? xs("Invis type") : xs(u8"����� ���"), Opts.Visuals.Players.Chams.InvisType, Eng ? ChamsType : ChamsTypeRus, asize(ChamsType));

				//ImGui::Text(u8"�����"); //�������
				//if (ImGui::IsItemHovered())
				//	ImGui::SetTooltip(u8"����� ��� ��������� �������");

				ImGui::Checkbox(Eng ? xs("Blinking") : xs(u8"��������"), &Opts.Visuals.Players.Chams.Blinking);

				ImGui::Combo(Eng ? xs("Type hands") : xs(u8"��� ���"), &Opts.Misc.Changer.View.iHands, Eng ? HSWChams : HSWChamsRus, asize(HSWChams));
				ImGui::Combo(Eng ? xs("Type sleeves ") : xs(u8"��� �����"), &Opts.Misc.Changer.View.iSleeves, Eng ? HSWChams : HSWChamsRus, asize(HSWChams));
				ImGui::Combo(Eng ? xs("Type weapons") : xs(u8"��� ������"), &Opts.Misc.Changer.View.iWeapons, Eng ? HSWChams : HSWChamsRus, asize(HSWChams));

				ImGui::Spacing();

				ImGui::EndChild();
				ImGui::BeginChild(xs("##Glow"), ImVec2(0, 0), true);
				ImGui::Text(Eng ? xs("Glow") : xs(u8"����"));
				ImGui::Separator();

				ImGui::Spacing();

				ImGui::Checkbox(Eng ? xs("Enable   ") : xs(u8"��������   "), &Opts.Visuals.Players.Glow.Enabled);

				ImGui::Checkbox(Eng ? xs("Enemy only  ") : xs(u8"������ ����������  "), &Opts.Visuals.Players.Glow.EnemyOnly);
				ImGui::SameLine();
				ImGui::Checkbox(Eng ? xs("Visible only  ") : xs(u8"������ �������  "), &Opts.Visuals.Players.Glow.VisibleOnly);

				ByteCombo(Eng ? xs("Type ") : xs(u8"��� "), Opts.Visuals.Players.Glow.Type, Eng ? GlowType : GlowTypeRus, asize(GlowType));

				ImGui::EndChild();
				ImGui::Columns(1, nullptr, false);
			}
			else if (ActiveSubTab == 1)
			{
				ImGui::Columns(2, nullptr, false);
				ImGui::BeginChild(xs("##Other"), ImVec2(0, 0), true);

				ImGui::Text(Eng ? xs("Other") : xs(u8"���������"));
				ImGui::Separator();

				ByteCombo(Eng ? xs("Hitmarker") : xs(u8"���������"), Opts.Visuals.Other.HitMarker, Eng ? ESPHitmarker : ESPHitmarkerRus, asize(ESPHitmarker));
				ByteCombo(Eng ? xs("Bullet tracer") : xs(u8"����� ����"), Opts.Visuals.Other.BulletTracer, Eng ? ESPTracer : ESPTracerRus, asize(ESPTracer));
				ImGui::Checkbox(Eng ? xs("Grenade prediction") : xs(u8"���������� �������"), &Opts.Visuals.Other.GrenadePrediction);
				ImGui::Checkbox(Eng ? xs("Crosshair") : xs(u8"������"), &Opts.Visuals.Other.Crosshair);
				ImGui::Checkbox(Eng ? xs("[Legit] fov") : xs(u8"[�����] ������� ������"), &Opts.Visuals.Other.FovCrosshair);
				ImGui::Checkbox(Eng ? xs("[Legit] show target bone") : xs(u8"[�����] ����� ������� �����"), &Opts.Visuals.Other.ShowTargetBone);

				if (Opts.Visuals.Other.ShowTargetBone)
				{
					ImGui::SliderInt(xs("##Target bone outline"), &Opts.Visuals.Other.TargetBoneOutline, Opts.Visuals.Other.TargetBoneInline + 1, 100, Eng ? xs("Target bone outline: %d") : xs(u8"������� ����� �������: %d"));
					ImGui::SliderInt(xs("##Target bone inline"), &Opts.Visuals.Other.TargetBoneInline, 0, Opts.Visuals.Other.TargetBoneOutline - 1, Eng ? xs("Target bone inline: %d") : xs(u8"������� ����� ����������: %d"));
				}

				ImGui::Checkbox(Eng ? xs("Spectator list") : xs(u8"������ ������������"), &Opts.Visuals.Other.SpectatorList);
				ImGui::Checkbox(Eng ? xs("Show esp preview") : xs(u8"���������� ��� ������"), &visible_esp_preview);

				ImGui::Checkbox(Eng ? xs("Colored walls") : xs(u8"������� �����"), &Opts.Visuals.Other.WallsColored);
				ImGui::Checkbox(Eng ? xs("Colored sky") : xs(u8"������� ����"), &Opts.Visuals.Other.SkyColored);
				ImGui::Checkbox(Eng ? xs("Colored props") : xs(u8"������� �����"), &Opts.Visuals.Other.PropColored);

				ImGui::Separator();
				ImGui::Checkbox(Eng ? xs("Water mark") : xs(u8"������� ����"), &Opts.Visuals.Other.WaterMark);

				ImGui::EndChild();
				ImGui::NextColumn();
				ImGui::BeginChild(xs("##Radar"), ImVec2(0, 0), true);

				ImGui::Text(Eng ? xs("Radar") : xs(u8"�����"));
				ImGui::Separator();

				ByteCombo(Eng ? xs("Type") : xs(u8"���"), Opts.Visuals.Radar.Type, Eng ? RadarType : RadarTypeRus, asize(RadarType));

				if (Opts.Visuals.Radar.Type == 2)
				{
					ImGui::Checkbox(Eng ? xs("Enemy only") : xs(u8"������ ����������"), &Opts.Visuals.Radar.EnemyOnly);
					ImGui::Separator();
					//ByteSlider(Eng ? xs("Size") : xs(u8"������"), Opts.Visuals.Radar.Size, 0, 250);
					//ImGui::SliderFloat(Eng ? xs("Size X") : xs(u8"������ X"), &Opts.Visuals.Radar.Size.x, 1.f, G::ScreenWidth, "%.2f");
					//ImGui::SliderFloat(Eng ? xs("Size Y") : xs(u8"������ Y"), &Opts.Visuals.Radar.Size.y, 1.f, G::ScreenHeight, "%.2f");
					ByteSlider(Eng ? xs("Point size") : xs(u8"������ �������"), Opts.Visuals.Radar.PointSize, 1, 20);
					ImGui::SliderFloat(Eng ? xs("Zoom") : xs(u8"�����������"), &Opts.Visuals.Radar.Zoom, 0.01f, 6.f, "%.4f");
					ByteSlider(Eng ? xs("Alpha") : xs(u8"�����"), Opts.Visuals.Radar.Alpha, 0, 255);

					DrawRadar();

					//ImGui::SliderFloat(Eng ? xs("Position X") : xs(u8"������� �� X"), &Opts.Visuals.Radar.Pos.x, 1.f, G::ScreenWidth, "%.2f");
					//ImGui::SliderFloat(Eng ? xs("Position Y") : xs(u8"������� �� Y"), &Opts.Visuals.Radar.Pos.y, 1.f, G::ScreenHeight, "%.2f");
				}

				ImGui::Separator();

				ImGui::Checkbox(Eng ? xs("Back ground") : xs(u8"������ ���"), &Opts.Visuals.Other.BackGround);
				ImGui::Checkbox(Eng ? xs("Back drop") : xs(u8"���������"), &Opts.Visuals.Other.BackDrop);

				ImGui::SliderInt(xs("##BackDropMaxPoints"), &Opts.Visuals.Other.BackDropMaxPoints, 10, 500, Eng ? xs("Back drop max square: %d") : xs(u8"��������� ���� ���������: %d"));
				ImGui::SliderFloat(xs("##BackDropMaxDist"), &Opts.Visuals.Other.BackDropMaxDist, 1.00f, 400.00f, Eng ? xs("Back drop lines dist: %.3f") : xs(u8"��������� ��������� �����: %.3f"));
				ImGui::SliderInt(xs("##BackDropSquareSize"), &Opts.Visuals.Other.BackDropSquareSize, 1, 500, Eng ? xs("Back drop square size: %d") : xs(u8"��������� ������ ���������: %d"));
				ImGui::SliderInt(xs("##BackDropMaxSpeed"), &Opts.Visuals.Other.BackDropMaxSpeed, 1, 500, Eng ? xs("Back drop max speed: %d") : xs(u8"��������� ���� ��������: %d"));

				ImGui::EndChild();
				ImGui::Columns(1, nullptr, false);
			}
			else if (ActiveSubTab == 2)
			{
				if (G::LocalPlayer && G::LocalPlayer->GetAlive())
				{
					ImGui::Checkbox(Eng ? xs("Enable") : xs(u8"��������"), &Opts.Visuals.GrenadeHelper.Enabled);

					//ImGui::ListBoxHeader("##Helper");

					//static int selected_pos = 0;
					//static int old_selected_pos = 0;
					//
					//ImGui::Combo(Eng ? xs(" Skin") : xs(u8" ����"), &selected_pos, [](void* data, int idx, const char** out_text)
					//{
					//	*out_text = std::string(Opts.Visuals.GrenadeHelper.OptMass[idx].name + " | " + U::GetMapNameById(Opts.Visuals.GrenadeHelper.OptMass[idx].for_map)).c_str();
					//	return true;
					//}, nullptr, Opts.Visuals.GrenadeHelper.OptMass.size(), 10);
					//
					static char pos_name[256] = "";
					ImGui::InputText(Eng ? xs("Name") : xs(u8"��������"), pos_name, 256);
					std::string opt_pos_name = pos_name;
					//
					//if (selected_pos != old_selected_pos)
					//{
					//	strcpy(pos_name, Opts.Visuals.GrenadeHelper.OptMass[selected_pos].name.c_str());
					//	old_selected_pos = selected_pos;
					//}

					if (ImGui::Button(Eng ? "Add new pos" : u8"�������� ��������"))
					{
						strGrenadeHelper new_str;
						new_str.name = opt_pos_name;
						new_str.org_pos = G::LocalPlayer->GetOrigin();
						new_str.eye_pos = G::LocalPlayer->GetEyePosition();
						I::Engine->GetViewAngles(new_str.ang);
						new_str.for_map = U::GetCurrentMap();

						Opts.Visuals.GrenadeHelper.OptMass.push_back(new_str);
					}
				}
				else
				{
					ImGui::Text(Eng ? "You can only customize when in-game and live" : u8"�� ������ �����������, ������ ����� � ���� � ����");
				}
			}
		}
		else if (G::MainTabIndex == 3) // selected ChangerSubTub
		{
			if (ActiveSubTab == 0)
			{
				ImGui::Checkbox(Eng ? xs("Enable") : xs(u8"��������"), &Opts.Misc.Changer.Models.Enable);
				ImGui::SameLine();
				ImGui::Checkbox(Eng ? xs("Fast change") : xs(u8"������� �������"), &Opts.Misc.Changer.Models.FastChange);

				ImGui::SameLine();

				SetTooltipER("Download progress bar", u8"����� ��������� ����������");

				ByteCombo(Eng ? xs("Sky changer") : xs(u8"�������� ����"), Opts.Visuals.Other.SkyChanger, "default\0cs_baggage_skybox_\0cs_tibet\0embassy\0italy\0jungle\0nukeblank\0office\0sky_cs15_daylight01_hdr\0sky_cs15_daylight02_hdr\0sky_cs15_daylight03_hdr\0sky_cs15_daylight04_hdr\0sky_csgo_cloudy01\0sky_csgo_night_flat\0sky_csgo_night02\0sky_day02_05_hdr\0sky_day02_05\0sky_dust\0sky_l4d_rural02_ldr\0sky_venice\0vertigo_hdr\0vertigo\0vertigoblue_hdr\0vietnam\0custom");

				if (Opts.Visuals.Other.SkyChanger == 24)
				{
					if (Opts.Visuals.Other.SkyChangerName.size() != 256) Opts.Visuals.Other.SkyChangerName.resize(256);
					ImGui::InputText(Eng ? xs(" Search") : xs(u8" �����"), &Opts.Visuals.Other.SkyChangerName[0], 256);
				}

				if (ImGui::Button(Eng ? xs("Update models") : xs(u8"�������� ������"), ImVec2(-1, 0)))
				{
					U::ForceFullUpdate();
				}
			}
			else if (ActiveSubTab == 1)
			{
				static int mode = 0;
				static int setting_mode_ct_tt = 0;

				if (Opts.Misc.Changer.Skins.AutoSelectWeapon)
				{
					static int old_select_team = 0;
					if (I::Engine->IsInGame() && !G::IsInDangerZone && G::LocalPlayer->GetHealth() > 0 && old_select_team != G::LocalPlayer->GetWeapon()->GetType())
					{
						if (G::LocalPlayer->GetWeapon()->IsFiredWeaponType())
						{
							mode = 0;
						}
						else if (G::LocalPlayer->GetWeapon()->GetType() == WT_KNIFES)
						{
							mode = 1;
						}

						setting_mode_ct_tt = G::LocalPlayer->GetTeam() == 3 ? 0 : 1;
						old_select_team = G::LocalPlayer->GetWeapon()->GetType();
					}
				}

				static int Type = 0;
				static int Weapon = 0;
				static int weapon;

				DrawSubTabs(Eng ? WeaponTypes : WeaponTypesRus, ARRAYSIZE(WeaponTypes), Type, true, 602, false);

				//if (G::LocalPlayer && G::LocalPlayer->GetWeapon()->IsFiredWeaponType())
				//{
				//	ImGui::SameLine();
				//	if (ImGui::Button(Eng ? xs("Current") : xs(u8"�������"), ImVec2(93, 24)))
				//	{
				//		Type = G::LocalPlayer->GetWeapon()->GetType() - 4;
				//
				//		if (Opts.LegitBot.SettingMode == 2)
				//		{
				//			switch (Type)
				//			{
				//			case 0: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex(); break;
				//			case 1: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 10; break;
				//			case 2: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 17; break;
				//			case 3: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 24; break;
				//			case 4: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 28; break;
				//			case 5: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 32; break;
				//			default: break;
				//			}
				//		}
				//	}
				//}

				ImGui::SameLine();

				ImGui::Checkbox(Eng ? xs("For teams") : xs(u8"��� ������"), &Opts.Misc.Changer.Skins.SettingsForTeams);

				ImGui::Spacing();

				switch (Type)
				{
				case 0:
					if (weapon < 0) weapon = 0;
					if (weapon > 9) weapon = 9;
					ImGui::Combo(xs("##weapon"), &weapon, Pistols, asize(Pistols));
					Weapon = weapon; break;
				case 1:
					if (weapon < 0) weapon = 0;
					if (weapon > 6) weapon = 6;
					ImGui::Combo(xs("##weapon"), &weapon, SMG, asize(SMG));
					Weapon = 10 + weapon; break;
				case 2:
					if (weapon < 0) weapon = 0;
					if (weapon > 6) weapon = 6;
					ImGui::Combo(xs("##weapon"), &weapon, Rifler, asize(Rifler));
					Weapon = 17 + weapon; break;
				case 3:
					if (weapon < 0) weapon = 0;
					if (weapon > 3) weapon = 3;
					ImGui::Combo(xs("##weapon"), &weapon, Snipers, asize(Snipers));
					Weapon = 24 + weapon; break;
				case 4:
					if (weapon < 0) weapon = 0;
					if (weapon > 3) weapon = 3;
					ImGui::Combo(xs("##weapon"), &weapon, Shotguns, asize(Shotguns));
					Weapon = 28 + weapon; break;
				case 5:
					if (weapon < 0) weapon = 0;
					if (weapon > 1) weapon = 1;
					ImGui::Combo(xs("##weapon"), &weapon, Machinguns, asize(Machinguns));
					Weapon = 32 + weapon; break;
				default: break;
				}

				if (Opts.Misc.Changer.Skins.SettingsForTeams)
				{
					ImGui::SameLine();

					ImGui::PushItemWidth(-1);
					ImGui::Combo(xs("##team"), &setting_mode_ct_tt, Eng ? CT_TT : CT_TT_RUS, ARRAYSIZE(CT_TT));
					ImGui::PopItemWidth();
				}

				ImGui::Spacing();

				ImGui::Columns(2, nullptr, false);
				ImGui::BeginChild(xs("##SkinChanger-Weapons"), ImVec2(0, 0), true);

				if (Opts.Misc.Changer.Skins.AutoSelectWeapon)
				{
					static int old_select_type = 0;
					if (I::Engine->IsInGame() && !G::IsInDangerZone && G::LocalPlayer->GetHealth() > 0 && old_select_type != G::LocalPlayer->GetWeapon()->GetType())
					{
						if (G::LocalPlayer->GetWeapon()->IsFiredWeaponType())
						{
							mode = 0;

							Type = G::LocalPlayer->GetWeapon()->GetType() - 4;

							switch (Type)
							{
							case 0: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex(); break;
							case 1: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 10; break;
							case 2: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 17; break;
							case 3: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 24; break;
							case 4: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 28; break;
							case 5: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 32; break;
							default: break;
							}
						}
						else if (G::LocalPlayer->GetWeapon()->GetType() == WT_KNIFES)
						{
							mode = 1;
						}

						old_select_type = G::LocalPlayer->GetWeapon()->GetType();
						setting_mode_ct_tt = G::LocalPlayer->GetTeam() == 3 ? 0 : 1;
					}
				}

				ImGui::Text(Eng ? xs("Skins") : xs(u8"�����"));
				ImGui::Separator();

				ImGui::Checkbox(Eng ? xs("Enable") : xs(u8"��������"), &Opts.Misc.Changer.Skins.EnableSkins);
				///ImGui::SameLine();
				///ImGui::Checkbox(Eng ? xs(" Auto select current weapon") : xs(u8" ���� ����������� ������"), &Opts.Misc.Changer.Skins.AutoSelectWeapon);

				///ImGui::Separator();

				// Combo start
				ImGui::PushItemWidth(-2);

				static char search_weapons[32] = "";
				ImGui::InputText(xs("##Search_weapons"), search_weapons, 32);

				ImGui::SameLine();

				static int old_weapon = Weapon, old_team_mode = setting_mode_ct_tt;
				if (old_weapon != Weapon || old_team_mode != setting_mode_ct_tt) // if we change current weapon then clear 'search'
				{
					old_weapon = Weapon; old_team_mode = setting_mode_ct_tt;
					for (int i = 0; i < 32; ++i) search_weapons[i] = 0;
				}

				skinPaints.clear();

				paint_kits skin_kits_weapon;
				for (int i = 0; i < SkinChanger::skinKits.size(); ++i) // this search skin
					if (strstr(SkinChanger::skinKits[i].name.c_str(), search_weapons) || search_weapons == nullptr) { skin_kits_weapon.name = SkinChanger::skinKits[i].name; skin_kits_weapon.skin_id = SkinChanger::skinKits[i].id; skinPaints.push_back(skin_kits_weapon); }


				static int skin_id_weapon = 0;
				for (int i = 0; i < skinPaints.size(); ++i) {
					if (Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].SkinID == skinPaints[i].skin_id) {
						skin_id_weapon = i;
						break;
					}
				}

				ImGui::Combo(Eng ? xs(" Skin") : xs(u8" ����"), &skin_id_weapon, [](void* data, int idx, const char** out_text)
				{
					*out_text = skinPaints[idx].name.c_str();
					return true;
				}, nullptr, skinPaints.size(), 10);

				ImGui::PopItemWidth();

				Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].SkinID = skinPaints[skin_id_weapon].skin_id;

				// Combo end

				// ImGui::InputInt(Eng ? xs("Skin ID") : xs(u8"���� ����"), &Opts.Misc.Changer.Skins.Weapons[Weapon].SkinID);

				ImGui::PushItemWidth(-2);

				ImGui::SliderFloat(xs("##Wear_knifes"), &Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].Wear, 0.f, 1.f, Eng ? xs("Wear: %.3f") : xs(u8"��������: %.3f"));
				ImGui::SameLine();
				ImGui::InputInt(Eng ? xs(" Seed") : xs(u8" ������"), &Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].Seed);

				ImGui::PopItemWidth();

				ImGui::Combo(Eng ? xs(" StatTrak") : xs(u8" ��������"), &Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].StatTrak.Type, Eng ? StatTrakType : StatTrakTypeRus, ARRAYSIZE(StatTrakType));

				static int old_stat = Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].StatTrak.Type;
				if (Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].StatTrak.Type != old_stat && !G::CFGUpdate) {
					Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].StatTrak.Kills = 0;
					old_stat = Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].StatTrak.Type;
				}
				else if (G::CFGUpdate) {
					old_stat = Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].StatTrak.Type;
					G::CFGUpdate = false;
				}

				if (Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].StatTrak.Type == 2) { // Custom
					ImGui::InputInt(Eng ? xs(" Kills") : xs(u8" �������"), &Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].StatTrak.Kills);
				}
				ImGui::Checkbox(Eng ? xs(" Name") : xs(u8" ���"), &Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].CustomName.Enabled);
				if (Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].CustomName.Enabled) {

					ImGui::SameLine();

					static char name[32] = "";
					for (int i = 0; i < Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].CustomName.Name.size(); ++i)
						name[i] = Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].CustomName.Name[i];

					ImGui::InputText(xs("##Name"), name, 32);
					Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].CustomName.Name = name;
				}

				SelectedText(Eng ? xs("Stikers") : xs(u8"�������"));

				static int sticker = 0;

				sticker += 1;

				ImGui::SliderInt(Eng ? xs(" Sticker pos") : xs(u8" ��� �������"), &sticker, 1, 4);
				if (sticker < 1 || 5 < sticker) sticker = 1;

				sticker -= 1;

				ImGui::PushItemWidth(-2);

				static char search[32] = "";
				ImGui::InputText(xs("##Search_stikers"), search, 32);

				ImGui::SameLine();

				if (old_weapon != Weapon || old_team_mode != setting_mode_ct_tt) {

					old_weapon = Weapon;
					old_team_mode = setting_mode_ct_tt;

					for (int i = 0; i < 32; ++i) {
						search[i] = 0;
					}
				}

				stickerPaints.clear();

				paint_kits sticker_kits;
				for (int i = 0; i < SkinChanger::stickerKits.size(); ++i) {
					if (strstr(SkinChanger::stickerKits[i].name.c_str(), search) || search == nullptr) {
						sticker_kits.name = SkinChanger::stickerKits[i].name;
						sticker_kits.skin_id = SkinChanger::stickerKits[i].id;
						stickerPaints.push_back(sticker_kits);
					}
				}

				static int stickerID = 0;
				for (int i = 0; i < stickerPaints.size(); ++i) {
					if (Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].Sticker[sticker].id == stickerPaints[i].skin_id) {
						stickerID = i;
						break;
					}
				}

				ImGui::Combo(Eng ? xs("Sticker") : xs(u8"������"), &stickerID, [](void* data, int idx, const char** out_text)
				{
					*out_text = stickerPaints[idx].name.c_str();
					return true;
				}, nullptr, stickerPaints.size(), 10);

				ImGui::PopItemWidth();

				Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].Sticker[sticker].id = stickerPaints[stickerID].skin_id;


				ImGui::SliderFloat(xs("##Sticker_Wear"), &Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].Sticker[sticker].wear, 0.00f, 1.00f, Eng ? xs("Wear: %.3f") : xs(u8"��������: %.3f"));

				//ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));
				//ImGui::PushItemWidth(-2);

				ImGui::SliderFloat(xs("##Sticker_Scale"), &Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].Sticker[sticker].scale, 0.01f, 5.00f, Eng ? xs("Scale: %.3f") : xs(u8"�������: %.3f"));
				//ImGui::SameLine();
				ImGui::SliderFloat(xs("##Sticker_Rotation"), &Opts.Misc.Changer.Skins.Weapons[setting_mode_ct_tt][Weapon].Sticker[sticker].rotation, 0.00f, 360.00f, Eng ? xs("Rotation: %.3f") : xs(u8"��������: %.1f"));

				//ImGui::PopItemWidth();
				//ImGui::PopStyleVar();

					// Combo end

					//ImGui::Separator();

				//}
				//else
				//{
				//	ImGui::Checkbox(Eng ? xs(" Enable skins") : xs(u8" �������� �����"), &Opts.Misc.Changer.Skins.EnableSkins);
				//	ImGui::SameLine();
				//	ImGui::Checkbox(Eng ? xs(" Auto select current weapon") : xs(u8" ���� ����������� ������"), &Opts.Misc.Changer.Skins.AutoSelectWeapon);
				//	ImGui::Combo(Eng ? xs(" Setting mode") : xs(u8" ����� ���������"), &mode, Eng ? SkinChangerSettignMode : SkinChangerSettignModeRus, asize(SkinChangerSettignMode));
				//}

				ImGui::EndChild();
				ImGui::NextColumn();
				ImGui::BeginChild(xs("##SkinChangerKnifesAndGloves"), ImVec2(0, 237), true, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);

				ImGui::Checkbox(Eng ? xs("Knifes") : xs(u8"����"), &Opts.Misc.Changer.Skins.EnableKnife);
				ImGui::SameLine();
				ImGui::Combo(xs("##Model"), &Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].ModelIndex, Eng ? Knife_Model : Knife_Model_Rus, asize(Knife_Model));

				ImGui::PushItemWidth(-2);

				static char search2[32] = "";
				ImGui::InputText(xs("##Search_knifes"), search2, 32);

				ImGui::SameLine();

				static int old_settings = setting_mode_ct_tt;
				if (old_settings != setting_mode_ct_tt) {
					for (int i = 0; i < 32; ++i) {
						search2[i] = 0;
					}

					old_settings = setting_mode_ct_tt;
				}

				KnifesPaints.clear();

				paint_kits skin_kits2;
				for (int i = 0; i < SkinChanger::skinKits.size(); ++i) {
					if (strstr(SkinChanger::skinKits[i].name.c_str(), search2) || search2 == nullptr) {
						skin_kits2.name = SkinChanger::skinKits[i].name;
						skin_kits2.skin_id = SkinChanger::skinKits[i].id;
						KnifesPaints.push_back(skin_kits2);
					}
				}

				static int skinID2 = 0;
				for (int i = 0; i < KnifesPaints.size(); ++i) {
					if (Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].SkinIndex == KnifesPaints[i].skin_id) {
						skinID2 = i;
						break;
					}
				}

				ImGui::Combo(Eng ? xs(" Skin") : xs(u8" ����"), &skinID2, [](void* data, int idx, const char** out_text)
				{
					*out_text = KnifesPaints[idx].name.c_str();
					return true;
				}, nullptr, KnifesPaints.size(), 10);

				ImGui::PopItemWidth();

				Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].SkinIndex = KnifesPaints[skinID2].skin_id;

				ImGui::PushItemWidth(-2);

				ImGui::SliderFloat(xs("##Wear_knifes"), &Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].Wear, 0.f, 1.f, Eng ? xs("Wear: %.3f") : xs(u8"��������: %.3f"));
				ImGui::SameLine();
				ImGui::InputInt(Eng ? xs(" Seed") : xs(u8" ������"), &Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].Seed);

				ImGui::PopItemWidth();

				ImGui::Combo(Eng ? xs(" StatTrak") : xs(u8" ��������"), &Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].StatTrak.Type, Eng ? StatTrakType : StatTrakTypeRus, ARRAYSIZE(StatTrakType));

				static int old_stat2 = Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].StatTrak.Type;
				if (Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].StatTrak.Type != old_stat2 && !G::CFGUpdate) {
					Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].StatTrak.Kills = 0;
					old_stat2 = Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].StatTrak.Type;
				}
				else if (G::CFGUpdate) {
					old_stat2 = Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].StatTrak.Type;
					G::CFGUpdate = false;
				}

				if (Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].StatTrak.Type == 2) { // Custom
					ImGui::InputInt(Eng ? xs(" Kills") : xs(u8" �������"), &Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].StatTrak.Kills);
				}
				ImGui::Checkbox(Eng ? xs(" Name") : xs(u8" ���"), &Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].CustomName.Enabled);
				if (Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].CustomName.Enabled) {

					ImGui::SameLine();

					static char name[32] = "";
					for (int i = 0; i < Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].CustomName.Name.size(); ++i)
						name[i] = Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].CustomName.Name[i];

					ImGui::InputText(xs("##Name_knifes"), name, 32);
					Opts.Misc.Changer.Skins.Knifes[setting_mode_ct_tt].CustomName.Name = name;
				}

				ImGui::Spacing();
				ImGui::Separator();
				ImGui::Spacing();

				ImGui::Checkbox(Eng ? xs("Gloves") : xs(u8"��������"), &Opts.Misc.Changer.Skins.EnableGlove);
				ImGui::SameLine();
				ImGui::Combo(xs("##Model_gloves"), &Opts.Misc.Changer.Skins.Gloves[setting_mode_ct_tt].ModelIndex, Eng ? Glove_Model : Glove_Model_Rus, ARRAYSIZE(Glove_Model));

				ImGui::Combo(Eng ? xs(" Skin ") : xs(u8" ���� "), &Opts.Misc.Changer.Skins.Gloves[setting_mode_ct_tt].SkinIndex, Eng ? Glove_Skin : Glove_Skin_Rus, ARRAYSIZE(Glove_Skin));

				ImGui::PushItemWidth(-2);

				ImGui::SliderFloat(xs("##Wear_glove"), &Opts.Misc.Changer.Skins.Gloves[setting_mode_ct_tt].Wear, 0.00f, 1.00f, Eng ? xs("Wear: %.3f") : xs(u8"��������: %.3f"));
				ImGui::SameLine();
				ImGui::InputInt(Eng ? xs(" Seed ") : xs(u8" ������ "), &Opts.Misc.Changer.Skins.Gloves[setting_mode_ct_tt].Seed);

				ImGui::PopItemWidth();

				ImGui::EndChild();
				ImGui::BeginChild(xs("##SkinChangerInGame"), ImVec2(0, 0), true, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);

				if (I::Engine->IsInGame() && G::LocalPlayer && G::LocalPlayer->GetAlive() && (G::LocalPlayer->GetWeapon()->IsFiredWeaponType() || G::LocalPlayer->GetWeapon()->GetType() == WT_KNIFES))
				{
					if (ImGui::Button(Eng ? xs("Current weapon") : xs(u8"������� ������"), ImVec2(-1, 0)))
					{
						Type = G::LocalPlayer->GetWeapon()->GetType() - 4;

						switch (Type)
						{
						case 0: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex(); break;
						case 1: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 10; break;
						case 2: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 17; break;
						case 3: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 24; break;
						case 4: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 28; break;
						case 5: weapon = G::LocalPlayer->GetWeapon()->GetAimIndex() - 32; break;
						default: break;
						}
					}

					if (Opts.Misc.Changer.Skins.SettingsForTeams)
					{
						if (ImGui::Button(Eng ? xs("Current team") : xs(u8"������� �������"), ImVec2(-1, 0)))
						{
							setting_mode_ct_tt = G::LocalPlayer->GetTeam() == 3 ? 0 : 1;
						}
					}

					if (ImGui::Button(Eng ? xs("Update") : xs(u8"��������"), ImVec2(-1, 0)))
					{
						U::ForceFullUpdate();
					}
				}
				else
				{
					ImGui::Text(Eng ? xs("Start game") : xs(u8"��������� ����"));
				}

				if (!Opts.Misc.Changer.Skins.SettingsForTeams)
				{
					setting_mode_ct_tt = 2;
				}
				else
				{
					if (setting_mode_ct_tt == 2)
					{
						setting_mode_ct_tt = 0;
					}
				}

				ImGui::EndChild();
				ImGui::Columns(1, nullptr, false);
			}
			else if (ActiveSubTab == 2)
			{
				if (ImGui::Checkbox(Eng ? xs("Enable") : xs(u8"��������"), &Opts.Misc.Changer.Profile.Enabled))
				{
					U::SendCSGOMessages();
				}

				ImGui::Separator();

				ImGui::InputInt(Eng ? xs("Level") : xs(u8"�������"), &Opts.Misc.Changer.Profile.Level, 0, 40);
				ImGui::InputInt(Eng ? xs("Experience") : xs(u8"����"), &Opts.Misc.Changer.Profile.Experience, 0, 5000);

				ImGui::Combo(Eng ? xs("5x5 rank") : xs(u8"���� � 5�5"), &Opts.Misc.Changer.Profile.MMRank, Eng ? MMRanks : MMRanksRus, asize(MMRanks));
				ImGui::InputInt(Eng ? xs("5x5 wins") : xs(u8"������ � 5�5"), &Opts.Misc.Changer.Profile.MMWins);

				ImGui::Combo(Eng ? xs("2x2 rank") : xs(u8"���� � 2�2"), &Opts.Misc.Changer.Profile.WMRank, Eng ? MMRanks : MMRanksRus, asize(MMRanks));
				ImGui::InputInt(Eng ? xs("2x2 wins") : xs(u8"������ � 2�2"), &Opts.Misc.Changer.Profile.WMWins);

				ImGui::Combo(Eng ? xs("Danger zone rank") : xs(u8"���� � ������� ����"), &Opts.Misc.Changer.Profile.DZRank, Eng ? DZRanks : DZRanksRus, asize(DZRanks));
				ImGui::InputInt(Eng ? xs("Danger zone wins") : xs(u8"������ � ������� ����"), &Opts.Misc.Changer.Profile.DZWins);

				ImGui::InputInt(Eng ? xs("Friendly") : xs(u8"�����������"), &Opts.Misc.Changer.Profile.Friendly);
				ImGui::InputInt(Eng ? xs("Leader") : xs(u8"�����"), &Opts.Misc.Changer.Profile.Leader);
				ImGui::InputInt(Eng ? xs("Teacher") : xs(u8"���������"), &Opts.Misc.Changer.Profile.Teacher);

				ByteCombo(Eng ? xs("Ban") : xs(u8"���"), Opts.Misc.Changer.Profile.Ban, Eng ? Bans : BansRus, ARRAYSIZE(Bans));
				ImGui::InputInt(Eng ? xs("Ban time") : xs(u8"����� ����"), &Opts.Misc.Changer.Profile.BanTime);

				if (ImGui::Button(Eng ? xs("Update profile") : xs(u8"�������� �������"), Eng ? ImVec2(93.f, 20.f) : ImVec2(123.f, 20.f)))
				{
					U::SendCSGOMessages();
				}
			}
			//else if (ActiveSubTab == 2) {
			//	if (ImGui::Checkbox(Eng ? xs("Enable") : xs(u8"��������"), &Opts.Misc.Changer.Inventory.Enabled))
			//	{
			//		U::SendClientHello();
			//		U::SendMMHello();
			//	}
			//
			//	static int itemidtmp = 0, itemDefinitionIndex = 0, paintKit = 0, paintkit_temp_skin = 0, paintkit_temp_gloves = 0, rarity = 0, seed = 0, raritypick = 0;
			//	static float wear = 0.f;
			//	const char* raritynames[] = { "Default (Gray)", "Consumer Grade (White)", "Industrial Grade (Light Blue)", "Mil-Spec (Darker Blue)", "Restricted (Purple)", "Classified (Pinkish Purple)", "Covert (Red)", "Exceedingly Rare (Gold)" };
			//	const char* itemnames[] = { "Desert Eagle", "Dual Berettas", "Five-Seven", "Glock-18", "AK-47", "AUG", "AWP", "FAMAS", "G3SG1", "Galil AR", "M249", "M4A4",
			//		"MAC-10", "P90", "UMP-45", "XM1014", "PP-Bizon", "MAG-7", "Negev", "Sawed-Off", "Tec-9", "P2000", "MP7", "MP5-SD", "MP9", "Nova", "P250", "SCAR-20", "SG 556", "SSG 08",
			//		"M4A1-S", "USP-S", "CZ75-Auto", "R8 Revolver", "Bayonet", "Flip Knife", "Gut Knife", "Karambit", "M9 Bayonet", "Huntsman Knife", "Falchion Knife", "Bowie Knife", "Butterfly Knife",
			//		"Shadow Daggers", "Navaja Knife", "Stiletto Knife", "Ursus Knife", "Talon Knife", "Sport Gloves", "Driver Gloves", "Hand Wraps", "Moto Gloves", "Specialist Gloves", "Hydra Gloves" };
			//	const int weapons_id[] = { WEAPON_DEAGLE, 2, WEAPON_FIVESEVEN, WEAPON_GLOCK, WEAPON_AK47, WEAPON_AUG, WEAPON_AWP, WEAPON_FAMAS, WEAPON_G3SG1, WEAPON_GALIL, WEAPON_M249,
			//		16, WEAPON_MAC10, WEAPON_P90, WEAPON_UMP45, WEAPON_XM1014, WEAPON_BIZON, WEAPON_MAG7, WEAPON_NEGEV, WEAPON_SAWEDOFF, WEAPON_TEC9, WEAPON_P2000, WEAPON_MP7, WEAPON_MP5SD, WEAPON_MP9,
			//		WEAPON_NOVA, WEAPON_P250, WEAPON_SCAR20, WEAPON_SG553, WEAPON_SSG08, WEAPON_M4A1S, WEAPON_USPS, WEAPON_CZ75, WEAPON_REVOLVER, 500, WEAPON_KNIFE_FLIP,
			//		WEAPON_KNIFE_GUT, WEAPON_KNIFE_KARAMBIT, WEAPON_KNIFE_M9_BAYONET, WEAPON_KNIFE_TACTICAL, WEAPON_KNIFE_FALCHION, WEAPON_KNIFE_SURVIVAL_BOWIE, WEAPON_KNIFE_SURVIVAL_BOWIE,
			//		WEAPON_KNIFE_BUTTERFLY, WEAPON_KNIFE_PUSH, WEAPON_KNIFE_GYPSY_JACKKNIFE, WEAPON_KNIFE_STILETTO, WEAPON_KNIFE_URSUS, WEAPON_KNIFE_WIDOWMAKER,
			//		5030, 5031, 5032, 5033, 5034, 5035
			//	};
			//	ImGui::Combo(("Item"), &itemidtmp, itemnames, ARRAYSIZE(itemnames));
			//	itemDefinitionIndex = weapons_id[itemidtmp];
			//
			//	//ImGui::Combo("Skin", &paintkit_temp_skin, KnifeSkins[0].SkinNames);
			//	//	paintKit = WeaponSkins[0].SkinPaintKit[paintkit_temp_skin];
			//	//else {
			//	//	ImGui::ComboBoxArray("Skin", &paintkit_temp_gloves, GloveSkin[0].Names);
			//	//	paintKit = GloveSkin[0].PaintKit[paintkit_temp_gloves];
			//	//}
			//
			//	ImGui::Combo(("Rarity"), &rarity, raritynames, ARRAYSIZE(raritynames));
			//	ImGui::InputInt("Seed", &seed);
			//	ImGui::SliderFloat("Wear", &wear, FLT_MIN, 1.f, "%.10f", 5);
			//
			//	if (ImGui::Button("Add")) {
			//		Opts.Misc.Changer.Inventory.weapons.insert(Opts.Misc.Changer.Inventory.weapons.end(), { itemDefinitionIndex , paintKit , rarity , seed, wear });
			//
			//		//Opts.Misc.Changer.Inventory.CustomWeaponCount = Settings::InvChanger::weapons.size();
			//	} ImGui::SameLine();
			//
			//	//if (ImGui::Button("Apply##Skin"))
			//	//	SendClientHello();
			//
			//	//ImGui::NextColumn();
			//
			//	//ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 1, 1));
			//	//ImGui::ListBoxHeader("Skins");
			//	//int weapon_index = 0;
			//	//for (auto weapon : Settings::InvChanger::weapons) {
			//	//	if (ImGui::Selectable(std::string(std::to_string(weapon.itemDefinitionIndex) + " " + std::to_string(weapon.paintKit)).c_str())) {
			//	//		Settings::InvChanger::weapons.erase(Settings::InvChanger::weapons.begin() + weapon_index);
			//	//		Settings::InvChanger::CustomWeaponCount = Settings::InvChanger::weapons.size();
			//	//	}
			//	//	weapon_index++;
			//	//}
			//	//ImGui::ListBoxFooter();
			//	//ImGui::PopStyleColor();
			//	//ImGui::Columns(1, nullptr, false);
			//
			//	if (ImGui::Button(Eng ? xs("Update inventory") : xs(u8"�������� ���������"), Eng ? ImVec2(93.f, 20.f) : ImVec2(123.f, 20.f)))
			//	{
			//		U::SendClientHello();
			//		U::SendMMHello();
			//	}
			//}
			else if (ActiveSubTab == 3) {
				ImGui::Checkbox(Eng ? xs("Enable viewmodel") : xs(u8"�������� ������ �� xyz"), &Opts.Misc.Changer.View.bViewModel);
				ImGui::SliderFloat(Eng ? xs("Viewmodel x") : xs(u8"������ �� x"), &Opts.Misc.Changer.View.fViewModelX, -30.f, 30.f, "%.2f");
				ImGui::SliderFloat(Eng ? xs("Viewmodel y") : xs(u8"������ �� y"), &Opts.Misc.Changer.View.fViewModelY, -30.f, 30.f, "%.2f");
				ImGui::SliderFloat(Eng ? xs("Viewmodel z") : xs(u8"������ �� z"), &Opts.Misc.Changer.View.fViewModelZ, -30.f, 30.f, "%.2f");

				ImGui::Checkbox(Eng ? xs("Enable view fov") : xs(u8"�������� ��������� ������"), &Opts.Misc.Changer.View.bViewFOV);
				ImGui::SliderFloat(Eng ? xs("View fov") : xs(u8"��������� ������"), &Opts.Misc.Changer.View.fViewFOV, 1.f, 120.f, "%.2f");

				ImGui::Checkbox(Eng ? xs("Enable model fov") : xs(u8"�������� ��������� ������"), &Opts.Misc.Changer.View.bModelFOV);
				ImGui::SliderFloat(Eng ? xs("Model fov") : xs(u8"��������� ������"), &Opts.Misc.Changer.View.fModelFOV, 1.f, 120.f, "%.2f");

				ImGui::Checkbox(Eng ? xs("Enable third person") : xs(u8"�������� 3-� ����"), &Opts.Misc.Changer.View.ThirdPerson);
				ImGui::SameLine();
				ByteKeyButton(Eng ? xs(" key") : xs(u8" ������"), Opts.Misc.Changer.View.ThirdPersonKey);
				ImGui::SameLine();
				ImGui::Checkbox(Eng ? xs("Remove local player") : xs(u8"������ ���������� ������"), &Opts.Misc.Changer.View.RemoveLocalPlayer);

				ByteSlider(xs("##third_person_dist"), Opts.Misc.Changer.View.ThirdPersonDist, 30, 200, Eng ? xs("Distance: %d") : xs(u8"���������: %d"));

				ImGui::Checkbox(Eng ? xs("No visual recoil") : xs(u8"��������� ���������� ������"), &Opts.Misc.Changer.View.NoVisualRecoil);
			}
		}
		else if (G::MainTabIndex == 4) // selected MiscSubTub
		{
			if (ActiveSubTab == 0) {

				ImGui::Columns(2, nullptr, false);
				ImGui::BeginChild(xs("##Global"), ImVec2(0, 0), true);

				//ImGui::Checkbox(Eng ? xs("Enable radio") : xs(u8"�������� �����"), &Opts.Misc.Globals.RadioEnabled);

#define standart_distantion 124

				ImGui::Checkbox(Eng ? xs("Status bar") : xs(u8"������ ���"), &Opts.Misc.Globals.StatusBar);
				ImGui::SameLine(standart_distantion);
				ImGui::Checkbox(Eng ? xs("Event log") : xs(u8"��� �������"), &Opts.Misc.Globals.EventLog);

				ImGui::Checkbox(Eng ? xs("Real aiming") : xs(u8"�������� ������������"), &Opts.Misc.Globals.RealAiming);
				ImGui::SameLine();
				ByteKeyButton(Eng ? xs(" key") : xs(u8" ������"), Opts.Misc.Globals.RealAimingKey);

				ImGui::Checkbox(Eng ? xs("Bunny hop") : xs(u8"���� ���"), &Opts.Misc.Globals.BunnyHop);
				ImGui::SameLine(standart_distantion);
				ImGui::Checkbox(Eng ? xs("Auto strafe") : xs(u8"����. �������"), &Opts.Misc.Globals.AutoStrafe);

				ByteSlider(xs("##Jump_chance"), Opts.Misc.Globals.JumpChance, 1, 100, Eng ? xs("Jump chance: %d") : xs(u8"���� ������: %d"));

				ImGui::Checkbox(Eng ? xs("Auto knife") : xs(u8"����. ���"), &Opts.Misc.Globals.AutoKnife);
				ImGui::SameLine(standart_distantion);
				ImGui::Checkbox(Eng ? xs("Auto zeus") : xs(u8"����. ����"), &Opts.Misc.Globals.AutoZeus);

				ImGui::Checkbox(Eng ? xs("Auto accept") : xs(u8"����. ��������"), &Opts.Misc.Globals.AutoAccept);
				ImGui::SameLine(standart_distantion);
				ImGui::Checkbox(Eng ? xs("Auto pistol") : xs(u8"����. ���������"), &Opts.Misc.Globals.AutoPistol);

				ImGui::Checkbox(Eng ? xs("Legit desync") : xs(u8"�������� �������"), &Opts.Misc.Globals.LegitDesync);
				ByteCombo(Eng ? xs("Desync type") : xs(u8"��� ��������"), Opts.Misc.Globals.LegitDesyncType, LegitDesyncType, asize(LegitDesyncType));

				if (Opts.Misc.Globals.LegitDesyncType == 0)
				{
					ByteKeyButton(Eng ? xs("Flip key") : xs(u8"������ ����������"), Opts.Misc.Globals.LegitDesyncFlipKey);
				}

				ImGui::Checkbox(Eng ? xs("FPS Boost") : xs(u8"��� ����"), &Opts.Misc.Globals.FPSBoost);
				ImGui::SameLine(standart_distantion);
				ImGui::Checkbox(Eng ? xs("Night mode") : xs(u8"������ �����"), &Opts.Misc.Globals.NightMode);

				if (Opts.Misc.Globals.NightMode)
				{
					ImGui::SliderFloat(xs("##Player_bright"), &Opts.Misc.Globals.PlayerBright, 0.f, 20.f, Eng ? xs("Player bright: %.3f") : xs(u8"������� �������: %.3f"));
					ImGui::SliderFloat(xs("##Map_bright"), &Opts.Misc.Globals.MapBright, 0.f, 1.f, Eng ? xs("Map bright: %.5f") : xs(u8"������� �����: %.5f"));
				}

				ImGui::Checkbox(Eng ? xs("Hands on knife") : xs(u8"���� � �����"), &Opts.Misc.Globals.HadsChanger);

				if (Opts.Misc.Globals.HadsChanger)
				{
					ImGui::SameLine(standart_distantion);
					ImGui::Checkbox(Eng ? xs("Override") : xs(u8"��������������"), &Opts.Misc.Globals.HadsChangerOverride);
				}

				//ImGui::Checkbox(Eng ? xs("Fast switch") : xs(u8"������� ������������"), &Opts.Misc.Globals.FastSwitch);

				SelectedText(Eng ? xs("Removes") : xs(u8"��������� �������"));

				ImGui::Checkbox(Eng ? xs("Rank reveal") : xs(u8"����� ������"), &Opts.Misc.Globals.RankReveal);
				ImGui::SameLine(standart_distantion);
				ImGui::Checkbox(Eng ? xs("Infinity crouch") : xs(u8"����������� ����������"), &Opts.Misc.Globals.InfinityCrouch);
				ImGui::Checkbox(Eng ? xs("No smoke") : xs(u8"������ ���"), &Opts.Misc.Globals.NoSmoke);

				if (Opts.Misc.Globals.NoSmoke)
				{
					ImGui::SameLine(standart_distantion);
					ImGui::Checkbox(Eng ? xs("Wire frame") : xs(u8"���������"), &Opts.Misc.Globals.NoSmokeWireFrame);
				}

				ImGui::Checkbox(Eng ? xs("No scope") : xs(u8"������ ����"), &Opts.Misc.Globals.NoScope);
				ImGui::SameLine(standart_distantion);

				ImGui::Checkbox(Eng ? xs("No zoom") : xs(u8"������ ���"), &Opts.Misc.Globals.NoZoom);

				//ImGui::Checkbox(Eng ? xs("No 3d sky") : xs(u8"������ 3d ����"), &Opts.Misc.Globals.No3dSky);
				//ImGui::SameLine(106);
				//ImGui::Checkbox(Eng ? xs("No fog") : xs(u8"������ �����"), &Opts.Misc.Globals.NoFog);
				//ImGui::SameLine(212);
				//ImGui::Checkbox(Eng ? xs("No grass") : xs(u8"������ �����"), &Opts.Misc.Globals.NoGrass);
				//ImGui::SameLine(318);
				//ImGui::Checkbox(Eng ? xs("No shadows") : xs(u8"������ ����"), &Opts.Misc.Globals.NoShadows);

				ImGui::Checkbox(Eng ? xs("Fix sensivity in scope") : xs(u8"����� ����� � �����"), &Opts.Misc.Globals.FixSensivityInScope);

				ByteSlider(xs("##Alpha"), Opts.Misc.Globals.FlashAlpha, 0, 255, Eng ? xs("Flash alpha: %d") : xs(u8"������� ����������: %d"));

				ImGui::EndChild();
				ImGui::NextColumn();
				ImGui::BeginChild(xs("##Secondery"), ImVec2(0, 0), true);

				static char NameChangerBuffer[32] = "";
				ImGui::InputText(Eng ? xs("New name") : xs(u8"����� ���"), NameChangerBuffer, 32);

				if (ImGui::Button(Eng ? xs(" Change name ") : xs(u8" �������� ��� "))) Misc::NameChange(NameChangerBuffer);
				ImGui::SameLine();
				if (ImGui::Button(Eng ? xs(" Hide name ") : xs(u8" ������ ��� "))) Misc::NameChange(xs("\n\xAD\xAD\xAD"));

				static char ClantagChangerBuffer[32] = "";
				ImGui::InputText(Eng ? xs("New clantag") : xs(u8"����� �������"), ClantagChangerBuffer, 32);

				static int temp_clantagmode = Opts.Misc.Secondary.ClanTagMode;
				if (ImGui::Button(Eng ? xs("Update") : xs(u8"��������")))
				{
					Opts.Misc.Secondary.ClanTag = ClantagChangerBuffer;
					Opts.Misc.Secondary.ClanTagMode = temp_clantagmode;
				}
				ImGui::SameLine();
				ImGui::Combo(xs("##modes"), &temp_clantagmode, Eng ? ClanTagModes : ClanTagModesRus, ARRAYSIZE(ClanTagModes));

				//	Misc::ClanTagChanger(ClantagChangerBuffer);

				ImGui::Separator();

				ImGui::Checkbox(Eng ? xs("Enable chat spam") : xs(u8"�������� ��� ����"), &Opts.Misc.Secondary.ChatSpam);
				ImGui::SameLine();

				if (ImGui::Button(Eng ? xs("Update file") : xs(u8"�������� ����")))
				{
					Opts.Misc.Secondary.chat_spam_mass_file.clear();

					std::ifstream file(Opts.Misc.Secondary.ChatSpamPathToFile);

					std::string str = "";
					while (getline(file, str))
					{
						Opts.Misc.Secondary.chat_spam_mass_file.push_back("say " + str);
					};

					file.close();
				}

				static char ChatSpamFileBuffer[32] = "";
				ImGui::InputText(Eng ? xs(" path to file") : xs(u8" ���� �� �����"), ChatSpamFileBuffer, 32);
				Opts.Misc.Secondary.ChatSpamPathToFile = ChatSpamFileBuffer;

				ImGui::Checkbox(Eng ? xs("Fake crouch") : xs(u8"�������� ����������"), &Opts.Misc.Secondary.FakeCrouch);
				ImGui::SameLine();
				ByteKeyButton(Eng ? xs(" key") : xs(u8" ������"), Opts.Misc.Secondary.FakeCrouchKey);

				ImGui::Checkbox(Eng ? xs("Enable fakeLag") : xs(u8"�������� ���� ����"), &Opts.Misc.Secondary.FakeLag);
				ByteCombo(Eng ? xs("FakeLag type") : xs(u8"��� ���������"), Opts.Misc.Secondary.FakeLagType, Eng ? FakeLagMode : FakeLagModeRus, ARRAYSIZE(FakeLagMode));

				if (Opts.Misc.Secondary.FakeLagType == 0)
				{
					ByteSlider(xs("##Standing_ticks"), Opts.Misc.Secondary.StandingAmount, 1, 14, Eng ? xs("Standing ticks: %d") : xs(u8"���� ����� ������: %d"));
					ByteSlider(xs("##Moving_ticks"), Opts.Misc.Secondary.MovingAmount, 1, 14, Eng ? xs("Moving ticks: %d") : xs(u8"���� �� ����� ������: %d"));
					ByteSlider(xs("##Jumping_ticks"), Opts.Misc.Secondary.JumpingAmount, 1, 14, Eng ? xs("Jumping ticks: %d") : xs(u8"���� �� ����� ������: %d"));
				}

				ImGui::Checkbox(Eng ? xs("Slowwalk") : xs(u8"��������� ������"), &Opts.Misc.Secondary.SlowWalk);
				ImGui::SameLine();
				ByteKeyButton(Eng ? xs(" key ") : xs(u8" ������ "), Opts.Misc.Secondary.SlowWalkKey);
				ImGui::SliderInt(xs("##Speed"), &Opts.Misc.Secondary.SlowWalkSpeed, 1, 150, Eng ? xs("Speed: %d") : xs(u8"��������: %d"));
				ImGui::Checkbox(Eng ? xs("Force ragdoll") : xs(u8"����� ������ ���� ��������"), &Opts.Misc.Secondary.ForceRagDoll);

				//ImGui::Checkbox(Eng ? xs("Real ahead") : xs(u8"Real ahead"), &Opts.Misc.Secondary.ReadAhead);

				ImGui::EndChild();
				ImGui::Columns(1, nullptr, false);
			}
			else if (ActiveSubTab == 1)
			{
				ImGui::Checkbox(Eng ? xs("Enable buybot") : xs(u8"�������� �������"), &Opts.Misc.Other.BuyBot.Enable);

				ByteCombo(Eng ? xs("Weapon") : xs(u8"������"), Opts.Misc.Other.BuyBot.Weapon, BuyBotWeapons, ARRAYSIZE(BuyBotWeapons));
				ByteCombo(Eng ? xs("Pistol") : xs(u8"��������"), Opts.Misc.Other.BuyBot.Pistol, BuyBotPistols, ARRAYSIZE(BuyBotPistols));

				ByteCombo(Eng ? xs("Grenade 1") : xs(u8"������� 1"), Opts.Misc.Other.BuyBot.grenade_1, BuyBotGrenades, ARRAYSIZE(BuyBotGrenades));
				ByteCombo(Eng ? xs("Grenade 2") : xs(u8"������� 2"), Opts.Misc.Other.BuyBot.grenade_2, BuyBotGrenades, ARRAYSIZE(BuyBotGrenades));
				ByteCombo(Eng ? xs("Grenade 3") : xs(u8"������� 3"), Opts.Misc.Other.BuyBot.grenade_3, BuyBotGrenades, ARRAYSIZE(BuyBotGrenades));
				ByteCombo(Eng ? xs("Grenade 4") : xs(u8"������� 4"), Opts.Misc.Other.BuyBot.grenade_4, BuyBotGrenades, ARRAYSIZE(BuyBotGrenades));

				ByteCombo(Eng ? xs("Armor") : xs(u8"�����"), Opts.Misc.Other.BuyBot.Armor, BuyBotArmor, ARRAYSIZE(BuyBotArmor));

				ImGui::Checkbox(xs("Zeus"), &Opts.Misc.Other.BuyBot.zeus);
				ImGui::SameLine();
				ImGui::Checkbox(xs("Defuse Kit"), &Opts.Misc.Other.BuyBot.defuse_kit);
			}
			else if (ActiveSubTab == 2)
			{
				ColorEdit(Eng ? xs("Players-global enemy vis") : xs(u8"������-������ ��� ����������"), Opts.Colors.Visuals.PlayersGlobalEnemyVisible, true);
				ColorEdit(Eng ? xs("Players-global enemy invis") : xs(u8"������-������ ����� ����������"), Opts.Colors.Visuals.PlayersGlobalEnemyInvisible, true);
				ColorEdit(Eng ? xs("Players-global teammate vis") : xs(u8"������-������ ��� �������"), Opts.Colors.Visuals.PlayersGlobalTeammateVisible, true);
				ColorEdit(Eng ? xs("Players-global teammate invis") : xs(u8"������-������ ����� �������"), Opts.Colors.Visuals.PlayersGlobalTeammateInvisible, true);

				ColorEdit(Eng ? xs("Players-lines enemy vis") : xs(u8"������-����� ��� ����������"), Opts.Colors.Visuals.PlayersSnipeLineEnemyVisible, true);
				ColorEdit(Eng ? xs("Players-lines enemy invis") : xs(u8"������-����� ����� ����������"), Opts.Colors.Visuals.PlayersSnipeLineEnemyInvisible, true);
				ColorEdit(Eng ? xs("Players-lines teammate vis") : xs(u8"������-����� ��� �������"), Opts.Colors.Visuals.PlayersSnipeLineTeammateVisible, true);
				ColorEdit(Eng ? xs("Players-lines teammate invis") : xs(u8"������-����� ����� �������"), Opts.Colors.Visuals.PlayersSnipeLineTeammateInvisible, true);

				ColorEdit(Eng ? xs("Players-chams enemy vis") : xs(u8"������-����� ��� ����������"), Opts.Colors.Visuals.PlayersChamsEnemyVisible, true);
				ColorEdit(Eng ? xs("Players-chams enemy invis") : xs(u8"������-����� ����� ����������"), Opts.Colors.Visuals.PlayersChamsEnemyInvisible, true);
				ColorEdit(Eng ? xs("Players-chams teammate vis") : xs(u8"������-����� ��� �������"), Opts.Colors.Visuals.PlayersChamsTeammateVisible, true);
				ColorEdit(Eng ? xs("Players-chams teammate invis") : xs(u8"������-����� ����� �������"), Opts.Colors.Visuals.PlayersChamsTeammateInvisible, true);

				ColorEdit(Eng ? xs("Players-glow enemy vis") : xs(u8"������-���� ��� ����������"), Opts.Colors.Visuals.PlayersGlowEnemyVisible, true);
				ColorEdit(Eng ? xs("Players-glow enemy invis") : xs(u8"������-���� ����� ����������"), Opts.Colors.Visuals.PlayersGlowEnemyInvisible, true);
				ColorEdit(Eng ? xs("Players-glow teammate vis") : xs(u8"������-���� ��� �������"), Opts.Colors.Visuals.PlayersGlowTeammateVisible, true);
				ColorEdit(Eng ? xs("Players-glow teammate invis") : xs(u8"������-���� ����� �������"), Opts.Colors.Visuals.PlayersGlowTeammateInvisible, true);

				ColorEdit(Eng ? xs("Weapon-glow weapons") : xs(u8"������-���� ������"), Opts.Colors.Visuals.WeaponGlowWeapons, true);
				ColorEdit(Eng ? xs("Weapon-glow grenades") : xs(u8"������-���� �������"), Opts.Colors.Visuals.WeaponGlowGrenades, true);
				ColorEdit(Eng ? xs("Weapon-glow bomb") : xs(u8"������-���� �����"), Opts.Colors.Visuals.WeaponGlowBomb, true);

				ColorEdit(Eng ? xs("Radar-enemy vis") : xs(u8"�����-���������� ���"), Opts.Colors.Visuals.RadarEnemyVisible, true);
				ColorEdit(Eng ? xs("Radar-enemy invis") : xs(u8"�����-���������� �����"), Opts.Colors.Visuals.RadarEnemyInvisible, true);
				ColorEdit(Eng ? xs("Radar-teammate vis") : xs(u8"�����-������� ���"), Opts.Colors.Visuals.RadarTeammateVisible, true);
				ColorEdit(Eng ? xs("Radar-teammate invis") : xs(u8"�����-������� �����"), Opts.Colors.Visuals.RadarTeammateInvisible, true);

				ColorEdit(Eng ? xs("Chams hands") : xs(u8"����� ���"), Opts.Colors.Misc.ChamsHands, true);
				ColorEdit(Eng ? xs("Chams sleeves") : xs(u8"����� �����"), Opts.Colors.Misc.ChamsSleeves, true);
				ColorEdit(Eng ? xs("Chams weapons") : xs(u8"����� ������"), Opts.Colors.Misc.ChamsWeapons, true);

				ColorEdit(Eng ? xs("Bullet trace") : xs(u8"����� ����"), Opts.Colors.Misc.BulletTrace, true);
				ColorEdit(Eng ? xs("Grenade prediction") : xs(u8"���������� �������"), Opts.Colors.Misc.GrenadePrediction, true);

				ColorEdit(Eng ? xs("Walls") : xs(u8"�����"), Opts.Colors.Misc.Walls, true);
				ColorEdit(Eng ? xs("Sky") : xs(u8"����"), Opts.Colors.Misc.Sky, true);
				ColorEdit(Eng ? xs("Props") : xs(u8"�����"), Opts.Colors.Misc.Prop, true);

				ColorEdit(Eng ? xs("Back ground") : xs(u8"������ ���"), Opts.Colors.Misc.BackGround, true);
				ColorEdit(Eng ? xs("Back drop square") : xs(u8"��������� ��������"), Opts.Colors.Misc.BackDropSquare, true);
				ColorEdit(Eng ? xs("Back drop outline") : xs(u8"��������� �������"), Opts.Colors.Misc.BackDropSquareOutLine, true);
				ColorEdit(Eng ? xs("Back drop lines") : xs(u8"��������� �����"), Opts.Colors.Misc.BackDropSquareLine, true);
			}
			else if (ActiveSubTab == 3)
			{
				ImGuiStyle& style = ImGui::GetStyle();

				if (ImGui::Button(Eng ? xs("Reset to default settings") : xs(u8"�������� �� ����������� ��������"), ImVec2(-1, 0)))
				{
					SetDefaultMenuColors(style.Colors);
				}

				ByteKeyButton(Eng ? xs("Key to open menu") : xs(u8"������ ��� �������� ����"), Opts.Menu.MenuKey);

				static BYTE old_panic_key = Opts.Menu.PanicKey;
				ByteKeyButton(Eng ? xs("Panic key") : xs(u8"���������� ������"), Opts.Menu.PanicKey);
				if (old_panic_key != Opts.Menu.PanicKey)
				{
					old_panic_key = Opts.Menu.PanicKey;
					panic_key_time = false;
				}
				if (!panic_key_time && !G::PressedKeys[Opts.Menu.PanicKey])
				{
					panic_key_time = true;
				}

				for (int i = 0; i < ImGuiCol_COUNT; ++i)
				{
					const char* name = ImGui::GetStyleColorName(i);
					ImGui::PushID(i);
					ImGui::ColorEdit4("##color", (float*)&style.Colors[i]);
					ImGui::SameLine(0.0f, style.ItemInnerSpacing.x);
					ImGui::TextUnformatted(name);
					ImGui::PopID();
				}
			}
			else if (ActiveSubTab == 4)
			{
				Config->UpdateCFGList();

				ImGui::PushItemWidth(300);

				static char new_cfg_name[65] = "";
				ImGui::InputText(xs("##new_cfg_name"), new_cfg_name, 65);

				ImGui::SameLine();

				ImGui::Combo(Eng ? xs(" Configs") : xs(u8" �������"), &Opts.Menu.Config, [](void* data, int idx, const char** out_text)
				{
				*out_text = Opts.Menu.MassConfigs[idx].c_str();
				return true;
				}, nullptr, Opts.Menu.MassConfigs.size(), 10);

				ImGui::PopItemWidth();


				if (ImGui::Button(Eng ? xs("Create") : xs(u8"�������"), ImVec2(100, 0)))
				{
					Config->CreateCfg(new_cfg_name);
				}

				ImGui::SameLine();

				if (ImGui::Button(Eng ? xs("Delete") : xs(u8"�������"), ImVec2(100, 0)))
				{
					Config->DeleteCfg(Opts.Menu.MassConfigs[Opts.Menu.Config]);
				}

				ImGui::SameLine();

				if (ImGui::Button(Eng ? xs("Save") : xs(u8"���������"), ImVec2(100, 0)))
				{
					Config->SaveCFG();
				}

				ImGui::SameLine();

				if (ImGui::Button(Eng ? xs("Load") : xs(u8"���������"), ImVec2(100, 0)))
				{
					Config->LoadCFG();
				}

				ImGui::SameLine();

				static bool is_open_load_lise = false;
				if (ImGui::Button(is_open_load_lise ? Eng ? xs("Close load list") : xs(u8"������� ������ ��������") : Eng ? xs("Open load list") : xs(u8"������� ������ ��������"), ImVec2(176, 0)))
				{
					is_open_load_lise = !is_open_load_lise;
				}

				if (is_open_load_lise)
				{
					static bool old_eng = Eng;
					static ImVec2 LoadListPos;
					if (old_eng != Eng)
					{
						old_eng = Eng;
						ImGui::SetNextWindowPos(LoadListPos);
					}

					ImGui::Begin(Eng ? "Load list" : u8"������ ��������", &is_open_load_lise, ImVec2(250, 420), 1.0f, ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize);
					{
						ImGui::Columns(2, "SetClearButtons", false);
						{
							if (ImGui::Button(Eng ? xs("Set all") : xs(u8"���������� ���"), ImVec2(-1, 0)))
							{
								for (size_t i = 0; i < LOAD_SETTINGS_MAX; ++i)
									Opts.Menu.Loads[i] = true;
							}

							ImGui::NextColumn();

							if (ImGui::Button(Eng ? xs("Clear all") : xs(u8"�������� ���"), ImVec2(-1, 0)))
							{
								for (size_t i = 0; i < LOAD_SETTINGS_MAX; ++i)
									Opts.Menu.Loads[i] = false;
							}
						}
						ImGui::Columns(1, nullptr, false);


						ImGui::Checkbox(Eng ? xs("RageBot") : xs(u8"��������"), &Opts.Menu.Loads[LOAD_SETTINGS_RAGE]);

						ImGui::Checkbox(Eng ? xs("LegitBot") : xs(u8"��������"), &Opts.Menu.Loads[LOAD_SETTINGS_LEGIT]);
						ImGui::Checkbox(Eng ? xs("LegitRage") : xs(u8"����������"), &Opts.Menu.Loads[LOAD_SETTINGS_LEGIT_RAGE]);

						ImGui::Checkbox(Eng ? xs("Visuals-Globals") : xs(u8"�������-����������"), &Opts.Menu.Loads[LOAD_SETTINGS_VISUAL_GLOBALS]);
						ImGui::Checkbox(Eng ? xs("Visuals-Glow") : xs(u8"�������-����"), &Opts.Menu.Loads[LOAD_SETTINGS_VISUAL_CHAMS]);
						ImGui::Checkbox(Eng ? xs("Visuals-Chams") : xs(u8"�������-�����"), &Opts.Menu.Loads[LOAD_SETTINGS_VISUAL_GLOW]);
						ImGui::Checkbox(Eng ? xs("Visuals-Other") : xs(u8"�������-���������"), &Opts.Menu.Loads[LOAD_SETTINGS_VISUAL_OTHER]);

						ImGui::Checkbox(Eng ? xs("Changers-Models") : xs(u8"��������-������"), &Opts.Menu.Loads[LOAD_SETTINGS_CHANGER_MODELS]);
						ImGui::Checkbox(Eng ? xs("Changers-Skins") : xs(u8"��������-�����"), &Opts.Menu.Loads[LOAD_SETTINGS_CHANGER_SKINS]);
						ImGui::Checkbox(Eng ? xs("Changers-Profile") : xs(u8"��������-�������"), &Opts.Menu.Loads[LOAD_SETTINGS_CHANGER_PROFILE]);
						ImGui::Checkbox(Eng ? xs("Changers-Other") : xs(u8"��������-���������"), &Opts.Menu.Loads[LOAD_SETTINGS_CHANGER_OTHER]);

						ImGui::Checkbox(Eng ? xs("Misc-Globals") : xs(u8"������-����������"), &Opts.Menu.Loads[LOAD_SETTINGS_MISC_GLOBALS]);
						ImGui::Checkbox(Eng ? xs("Misc-BuyBot") : xs(u8"������-������"), &Opts.Menu.Loads[LOAD_SETTINGS_MISC_BUYBOT]);
						ImGui::Checkbox(Eng ? xs("Misc-Colors") : xs(u8"������-�����"), &Opts.Menu.Loads[LOAD_SETTINGS_MISC_COLORS]);
						ImGui::Checkbox(Eng ? xs("Misc-Menu") : xs(u8"������-����"), &Opts.Menu.Loads[LOAD_SETTINGS_MISC_MENU]);

						LoadListPos = ImGui::GetWindowPos();
					}
					ImGui::End();
				}
			}
			else if (ActiveSubTab == 5)
			{
				LManager.UpdateLuaList();

				ImGui::PushItemWidth(400);

				static int select_lua = 0;
				ImGui::Combo(Eng ? xs(" Scripts") : xs(u8" �������"), &select_lua, [](void* data, int idx, const char** out_text)
				{
					*out_text = Opts.Menu.MassLuas[idx].c_str();
					return true;
				}, nullptr, Opts.Menu.MassLuas.size(), 10);

				if (ImGui::Button(Eng ? "Load" : u8"���������", ImVec2(140, 0)))
				{
					LManager.LoadLua(Opts.Menu.MassLuas[select_lua]);
				}

				ImGui::SameLine();

				if (ImGui::Button(Eng ? "Reload" : u8"�������������", ImVec2(140, 0)))
				{
					LManager.ReloadLua(Opts.Menu.MassLuas[select_lua]);
				}

				ImGui::SameLine();

				if (ImGui::Button(Eng ? "Unload" : u8"���������", ImVec2(140, 0)))
				{
					LManager.UnloadLua(Opts.Menu.MassLuas[select_lua]);
				}

				ImGui::SameLine();

				if (ImGui::Button(Eng ? "Unload all" : u8"��������� ���", ImVec2(140, 0)))
				{
					LManager.UnloadAllScripts();
				}
			}
		}
		ImGui::End();
	}

	//if (Opts.Misc.Globals.RadioEnabled)
	//{
	//	ImGui::SetNextWindowSize(ImVec2(378, 60));
	//
	//	if (ImGui::Begin(xs("Radio"), nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar))
	//	{
	//		ImGui::Combo(xs("##radio_channel"), &Opts.Misc.Globals.RadioCurrent, RadioChannels, ARRAYSIZE(RadioChannels));
	//		
	//		ImGui::SameLine();
	//
	//		if (!G::radio_stat)
	//		{
	//			if (ImGui::Button(Eng ? xs("Play") : xs(u8"������"), ImVec2(-1, 20)))
	//			{
	//				G::radio_stat = true;
	//			}
	//		}
	//		else
	//		{
	//			if (ImGui::Button(Eng ? xs("Pause") : xs(u8"�����"), ImVec2(-1, 20)))
	//			{
	//				G::radio_stat = false;
	//			}
	//		}
	//
	//		if (ImGui::Button(xs("<<"), ImVec2(50, 20)))
	//		{
	//			if (Opts.Misc.Globals.RadioCurrent - 1 >= 0) Opts.Misc.Globals.RadioCurrent -= 1;
	//		}
	//
	//		ImGui::SameLine();
	//
	//		ImGui::SliderInt(xs("##radio_vol"), &Opts.Misc.Globals.RadioVolume, 0, 100, Eng ? xs("Volume: %d") : xs(u8"���������: %d"));
	//		
	//		ImGui::SameLine();
	//
	//		if (ImGui::Button(xs(">>"), ImVec2(50, 20)))
	//		{
	//			if (Opts.Misc.Globals.RadioCurrent + 1 < ARRAYSIZE(RadioChannels)) Opts.Misc.Globals.RadioCurrent += 1;
	//		}
	//
	//		ImGui::End();
	//	}
	//}

	//if (Opts.Visuals.Players.Global.DangerZone)
	//{
	//	ImGui::SetNextWindowSize(ImVec2(300, 200));
	//
	//	if (ImGui::Begin(xs("DangerZone"), nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar))
	//	{
	//		ImGui::PushItemWidth(-1);
	//		ImGui::SliderInt(xs("##Length"), &Opts.Visuals.DangerZone.Length, 0, 3000, Eng ? xs("Distance: %d") : xs(u8"����������: %d"));
	//		ImGui::PushItemWidth(0);
	//
	//		ImGui::End();
	//	}
	//}

	ImGui::PopFont();
}

inline void MenuV2()
{
	static bool old_eng = Eng;
	static ImVec2 MenuPos;
	if (old_eng != Eng)
	{
		old_eng = Eng;
		ImGui::SetNextWindowPos(MenuPos);
	}

	//enum MenuMainTabs : int
	//{
	//	RageTab = 0,
	//	LegitTab,
	//	LegitRageTab,
	//	VisualsTab,
	//	MiscTab,
	//	CfgTab,
	//	MaxTabs
	//};
	//
	//static bool tabs_enabled[MaxTabs];

	ImGui::Begin(ER("No Name Hack", u8"������ ���"), &Opts.Menu.Opened, ImVec2(180, 200), 1.0f, ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize);
	{
		ImGui::PushItemWidth(-1);
		ImGui::Combo("##menu_style", &Opts.Menu.Style, Eng ? MenuStyleVars : MenuStyleVarsRus, asize(MenuStyleVars));
		ImGui::PopItemWidth();

		static bool Rus = !Eng;

		bool cur_eng = Eng;

		ImGui::Checkbox(xs("En"), &Eng);
		ImGui::SameLine();
		ImGui::Checkbox(xs("Ru"), &Rus);

		if (cur_eng != Rus || Eng == Rus)
		{
			if (cur_eng && Rus) { Rus = true; Eng = false; }
			else if (!cur_eng && !Rus) { Rus = true; Eng = false; }
			else if (cur_eng && !Eng) { Rus = false; Eng = true; }
			else if (!cur_eng && Eng) { Rus = false; Eng = true; }
		}

		//ImGui::Checkbox(ER("RageBot", u8"�������"), &tabs_enabled[RageTab]);
		//ImGui::Checkbox(ER("LegitBot", u8"����� ���"), &tabs_enabled[LegitTab]);
		//ImGui::Checkbox(ER("LegitRage", u8"����� ����"), &tabs_enabled[LegitRageTab]);
		//ImGui::Checkbox(ER("Visuals", u8"�������"), &tabs_enabled[VisualsTab]);
		//ImGui::Checkbox(ER("Misc", u8"�����"), &tabs_enabled[MiscTab]);
		//ImGui::Checkbox(ER("Cfg system", u8"������� ���"), &tabs_enabled[CfgTab]);

		ImGui::Checkbox(Eng ? xs("Enable") : xs(u8"��������"), &Opts.Visuals.Players.Global.Enabled);
		ByteCombo(Eng ? xs("Box") : xs(u8"�������"), Opts.Visuals.Players.Global.BoxMode, Eng ? ESPBox : ESPBoxRus, asize(ESPBox));
		ImGui::Checkbox(Eng ? xs("Box outline") : xs(u8"�������"), &Opts.Visuals.Players.Global.Outline);
		ImGui::Checkbox(Eng ? xs("Enable glow") : xs(u8"�������� ����"), &Opts.Visuals.Players.Glow.Enabled);
		ImGui::Checkbox(Eng ? xs("Enable chams") : xs(u8"�������� �����"), &Opts.Visuals.Players.Chams.Enabled);

		MenuPos = ImGui::GetWindowPos();
	}
	ImGui::End();
}

inline void MenuV3()
{
	static bool old_eng = Eng;
	static ImVec2 MenuPos;
	if (old_eng != Eng)
	{
		old_eng = Eng;
		ImGui::SetNextWindowPos(MenuPos);
	}

	ImGui::Begin(ER("LooOOOl", u8"��� �����������"), &Opts.Menu.Opened, ImVec2(800, 400), 1.0f, ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize);
	{
		ImGui::Combo("##menu_style", &Opts.Menu.Style, Eng ? MenuStyleVars : MenuStyleVarsRus, asize(MenuStyleVars));

		static bool Rus = !Eng;
		
		bool cur_eng = Eng;

		ImGui::Checkbox(xs("En"), &Eng);
		ImGui::SameLine();
		ImGui::Checkbox(xs("Ru"), &Rus);

		if (cur_eng != Rus || Eng == Rus)
		{
			if (cur_eng && Rus) { Rus = true; Eng = false; }
			else if (!cur_eng && !Rus) { Rus = true; Eng = false; }
			else if (cur_eng && !Eng) { Rus = false; Eng = true; }
			else if (!cur_eng && Eng) { Rus = false; Eng = true; }
		}

		ImGui::Text(Eng ? "Get the fuck out of here, the menu isn't finished yet" : u8"����� �����. ��� �� ���� - ��� �� ���� \"��???\" ��� ����������");

		MenuPos = ImGui::GetWindowPos();
	}
	ImGui::End();
}