#pragma once

class IGameEvent;

namespace Legit
{
	extern void StartTrigger();

	namespace AimBot
	{
		extern void DropTarget();
		extern void FindTarget();
		extern void GoToTarget();
	}

	extern void StartRCS();

	extern void RunLegit();
}