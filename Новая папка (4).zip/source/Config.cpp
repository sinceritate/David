#include "Cheat.h"
#include "Config.h"

#include <fstream>

#define DeleteStrings(bVal, dStr) if (!bVal) DeleteAllStrings(dStr);

void NNconfig::SetUpSettings()
{
	char path[512];
	SHGetFolderPathA(NULL, CSIDL_APPDATA, NULL, 0, path);
	path_to_folder = std::string(path) + "\\NoNameHack\\Cheat\\Cfgs\\";

	ImGuiStyle& style = ImGui::GetStyle();
	
	for (int i = 0; i < ImGuiCol_COUNT; ++i)
		Opts.Menu.colors[i] = Color(style.Colors[i].x * 255.f, style.Colors[i].y * 255.f, style.Colors[i].z * 255.f, style.Colors[i].w * 255.f);

	// RageGlobals
	SetupValue("Rage.SettingMode", &Opts.RageBot.AimBot.SettingMode);
	SetupValue("Rage.Enabled", &Opts.RageBot.AimBot.Enabled);
	SetupValue("Rage.BAimKey", &Opts.RageBot.AimBot.BAimKey);
	SetupValue("Rage.FriendlyFire", &Opts.RageBot.AimBot.FriendlyFire);
	SetupValue("Rage.AutoRevolver", &Opts.RageBot.AimBot.AutoRevolver);

	SetupValue("Rage.Resolver", &Opts.RageBot.AimBot.Resolver);
	SetupValue("Rage.Override", &Opts.RageBot.AimBot.Override);
	SetupValue("Rage.OverrideKey", &Opts.RageBot.AimBot.OverrideKey);

	SetupValue("Rage.AutoWall", &Opts.RageBot.AimBot.AutoWall);
	SetupValue("Rage.AutoScope", &Opts.RageBot.AimBot.AutoScope);
	SetupValue("Rage.AutoStop", &Opts.RageBot.AimBot.AutoStop);

	// Rage All_Rage
	SetupValue("Rage.All.bBAimHealth", &Opts.RageBot.AimBot.All_Rage.bBAimHealth);
	SetupValue("Rage.All.iBAimHealth", &Opts.RageBot.AimBot.All_Rage.iBAimHealth);

	SetupValue("Rage.All.bBAimMiss", &Opts.RageBot.AimBot.All_Rage.bBAimMiss);
	SetupValue("Rage.All.iBAimMiss", &Opts.RageBot.AimBot.All_Rage.iBAimMiss);

	SetupValue("Rage.All.Bone", &Opts.RageBot.AimBot.All_Rage.Bone);

	SetupValue("Rage.All.HitChance", &Opts.RageBot.AimBot.All_Rage.HitChance);
	SetupValue("Rage.All.MinDamage", &Opts.RageBot.AimBot.All_Rage.MinDamage);

	// Rage WT_Rage
	for (int i = 0; i < 6; ++i)
	{
		std::string section = "Rage.WT." + std::to_string(i) + '.';

		SetupValue(section + "bBAimHealth", &Opts.RageBot.AimBot.WT_Rage[i].bBAimHealth);
		SetupValue(section + "iBAimHealth", &Opts.RageBot.AimBot.WT_Rage[i].iBAimHealth);

		SetupValue(section + "bBAimMiss", &Opts.RageBot.AimBot.WT_Rage[i].bBAimMiss);
		SetupValue(section + "iBAimMiss", &Opts.RageBot.AimBot.WT_Rage[i].iBAimMiss);

		SetupValue(section + "Bone", &Opts.RageBot.AimBot.WT_Rage[i].Bone);

		SetupValue(section + "HitChance", &Opts.RageBot.AimBot.WT_Rage[i].HitChance);
		SetupValue(section + "MinDamage", &Opts.RageBot.AimBot.WT_Rage[i].MinDamage);
	}

	// Rage EW_Rage
	for (int i = 0; i < 34; ++i)
	{
		std::string section = "Rage.EW." + std::to_string(i) + '.';

		SetupValue(section + "bBAimHealth", &Opts.RageBot.AimBot.EW_Rage[i].bBAimHealth);
		SetupValue(section + "iBAimHealth", &Opts.RageBot.AimBot.EW_Rage[i].iBAimHealth);

		SetupValue(section + "bBAimMiss", &Opts.RageBot.AimBot.EW_Rage[i].bBAimMiss);
		SetupValue(section + "iBAimMiss", &Opts.RageBot.AimBot.EW_Rage[i].iBAimMiss);

		SetupValue(section + "Bone", &Opts.RageBot.AimBot.EW_Rage[i].Bone);

		SetupValue(section + "HitChance", &Opts.RageBot.AimBot.EW_Rage[i].HitChance);
		SetupValue(section + "MinDamage", &Opts.RageBot.AimBot.EW_Rage[i].MinDamage);
	}

	// Rage AntiAims
	SetupValue("Rage.AA.Enabled", &Opts.RageBot.AntiAims.Enabled);
	SetupValue("Rage.AA.CustomAngles", &Opts.RageBot.AntiAims.CustomAngles);

	for (int i = 0; i < 3; ++i)
	{
		std::string section = "Rage.AA." + std::to_string(i) + '.';

		SetupValue(section + "CustomX", &Opts.RageBot.AntiAims.Custom[i * 2]);
		SetupValue(section + "CustomY", &Opts.RageBot.AntiAims.Custom[i * 2 + 1]);
		
		SetupValue(section + "CustomX", &Opts.RageBot.AntiAims.Real[i * 2]);
		SetupValue(section + "CustomY", &Opts.RageBot.AntiAims.Real[i * 2 + 1]);
		
		SetupValue(section + "ManualKey1", &Opts.RageBot.AntiAims.ManualKey[i * 3]);
		SetupValue(section + "ManualKey2", &Opts.RageBot.AntiAims.ManualKey[i * 3 + 1]);
		SetupValue(section + "ManualKey3", &Opts.RageBot.AntiAims.ManualKey[i * 3 + 2]);
		
		SetupValue(section + "DesyncType", &Opts.RageBot.AntiAims.DesyncType[i]);
	}

	// Legit Globals
	SetupValue("Legit.SettingMode", &Opts.LegitBot.SettingMode);

	SetupValue("Legit.Aim.Enabled", &Opts.LegitBot.AimBot.Enabled);
	SetupValue("Legit.Aim.AimBotKey", &Opts.LegitBot.AimBot.AimBotKey);
	SetupValue("Legit.Aim.FriendlyFire", &Opts.LegitBot.AimBot.FriendlyFire);
	SetupValue("Legit.Aim.FlashCheck", &Opts.LegitBot.AimBot.FlashCheck);
	SetupValue("Legit.Aim.SmokeCheck", &Opts.LegitBot.AimBot.SmokeCheck);
	SetupValue("Legit.Aim.JumpCheck", &Opts.LegitBot.AimBot.JumpCheck);


	SetupValue("Legit.Rcs.Enabled", &Opts.LegitBot.RCS.Enabled);


	SetupValue("Legit.Trigger.Enabled", &Opts.LegitBot.Trigger.Enabled);

	SetupValue("Legit.Trigger.TriggerKey", &Opts.LegitBot.Trigger.TriggerKey);

	SetupValue("Legit.Trigger.FriendlyFire", &Opts.LegitBot.Trigger.FriendlyFire);

	SetupValue("Legit.Trigger.FlashCheck", &Opts.LegitBot.Trigger.FlashCheck);
	SetupValue("Legit.Trigger.SmokeCheck", &Opts.LegitBot.Trigger.SmokeCheck);
	SetupValue("Legit.Trigger.JumpCheck", &Opts.LegitBot.Trigger.JumpCheck);

	// Legit All_Legit
	SetupValue("Legit.All.Aim.TargetBone", &Opts.LegitBot.All_Legit.AimBot.TargetBone);

	SetupValue("Legit.All.Aim.Fov", &Opts.LegitBot.All_Legit.AimBot.Fov);
	SetupValue("Legit.All.Aim.Smooth", &Opts.LegitBot.All_Legit.AimBot.Smooth);

	SetupValue("Legit.All.Aim.pSilent", &Opts.LegitBot.All_Legit.AimBot.pSilent);
	SetupValue("Legit.All.Aim.pSilentFov", &Opts.LegitBot.All_Legit.AimBot.pSilentFov);

	SetupValue("Legit.All.Aim.Delay", &Opts.LegitBot.All_Legit.AimBot.Delay);
	SetupValue("Legit.All.Aim.ShotDelay", &Opts.LegitBot.All_Legit.AimBot.ShotDelay);
	SetupValue("Legit.All.Aim.KillDelay", &Opts.LegitBot.All_Legit.AimBot.KillDelay);


	SetupValue("Legit.All.Rcs.Type", &Opts.LegitBot.All_Legit.RCS.Type);
	SetupValue("Legit.All.Rcs.X", &Opts.LegitBot.All_Legit.RCS.X);
	SetupValue("Legit.All.Rcs.Y", &Opts.LegitBot.All_Legit.RCS.Y);


	SetupValue("Legit.All.Trigger.Head", &Opts.LegitBot.All_Legit.Trigger.Head);
	SetupValue("Legit.All.Trigger.Body", &Opts.LegitBot.All_Legit.Trigger.Body);
	SetupValue("Legit.All.Trigger.Misc", &Opts.LegitBot.All_Legit.Trigger.Misc);
	SetupValue("Legit.All.Trigger.Delay", &Opts.LegitBot.All_Legit.Trigger.Delay);

	// Legit WT_Legit
	for (int i = 0; i < 6; ++i)
	{
		std::string section = "Legit.WT." + std::to_string(i) + '.';

		SetupValue(section + "TargetBone", &Opts.LegitBot.WT_Legit[i].AimBot.TargetBone);

		SetupValue(section + "Aim.Fov", &Opts.LegitBot.WT_Legit[i].AimBot.Fov);
		SetupValue(section + "Aim.Smooth", &Opts.LegitBot.WT_Legit[i].AimBot.Smooth);

		SetupValue(section + "Aim.pSilent", &Opts.LegitBot.WT_Legit[i].AimBot.pSilent);
		SetupValue(section + "Aim.pSilentFov", &Opts.LegitBot.WT_Legit[i].AimBot.pSilentFov);

		SetupValue(section + "Aim.Delay", &Opts.LegitBot.WT_Legit[i].AimBot.Delay);
		SetupValue(section + "Aim.ShotDelay", &Opts.LegitBot.WT_Legit[i].AimBot.ShotDelay);
		SetupValue(section + "Aim.KillDelay", &Opts.LegitBot.WT_Legit[i].AimBot.KillDelay);


		SetupValue(section + "Rcs.Type", &Opts.LegitBot.WT_Legit[i].RCS.Type);
		SetupValue(section + "Rcs.X", &Opts.LegitBot.WT_Legit[i].RCS.X);
		SetupValue(section + "Rcs.Y", &Opts.LegitBot.WT_Legit[i].RCS.Y);


		SetupValue(section + "Trigger.Head", &Opts.LegitBot.WT_Legit[i].Trigger.Head);
		SetupValue(section + "Trigger.Body", &Opts.LegitBot.WT_Legit[i].Trigger.Body);
		SetupValue(section + "Trigger.Misc", &Opts.LegitBot.WT_Legit[i].Trigger.Misc);
		SetupValue(section + "Trigger.Delay", &Opts.LegitBot.WT_Legit[i].Trigger.Delay);
	}

	// Legit EW_Legit
	for (int i = 0; i < 34; ++i)
	{
		std::string section = "Legit.EW." + std::to_string(i) + '.';

		SetupValue(section + "TargetBone", &Opts.LegitBot.EW_Legit[i].AimBot.TargetBone);

		SetupValue(section + "Aim.Fov", &Opts.LegitBot.EW_Legit[i].AimBot.Fov);
		SetupValue(section + "Aim.Smooth", &Opts.LegitBot.EW_Legit[i].AimBot.Smooth);

		SetupValue(section + "Aim.pSilent", &Opts.LegitBot.EW_Legit[i].AimBot.pSilent);
		SetupValue(section + "Aim.pSilentFov", &Opts.LegitBot.EW_Legit[i].AimBot.pSilentFov);

		SetupValue(section + "Aim.Delay", &Opts.LegitBot.EW_Legit[i].AimBot.Delay);
		SetupValue(section + "Aim.ShotDelay", &Opts.LegitBot.EW_Legit[i].AimBot.ShotDelay);
		SetupValue(section + "Aim.KillDelay", &Opts.LegitBot.EW_Legit[i].AimBot.KillDelay);


		SetupValue(section + "Rcs.Type", &Opts.LegitBot.EW_Legit[i].RCS.Type);
		SetupValue(section + "Rcs.X", &Opts.LegitBot.EW_Legit[i].RCS.X);
		SetupValue(section + "Rcs.Y", &Opts.LegitBot.EW_Legit[i].RCS.Y);


		SetupValue(section + "Trigger.Head", &Opts.LegitBot.EW_Legit[i].Trigger.Head);
		SetupValue(section + "Trigger.Body", &Opts.LegitBot.EW_Legit[i].Trigger.Body);
		SetupValue(section + "Trigger.Misc", &Opts.LegitBot.EW_Legit[i].Trigger.Misc);
		SetupValue(section + "Trigger.Delay", &Opts.LegitBot.EW_Legit[i].Trigger.Delay);
	}

	// LegitRage Globals
	SetupValue("LRage.Enabled", &Opts.LegitRageBot.Enabled);

	SetupValue("LRage.AimBotAutoFireOnKey", &Opts.LegitRageBot.AimBotAutoFireOnKey);
	SetupValue("LRage.AimBotAutoFireKey", &Opts.LegitRageBot.AimBotAutoFireKey);

	SetupValue("LRage.Aim.FriendlyFire", &Opts.LegitRageBot.AimBot.FriendlyFire);

	SetupValue("LRage.Aim.FlashCheck", &Opts.LegitRageBot.AimBot.FlashCheck);
	SetupValue("LRage.Aim.SmokeCheck", &Opts.LegitRageBot.AimBot.SmokeCheck);
	SetupValue("LRage.Aim.JumpCheck", &Opts.LegitRageBot.AimBot.JumpCheck);

	SetupValue("LRage.Aim.AutoRevolver", &Opts.LegitRageBot.AimBot.AutoRevolver);
	SetupValue("LRage.Aim.AutoScope", &Opts.LegitRageBot.AimBot.AutoScope);
	SetupValue("LRage.Aim.AutoWall", &Opts.LegitRageBot.AimBot.AutoWall);
	SetupValue("LRage.Aim.AutoStop", &Opts.LegitRageBot.AimBot.AutoStop);

	// LegitRage All_LRage
	SetupValue("LRage.All.Aim.TargetBone", &Opts.LegitRageBot.All_Legit.AimBot.TargetBone);

	SetupValue("LRage.All.Aim.Fov", &Opts.LegitRageBot.All_Legit.AimBot.Fov);
	SetupValue("LRage.All.Aim.Smooth", &Opts.LegitRageBot.All_Legit.AimBot.Smooth);

	SetupValue("LRage.All.Aim.pSilent", &Opts.LegitRageBot.All_Legit.AimBot.pSilent);
	SetupValue("LRage.All.Aim.pSilentFov", &Opts.LegitRageBot.All_Legit.AimBot.pSilentFov);

	SetupValue("LRage.All.Aim.Delay", &Opts.LegitRageBot.All_Legit.AimBot.Delay);
	SetupValue("LRage.All.Aim.ShotDelay", &Opts.LegitRageBot.All_Legit.AimBot.ShotDelay);
	SetupValue("LRage.All.Aim.KillDelay", &Opts.LegitRageBot.All_Legit.AimBot.KillDelay);

	SetupValue("LRage.All.Aim.HitChance", &Opts.LegitRageBot.All_Legit.AimBot.HitChance);
	SetupValue("LRage.All.Aim.MinDamage", &Opts.LegitRageBot.All_Legit.AimBot.MinDamage);


	SetupValue("LRage.All.Rcs.Type", &Opts.LegitRageBot.All_Legit.RCS.Type);
	SetupValue("LRage.All.Rcs.X", &Opts.LegitRageBot.All_Legit.RCS.X);
	SetupValue("LRage.All.Rcs.Y", &Opts.LegitRageBot.All_Legit.RCS.Y);


	SetupValue("LRage.All.Trigger.Head", &Opts.LegitRageBot.All_Legit.Trigger.Head);
	SetupValue("LRage.All.Trigger.Body", &Opts.LegitRageBot.All_Legit.Trigger.Body);
	SetupValue("LRage.All.Trigger.Misc", &Opts.LegitRageBot.All_Legit.Trigger.Misc);
	SetupValue("LRage.All.Trigger.Delay", &Opts.LegitRageBot.All_Legit.Trigger.Delay);

	// LegitRage WT_LRage
	for (int i = 0; i < 6; ++i)
	{
		std::string section = "LRage.WT." + std::to_string(i) + '.';

		SetupValue(section + "TargetBone", &Opts.LegitRageBot.WT_Legit[i].AimBot.TargetBone);

		SetupValue(section + "Aim.Fov", &Opts.LegitRageBot.WT_Legit[i].AimBot.Fov);
		SetupValue(section + "Aim.Smooth", &Opts.LegitRageBot.WT_Legit[i].AimBot.Smooth);

		SetupValue(section + "Aim.pSilent", &Opts.LegitRageBot.WT_Legit[i].AimBot.pSilent);
		SetupValue(section + "Aim.pSilentFov", &Opts.LegitRageBot.WT_Legit[i].AimBot.pSilentFov);

		SetupValue(section + "Aim.Delay", &Opts.LegitRageBot.WT_Legit[i].AimBot.Delay);
		SetupValue(section + "Aim.ShotDelay", &Opts.LegitRageBot.WT_Legit[i].AimBot.ShotDelay);
		SetupValue(section + "Aim.KillDelay", &Opts.LegitRageBot.WT_Legit[i].AimBot.KillDelay);

		SetupValue(section + "Aim.HitChance", &Opts.LegitRageBot.WT_Legit[i].AimBot.HitChance);
		SetupValue(section + "Aim.MinDamage", &Opts.LegitRageBot.WT_Legit[i].AimBot.MinDamage);

		SetupValue(section + "Rcs.Type", &Opts.LegitRageBot.WT_Legit[i].RCS.Type);
		SetupValue(section + "Rcs.X", &Opts.LegitRageBot.WT_Legit[i].RCS.X);
		SetupValue(section + "Rcs.Y", &Opts.LegitRageBot.WT_Legit[i].RCS.Y);


		SetupValue(section + "Trigger.Head", &Opts.LegitRageBot.WT_Legit[i].Trigger.Head);
		SetupValue(section + "Trigger.Body", &Opts.LegitRageBot.WT_Legit[i].Trigger.Body);
		SetupValue(section + "Trigger.Misc", &Opts.LegitRageBot.WT_Legit[i].Trigger.Misc);
		SetupValue(section + "Trigger.Delay", &Opts.LegitRageBot.WT_Legit[i].Trigger.Delay);
	}

	// LegitRage EW_LRage
	for (int i = 0; i < 34; ++i)
	{
		std::string section = "LRage.EW." + std::to_string(i) + '.';

		SetupValue(section + "TargetBone", &Opts.LegitRageBot.EW_Legit[i].AimBot.TargetBone);

		SetupValue(section + "Aim.Fov", &Opts.LegitRageBot.EW_Legit[i].AimBot.Fov);
		SetupValue(section + "Aim.Smooth", &Opts.LegitRageBot.EW_Legit[i].AimBot.Smooth);

		SetupValue(section + "Aim.pSilent", &Opts.LegitRageBot.EW_Legit[i].AimBot.pSilent);
		SetupValue(section + "Aim.pSilentFov", &Opts.LegitRageBot.EW_Legit[i].AimBot.pSilentFov);

		SetupValue(section + "Aim.Delay", &Opts.LegitRageBot.EW_Legit[i].AimBot.Delay);
		SetupValue(section + "Aim.ShotDelay", &Opts.LegitRageBot.EW_Legit[i].AimBot.ShotDelay);
		SetupValue(section + "Aim.KillDelay", &Opts.LegitRageBot.EW_Legit[i].AimBot.KillDelay);

		SetupValue(section + "Aim.HitChance", &Opts.LegitRageBot.EW_Legit[i].AimBot.HitChance);
		SetupValue(section + "Aim.MinDamage", &Opts.LegitRageBot.EW_Legit[i].AimBot.MinDamage);

		SetupValue(section + "Rcs.Type", &Opts.LegitRageBot.EW_Legit[i].RCS.Type);
		SetupValue(section + "Rcs.X", &Opts.LegitRageBot.EW_Legit[i].RCS.X);
		SetupValue(section + "Rcs.Y", &Opts.LegitRageBot.EW_Legit[i].RCS.Y);


		SetupValue(section + "Trigger.Head", &Opts.LegitRageBot.EW_Legit[i].Trigger.Head);
		SetupValue(section + "Trigger.Body", &Opts.LegitRageBot.EW_Legit[i].Trigger.Body);
		SetupValue(section + "Trigger.Misc", &Opts.LegitRageBot.EW_Legit[i].Trigger.Misc);
		SetupValue(section + "Trigger.Delay", &Opts.LegitRageBot.EW_Legit[i].Trigger.Delay);
	}

	// Visuals Globals
	SetupValue("VGlobals.Enabled", &Opts.Visuals.Players.Global.Enabled);
	SetupValue("VGlobals.VisualsKey", &Opts.Visuals.Players.Global.VisualsKey);

	SetupValue("VGlobals.ScreenShotBypass", &Opts.Visuals.Players.Global.ScreenShotBypass);

	SetupValue("VGlobals.EnemyOnly", &Opts.Visuals.Players.Global.EnemyOnly);
	SetupValue("VGlobals.VisibleOnly", &Opts.Visuals.Players.Global.VisibleOnly);

	SetupValue("VGlobals.BoxMode", &Opts.Visuals.Players.Global.BoxMode);
	SetupValue("VGlobals.Outline", &Opts.Visuals.Players.Global.Outline);

	SetupValue("VGlobals.Health.Enable", &Opts.Visuals.Players.Global.Health.Enable);

	SetupValue("VGlobals.Health.Outline", &Opts.Visuals.Players.Global.Health.Outline);
	SetupValue("VGlobals.Health.Background", &Opts.Visuals.Players.Global.Health.Background);

	SetupValue("VGlobals.Health.Type", &Opts.Visuals.Players.Global.Health.Type);

	SetupValue("VGlobals.Health.Division", &Opts.Visuals.Players.Global.Health.Division);

	SetupValue("VGlobals.Health.Width", &Opts.Visuals.Players.Global.Health.Width);
	SetupValue("VGlobals.Health.Height", &Opts.Visuals.Players.Global.Health.Height);

	SetupValue("VGlobals.Health.Outline_Color", &Opts.Visuals.Players.Global.Health.Outline_Color);
	SetupValue("VGlobals.Health.Background_Color", &Opts.Visuals.Players.Global.Health.Background_Color);
	SetupValue("VGlobals.Health.Health_Color", &Opts.Visuals.Players.Global.Health.Health_Color);

	SetupValue("VGlobals.Health.DefaulPos.x", &Opts.Visuals.Players.Global.Health.DefaulPos.x);
	SetupValue("VGlobals.Health.DefaulPos.y", &Opts.Visuals.Players.Global.Health.DefaulPos.y);
	SetupValue("VGlobals.Health.DefaulPos.z", &Opts.Visuals.Players.Global.Health.DefaulPos.z);
	SetupValue("VGlobals.Health.DefaulPos.w", &Opts.Visuals.Players.Global.Health.DefaulPos.w);

	SetupValue("VGlobals.Health.DefaulPos2.x", &Opts.Visuals.Players.Global.Health.DefaulPos2.x);
	SetupValue("VGlobals.Health.DefaulPos2.y", &Opts.Visuals.Players.Global.Health.DefaulPos2.y);
	SetupValue("VGlobals.Health.DefaulPos2.z", &Opts.Visuals.Players.Global.Health.DefaulPos2.z);
	SetupValue("VGlobals.Health.DefaulPos2.w", &Opts.Visuals.Players.Global.Health.DefaulPos2.w);

	SetupValue("VGlobals.SoundEsp", &Opts.Visuals.Players.Global.SoundEsp);

	SetupValue("VGlobals.HeadDot", &Opts.Visuals.Players.Global.HeadDot);
	SetupValue("VGlobals.Skeleton", &Opts.Visuals.Players.Global.Skeleton);

	SetupValue("VGlobals.Info", &Opts.Visuals.Players.Global.Info);

	SetupValue("VGlobals.Name", &Opts.Visuals.Players.Global.Name);
	SetupValue("VGlobals.Weapon", &Opts.Visuals.Players.Global.Weapon);
	SetupValue("VGlobals.Money", &Opts.Visuals.Players.Global.Money);
	SetupValue("VGlobals.Distance", &Opts.Visuals.Players.Global.Distance);
	SetupValue("VGlobals.SnipeLine", &Opts.Visuals.Players.Global.SnipeLine);

	// Visuals Chams
	SetupValue("VChams.Enabled", &Opts.Visuals.Players.Chams.Enabled);

	SetupValue("VChams.EnemyOnly", &Opts.Visuals.Players.Chams.EnemyOnly);
	SetupValue("VChams.VisibleOnly", &Opts.Visuals.Players.Chams.VisibleOnly);

	SetupValue("VChams.Blinking", &Opts.Visuals.Players.Chams.Blinking);
	SetupValue("VChams.VisType", &Opts.Visuals.Players.Chams.VisType);
	SetupValue("VChams.InvisType", &Opts.Visuals.Players.Chams.InvisType);

	// Visuals Glow
	SetupValue("VGlow.Enabled", &Opts.Visuals.Players.Glow.Enabled);

	SetupValue("VGlow.EnemyOnly", &Opts.Visuals.Players.Glow.EnemyOnly);
	SetupValue("VGlow.VisibleOnly", &Opts.Visuals.Players.Glow.VisibleOnly);

	SetupValue("VGlow.Type", &Opts.Visuals.Players.Glow.Type);

	// Visuals other
	SetupValue("VOther.Weapons.Enabled", &Opts.Visuals.Weapons.Enabled);

	SetupValue("VOther.Weapons.Glow", &Opts.Visuals.Weapons.Glow);
	SetupValue("VOther.Weapons.GlowType", &Opts.Visuals.Weapons.GlowType);

	SetupValue("VOther.Weapons.BoxMode", &Opts.Visuals.Weapons.BoxMode);
	SetupValue("VOther.Weapons.Outline", &Opts.Visuals.Weapons.Outline);

	SetupValue("VOther.Weapons.Weapons", &Opts.Visuals.Weapons.Weapons);
	SetupValue("VOther.Weapons.Grenades", &Opts.Visuals.Weapons.Grenades);
	SetupValue("VOther.Weapons.Bomb", &Opts.Visuals.Weapons.Bomb);

	SetupValue("VOther.Other.HitMarker", &Opts.Visuals.Other.HitMarker);
	SetupValue("VOther.Other.BulletTracer", &Opts.Visuals.Other.BulletTracer);
	SetupValue("VOther.Other.GrenadePrediction", &Opts.Visuals.Other.GrenadePrediction);
	SetupValue("VOther.Other.Crosshair", &Opts.Visuals.Other.Crosshair);
	SetupValue("VOther.Other.FovCrosshair", &Opts.Visuals.Other.FovCrosshair);
	SetupValue("VOther.Other.ShowTargetBone", &Opts.Visuals.Other.ShowTargetBone);
	SetupValue("VOther.Other.TargetBoneOutline", &Opts.Visuals.Other.TargetBoneOutline);
	SetupValue("VOther.Other.TargetBoneInline", &Opts.Visuals.Other.TargetBoneInline);
	SetupValue("VOther.Other.SpectatorList", &Opts.Visuals.Other.SpectatorList);
	SetupValue("VOther.Other.SpectatorListPos.x", &Opts.Visuals.Other.SpectatorListPos.x);
	SetupValue("VOther.Other.SpectatorListPos.y", &Opts.Visuals.Other.SpectatorListPos.y);
	SetupValue("VOther.Other.SkyChanger", &Opts.Visuals.Other.SkyChanger);
	SetupValue("VOther.Other.SkyChangerName", &Opts.Visuals.Other.SkyChangerName);
	SetupValue("VOther.Other.BackGround", &Opts.Visuals.Other.BackGround);
	SetupValue("VOther.Other.BackDrop", &Opts.Visuals.Other.BackDrop);
	SetupValue("VOther.Other.WaterMark", &Opts.Visuals.Other.WaterMark);
	SetupValue("VOther.Other.BackDropMaxPoints", &Opts.Visuals.Other.BackDropMaxPoints);
	SetupValue("VOther.Other.BackDropMaxDist", &Opts.Visuals.Other.BackDropMaxDist);
	SetupValue("VOther.Other.BackDropSquareSize", &Opts.Visuals.Other.BackDropSquareSize);
	SetupValue("VOther.Other.BackDropMaxSpeed", &Opts.Visuals.Other.BackDropMaxSpeed);
	SetupValue("VOther.Other.WallsColored", &Opts.Visuals.Other.WallsColored);
	SetupValue("VOther.Other.SkyColored", &Opts.Visuals.Other.SkyColored);
	SetupValue("VOther.Other.PropColored", &Opts.Visuals.Other.PropColored);

	SetupValue("VOther.Radar.Type", &Opts.Visuals.Radar.Type);
	SetupValue("VOther.Radar.EnemyOnly", &Opts.Visuals.Radar.EnemyOnly);
	SetupValue("VOther.Radar.Size.x", &Opts.Visuals.Radar.Size.x);
	SetupValue("VOther.Radar.Size.y", &Opts.Visuals.Radar.Size.y);
	SetupValue("VOther.Radar.PointSize", &Opts.Visuals.Radar.PointSize);
	SetupValue("VOther.Radar.Zoom", &Opts.Visuals.Radar.Zoom);
	SetupValue("VOther.Radar.Alpha", &Opts.Visuals.Radar.Alpha);

	SetupValue("VOther.Radar.Pos.x", &Opts.Visuals.Radar.Pos.x);
	SetupValue("VOther.Radar.Pos.y", &Opts.Visuals.Radar.Pos.y);

	// Changer Models
	SetupValue("CModels.Enable", &Opts.Misc.Changer.Models.Enable);
	SetupValue("CModels.FastChange", &Opts.Misc.Changer.Models.FastChange);

	for (size_t i = 0; i < MODEL_TYPE_MAX; ++i)
		SetupValue("CModels.ModelType" + std::to_string(i), &Opts.Misc.Changer.Models.iModelMass[i]);

	// Changer Skins
	SetupValue("CSkins.EnableSkins", &Opts.Misc.Changer.Skins.EnableSkins);
	SetupValue("CSkins.EnableGlove", &Opts.Misc.Changer.Skins.EnableGlove);
	SetupValue("CSkins.EnableKnife", &Opts.Misc.Changer.Skins.EnableKnife);

	SetupValue("CSkins.SettingsForTeams", &Opts.Misc.Changer.Skins.SettingsForTeams);

	for (int i = 0; i < 3; ++i)
	{
		for (int j = 0; j < 34; ++j)
		{
			std::string section = "CSkins.Weapons." + std::to_string(i) + '.' + std::to_string(j) + '.';

			SetupValue(section + "SkinID", &Opts.Misc.Changer.Skins.Weapons[i][j].SkinID);
			SetupValue(section + "Wear", &Opts.Misc.Changer.Skins.Weapons[i][j].Wear);
			SetupValue(section + "Seed", &Opts.Misc.Changer.Skins.Weapons[i][j].Seed);

			for (int l = 0; l < 5; ++l)
			{
				SetupValue(section + "Sticker." + std::to_string(l) + ".id", &Opts.Misc.Changer.Skins.Weapons[i][i].Sticker[l].id);
				SetupValue(section + "Sticker." + std::to_string(l) + ".wear", &Opts.Misc.Changer.Skins.Weapons[i][i].Sticker[l].wear);
				SetupValue(section + "Sticker." + std::to_string(l) + ".scale", &Opts.Misc.Changer.Skins.Weapons[i][i].Sticker[l].scale);
				SetupValue(section + "Sticker." + std::to_string(l) + ".rotation", &Opts.Misc.Changer.Skins.Weapons[i][i].Sticker[l].rotation);
			}

			SetupValue(section + "StatTrak.Type", &Opts.Misc.Changer.Skins.Weapons[i][j].StatTrak.Type);
			SetupValue(section + "StatTrak.Kills", &Opts.Misc.Changer.Skins.Weapons[i][j].StatTrak.Kills);

			SetupValue(section + "CustomName.Enabled", &Opts.Misc.Changer.Skins.Weapons[i][j].CustomName.Enabled);
			SetupValue(section + "CustomName.Name", &Opts.Misc.Changer.Skins.Weapons[i][j].CustomName.Name);
		}

		std::string section = "CSkins.Knifes." + std::to_string(i) + '.';

		SetupValue(section + "ModelIndex", &Opts.Misc.Changer.Skins.Knifes[i].ModelIndex);
		SetupValue(section + "SkinIndex", &Opts.Misc.Changer.Skins.Knifes[i].SkinIndex);
		SetupValue(section + "Wear", &Opts.Misc.Changer.Skins.Knifes[i].Wear);
		SetupValue(section + "Seed", &Opts.Misc.Changer.Skins.Knifes[i].Seed);

		SetupValue(section + "StatTrak.Type", &Opts.Misc.Changer.Skins.Knifes[i].StatTrak.Type);
		SetupValue(section + "StatTrak.Kills", &Opts.Misc.Changer.Skins.Knifes[i].StatTrak.Kills);

		SetupValue(section + "CustomName.Enabled", &Opts.Misc.Changer.Skins.Knifes[i].CustomName.Enabled);
		SetupValue(section + "CustomName.Name", &Opts.Misc.Changer.Skins.Knifes[i].CustomName.Name);

		section = "CSkins.Gloves." + std::to_string(i) + '.';

		SetupValue(section + "ModelIndex", &Opts.Misc.Changer.Skins.Gloves[i].ModelIndex);
		SetupValue(section + "SkinIndex", &Opts.Misc.Changer.Skins.Gloves[i].SkinIndex);
		SetupValue(section + "Wear", &Opts.Misc.Changer.Skins.Gloves[i].Wear);
		SetupValue(section + "Seed", &Opts.Misc.Changer.Skins.Gloves[i].Seed);
	}

	// Changer Profile
	SetupValue("CProfile.Enabled", &Opts.Misc.Changer.Profile.Enabled);

	SetupValue("CProfile.Level", &Opts.Misc.Changer.Profile.Level);
	SetupValue("CProfile.Experience", &Opts.Misc.Changer.Profile.Experience);

	SetupValue("CProfile.MMRank", &Opts.Misc.Changer.Profile.MMRank);
	SetupValue("CProfile.MMWins", &Opts.Misc.Changer.Profile.MMWins);
	SetupValue("CProfile.WMRank", &Opts.Misc.Changer.Profile.WMRank);
	SetupValue("CProfile.WMWins", &Opts.Misc.Changer.Profile.WMWins);
	SetupValue("CProfile.DZRank", &Opts.Misc.Changer.Profile.DZRank);
	SetupValue("CProfile.DZWins", &Opts.Misc.Changer.Profile.DZWins);

	SetupValue("CProfile.Friendly", &Opts.Misc.Changer.Profile.Friendly);
	SetupValue("CProfile.Leader", &Opts.Misc.Changer.Profile.Leader);
	SetupValue("CProfile.Teacher", &Opts.Misc.Changer.Profile.Teacher);

	SetupValue("CProfile.Ban", &Opts.Misc.Changer.Profile.Ban);
	SetupValue("CProfile.BanTime", &Opts.Misc.Changer.Profile.BanTime);

	// Changer other
	SetupValue("COther.bViewModel", &Opts.Misc.Changer.View.bViewModel);
	SetupValue("COther.fViewModelX", &Opts.Misc.Changer.View.fViewModelX);
	SetupValue("COther.fViewModelY", &Opts.Misc.Changer.View.fViewModelY);
	SetupValue("COther.fViewModelZ", &Opts.Misc.Changer.View.fViewModelZ);

	SetupValue("COther.bViewFOV", &Opts.Misc.Changer.View.bViewFOV);
	SetupValue("COther.fViewFOV", &Opts.Misc.Changer.View.fViewFOV);

	SetupValue("COther.bModelFOV", &Opts.Misc.Changer.View.bModelFOV);
	SetupValue("COther.fModelFOV", &Opts.Misc.Changer.View.fModelFOV);

	SetupValue("COther.iHands", &Opts.Misc.Changer.View.iHands);
	SetupValue("COther.iSleeves", &Opts.Misc.Changer.View.iSleeves);
	SetupValue("COther.iWeapons", &Opts.Misc.Changer.View.iWeapons);

	SetupValue("COther.ThirdPerson", &Opts.Misc.Changer.View.ThirdPerson);
	SetupValue("COther.ThirdPersonKey", &Opts.Misc.Changer.View.ThirdPersonKey);
	SetupValue("COther.RemoveLocalPlayer", &Opts.Misc.Changer.View.RemoveLocalPlayer);
	SetupValue("COther.ThirdPersonDist", &Opts.Misc.Changer.View.ThirdPersonDist);

	SetupValue("COther.NoVisualRecoil", &Opts.Misc.Changer.View.NoVisualRecoil);

	// Misc globals
	SetupValue("MGlobals.RadioEnabled", &Opts.Misc.Globals.RadioEnabled);
	SetupValue("MGlobals.RadioCurrent", &Opts.Misc.Globals.RadioCurrent);
	SetupValue("MGlobals.RadioVolume", &Opts.Misc.Globals.RadioVolume);

	SetupValue("MGlobals.StatusBar", &Opts.Misc.Globals.StatusBar);
	SetupValue("MGlobals.EventLog", &Opts.Misc.Globals.EventLog);
	SetupValue("MGlobals.RealAiming", &Opts.Misc.Globals.RealAiming);
	SetupValue("MGlobals.RealAimingKey", &Opts.Misc.Globals.RealAimingKey);

	SetupValue("MGlobals.BunnyHop", &Opts.Misc.Globals.BunnyHop);
	SetupValue("MGlobals.AutoStrafe", &Opts.Misc.Globals.AutoStrafe);
	SetupValue("MGlobals.JumpChance", &Opts.Misc.Globals.JumpChance);

	SetupValue("MGlobals.AutoKnife", &Opts.Misc.Globals.AutoKnife);
	SetupValue("MGlobals.AutoZeus", &Opts.Misc.Globals.AutoZeus);

	SetupValue("MGlobals.AutoPistol", &Opts.Misc.Globals.AutoPistol);

	SetupValue("MGlobals.InfinityCrouch", &Opts.Misc.Globals.InfinityCrouch);
	SetupValue("MGlobals.RankReveal", &Opts.Misc.Globals.RankReveal);
	SetupValue("MGlobals.AutoAccept", &Opts.Misc.Globals.AutoAccept);

	SetupValue("MGlobals.LegitDesync", &Opts.Misc.Globals.LegitDesync);
	SetupValue("MGlobals.LegitDesyncType", &Opts.Misc.Globals.LegitDesyncType);
	SetupValue("MGlobals.LegitDesyncFlipKey", &Opts.Misc.Globals.LegitDesyncFlipKey);

	SetupValue("MGlobals.FPSBoost", &Opts.Misc.Globals.FPSBoost);
	SetupValue("MGlobals.NightMode", &Opts.Misc.Globals.NightMode);
	SetupValue("MGlobals.PlayerBright", &Opts.Misc.Globals.PlayerBright);
	SetupValue("MGlobals.MapBright", &Opts.Misc.Globals.MapBright);

	SetupValue("MGlobals.HadsChanger", &Opts.Misc.Globals.HadsChanger);
	SetupValue("MGlobals.HadsChangerOverride", &Opts.Misc.Globals.HadsChangerOverride);

	SetupValue("MGlobals.NoSmoke", &Opts.Misc.Globals.NoSmoke);
	SetupValue("MGlobals.NoSmokeWireFrame", &Opts.Misc.Globals.NoSmokeWireFrame);

	SetupValue("MGlobals.NoScope", &Opts.Misc.Globals.NoScope);
	SetupValue("MGlobals.NoZoom", &Opts.Misc.Globals.NoZoom);

	SetupValue("MGlobals.No3dSky", &Opts.Misc.Globals.No3dSky);
	SetupValue("MGlobals.NoFog", &Opts.Misc.Globals.NoFog);
	SetupValue("MGlobals.NoGrass", &Opts.Misc.Globals.NoGrass);
	SetupValue("MGlobals.NoShadows", &Opts.Misc.Globals.NoShadows);

	SetupValue("MGlobals.FixSensivityInScope", &Opts.Misc.Globals.FixSensivityInScope);

	SetupValue("MGlobals.FlashAlpha", &Opts.Misc.Globals.FlashAlpha);

	SetupValue("MGlobals.ClanTag", &Opts.Misc.Secondary.ClanTag);
	SetupValue("MGlobals.ClanTagMode", &Opts.Misc.Secondary.ClanTagMode);

	SetupValue("MGlobals.ChatSpam", &Opts.Misc.Secondary.ChatSpam);
	SetupValue("MGlobals.ChatSpamPathToFile", &Opts.Misc.Secondary.ChatSpamPathToFile);

	SetupValue("MGlobals.FakeCrouch", &Opts.Misc.Secondary.FakeCrouch);
	SetupValue("MGlobals.FakeCrouchKey", &Opts.Misc.Secondary.FakeCrouchKey);

	SetupValue("MGlobals.FakeLag", &Opts.Misc.Secondary.FakeLag);
	SetupValue("MGlobals.FakeLagType", &Opts.Misc.Secondary.FakeLagType);

	SetupValue("MGlobals.StandingAmount", &Opts.Misc.Secondary.StandingAmount);
	SetupValue("MGlobals.MovingAmount", &Opts.Misc.Secondary.MovingAmount);
	SetupValue("MGlobals.JumpingAmount", &Opts.Misc.Secondary.JumpingAmount);

	SetupValue("MGlobals.SlowWalk", &Opts.Misc.Secondary.SlowWalk);
	SetupValue("MGlobals.SlowWalkKey", &Opts.Misc.Secondary.SlowWalkKey);
	SetupValue("MGlobals.SlowWalkSpeed", &Opts.Misc.Secondary.SlowWalkSpeed);

	SetupValue("MSecond.ForceRagDoll", &Opts.Misc.Secondary.ForceRagDoll);

	// Misc BuyBot
	SetupValue("MBuyBot.Enable", &Opts.Misc.Other.BuyBot.Enable);

	SetupValue("MBuyBot.Weapon", &Opts.Misc.Other.BuyBot.Weapon);
	SetupValue("MBuyBot.Pistol", &Opts.Misc.Other.BuyBot.Pistol);

	SetupValue("MBuyBot.grenade_1", &Opts.Misc.Other.BuyBot.grenade_1);
	SetupValue("MBuyBot.grenade_2", &Opts.Misc.Other.BuyBot.grenade_2);
	SetupValue("MBuyBot.grenade_3", &Opts.Misc.Other.BuyBot.grenade_3);
	SetupValue("MBuyBot.grenade_4", &Opts.Misc.Other.BuyBot.grenade_4);

	SetupValue("MBuyBot.Armor", &Opts.Misc.Other.BuyBot.Armor);

	SetupValue("MBuyBot.zeus", &Opts.Misc.Other.BuyBot.zeus);
	SetupValue("MBuyBot.defuse_kit", &Opts.Misc.Other.BuyBot.defuse_kit);

	// Colors
	SetupValue("MColors.PlayersGlobalEnemyVisible", &Opts.Colors.Visuals.PlayersGlobalEnemyVisible);
	SetupValue("MColors.PlayersGlobalEnemyInvisible", &Opts.Colors.Visuals.PlayersGlobalEnemyInvisible);
	SetupValue("MColors.PlayersGlobalTeammateVisible", &Opts.Colors.Visuals.PlayersGlobalTeammateVisible);
	SetupValue("MColors.PlayersGlobalTeammateInvisible", &Opts.Colors.Visuals.PlayersGlobalTeammateInvisible);

	SetupValue("MColors.PlayersChamsEnemyVisible", &Opts.Colors.Visuals.PlayersChamsEnemyVisible);
	SetupValue("MColors.PlayersChamsEnemyInvisible", &Opts.Colors.Visuals.PlayersChamsEnemyInvisible);
	SetupValue("MColors.PlayersChamsTeammateVisible", &Opts.Colors.Visuals.PlayersChamsTeammateVisible);
	SetupValue("MColors.PlayersChamsTeammateInvisible", &Opts.Colors.Visuals.PlayersChamsTeammateInvisible);

	SetupValue("MColors.PlayersSnipeLineEnemyVisible", &Opts.Colors.Visuals.PlayersSnipeLineEnemyVisible);
	SetupValue("MColors.PlayersSnipeLineEnemyInvisible", &Opts.Colors.Visuals.PlayersSnipeLineEnemyInvisible);
	SetupValue("MColors.PlayersSnipeLineTeammateVisible", &Opts.Colors.Visuals.PlayersSnipeLineTeammateVisible);
	SetupValue("MColors.PlayersSnipeLineTeammateInvisible", &Opts.Colors.Visuals.PlayersSnipeLineTeammateInvisible);

	SetupValue("MColors.PlayersGlowEnemyVisible", &Opts.Colors.Visuals.PlayersGlowEnemyVisible);
	SetupValue("MColors.PlayersGlowEnemyInvisible", &Opts.Colors.Visuals.PlayersGlowEnemyInvisible);
	SetupValue("MColors.PlayersGlowTeammateVisible", &Opts.Colors.Visuals.PlayersGlowTeammateVisible);
	SetupValue("MColors.PlayersGlowTeammateInvisible", &Opts.Colors.Visuals.PlayersGlowTeammateInvisible);

	SetupValue("MColors.WeaponGlowWeapons", &Opts.Colors.Visuals.WeaponGlowWeapons);
	SetupValue("MColors.WeaponGlowGrenades", &Opts.Colors.Visuals.WeaponGlowGrenades);
	SetupValue("MColors.WeaponGlowBomb", &Opts.Colors.Visuals.WeaponGlowBomb);

	SetupValue("MColors.RadarEnemyVisible", &Opts.Colors.Visuals.RadarEnemyVisible);
	SetupValue("MColors.RadarEnemyInvisible", &Opts.Colors.Visuals.RadarEnemyInvisible);
	SetupValue("MColors.RadarTeammateVisible", &Opts.Colors.Visuals.RadarTeammateVisible);
	SetupValue("MColors.RadarTeammateInvisible", &Opts.Colors.Visuals.RadarTeammateInvisible);

	SetupValue("MColors.ChamsHands", &Opts.Colors.Misc.ChamsHands);
	SetupValue("MColors.ChamsSleeves", &Opts.Colors.Misc.ChamsSleeves);
	SetupValue("MColors.ChamsWeapons", &Opts.Colors.Misc.ChamsWeapons);

	SetupValue("MColors.BulletTrace", &Opts.Colors.Misc.BulletTrace);
	SetupValue("MColors.GrenadePrediction", &Opts.Colors.Misc.GrenadePrediction);

	SetupValue("MColors.Walls", &Opts.Colors.Misc.Walls);
	SetupValue("MColors.Sky", &Opts.Colors.Misc.Sky);
	SetupValue("MColors.Prop", &Opts.Colors.Misc.Prop);

	SetupValue("MColors.BackGround", &Opts.Colors.Misc.BackGround);
	SetupValue("MColors.BackDropSquare", &Opts.Colors.Misc.BackDropSquare);
	SetupValue("MColors.BackDropSquareOutLine", &Opts.Colors.Misc.BackDropSquareOutLine);
	SetupValue("MColors.BackDropSquareLine", &Opts.Colors.Misc.BackDropSquareLine);

	// Menu
	for (int i = 0; i < ImGuiCol_COUNT; ++i)
		SetupValue("MMenu." + std::to_string(i), &Opts.Menu.colors[i]);

	SetupValue("MMenu.OpenMenu", &Opts.Menu.MenuKey);
	SetupValue("MMenu.Panic", &Opts.Menu.PanicKey);
}

//#include <chrono>

void NNconfig::SaveCFG()
{
	std::ofstream file_stream(path_to_folder + Opts.Menu.MassConfigs[Opts.Menu.Config]);
	NNconfig::file_str = "CFG for NoNameHack By " + G::user_login;

	if (file_stream.is_open())
	{
		ImGuiStyle& style = ImGui::GetStyle();


		for (int i = 0; i < ImGuiCol_COUNT; ++i)
			Opts.Menu.colors[i] = Color(style.Colors[i].x * 255.0f, style.Colors[i].y * 255.0f, style.Colors[i].z * 255.0f, style.Colors[i].w * 255.0f);

		for (unsigned long long i = 0; i < byte_values.size(); ++i)
			SaveByteVal(byte_values[i].value_name, *byte_values[i].value_address);

		for (unsigned long long i = 0; i < bool_values.size(); ++i)
			SaveBoolVal(bool_values[i].value_name, *bool_values[i].value_address);

		for (unsigned long long i = 0; i < int_values.size(); ++i)
			SaveIntVal(int_values[i].value_name, *int_values[i].value_address);

		for (unsigned long long i = 0; i < float_values.size(); ++i)
			SaveFloatVal(float_values[i].value_name, *float_values[i].value_address);

		for (unsigned long long i = 0; i < str_values.size(); ++i)
			SaveStringVal(str_values[i].value_name, *str_values[i].value_address);

		for (unsigned long long i = 0; i < col_values.size(); ++i)
			SaveColor4Val(col_values[i].value_name, *col_values[i].value_address);


		NNconfig::file_str += '\n';
		file_stream << NNconfig::file_str;

	}
	else
	{
		MessageBox(0, "Cfg file not found", "Error 404", 0);
	}

	file_stream.close();
}

void NNconfig::LoadCFG()
{
	std::ifstream file_stream(path_to_folder + Opts.Menu.MassConfigs[Opts.Menu.Config]);

	ImGuiStyle& style = ImGui::GetStyle();

	if (file_stream.is_open())
	{
		NNconfig::file_str = std::string((std::istreambuf_iterator<char>(file_stream)), std::istreambuf_iterator<char>());

		NNconfig::file_str.erase(0, NNconfig::file_str.find('\n'));

		DeleteStrings(Opts.Menu.Loads[LOAD_SETTINGS_RAGE], "Rage");
		DeleteStrings(Opts.Menu.Loads[LOAD_SETTINGS_LEGIT], "Legit");
		DeleteStrings(Opts.Menu.Loads[LOAD_SETTINGS_LEGIT_RAGE], "LRage");
		DeleteStrings(Opts.Menu.Loads[LOAD_SETTINGS_VISUAL_GLOBALS], "VGlobals");
		DeleteStrings(Opts.Menu.Loads[LOAD_SETTINGS_VISUAL_CHAMS], "VChams");
		DeleteStrings(Opts.Menu.Loads[LOAD_SETTINGS_VISUAL_GLOW], "VGlow");
		DeleteStrings(Opts.Menu.Loads[LOAD_SETTINGS_VISUAL_OTHER], "VOther");
		DeleteStrings(Opts.Menu.Loads[LOAD_SETTINGS_CHANGER_MODELS], "CModels");
		DeleteStrings(Opts.Menu.Loads[LOAD_SETTINGS_CHANGER_SKINS], "CSkins");
		DeleteStrings(Opts.Menu.Loads[LOAD_SETTINGS_CHANGER_PROFILE], "CProfile");
		DeleteStrings(Opts.Menu.Loads[LOAD_SETTINGS_CHANGER_OTHER], "COther");
		DeleteStrings(Opts.Menu.Loads[LOAD_SETTINGS_MISC_GLOBALS], "MGlobals");
		DeleteStrings(Opts.Menu.Loads[LOAD_SETTINGS_MISC_BUYBOT], "MBuyBot");
		DeleteStrings(Opts.Menu.Loads[LOAD_SETTINGS_MISC_COLORS], "MColors");
		DeleteStrings(Opts.Menu.Loads[LOAD_SETTINGS_MISC_MENU], "MMenu");

		for (unsigned long long i = 0; i < byte_values.size(); ++i)
			LoadByteVal(byte_values[i].value_name, byte_values[i].value_address, byte_values[i].def_value);

		for (unsigned long long i = 0; i < bool_values.size(); ++i)
			LoadBoolVal(bool_values[i].value_name, bool_values[i].value_address, bool_values[i].def_value);

		for (unsigned long long i = 0; i < int_values.size(); ++i)
			LoadIntVal(int_values[i].value_name, int_values[i].value_address, int_values[i].def_value);

		for (unsigned long long i = 0; i < float_values.size(); ++i)
			LoadFloatVal(float_values[i].value_name, float_values[i].value_address, float_values[i].def_value);

		for (unsigned long long i = 0; i < str_values.size(); ++i)
			LoadStringVal(str_values[i].value_name, str_values[i].value_address, str_values[i].def_value);

		for (unsigned long long i = 0; i < col_values.size(); ++i)
			LoadColor4Val(col_values[i].value_name, col_values[i].value_address, col_values[i].def_value);


		if (Opts.Menu.Loads[LOAD_SETTINGS_MISC_MENU])
		{
			for (int i = 0; i < ImGuiCol_COUNT; ++i)
				style.Colors[i] = ImVec4(Opts.Menu.colors[i].rBase(), Opts.Menu.colors[i].gBase(), Opts.Menu.colors[i].bBase(), Opts.Menu.colors[i].aBase());
		}

		U::ForceFullUpdate();

		G::LegitUpdate = true;
		G::RageUpdate = true;
		G::LegitRageUpdate = true;
		G::RadarUpdate = true;
		G::SpecratorsUpdate = true;

		G::CFGUpdate = true;
	}
	else
	{
		MessageBox(0, "Cfg file not found", "Error 404", 0);
	}

	file_stream.close();
}

void NNconfig::UpdateCFGList()
{
	WIN32_FIND_DATA FindFileData;
	HANDLE file_handle;

	static std::string first_file = path_to_folder + "*";
	file_handle = FindFirstFile(first_file.c_str(), &FindFileData);

	Opts.Menu.MassConfigs.clear();
	if (file_handle != INVALID_HANDLE_VALUE)
	{
		do
		{
			std::string file = FindFileData.cFileName;
			if (file.rfind(".nn") != std::string::npos)
				Opts.Menu.MassConfigs.push_back(file);

		} while (FindNextFile(file_handle, &FindFileData) != 0);

		FindClose(file_handle);
	}
}

void NNconfig::CreateCfg(std::string name)
{
	std::ofstream new_cfg(path_to_folder + name + ".nn");
	new_cfg.close();
}

void NNconfig::DeleteCfg(std::string name)
{
	std::remove(std::string(path_to_folder + name).c_str());
}

__forceinline bool IsNotNeedLoadVal(std::string name)
{
	if (!Opts.Menu.Loads[LOAD_SETTINGS_RAGE]) if (name.find("Rage.") != std::string::npos) return true;
	if (!Opts.Menu.Loads[LOAD_SETTINGS_LEGIT]) if (name.find("Legit.") != std::string::npos) return true;
	if (!Opts.Menu.Loads[LOAD_SETTINGS_LEGIT_RAGE]) if (name.find("LRage.") != std::string::npos) return true;
	if (!Opts.Menu.Loads[LOAD_SETTINGS_VISUAL_GLOBALS]) if (name.find("VGlobals.") != std::string::npos) return true;
	if (!Opts.Menu.Loads[LOAD_SETTINGS_VISUAL_CHAMS]) if (name.find("VChams.") != std::string::npos) return true;
	if (!Opts.Menu.Loads[LOAD_SETTINGS_VISUAL_GLOW]) if (name.find("VGlow.") != std::string::npos) return true;
	if (!Opts.Menu.Loads[LOAD_SETTINGS_VISUAL_OTHER]) if (name.find("VOther.") != std::string::npos) return true;
	if (!Opts.Menu.Loads[LOAD_SETTINGS_CHANGER_MODELS]) if (name.find("CModels.") != std::string::npos) return true;
	if (!Opts.Menu.Loads[LOAD_SETTINGS_CHANGER_SKINS]) if (name.find("CSkins.") != std::string::npos) return true;
	if (!Opts.Menu.Loads[LOAD_SETTINGS_CHANGER_PROFILE]) if (name.find("CProfile.") != std::string::npos) return true;
	if (!Opts.Menu.Loads[LOAD_SETTINGS_CHANGER_OTHER]) if (name.find("COther.") != std::string::npos) return true;
	if (!Opts.Menu.Loads[LOAD_SETTINGS_MISC_GLOBALS]) if (name.find("MGlobals.") != std::string::npos) return true;
	if (!Opts.Menu.Loads[LOAD_SETTINGS_MISC_BUYBOT]) if (name.find("MBuyBot.") != std::string::npos) return true;
	if (!Opts.Menu.Loads[LOAD_SETTINGS_MISC_COLORS]) if (name.find("MColors.") != std::string::npos) return true;
	if (!Opts.Menu.Loads[LOAD_SETTINGS_MISC_MENU]) if (name.find("MMenu.") != std::string::npos) return true;

	return false;
}

void NNconfig::SaveByteVal(std::string name, unsigned char value)
{
	NNconfig::file_str += '\n' + name + '=' + std::to_string((int)value);
}
void NNconfig::LoadByteVal(std::string name, unsigned char* value, unsigned char def_value)
{
	int pos_name = NNconfig::file_str.find(std::string('\n' + name));

	if (pos_name != std::string::npos)
	{
		++pos_name;
		int pos_1 = pos_name + name.size() + 1;
		int pos_2 = NNconfig::file_str.find('\n', pos_1);

		NNconfig::temp_str.assign(NNconfig::file_str, pos_1, pos_2 - pos_1);

		*value = std::atoi(temp_str.c_str());
		NNconfig::file_str.erase(pos_name, pos_2 - pos_name + 1);
	}
	else
	{
		if (IsNotNeedLoadVal(name)) return;

		*value = def_value;
	}
}

void NNconfig::SaveBoolVal(std::string name, bool value)
{
	if (value)
		NNconfig::file_str += '\n' + name + "=t";
	else
		NNconfig::file_str += '\n' + name + "=f";
}
void NNconfig::LoadBoolVal(std::string name, bool* value, bool def_value)
{
	int pos_name = NNconfig::file_str.find(std::string('\n' + name));

	if (pos_name != std::string::npos)
	{
		++pos_name;
		int pos_1 = pos_name + name.size() + 1;
		int pos_2 = NNconfig::file_str.find('\n', pos_1);

		NNconfig::temp_str.assign(NNconfig::file_str, pos_1, pos_2 - pos_1);

		*value = (bool)(temp_str[0] == 't'); // if true then val = true else val = false
		NNconfig::file_str.erase(pos_name, pos_2 - pos_name + 1);
	}
	else
	{
		if (IsNotNeedLoadVal(name)) return;

		*value = def_value;
	}
}

void NNconfig::SaveIntVal(std::string name, int value)
{
	NNconfig::file_str += '\n' + name + '=' + std::to_string(value);
}
void NNconfig::LoadIntVal(std::string name, int* value, int def_value)
{
	int pos_name = NNconfig::file_str.find(std::string('\n' + name));

	if (pos_name != std::string::npos)
	{
		++pos_name;
		int pos_1 = pos_name + name.size() + 1;
		int pos_2 = NNconfig::file_str.find('\n', pos_1);

		NNconfig::temp_str.assign(NNconfig::file_str, pos_1, pos_2 - pos_1);

		*value = std::atoi(temp_str.c_str());
		NNconfig::file_str.erase(pos_name, pos_2 - pos_name + 1);
	}
	else
	{
		if (IsNotNeedLoadVal(name)) return;

		*value = def_value;
	}
}

void NNconfig::SaveFloatVal(std::string name, float value)
{
	NNconfig::file_str += '\n' + name + '=' + std::to_string(value);
}
void NNconfig::LoadFloatVal(std::string name, float* value, float def_value)
{
	int pos_name = NNconfig::file_str.find(std::string('\n' + name));

	if (pos_name != std::string::npos)
	{
		++pos_name;
		int pos_1 = pos_name + name.size() + 1;
		int pos_2 = NNconfig::file_str.find('\n', pos_1);

		NNconfig::temp_str.assign(NNconfig::file_str, pos_1, pos_2 - pos_1);

		*value = std::atof(temp_str.c_str());
		NNconfig::file_str.erase(pos_name, pos_2 - pos_name + 1);
	}
	else
	{
		if (IsNotNeedLoadVal(name)) return;

		*value = def_value;
	}
}

void NNconfig::SaveStringVal(std::string name, std::string value)
{
	NNconfig::file_str += '\n' + name + '=' + value;
}
void NNconfig::LoadStringVal(std::string name, std::string* value, std::string def_value)
{
	int pos_name = NNconfig::file_str.find(std::string('\n' + name));

	if (pos_name != std::string::npos)
	{
		++pos_name;
		int pos_1 = pos_name + name.size() + 1;
		int pos_2 = NNconfig::file_str.find('\n', pos_1);

		NNconfig::temp_str.assign(NNconfig::file_str, pos_1, pos_2 - pos_1);
		NNconfig::file_str.erase(pos_name, pos_2 - pos_name + 1);
	}
	else
	{
		if (IsNotNeedLoadVal(name)) return;

		*value = def_value;
	}
}

void NNconfig::SaveColor4Val(std::string name, Color value)
{
	NNconfig::file_str += '\n' + name + '=' + std::to_string(value._color[0]) + ',' + std::to_string(value._color[1]) + ',' + std::to_string(value._color[2]) + ',' + std::to_string(value._color[3]);
}
void NNconfig::LoadColor4Val(std::string name, Color* value, Color def_value)
{
	int pos_name = NNconfig::file_str.find(std::string('\n' + name));

	if (pos_name != std::string::npos)
	{
		++pos_name;
		int pos_1 = pos_name + name.size() + 1;
		int pos_2 = NNconfig::file_str.find('\n', pos_1);

		NNconfig::temp_str.assign(NNconfig::file_str, pos_1, pos_2 - pos_1);
		NNconfig::file_str.erase(pos_name, pos_2 - pos_name + 1);

		std::string temp_str_1;

		pos_2 = temp_str.find(',');
		temp_str_1.assign(temp_str, 0, pos_2);
		(*value)._color[0] = std::atoi(temp_str_1.c_str());
		pos_1 = pos_2 + 1;

		pos_2 = temp_str.find(',', pos_1);
		temp_str_1.assign(temp_str, pos_1, pos_2);
		(*value)._color[1] = std::atoi(temp_str_1.c_str());
		pos_1 = pos_2 + 1;

		pos_2 = temp_str.find(',', pos_1);
		temp_str_1.assign(temp_str, pos_1, pos_2);
		(*value)._color[2] = std::atoi(temp_str_1.c_str());
		pos_1 = pos_2 + 1;

		pos_2 = temp_str.find(',', pos_1);
		temp_str_1.assign(temp_str, pos_1, pos_2);
		(*value)._color[3] = std::atoi(temp_str_1.c_str());
	}
	else
	{
		if (IsNotNeedLoadVal(name)) return;

		(*value)._color[0] = def_value._color[0];
		(*value)._color[1] = def_value._color[1];
		(*value)._color[2] = def_value._color[2];
		(*value)._color[3] = def_value._color[3];
	}
}

void NNconfig::SaveColor3Val(std::string name, Color value)
{
	NNconfig::file_str += '\n' + name + '=' + std::to_string(value._color[0]) + ',' + std::to_string(value._color[1]) + ',' + std::to_string(value._color[2]);
}
void NNconfig::LoadColor3Val(std::string name, Color* value, Color def_value)
{
	int pos_name = NNconfig::file_str.find(std::string('\n' + name));

	if (pos_name != std::string::npos)
	{
		++pos_name;
		int pos_1 = pos_name + name.size() + 1;
		int pos_2 = NNconfig::file_str.find('\n', pos_1);

		NNconfig::temp_str.assign(NNconfig::file_str, pos_1, pos_2 - pos_1);
		NNconfig::file_str.erase(pos_name, pos_2 - pos_name + 1);

		std::string temp_str_1;

		pos_2 = temp_str.find(',');
		temp_str_1.assign(temp_str, 0, pos_2);
		(*value)._color[0] = std::atoi(temp_str_1.c_str());
		pos_1 = pos_2 + 1;

		pos_2 = temp_str.find(',', pos_1);
		temp_str_1.assign(temp_str, pos_1, pos_2);
		(*value)._color[1] = std::atoi(temp_str_1.c_str());
		pos_1 = pos_2 + 1;

		pos_2 = temp_str.find(',', pos_1);
		temp_str_1.assign(temp_str, pos_1, pos_2);
		(*value)._color[2] = std::atoi(temp_str_1.c_str());

		(*value)._color[3] = 255;
	}
	else
	{
		(*value)._color[0] = def_value._color[0];
		(*value)._color[1] = def_value._color[1];
		(*value)._color[2] = def_value._color[2];
		(*value)._color[3] = 255;
	}
}

void NNconfig::SaveOneByteVal(std::string name, unsigned char value)
{
	std::ifstream file_stream_read(path_to_folder + Opts.Menu.MassConfigs[Opts.Menu.Config]);
	std::ofstream file_stream_write(path_to_folder + Opts.Menu.MassConfigs[Opts.Menu.Config]);

	if (file_stream_read.is_open())
	{
		file_stream_read.seekg(0, std::ios::end);
		size_t size = file_stream_read.tellg();
		std::string temp_file_str(size, ' ');
		file_stream_read.seekg(0);
		file_stream_read.read(&temp_file_str[0], size);

		int name_pos = temp_file_str.find(name);

		if (name_pos != std::string::npos)
		{
			int pos1 = temp_file_str.find("=", name_pos) + 1;
			int pos2 = temp_file_str.find(";", name_pos);

			temp_file_str.erase(pos1, pos2 - pos1);
			temp_file_str.insert(pos1, std::to_string((int)value));
		}

		file_stream_write << temp_file_str;
	}
	else
	{
		// error
	}

	file_stream_read.close();
	file_stream_write.close();
}

void NNconfig::SaveOneIntVal(std::string name, int value)
{
	std::fstream file_stream(path_to_folder + Opts.Menu.MassConfigs[Opts.Menu.Config]);
	NNconfig::file_str = "";

	ImGuiStyle& style = ImGui::GetStyle();

	if (file_stream.is_open())
	{
		NNconfig::file_str = std::string((std::istreambuf_iterator<char>(std::ifstream(path_to_folder + Opts.Menu.MassConfigs[Opts.Menu.Config]))), std::istreambuf_iterator<char>());


		std::ofstream file_stream_write(path_to_folder + Opts.Menu.MassConfigs[Opts.Menu.Config]);
		 
		int pos_name = NNconfig::file_str.find(std::string('\n' + name));
		 
		if (pos_name != std::string::npos)
		{
			int pos_1 = pos_name + name.size() + 2;
			int pos_2 = NNconfig::file_str.find('\n', pos_1);
			
			NNconfig::file_str.erase(pos_1, pos_2 - pos_1);
			NNconfig::file_str.insert(pos_1, std::to_string(value));
		}

		file_stream_write << NNconfig::file_str;
		
		file_stream_write.close();
	}
}

void NNconfig::SetupValue(std::string name, unsigned char* value)
{
	byte_values.push_back(ValueType<unsigned char>(name, value, *value));
}
void NNconfig::SetupValue(std::string name, bool* value)
{
	bool_values.push_back(ValueType<bool>(name, value, *value));
}
void NNconfig::SetupValue(std::string name, int* value)
{
	int_values.push_back(ValueType<int>(name, value, *value));
}
void NNconfig::SetupValue(std::string name, float* value)
{
	float_values.push_back(ValueType<float>(name, value, *value));
}
void NNconfig::SetupValue(std::string name, std::string* value)
{
	str_values.push_back(ValueType<std::string>(name, value, *value));
}
void NNconfig::SetupValue(std::string name, Color* value)
{
	col_values.push_back(ValueType<Color>(name, value, *value));
}

void NNconfig::DeleteAllStrings(std::string name)
{
	while (true)
	{
		int pos_name = NNconfig::file_str.find(std::string('\n' + name + '.'));

		if (pos_name != std::string::npos)
		{
			++pos_name;
			int pos_2 = NNconfig::file_str.find('\n', (pos_name + name.size() + 1));
			NNconfig::file_str.erase(pos_name, pos_2 - pos_name + 1);
		}
		else
			break;
	}
}

std::string ParsePointsInStr(std::string source_str, size_t max_pixels)
{
	size_t source_size = source_str.size();

	source_str += '\0';
	size_t source_x = ImGui::CalcTextSize(source_str.c_str()).x;

	while (source_x > max_pixels) // 70, but 70 - 13
	{
		source_str.erase(source_str.end() - 2, source_str.end() - 1);
		source_x = ImGui::CalcTextSize(source_str.c_str()).x;
	}

	source_str.erase(source_str.end() - 1);

	if (source_size != source_str.size())
		source_str += "...";

	return source_str;
}

std::string ParseCfgInfoStr(std::string& source_str, bool del_str = true)
{
	size_t pos_1 = source_str.find(';');
	
	if (pos_1 != std::string::npos)
	{
		if (del_str)
		{
			std::string temp_str = source_str.substr(0, pos_1);
			source_str = source_str.substr(pos_1 + 1);

			return temp_str;
		}
		else
		{
			return source_str.substr(0, pos_1);
		}
	}

	return "__nullptr__";
}

std::string ParseSpecSymbol(std::string source_str, std::string spec_symbs, char symb)
{
	for (size_t new_line = source_str.find(spec_symbs); new_line != std::string::npos; new_line = source_str.find(spec_symbs))
	{
		source_str.erase(new_line, spec_symbs.size() - 1);
		source_str[new_line] = symb;
	}

	return source_str;
}

std::string ParseSpecSymbols(std::string source_str)
{
	source_str = ParseSpecSymbol(source_str, "\\n", '\n');
	source_str = ParseSpecSymbol(source_str, "\\t", '\t');

	return source_str;
}

NNconfig* Config = new NNconfig();