#pragma once

#include "Cheat.h"

struct _LOCAL_CLOUD_CFG
{
	std::string name;
	std::string short_name;
	std::string description;
	std::string rating;
	std::string code;
};

struct _USERS_CLOUD_CFG
{
	std::string cfg_name;
	std::string short_cfg_name;
	std::string user_name;
	std::string short_user_name;
	std::string description;
	std::string rating;
	std::string code;
};

enum LoadSettings
{
	LOAD_SETTINGS_RAGE = 0,

	LOAD_SETTINGS_LEGIT,
	LOAD_SETTINGS_LEGIT_RAGE,

	LOAD_SETTINGS_VISUAL_GLOBALS,
	LOAD_SETTINGS_VISUAL_CHAMS,
	LOAD_SETTINGS_VISUAL_GLOW,
	LOAD_SETTINGS_VISUAL_OTHER,

	LOAD_SETTINGS_CHANGER_MODELS,
	LOAD_SETTINGS_CHANGER_SKINS,
	LOAD_SETTINGS_CHANGER_PROFILE,
	LOAD_SETTINGS_CHANGER_OTHER,

	LOAD_SETTINGS_MISC_GLOBALS,
	LOAD_SETTINGS_MISC_BUYBOT,
	LOAD_SETTINGS_MISC_COLORS,
	LOAD_SETTINGS_MISC_MENU,

	LOAD_SETTINGS_MAX
};

template< typename T >
class ValueType
{
public:
	ValueType(std::string value_name_, T* value_address_, T def_value_)
	{
		value_name = value_name_;
		value_address = value_address_;
		def_value = def_value_;
	}

	std::string value_name;
	T* value_address;
	T def_value;
};

class NNconfig
{

public:
	void SetUpSettings();

	void SaveCFG();
	void LoadCFG();

	void UpdateCFGList();

	void CreateCfg(std::string name);
	void DeleteCfg(std::string name);

	void SaveByteVal(std::string name, unsigned char value);
	void LoadByteVal(std::string name, unsigned char* value, unsigned char def_value);

	void SaveBoolVal(std::string name, bool value);
	void LoadBoolVal(std::string name, bool* value, bool def_value);

	void SaveIntVal(std::string name, int value);
	void LoadIntVal(std::string name, int* value, int def_value);

	void SaveFloatVal(std::string name, float value);
	void LoadFloatVal(std::string name, float* value, float def_value);

	void SaveStringVal(std::string name, std::string value);
	void LoadStringVal(std::string name, std::string* value, std::string def_value);

	void SaveColor4Val(std::string name, Color value);
	void LoadColor4Val(std::string name, Color* value, Color def_value);

	void SaveColor3Val(std::string name, Color value);
	void LoadColor3Val(std::string name, Color* value, Color def_value);

	void SaveOneByteVal(std::string name, unsigned char value);
	void LoadOneByteVal(std::string name, unsigned char* value, unsigned char def_value);

	void SaveOneBoolVal(std::string name, bool value);
	void LoadOneBoolVal(std::string name, bool* value, bool def_value);

	void SaveOneIntVal(std::string name, int value);
	void LoadOneIntVal(std::string name, int* value, int def_value);

	void SaveOneFloatVal(std::string name, float value);
	void LoadOneFloatVal(std::string name, float* value, float def_value);

	void SaveOneStringVal(std::string name, std::string value);
	void LoadOneStringVal(std::string name, std::string* value, std::string def_value);

	void SetupValue(std::string name, unsigned char* value);
	void SetupValue(std::string name, bool* value);
	void SetupValue(std::string name, int* value);
	void SetupValue(std::string name, float* value);
	void SetupValue(std::string name, std::string* value);
	void SetupValue(std::string name, Color* value);

	void DeleteAllStrings(std::string name);

	std::string file_str;
	std::string temp_str;

	std::string path_to_folder;

	std::vector<ValueType<unsigned char>> byte_values;
	std::vector<ValueType<bool>> bool_values;
	std::vector<ValueType<int>> int_values;
	std::vector<ValueType<float>> float_values;
	std::vector<ValueType<std::string>> str_values;
	std::vector<ValueType<Color>> col_values;
};

extern NNconfig* Config;