#pragma once

extern RecvVarProxyFn oSequenceProxy;
extern RecvVarProxyFn oRecvnModelIndex;

extern void NetvarHook();