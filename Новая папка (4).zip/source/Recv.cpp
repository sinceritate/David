#include "KnifeChanger.h"
#include "Recv.h"
#include "Cheat.h"

RecvVarProxyFn oSequenceProxy = nullptr;
RecvVarProxyFn oRecvnModelIndex = nullptr;

#define hrcvpv_model_def_func(index, def_model_name) \
if (pData->m_Value.m_Int == I::ModelInfo->GetModelIndex(def_model_name)) \
{ \
	size_t sct_index = Opts.Misc.Changer.Models.iModelMass[index]; \
	if (sct_index != 0) \
	{ \
		size_t global_sct_index = MD_Manager.models_mass[index][sct_index].global_id; \
		std::string path_to_model = MD_Manager.model_structs[global_sct_index].model_path + MD_Manager.model_structs[global_sct_index].model_path_files[0]; \
		U::PrecacheModel(path_to_model.c_str()); \
		pData->m_Value.m_Int = I::ModelInfo->GetModelIndex(path_to_model.c_str()); \
	} \
	oRecvnModelIndex(pData, pStruct, pOut); \
	return; \
}

void Hooked_RecvProxy_Viewmodel(CRecvProxyData* pData, void *pStruct, void *pOut)
{
	if (!G::IsInDangerZone && I::Engine->IsInGame() && I::Engine->IsConnected() && G::LocalPlayer && G::LocalPlayer->GetAlive())
	{
		if (Opts.Misc.Changer.Skins.EnableKnife || (Opts.Misc.Changer.Models.Enable && Opts.Misc.Changer.Models.FastChange))
		{
			if (Opts.Misc.Changer.Models.Enable && Opts.Misc.Changer.Models.FastChange)
			{

			}

			int model_massive[] =
			{
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_T.c_str()),
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL.c_str()),
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_GG.c_str()),
			
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_BAYONET.c_str()),
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_FLIP.c_str()),
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_GUT.c_str()),
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_KARAMBIT.c_str()),
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_M9_BAYONET.c_str()),
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_TACTICAL.c_str()),
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_FALCHION.c_str()),
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_SURVIVAL_BOWIE.c_str()),
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_BUTTERFLY.c_str()),
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_PUSH.c_str()),

				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_URSUS.c_str()),
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_GYPSY_JACKKNIFE.c_str()),
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_STILETTO.c_str()),
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_WIDOWMAKER.c_str()),
			
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_CSS.c_str()),
			
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_CORD.c_str()),
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_CANIS.c_str()),
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_OUTDOOR.c_str()),
				I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_SKELETON.c_str()),
			};

			for (int index = 0; index <= ARRAYSIZE(model_massive); ++index)
			{
				if (pData->m_Value.m_Int == model_massive[index]) break;
				else if (index == ARRAYSIZE(model_massive))
				{
					oRecvnModelIndex(pData, pStruct, pOut);
					return;
				}
			}

			if (Opts.Misc.Changer.Models.Enable && Opts.Misc.Changer.Models.FastChange)
			{
				size_t sct_index = Opts.Misc.Changer.Models.iModelMass[MT_WEAPON_KNIFE];
				if (sct_index != 0)
				{

				}

				/*switch (Opts.Misc.Changer.Models.iModelMass[MT_WEAPON_KNIFE])
				{
				case 1: U::PrecacheModel("models/weapons/ventoz/Abyss_Greatsword/v_abyss_greatsword.mdl"); pData->m_Value.m_Int = I::ModelInfo->GetModelIndex("models/weapons/ventoz/Abyss_Greatsword/v_abyss_greatsword.mdl"); break;
				case 2: U::PrecacheModel("models/weapons/eminem/police_baton/v_police_baton.mdl"); pData->m_Value.m_Int = I::ModelInfo->GetModelIndex("models/weapons/eminem/police_baton/v_police_baton.mdl"); break;
				case 3: U::PrecacheModel("models/weapons/eminem/zombie_hands/v_zombie_hands.mdl"); pData->m_Value.m_Int = I::ModelInfo->GetModelIndex("models/weapons/eminem/zombie_hands/v_zombie_hands.mdl"); break;
				case 4: U::PrecacheModel("models/weapons/eminem/fidget_spinner/v_fidget_spinner.mdl"); pData->m_Value.m_Int = I::ModelInfo->GetModelIndex("models/weapons/eminem/fidget_spinner/v_fidget_spinner.mdl"); break;
				case 5: U::PrecacheModel("models/weapons/eminem/master_sword/v_master_sword.mdl"); pData->m_Value.m_Int = I::ModelInfo->GetModelIndex("models/weapons/eminem/master_sword/v_master_sword.mdl"); break;
				case 6: U::PrecacheModel("models/weapons/eminem/sharpened_volcano_fragment/v_sharpened_volcano_fragment.mdl"); pData->m_Value.m_Int = I::ModelInfo->GetModelIndex("models/weapons/eminem/sharpened_volcano_fragment/v_sharpened_volcano_fragment.mdl"); break;
				case 7: U::PrecacheModel("models/weapons/eminem/hammer/v_hammer.mdl"); pData->m_Value.m_Int = I::ModelInfo->GetModelIndex("models/weapons/eminem/hammer/v_hammer.mdl"); break;
				case 8: U::PrecacheModel("models/weapons/eminem/blue_screwdriver/v_blue_screwdriver.mdl"); pData->m_Value.m_Int = I::ModelInfo->GetModelIndex("models/weapons/eminem/blue_screwdriver/v_blue_screwdriver.mdl"); break;
				case 9: U::PrecacheModel("models/weapons/eminem/candy_cane/v_candy_cane.mdl"); pData->m_Value.m_Int = I::ModelInfo->GetModelIndex("models/weapons/eminem/candy_cane/v_candy_cane.mdl"); break;
				case 10: U::PrecacheModel("models/weapons/eminem/bananabit/v_bananabit.mdl"); pData->m_Value.m_Int = I::ModelInfo->GetModelIndex("models/weapons/eminem/bananabit/v_bananabit.mdl"); break;
				default: break;
				}*/
			}
			else
			{
				if (Opts.Misc.Changer.Skins.SettingsForTeams)
				{
					if (G::LocalPlayer->GetTeam() == 3) // if ct
					{
						if (Opts.Misc.Changer.Skins.Knifes[0].ModelIndex == 0)
							pData->m_Value.m_Int = model_massive[1];
						else
							pData->m_Value.m_Int = model_massive[Opts.Misc.Changer.Skins.Knifes[0].ModelIndex - 1];
					}
					else // if tt
					{
						if (Opts.Misc.Changer.Skins.Knifes[1].ModelIndex == 0)
							pData->m_Value.m_Int = model_massive[0];
						else
							pData->m_Value.m_Int = model_massive[Opts.Misc.Changer.Skins.Knifes[1].ModelIndex - 1];
					}
				}
				else // if setting mode for team off
				{
					if (Opts.Misc.Changer.Skins.Knifes[2].ModelIndex != 0)
						pData->m_Value.m_Int = model_massive[Opts.Misc.Changer.Skins.Knifes[2].ModelIndex - 1];
				}
			}
		}
	}

	oRecvnModelIndex(pData, pStruct, pOut);
}

class CBaseViewModel : public IVModelInfo
{
public:

	inline DWORD GetOwner() {

		return *(PDWORD)((DWORD)this + offsets.m_hOwner);
	}

	inline int GetModelIndex() {

		return *(int*)((DWORD)this + offsets.m_nModelIndex);
	}
};

void Hooked_RecvProxy_SetViewModelSequence(const CRecvProxyData* pDataConst, void* pStruct, void* pOut)
{
	CRecvProxyData* pData = const_cast<CRecvProxyData*>(pDataConst);
	CBaseViewModel* pViewModel = static_cast<CBaseViewModel*>(pStruct);

	if (I::Engine->IsInGame() && I::Engine->IsConnected() && G::LocalPlayer && G::LocalPlayer->GetAlive() && G::LocalPlayer->GetWeapon()->GetType() == WT_KNIFES && Opts.Misc.Changer.Skins.EnableKnife)
	{
		if (pViewModel)
		{
			CBaseEntity* pOwner = I::ClientEntList->GetClientEntity(pViewModel->GetOwner() & 0xFFF);

			if (pOwner && pOwner == G::LocalPlayer)
			{
				const model_t* pModel = I::ModelInfo->GetModel(pViewModel->GetModelIndex());
				std::string szModel = I::ModelInfo->GetModelName(pModel);
			
				if (szModel == xs("models/weapons/v_knife_butterfly.mdl"))
				{
					switch (pData->m_Value.m_Int)
					{
					case SEQUENCE_DEFAULT_DRAW:
						pData->m_Value.m_Int = RandomInt(SEQUENCE_BUTTERFLY_DRAW, SEQUENCE_BUTTERFLY_DRAW2);
						break;
					case SEQUENCE_DEFAULT_LOOKAT01:
						pData->m_Value.m_Int = RandomInt(SEQUENCE_BUTTERFLY_LOOKAT01, SEQUENCE_BUTTERFLY_LOOKAT03);
						break;
					default:
						pData->m_Value.m_Int++;
					}
				}
				else if (szModel == xs("models/weapons/v_knife_falchion_advanced.mdl"))
				{
					switch (pData->m_Value.m_Int)
					{
					case SEQUENCE_DEFAULT_IDLE2:
						pData->m_Value.m_Int = SEQUENCE_FALCHION_IDLE1;
						break;
					case SEQUENCE_DEFAULT_HEAVY_MISS1:
						pData->m_Value.m_Int = RandomInt(SEQUENCE_FALCHION_HEAVY_MISS1, SEQUENCE_FALCHION_HEAVY_MISS1_NOFLIP);
						break;
					case SEQUENCE_DEFAULT_LOOKAT01:
						pData->m_Value.m_Int = RandomInt(SEQUENCE_FALCHION_LOOKAT01, SEQUENCE_FALCHION_LOOKAT02);
						break;
					case SEQUENCE_DEFAULT_DRAW:
					case SEQUENCE_DEFAULT_IDLE1:
						break;
					default:
						pData->m_Value.m_Int--;
						break;
					}
				}
				else if (szModel == xs("models/weapons/v_knife_push.mdl"))
				{
					switch (pData->m_Value.m_Int)
					{
					case SEQUENCE_DEFAULT_IDLE2:
						pData->m_Value.m_Int = SEQUENCE_DAGGERS_IDLE1; break;
					case SEQUENCE_DEFAULT_LIGHT_MISS1:
					case SEQUENCE_DEFAULT_LIGHT_MISS2:
						pData->m_Value.m_Int = RandomInt(SEQUENCE_DAGGERS_LIGHT_MISS1, SEQUENCE_DAGGERS_LIGHT_MISS5);
						break;
					case SEQUENCE_DEFAULT_HEAVY_MISS1:
						pData->m_Value.m_Int = RandomInt(SEQUENCE_DAGGERS_HEAVY_MISS2, SEQUENCE_DAGGERS_HEAVY_MISS1);
						break;
					case SEQUENCE_DEFAULT_HEAVY_HIT1:
					case SEQUENCE_DEFAULT_HEAVY_BACKSTAB:
					case SEQUENCE_DEFAULT_LOOKAT01:
						pData->m_Value.m_Int += 3; break;
					case SEQUENCE_DEFAULT_DRAW:
					case SEQUENCE_DEFAULT_IDLE1:
						break;
					default:
						pData->m_Value.m_Int += 2;
					}
				}
				else if (szModel == xs("models/weapons/v_knife_survival_bowie.mdl"))
				{
					switch (pData->m_Value.m_Int)
					{
					case SEQUENCE_DEFAULT_DRAW:
					case SEQUENCE_DEFAULT_IDLE1:
						break;
					case SEQUENCE_DEFAULT_IDLE2:
						pData->m_Value.m_Int = SEQUENCE_BOWIE_IDLE1;
						break;
					default:
						pData->m_Value.m_Int--;
					}
				}
				else if (szModel == xs("models/weapons/v_knife_ursus.mdl"))
				{
					switch (pData->m_Value.m_Int)
					{
					case SEQUENCE_DEFAULT_DRAW:
						pData->m_Value.m_Int = RandomInt(SEQUENCE_BUTTERFLY_DRAW, SEQUENCE_BUTTERFLY_DRAW2);
						break;
					case SEQUENCE_DEFAULT_LOOKAT01:
						pData->m_Value.m_Int = RandomInt(SEQUENCE_BUTTERFLY_LOOKAT01, SEQUENCE_BUTTERFLY_LOOKAT03);
						break;
					default:
						pData->m_Value.m_Int++;
						break;
					}
				}
				else if (szModel == xs("models/weapons/v_knife_stiletto.mdl"))
				{
					switch (pData->m_Value.m_Int)
					{
					case SEQUENCE_DEFAULT_LOOKAT01:
						pData->m_Value.m_Int = RandomInt(SEQUENCE_DEFAULT_LOOKAT01, SEQUENCE_BUTTERFLY_LOOKAT01);
						break;
					}
				}
				else if (szModel == xs("models/weapons/v_knife_widowmaker.mdl"))
				{
					switch (pData->m_Value.m_Int)
					{
					case SEQUENCE_DEFAULT_IDLE2:
						pData->m_Value.m_Int = SEQUENCE_DEFAULT_IDLE1;
						break;
					case SEQUENCE_DEFAULT_LOOKAT01:
						pData->m_Value.m_Int = RandomInt(SEQUENCE_BUTTERFLY_LOOKAT02, SEQUENCE_BUTTERFLY_LOOKAT03);
						break;
					}
				}
				else if (szModel == xs("models/weapons/v_knife_cord.mdl"))
				{
					switch (pData->m_Value.m_Int)
					{
					case SEQUENCE_DEFAULT_DRAW:
						pData->m_Value.m_Int = RandomInt(SEQUENCE_BUTTERFLY_DRAW, SEQUENCE_BUTTERFLY_DRAW2);
						break;
					case SEQUENCE_DEFAULT_LOOKAT01:
						pData->m_Value.m_Int = RandomInt(SEQUENCE_BUTTERFLY_LOOKAT01, SEQUENCE_BUTTERFLY_LOOKAT02);
						break;
					default:
						pData->m_Value.m_Int++;
						break;
					}
				}
				else if (szModel == xs("models/weapons/v_knife_canis.mdl"))
				{
					switch (pData->m_Value.m_Int)
					{
					case SEQUENCE_DEFAULT_DRAW:
						pData->m_Value.m_Int = RandomInt(SEQUENCE_BUTTERFLY_DRAW, SEQUENCE_BUTTERFLY_DRAW2);
						break;
					case SEQUENCE_DEFAULT_LOOKAT01:
						pData->m_Value.m_Int = RandomInt(SEQUENCE_BUTTERFLY_LOOKAT01, SEQUENCE_BUTTERFLY_LOOKAT02);
						break;
					default:
						pData->m_Value.m_Int++;
						break;
					}
				}
				else if (szModel == xs("models/weapons/v_knife_outdoor.mdl"))
				{
					switch (pData->m_Value.m_Int)
					{
					case SEQUENCE_DEFAULT_DRAW:
						pData->m_Value.m_Int = SEQUENCE_BUTTERFLY_DRAW2; //RandomInt(SEQUENCE_BUTTERFLY_DRAW, SEQUENCE_BUTTERFLY_DRAW2);
						break;
					case SEQUENCE_DEFAULT_LOOKAT01:
						pData->m_Value.m_Int = RandomInt(SEQUENCE_BUTTERFLY_LOOKAT01, SEQUENCE_BUTTERFLY_LOOKAT02);
						break;
					default:
						pData->m_Value.m_Int++;
						break;
					}
				}
				else if (szModel == xs("models/weapons/v_knife_skeleton.mdl"))
				{
					switch (pData->m_Value.m_Int)
					{
					case SEQUENCE_DEFAULT_DRAW:
						pData->m_Value.m_Int = RandomInt(SEQUENCE_BUTTERFLY_DRAW, SEQUENCE_BUTTERFLY_DRAW2);
						break;
					case SEQUENCE_DEFAULT_LOOKAT01:
						pData->m_Value.m_Int = RandomInt(SEQUENCE_BUTTERFLY_LOOKAT01, SEQUENCE_BUTTERFLY_LOOKAT02);
						break;
					default:
						pData->m_Value.m_Int++;
						break;
					}
				}

				//G::OldRagdollGravity = pData->m_Value.m_Int;
			}
		}
	}

	oSequenceProxy(pData, pStruct, pOut);
}

void NetvarHook()
{
	for (ClientClass* pClass = I::Client->GetAllClasses(); pClass; pClass = pClass->m_pNext)
	{
		if (!strcmp(pClass->m_pNetworkName, ("CBaseViewModel")))
		{
			RecvTable* pClassTable = pClass->m_pRecvTable;

			for (int i = 0; i < pClassTable->m_nProps; ++i)
			{
				RecvProp* pProp = &pClassTable->m_pProps[i];

				if (pProp && !strcmp(pProp->m_pVarName, ("m_nSequence")))
				{
					oSequenceProxy = static_cast<RecvVarProxyFn>(pProp->m_ProxyFn);
					pProp->m_ProxyFn = reinterpret_cast<RecvVarProxyFn>(Hooked_RecvProxy_SetViewModelSequence);
					break;
				}
			}
		}
		
		if (!strcmp(pClass->m_pRecvTable->m_pNetTableName, ("DT_BaseViewModel")))
		{
			RecvTable* pClassTable = pClass->m_pRecvTable;

			for (int i = 0; i < pClassTable->m_nProps; ++i)
			{
				RecvProp *pProp = &(pClassTable->m_pProps[i]);

				if (pProp && !strcmp(pProp->m_pVarName, ("m_nModelIndex")))
				{
					oRecvnModelIndex = static_cast<RecvVarProxyFn>(pProp->m_ProxyFn);
					pProp->m_ProxyFn = reinterpret_cast<RecvVarProxyFn>(Hooked_RecvProxy_Viewmodel);
					break;
				}
			}
		}

		if (oSequenceProxy != nullptr && oRecvnModelIndex != nullptr)
			break;
	}
}