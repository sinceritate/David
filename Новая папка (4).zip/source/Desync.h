#pragma once

#include "Cheat.h"

extern int max_choke_ticks;
extern float static_side;
extern float balance_side;
extern CBaseAnimState g_AnimState;
extern bool broke_lby;
extern float next_lby;

class cDesync
{

public:

	bool is_enabled();
	bool is_firing();
	void handle();

};


extern cDesync* Desync;