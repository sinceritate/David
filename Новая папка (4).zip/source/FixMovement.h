#pragma once

namespace FixMovement
{
	extern float OldForward;
	extern float OldSideMove;
	extern QAngle OldAngle;

	extern void Start();
	extern void End();
};