#pragma once

//#include "bass/bass.h"
//#pragma comment (lib, "bass/bass.lib")

//extern std::vector < std::string > radioStreams;

inline void Radio() // ��� ����� ��������, �� �� � ����, ������? � �� ����
{
	//static HSTREAM main_stream = BASS_StreamCreateURL(radioStreams[Opts.Misc.Globals.RadioCurrent].c_str(), 0, 0, NULL, 0);
	//
	//while (true)
	//{
	//	static bool radio_close = false;
	//	if (Opts.Misc.Globals.RadioEnabled)
	//	{
	//		if (radio_close)
	//		{
	//			BASS_StreamFree(main_stream);
	//			main_stream = BASS_StreamCreateURL(radioStreams[Opts.Misc.Globals.RadioCurrent].c_str(), 0, 0, NULL, 0);
	//
	//			if (G::radio_stat) BASS_ChannelPlay(main_stream, false);
	//
	//			BASS_ChannelSetAttribute(main_stream, BASS_ATTRIB_VOL, Opts.Misc.Globals.RadioVolume / 100.0f);
	//
	//			radio_close = false;
	//		}
	//
	//		static int old_radio_channel = -1;
	//		if (old_radio_channel != Opts.Misc.Globals.RadioCurrent)
	//		{
	//			BASS_StreamFree(main_stream);
	//			main_stream = BASS_StreamCreateURL(radioStreams[Opts.Misc.Globals.RadioCurrent].c_str(), 0, 0, NULL, 0);
	//
	//			if (G::radio_stat) BASS_ChannelPlay(main_stream, false);
	//
	//			BASS_ChannelSetAttribute(main_stream, BASS_ATTRIB_VOL, Opts.Misc.Globals.RadioVolume / 100.0f);
	//
	//			old_radio_channel = Opts.Misc.Globals.RadioCurrent;
	//		}
	//
	//		static int old_volume = -1;
	//		if (old_volume != Opts.Misc.Globals.RadioVolume)
	//		{
	//			BASS_ChannelSetAttribute(main_stream, BASS_ATTRIB_VOL, Opts.Misc.Globals.RadioVolume / 100.0f);
	//			old_volume = Opts.Misc.Globals.RadioVolume;
	//		}
	//
	//		static bool old_radio_stat = false;
	//		if (old_radio_stat != G::radio_stat)
	//		{
	//			if (G::radio_stat) BASS_ChannelPlay(main_stream, false);
	//			else BASS_ChannelPause(main_stream);
	//
	//			old_radio_stat = G::radio_stat;
	//		}
	//	}
	//	else if (!radio_close)
	//	{
	//		BASS_StreamFree(main_stream);
	//		radio_close = true;
	//	}
	//
	//	std::this_thread::sleep_for(std::chrono::milliseconds(100));
	//}
}