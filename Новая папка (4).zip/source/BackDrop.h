#pragma once

#include "Cheat.h"

/*

x, y, speedx, speedy

*/

class Point
{
public:

	Point(int _x, int _y, int _speed_x, int _speed_y)
	{
		x = _x;
		y = _y;
		speed_x = _speed_x;
		speed_y = _speed_y;
	}

	void DrawPoint()
	{
		I::Surface->DrawSetColor(Color(255, 255, 255, 255));
		I::Surface->DrawFilledRect(x - 1, y - 1, x + 1, y + 1);

		x += speed_x;
		y += speed_y;
	}

	float DistTo(Point p)
	{
		int _x = p.x - x;
		int _y = p.y - y;

		return new_math::FastSQRT(_x*_x + _y*_y);
	}

	int x, y;
	int speed_x, speed_y;
};

extern std::vector <Point> points;

namespace BackDrop
{
	void BackDropAndBackGround();
}