#include "Cheat.h"
#include "Override.h"
#include "Skins.h"

DWORD dwEconItemInterfaceWrapper = 0x2DCC;

typedef float(__thiscall* GetStickerAttributeBySlotIndexFloatFn)(void*, int, StickerAttributeType_t, float);
GetStickerAttributeBySlotIndexFloatFn oGetStickerAttributeBySlotIndexFloat;

float __fastcall Hooked_GetStickerAttributeBySlotIndexFloat(void* thisptr, void* edx, int iSlot, StickerAttributeType_t iAttribute, float flUnknown)
{
	if (iAttribute == StickerAttributeType_t::Wear)
	{
		auto pItem = reinterpret_cast<CBaseCombatWeapon*>(uintptr_t(thisptr) - dwEconItemInterfaceWrapper);
		int iID = pItem->GetAimIndex();
		return min(1.f, Opts.Misc.Changer.Skins.Weapons[Opts.Misc.Changer.Skins.SettingsForTeams ? G::LocalPlayer->GetTeam() == 3 ? 0 : 1 : 2][iID].Sticker[iSlot].wear + 0.0000000001f);
	}
	else if (iAttribute == StickerAttributeType_t::Scale)
	{
		auto pItem = reinterpret_cast<CBaseCombatWeapon*>(uintptr_t(thisptr) - dwEconItemInterfaceWrapper);
		int iID = pItem->GetAimIndex();
		return Opts.Misc.Changer.Skins.Weapons[Opts.Misc.Changer.Skins.SettingsForTeams ? G::LocalPlayer->GetTeam() == 3 ? 0 : 1 : 2][iID].Sticker[iSlot].scale;
	}
	else if (iAttribute == StickerAttributeType_t::Rotation)
	{
		auto pItem = reinterpret_cast<CBaseCombatWeapon*>(uintptr_t(thisptr) - dwEconItemInterfaceWrapper);
		int iID = pItem->GetAimIndex();
		return Opts.Misc.Changer.Skins.Weapons[Opts.Misc.Changer.Skins.SettingsForTeams ? G::LocalPlayer->GetTeam() == 3 ? 0 : 1 : 2][iID].Sticker[iSlot].rotation;
	}

	return oGetStickerAttributeBySlotIndexFloat(thisptr, iSlot, iAttribute, flUnknown);
}

typedef UINT(__thiscall* GetStickerAttributeBySlotIndexIntFn)(void*, int, StickerAttributeType_t, float);
GetStickerAttributeBySlotIndexIntFn oGetStickerAttributeBySlotIndexInt;

UINT __fastcall Hooked_GetStickerAttributeBySlotIndexInt(void* thisptr, void* edx, int iSlot, StickerAttributeType_t iAttribute, UINT iUnknown)
{
	if (iAttribute == StickerAttributeType_t::Index)
	{
		auto pItem = reinterpret_cast<CBaseCombatWeapon*>(uintptr_t(thisptr) - dwEconItemInterfaceWrapper);

		int iID = pItem->GetAimIndex();

		return (Opts.Misc.Changer.Skins.Weapons[Opts.Misc.Changer.Skins.SettingsForTeams ? G::LocalPlayer->GetTeam() == 3 ? 0 : 1 : 2][iID].Sticker[iSlot].id);
	}

	return oGetStickerAttributeBySlotIndexInt(thisptr, iSlot, iAttribute, iUnknown);
}

bool IsCodePtr(void* ptr)
{
	static DWORD protect_flags = PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;

	MEMORY_BASIC_INFORMATION Out;
	VirtualQuery(ptr, &Out, sizeof Out);

	return Out.Type && !(Out.Protect & (PAGE_GUARD | PAGE_NOACCESS)) && Out.Protect & protect_flags;
}

void ApplyStickers(CBaseCombatWeapon* Weapon)
{
	void**& vmt = *reinterpret_cast<void***>(uintptr_t(Weapon) + dwEconItemInterfaceWrapper);

	static void** hooked_vmt = nullptr;
	if (!hooked_vmt)
	{
		size_t size = 0;

		while (IsCodePtr(vmt[size]))
		{
			++size;
		}

		hooked_vmt = new void*[size];
		memcpy(hooked_vmt, vmt, size * sizeof(void*));

		oGetStickerAttributeBySlotIndexFloat = (GetStickerAttributeBySlotIndexFloatFn)hooked_vmt[4];
		hooked_vmt[4] = reinterpret_cast<void*>(&Hooked_GetStickerAttributeBySlotIndexFloat);

		oGetStickerAttributeBySlotIndexInt = (GetStickerAttributeBySlotIndexIntFn)hooked_vmt[5];
		hooked_vmt[5] = reinterpret_cast<void*>(&Hooked_GetStickerAttributeBySlotIndexInt);
	}

	vmt = hooked_vmt;
}

void ThirdPerson()
{
	static bool Key_Click = false;

	if (Opts.Misc.Changer.View.ThirdPersonKey != 0 && GetAsyncKeyState(Opts.Misc.Changer.View.ThirdPersonKey))
	{
		if (!Key_Click)
			Opts.Misc.Changer.View.ThirdPerson = !Opts.Misc.Changer.View.ThirdPerson;

		Key_Click = true;
	}
	else
		Key_Click = false;

	if (!I::Engine->IsInGame() || !G::LocalPlayer || !G::LocalPlayer->GetAlive())
	{
		if (I::Input->m_fCameraInThirdPerson)
		{
			I::Input->m_fCameraInThirdPerson = false;
		}

		return;
	}

	if (Opts.Misc.Changer.View.ThirdPerson)
	{
		if (Opts.Misc.Globals.LegitDesync)
			*reinterpret_cast<QAngle*>(reinterpret_cast<DWORD>(G::LocalPlayer) + 0x31D8) = G::RealAngle;
		else
			*reinterpret_cast<QAngle*>(reinterpret_cast<DWORD>(G::LocalPlayer) + 0x31D8) = G::LastAngle;

		static auto cam_idealdist = I::Cvar->FindVar(rxs("cam_idealdist"));
		static auto cam_idealpitch = I::Cvar->FindVar(rxs("cam_idealpitch"));
		static auto cam_idealyaw = I::Cvar->FindVar(rxs("cam_idealyaw"));

		static int old_dist = 0;

		if (old_dist != Opts.Misc.Changer.View.ThirdPersonDist)
		{
			cam_idealdist->SetValue(Opts.Misc.Changer.View.ThirdPersonDist);
			cam_idealpitch->SetValue(0);
			cam_idealyaw->SetValue(0);

			old_dist = Opts.Misc.Changer.View.ThirdPersonDist;
		}

		if (!I::Input->m_fCameraInThirdPerson)
		{
			I::Input->m_fCameraInThirdPerson = true;
		}
	}
	else if (I::Input->m_fCameraInThirdPerson)
	{
		I::Input->m_fCameraInThirdPerson = false;
	}
}

FrameStageNotifyFn oFrameStageNotify;
void __fastcall Hooks::FrameStageNotify(void* ecx, void* edx, int stage)
{
	static QAngle view_punch_old;
	static QAngle* view_punch = nullptr;

#ifdef FULL_MODE

	if (stage == FRAME_NET_UPDATE_END && I::Engine->IsInGame() && G::LocalPlayer && G::LocalPlayer->GetAlive()) // fixed
	{
		if (Opts.Visuals.Players.Global.Enabled && Opts.Visuals.Players.Global.SoundEsp)
		{
			static CUtlVector<SourceSoundInfo> soundList;
			soundList.RemoveAll();
			I::EngineSound->GetActiveSounds(soundList);

			for (int i = 0; i < soundList.Count(); ++i)
			{
				SourceSoundInfo soundInfo = soundList.Element(i);

				if (soundInfo.m_nChannel == 4)
				{
					int TempEntityIndex = soundInfo.m_nSoundSource;
					CBaseEntity* pEntity = I::ClientEntList->GetClientEntity(TempEntityIndex);

					if (!pEntity || pEntity == G::LocalPlayer || pEntity->GetClientClass()->m_ClassID != CCSPlayer || (!pEntity->IsEnemy() && Opts.Visuals.Players.Global.EnemyOnly))
						continue;
					Vector TempOrigin = *soundInfo.m_pOrigin;

					static Vector PlayerOrigin[64];
					if (PlayerOrigin[TempEntityIndex] != TempOrigin)
					{
						ESP::Misc::SoundESP::Sound.AddEntity(TempOrigin, TempEntityIndex);
						PlayerOrigin[TempEntityIndex] = TempOrigin;
					}
				}
			}
		}
	}
	else if (stage == FRAME_RENDER_START)
	{
		ThirdPerson();

		if (I::Engine->IsInGame() && G::LocalPlayer && G::LocalPlayer->GetAlive())
		{
			if (Opts.Misc.Changer.View.NoVisualRecoil)
			{
				view_punch = (QAngle*)((DWORD)G::LocalPlayer + offsets.m_viewPunchAngle);
				view_punch_old = *view_punch;
				*view_punch = QAngle(0, 0, 0);
			}

			for (int i = 0; i < 64; ++i) // anim fix
			{
				auto entity = I::ClientEntList->GetClientEntity(i);
				if (!entity || entity->GetDormant() || entity->GetHealth() <= 0 || entity == G::LocalPlayer) continue;

				entity->UpdateClientSideAnimation();
				*(int*)((uintptr_t)entity + 0xA28) = 0;
				*(int*)((uintptr_t)entity + 0xA30) = I::Globals->framecount;
			}
		}
	}

#endif

	else if (stage == FRAME_NET_UPDATE_POSTDATAUPDATE_START)
	{
		if (!I::Engine->IsInGame() || !I::Engine->IsConnected() || !G::LocalPlayer)
		{
			goto end_break;
		}

		if (Opts.Misc.Changer.Models.Enable)
		{
			/*for (int i = 0; i < 64; ++i)
			{
				CBaseEntity* entity = I::ClientEntList->GetClientEntity(i);
				
				if (!entity || entity->GetClientClass()->m_ClassID != CCSPlayer) continue;
				
				size_t model_index = 0;

				if (entity == G::LocalPlayer)
				{
					model_index = MT_LOCAL_PLAYER;
				}
				else if (entity->IsEnemy())
				{
					model_index = MT_ENEMY_PLAYER;
				}
				else
				{
					model_index = MT_TEAM_PLAYER;
				}
				
				size_t sct_index = Opts.Misc.Changer.Models.iModelMass[model_index];
				if (sct_index != 0)
				{

				}
			}*/
		}

		if (Opts.Misc.Changer.Skins.EnableSkins || Opts.Misc.Changer.Skins.EnableKnife)
		{
			player_info_t localPlayerInfo;
			if (!I::Engine->GetPlayerInfo(I::Engine->GetLocalPlayer(), &localPlayerInfo)) goto skinchanger_break;

			int* hweapons = G::LocalPlayer->GetWeapons();
			if (!hweapons) goto skinchanger_break;

			for (int i = 0; hweapons[i] != INVALID_EHANDLE_INDEX; ++i)
			{
				CBaseEntity* EntityWeapon = I::ClientEntList->GetClientEntity(hweapons[i] & 0xFFF);
				if (!EntityWeapon) continue;

				CBaseCombatWeapon* Weapon = (CBaseCombatWeapon*)EntityWeapon;

				if (localPlayerInfo.xuidlow != *Weapon->GetXUIDLow() || localPlayerInfo.xuidhigh != *Weapon->GetXUIDHigh()) continue;

				if (Weapon->IsKnife())
				{
#ifdef FULL_MODE
					//if (!Opts.Misc.Changer.Skins.EnableKnife || G::IsInDangerZone || (Opts.Misc.Changer.Models.Enable && Opts.Misc.Changer.Models.iKnifeModel != 0)) continue;

					KnifeChanger(Weapon);
#endif
					if (!Opts.Misc.Changer.Skins.EnableSkins) goto skinchanger_break;
				}
				else if (Opts.Misc.Changer.Skins.EnableSkins)
				{
					int id = Weapon->GetAimIndex();
					if (id == 34) continue;

					//if (Opts.Misc.Changer.Models.Enable)
					//{
					//	if (id == 24 && Opts.Misc.Changer.Models.iAwpModel != 0) continue;
					//}

					int local_team = Opts.Misc.Changer.Skins.SettingsForTeams ? G::LocalPlayer->GetTeam() == 3 ? 0 : 1 : 2;

					*Weapon->GetAccountID() = localPlayerInfo.xuidlow;
					*Weapon->GetFallbackPaintKit() = Opts.Misc.Changer.Skins.Weapons[local_team][id].SkinID;
					*Weapon->GetFallbackWear() = min(1.f, Opts.Misc.Changer.Skins.Weapons[local_team][id].Wear + 0.0000000001f);
					*Weapon->GetFallbackSeed() = Opts.Misc.Changer.Skins.Weapons[local_team][id].Seed;
					*Weapon->GetItemIDHigh() = -1;

					if (Opts.Misc.Changer.Skins.Weapons[local_team][id].StatTrak.Type != 0)
					{
						*Weapon->GetFallbackStatTrak() = Opts.Misc.Changer.Skins.Weapons[local_team][id].StatTrak.Kills;

						((IClientEntity*)Weapon)->PostDataUpdate(DATA_UPDATE_CREATED);
						((IClientEntity*)Weapon)->OnDataChanged(DATA_UPDATE_CREATED);
					}

					if (Opts.Misc.Changer.Skins.Weapons[local_team][id].CustomName.Enabled)
					{
						std::strcpy(Weapon->GetCustomName(), Opts.Misc.Changer.Skins.Weapons[local_team][id].CustomName.Name.c_str());
					}

#ifdef FULL_MODE
					ApplyStickers(Weapon);
#endif

				}
			}
		}

	skinchanger_break:

		if (Opts.Misc.Changer.Skins.EnableGlove) GloveChanger(); // fixed

		if (G::LocalPlayer->GetAlive())
		{
#ifdef FULL_MODE
			//if (!G::IsInDangerZone)
			//{
			//}


			if (Opts.RageBot.AimBot.Enabled && Opts.RageBot.AimBot.Resolver)
			{
				static bool Key_Click = false;
				
				if (Opts.RageBot.AimBot.OverrideKey != 0 && GetAsyncKeyState(Opts.RageBot.AimBot.OverrideKey))
				{
					if (!Key_Click)
						Opts.RageBot.AimBot.Override = !Opts.RageBot.AimBot.Override;
				
					Key_Click = true;
				}
				else
					Key_Click = false;

				for (int i = 0; i < 64; ++i)
				{
					CBaseEntity* entity = I::ClientEntList->GetClientEntity(i);
				
					if (!entity || entity == G::LocalPlayer || entity->GetClientClass()->m_ClassID != CCSPlayer || entity->GetHealth() <= 0 || entity->GetDormant()) continue;
				
					if (Opts.RageBot.AimBot.Override)
						Resolver.override_entity(entity);
				
					Resolver.resolver(entity);
				}
			}
#endif
		}
	}

end_break:

	oFrameStageNotify(ecx, stage);

	if (view_punch && Opts.Misc.Changer.View.NoVisualRecoil)
	{
		*view_punch = view_punch_old;
	}
}