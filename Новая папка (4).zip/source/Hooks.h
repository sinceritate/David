#pragma once

typedef void(__thiscall* PaintTraverseFn)(void*, unsigned int, bool, bool);
extern PaintTraverseFn oPaintTraverse;

typedef void(__thiscall* OverrideViewFn)(void* ecx, CViewSetup* pSetup);
extern OverrideViewFn oOverrideView;

typedef bool(__stdcall* CreateMoveFn)(float, CUserCmd*);
extern CreateMoveFn oCreateMove;

typedef float(__thiscall* ViewModelViewFn)();
extern ViewModelViewFn oViewModelView;

typedef int(__thiscall* DoPostscreenEffectsFn)(IClientModeShared*, int);
extern DoPostscreenEffectsFn oDoPostscreenEffects;

typedef void(__thiscall* FrameStageNotifyFn)(void*, int);
extern FrameStageNotifyFn oFrameStageNotify;

typedef bool(__thiscall* DispatchUserMessageFn)(void*, int, int, int, const void*);
extern DispatchUserMessageFn oDispatchUserMessage;

typedef void(__thiscall* DrawModelExecuteFn)(void*, IMatRenderContext*, const DrawModelState_t&, const ModelRenderInfo_t&, matrix3x4_t*);
extern DrawModelExecuteFn oDrawModelExecute;

typedef void(__stdcall* LockCursorFn)();
extern LockCursorFn oLockCursor;

typedef void(__thiscall* OnScreenSizeChangedFn)(ISurface*, int, int);
extern OnScreenSizeChangedFn oOnScreenSizeChanged;

class IRecipientFilter;
typedef void(__thiscall* EmitSoundFn)(void*, IRecipientFilter&, int, int, const char*, unsigned int, const char*, float, int, float, int, int, const Vector*, const Vector*, void*, bool, float, int, int);
extern EmitSoundFn oEmitSound;

typedef int(__thiscall* ListLeavesInBox)(void*, const Vector&, const Vector&, unsigned short*, int);
extern ListLeavesInBox oListLeavesInBox;

using SceneEndFn = void(__fastcall*)(void*, void*);
extern SceneEndFn oSceneEnd;

typedef MDLHandle_t(__thiscall* FindMdlFn)(void*, char*);
extern FindMdlFn oFindMdl;

typedef EGCResults(__fastcall* SendNetMsgFn)(void* ecx, void* edx, uint32_t unMsgType, const void* pubData, uint32_t cubData);
extern SendNetMsgFn oSendNetMsg;

typedef EGCResults(__fastcall* RetrieveMessageFn)(void* ecx, void* edx, uint32 *punMsgType, void *pubDest, uint32 cubDest, uint32_t *pcubMsgSize);
extern RetrieveMessageFn oRetrieveMessage;

typedef long(__stdcall* ResetFn)(IDirect3DDevice9*, D3DPRESENT_PARAMETERS*);
extern ResetFn oReset;

typedef long(__stdcall* EndSceneFn)(IDirect3DDevice9*);
extern EndSceneFn oEndScene;

typedef bool(__thiscall* SvCheatsFn)(void*);
extern SvCheatsFn oSvCheats;

namespace Hooks
{
	extern void __stdcall  PaintTraverse(unsigned int panel, bool forceRepaint, bool allowForce);
	extern void __fastcall OverrideView(void* ecx, void* edx, CViewSetup* pSetup);
	extern bool __stdcall  CreateMove(float flInputSampleTime, CUserCmd* cmd);
	extern float __stdcall ViewModelView();
	extern int  __stdcall   DoPostscreenEffects(int unk1);
	extern void __fastcall FrameStageNotify(void* ecx, void* edx, int stage);
	extern bool __fastcall DispatchUserMessage(void* ecx, void* edx, int type, unsigned int a3, unsigned int length, const void* msg_data);
	extern void __fastcall DrawModelExecute(void* ecx, void* edx, IMatRenderContext* context, const DrawModelState_t& state, const ModelRenderInfo_t& render_info, matrix3x4_t* matrix);
	extern void __stdcall  LockCursor();
	extern void __stdcall  OnScreenSizeChanged(int oldWidth, int oldHeight);
	extern void __stdcall EmitSound(IRecipientFilter& filter, int iEntIndex, int iChannel, const char* pSoundEntry, unsigned int nSoundEntryHash, const char *pSample, float flVolume, int nSeed, float flAttenuation, int iFlags, int iPitch, const Vector* pOrigin, const Vector* pDirection, void* pUtlVecOrigins, bool bUpdatePositions, float soundtime, int speakerentity, int unk);
	extern int  __fastcall ListLeavesInBox(void* bsp, void* edx, Vector& mins, Vector& maxs, unsigned short* pList, int listMax);
	extern void __fastcall SceneEnd(void* thisptr, void* edx);
	extern MDLHandle_t __fastcall FindMdl(void*, void*, char*);
	extern EGCResults __fastcall  SendNetMsg(void* ecx, void* edx, uint32_t unMsgType, const void* pubData, uint32_t cubData);
	extern EGCResults __fastcall RetrieveMessage(void* ecx, void* edx, uint32_t *punMsgType, void *pubDest, uint32_t cubDest, uint32_t *pcubMsgSize);
	extern long __stdcall  Reset(IDirect3DDevice9* pDevice, D3DPRESENT_PARAMETERS* pPresentationParameters);
	extern long __stdcall  EndScene(IDirect3DDevice9* pDevice);
	extern bool __fastcall SvCheats(void* pConVar, void* edx);

	extern WNDPROC oldWindowProc;
	extern LRESULT __stdcall WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
}