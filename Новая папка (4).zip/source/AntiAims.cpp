#include "Cheat.h"

#define MIN_PITH   -89
#define MAX_PITH    89
#define CLAMP_PITH -89, 89
#define MIN_YAW    -108
#define MAX_YAW     180
#define CLAMP_YAW  -180, 180

float NormalizeY(float y)
{
	while (y < -180.0f) y += 360.0f;
	while (y > 180.0f) y -= 360.0f;

	return y;
}

float Rage::AntiAims::GetMaxDelta(CBaseEntity* entity) {
	auto anim_state = entity->GetAnimState();
	//assert(anim_state);

	auto animstate = uintptr_t(anim_state);

	float duckammount = *(float *)(animstate + 0xA4);
	float speedfraction = max(0.f, min(*reinterpret_cast<float*>(animstate + 0xF8), 1.f));

	float speedfactor = max(0.f, min(1.f, *reinterpret_cast<float*>(animstate + 0xFC)));

	float unk1 = ((*reinterpret_cast<float*> (animstate + 0x11C) * -0.30000001) - 0.19999999) * speedfraction;
	float unk2 = unk1 + 1.f;
	float unk3;

	if (duckammount > 0) {
		unk2 += ((duckammount * speedfactor) * (0.5f - unk2));
	}

	unk3 = *(float *)(animstate + 0x334) * unk2;

	return unk3;
}

void Rage::AntiAims::LegitDesync()
{

	static float static_flip = 1.00f;

	float old_yaw = G::UserCmd->viewangles.y;

	//if (!G::SendPacket && (G::UserCmd->command_number % 2) == 1)
	//{
		//if (G::SendPacket)
		//{
		//float minimal_move = 2.0f;
		//if (G::LocalPlayer->GetFlags() & FL_DUCKING)
		//	minimal_move *= 3.f;
		//
		//if (G::UserCmd->buttons & IN_WALK)
		//	minimal_move *= 3.f;
		//
		//bool should_move = G::LocalPlayer->GetVelocity().Length2D() <= 0.0f || std::fabsf(G::LocalPlayer->GetVelocity().z) <= 100.0f;
		//
		//if ((G::UserCmd->command_number % 2) == 1) {
		//	G::UserCmd->viewangles.y += 120.0f;// *side; // for desync flip
		//	if (should_move)
		//		G::UserCmd->sidemove -= minimal_move;
		//	//G::SendPacket = false;
		//}
		//else if (should_move) {
		//	G::UserCmd->sidemove += minimal_move;
		//}

		//if (G::LocalPlayer->GetAnimState()->speed_2d <= 0.1)
		//{
		//	G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y + GetMaxDelta(G::LocalPlayer) + 30.f) * static_flip;
		//}
		//else
		//{
		//	G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y + GetMaxDelta(G::LocalPlayer)) * static_flip;
		//}
	//}
		//G::SendPacket = !G::SendPacket;
		//
		//// static
		//if (G::SendPacket)
		//{
		//	float minimal_move = 2.0f;
		//	if (G::LocalPlayer->GetFlags() & FL_DUCKING)
		//		minimal_move *= 3.f;
		//
		//	if (G::UserCmd->buttons & IN_WALK)
		//		minimal_move *= 3.f;
		//
		//	bool should_move = G::LocalPlayer->GetVelocity().Length2D() <= 0.0f
		//		|| std::fabsf(G::LocalPlayer->GetVelocity().z) <= 100.0f;
		//
		//	if ((G::UserCmd->command_number % 2) == 1) {
		//		G::UserCmd->viewangles.y += 120.0f;// *side; // for desync flip
		//		if (should_move)
		//			G::UserCmd->sidemove -= minimal_move;
		//		//G::SendPacket = false;
		//	}
		//	else if (should_move) {
		//		G::UserCmd->sidemove += minimal_move;
		//	}
		//}
		//
		//G::UserCmd->viewangles = G::UserCmd->viewangles.Normalized();
		//G::UserCmd->viewangles.y = std::remainderf(G::UserCmd->viewangles.y, 360.0f);

		//auto net_channel = I::Engine->GetNetChannel();
		//if (net_channel->m_nChokedPackets >= 11)
		//{
		//}

		//auto animstate = G::LocalPlayer->GetAnimState();
		//G::RealAngle = animstate->m_flGoalFeetYaw;
			
		// balanse
		//if (next_lby >= g_GlobalVars->curtime) {
		//	if (!broke_lby && *send_packet && g_ClientState->chokedcommands > 0)
		//		return;
		//
		//	broke_lby = false;
		//	*send_packet = false;
		//	cmd->viewangles.yaw += 120.0f * side;
		//}
		//else {
		//	broke_lby = true;
		//	*send_packet = false;
		//	cmd->viewangles.yaw += 120.0f * -side;
		//}

		//float maxDelta = GetMaxDelta(G::LocalPlayer);
		//
		//if (maxDelta > Opts.Misc.Globals.LegitDesyncMaxDelta)
		//	maxDelta = Opts.Misc.Globals.LegitDesyncMaxDelta;
		//
		//static bool Flip = false;
		//
		//if (G::SendPacket)
		//{
		//	if (!Flip)
		//	{
		//		G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y + maxDelta);
		//	}
		//	else
		//	{
		//		G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y - maxDelta);
		//	}
		//	//auto anim = G::LocalPlayer->GetAnimState();
		//	//anim->m_flGoalFeetYaw += maxDelta;
		//
		//	//G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y + maxDelta);
		//
		//	//G::FakeAngle.y = anim->m_flGoalFeetYaw;
		//	G::FakeAngle = G::UserCmd->viewangles;
		//
		//	G::SendPacket = !G::SendPacket;
		//	Flip = !Flip;
		//}
		//else
		//{
		//	G::RealAngle = G::UserCmd->viewangles;
		//	G::SendPacket = !G::SendPacket;
		//}
	// }

	float minimal_move = 2.0f;
	if (G::LocalPlayer->GetFlags() & FL_DUCKING)
	minimal_move *= 3.f;

	if (G::UserCmd->buttons & IN_WALK)
	minimal_move *= 3.f;

	bool should_move = G::LocalPlayer->GetVelocity().Length2D() <= 0.0f
	|| std::fabsf(G::LocalPlayer->GetVelocity().z) <= 100.0f;

	if ((G::UserCmd->command_number % 2) == 1) {
		G::UserCmd->viewangles.y += 120.0f * 1;// side;
		if (should_move)
			G::UserCmd->sidemove -= minimal_move;
		G::SendPacket = false;
	}
	else if (should_move) {
		G::UserCmd->sidemove += minimal_move;
	}

	auto net_channel = I::Engine->GetNetChannel();
	if (net_channel->m_nChokedPackets >= 3)
	{
		QAngle angles;
		I::Engine->GetViewAngles(angles);
		G::UserCmd->viewangles = angles;

		G::SendPacket = true;
	}

	//G::SendPacket = !G::SendPacket;
	//
	//if (!G::SendPacket)
	//{
	//	G::UserCmd->viewangles.y += 180.f;
	//}
	//else
	//{
	//	G::UserCmd->viewangles.y += 180.f + GetMaxDelta(G::LocalPlayer); // - g_plocal->getmaxdesyncdelta(); works too
	//}
	//
	// // while testing on hvh i noticed than you are slowwalking desync works perefectly, so lets do a little movement while standing
	//if (G::LocalPlayer->GetFlags() & FL_ONGROUND && G::UserCmd->sidemove < 3 && G::UserCmd->sidemove > -3)
	//{
	//	static bool switch_ = false;
	//
	//	if (switch_)
	//		G::UserCmd->sidemove = 2;
	//	else
	//		G::UserCmd->sidemove = -2;
	//
	//	switch_ = !switch_;
	//}

	//auto net_channel = I::Engine->GetNetChannel();
	//if (net_channel->m_nChokedPackets >= 11)
	//{
	//	G::UserCmd->viewangles.y = old_yaw;
	//	G::SendPacket = true;
	//}
	//else
	//{
	//	G::SendPacket = false;
	//}
}

int DoRealYaw()
{
	BYTE mode = 0;

	if (!(G::LocalPlayer->GetFlags() & FL_ONGROUND)) mode = 1;
	else if (G::LocalPlayer->GetVelocity().Length() > 0.1f) mode = 2;
	else mode = 0;

	switch (Opts.RageBot.AntiAims.Real[mode * 2 + 1])
	{
	case AA_YAW_None: break;
	case AA_YAW_Zero: G::UserCmd->viewangles.y = 0.f; G::RealAngle.y = 0.f; break;
	case AA_YAW_Static: G::UserCmd->viewangles.y = 180.f; G::RealAngle.y = 180.f; break;
	case AA_YAW_BackWard: G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y + 180.f); G::RealAngle.y = NormalizeY(G::UserCmd->viewangles.y + 180.f); break;
	case AA_YAW_Left: G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y + 90.f); G::RealAngle.y = NormalizeY(G::UserCmd->viewangles.y + 90.f); break;
	case AA_YAW_Right: G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y - 90.f); G::RealAngle.y = NormalizeY(G::UserCmd->viewangles.y - 90.f); break;
	case AA_YAW_Jitter:
	{
		static bool Flip = false;
		Flip = !Flip;

		if (Flip)
		{
			G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y + 90.f);
			G::RealAngle.y = NormalizeY(G::UserCmd->viewangles.y + 90.f);
		}
		else
		{
			G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y - 90.f);
			G::RealAngle.y = NormalizeY(G::UserCmd->viewangles.y - 90.f);
		}

		break;
	}
	case AA_YAW_Random: G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y + RandomInt(-180, 180)); G::RealAngle.y = NormalizeY(G::UserCmd->viewangles.y + RandomInt(-180, 180)); break;
	case AA_YAW_LBY:
	{
		static bool Flip = false;
		Flip = !Flip;

		if (Flip)
		{
			G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y + (G::LocalPlayer->GetLBY() / 2 + 70.f));
			G::RealAngle.y = NormalizeY(G::UserCmd->viewangles.y + (G::LocalPlayer->GetLBY() / 2 + 70.f));
		}
		else
		{
			G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y - (G::LocalPlayer->GetLBY() / 2 + 140.f));
			G::RealAngle.y = NormalizeY(G::UserCmd->viewangles.y - (G::LocalPlayer->GetLBY() / 2 + 140.f));
		}

		break;
	}

	case AA_YAW_LBYSmart:
	{
		static bool Flip = false;

		static float LBY = G::LocalPlayer->GetLBY();
		if (LBY != G::LocalPlayer->GetLBY())
		{
			Flip = !Flip;

			LBY = G::LocalPlayer->GetLBY();
		}

		if (Flip)
		{
			G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y + (G::LocalPlayer->GetLBY() / 2 + 70.f));
			G::RealAngle.y = NormalizeY(G::UserCmd->viewangles.y + (G::LocalPlayer->GetLBY() / 2 + 70.f));
		}
		else
		{
			G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y - (G::LocalPlayer->GetLBY() / 2 + 140.f));
			G::RealAngle.y = NormalizeY(G::UserCmd->viewangles.y - (G::LocalPlayer->GetLBY() / 2 + 140.f));
		}

		break;
	}

	case AA_YAW_SlowSpin: G::UserCmd->viewangles.y = NormalizeY(G::RealAngle.y + 10); break;
	case AA_YAW_FastSpin: G::UserCmd->viewangles.y = NormalizeY(G::RealAngle.y + 30); break;
	
	case AA_YAW_ManualKeys:
	{
		static int pos = 0;
		if (G::PressedKeys[Opts.RageBot.AntiAims.ManualKey[mode * 3]])
			pos = -1;
		else if (G::PressedKeys[Opts.RageBot.AntiAims.ManualKey[mode * 3 + 1]])
			pos = 0;
		else if (G::PressedKeys[Opts.RageBot.AntiAims.ManualKey[mode * 3 + 2]])
			pos = 1;

		switch (pos)
		{
		case -1: G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y + 90.f); G::RealAngle.y = NormalizeY(G::UserCmd->viewangles.y + 90.f); break;
		case 0: G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y + 180.f); G::RealAngle.y = NormalizeY(G::UserCmd->viewangles.y + 180.f); break;
		case 1: G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y - 90.f); G::RealAngle.y = NormalizeY(G::UserCmd->viewangles.y - 90.f); break;
		}

		break;
	}
	case AA_YAW_Auto_Direction:
	{
		static std::vector <float> yaws;
		yaws.clear();

		for (int i = 0; i < 64; ++i)
		{
			CBaseEntity* entity = I::ClientEntList->GetClientEntity(i);

			if (!entity || entity->GetDormant() || entity->GetHealth() <= 0 || !entity->IsEnemy() || entity == G::LocalPlayer) continue;


			QAngle Local_angles = M::CalcAngle(G::LocalPlayer->GetEyePosition(), entity->GetBonePosition(BONE_CHEST));
			yaws.push_back(Local_angles.y + 360.f);

			//G::UserCmd->viewangles.y = NormalizeY(Local_angles.y);
		}

		if (yaws.size() > 0)
		{
			float sum = 0;
			for (int i = 0; i < yaws.size(); ++i)
			{
				sum += yaws[i];
			}

			G::UserCmd->viewangles.y = NormalizeY(yaws[0] - (sum / yaws.size() - 360.f));
		}
		else
		{
			G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y -180.f);
		}

		break;
	}
	}

	G::RealAngle = G::UserCmd->viewangles;

	return 720;
}

int m_iRotate = 0;
int m_iRotateIteration = 0;

float m_flCurrentFeetYaw = 0.0f;
float m_flPreviousFeetYaw = 0.0f;

bool m_bAutomaticDir = false;
int m_iAutoDirection = 0;

void SinCos(float& Sin, float& Cos, float angle)
{
	Sin = sin(angle * 3.14159265 / 180);
	Cos = cos(angle * 3.14159265 / 180);
}

bool DesyncRotate(float rotation, int direction) {
	//CGOPlayerAnimState* animState = g_LocalPlayer->m_PlayerAnimState();
	auto animState = G::LocalPlayer->GetAnimState();
	float feetYaw = DEG2RAD(animState->m_flGoalFeetYaw);
	static float m_flGoalFeetYaw = DEG2RAD(animState->m_flGoalFeetYaw);

	float feetSin, feetCos;

	SinCos(feetSin, feetCos, feetYaw);

	float feetSin1, feetCos1;
	SinCos(feetSin1, feetCos1, m_flGoalFeetYaw);

	float feetSin2, feetCos2;
	SinCos(feetSin2, feetCos2, m_flPreviousFeetYaw);

	m_flPreviousFeetYaw = m_flGoalFeetYaw;
	m_flGoalFeetYaw = animState->m_flGoalFeetYaw;

	float totalRotation = atan2(feetSin1 + feetSin + feetSin2, feetCos1 + feetCos + feetCos2);
	totalRotation = M::NormalizeYaw(RAD2DEG(totalRotation) - rotation);
	if (direction == 1) {
		if (totalRotation >= 0.0f) {
			m_iRotateIteration = 1;
			return false;
		}
	}
	else if (totalRotation <= 0.0f) {
		m_iRotateIteration = 1;
		return false;
	}

	float rotate = static_cast<float>(30 * (m_iRotateIteration % 12));
	if (direction == 1)
		G::UserCmd->viewangles.y -= rotate;
	else
		G::UserCmd->viewangles.y += rotate;

	G::UserCmd->viewangles.y = NormalizeY(G::UserCmd->viewangles.y);
	//G::SendPacket = true;
	++m_iRotateIteration;
	return true;
}

int Rage::AntiAims::DoYaw(int type)
{
	BYTE mode = 0;

	if (!(G::LocalPlayer->GetFlags() & FL_ONGROUND)) mode = 1;
	else if (G::LocalPlayer->GetVelocity().Length() > 0.1f) mode = 2;
	else mode = 0;

	float Real;

	switch (type)
	{
		case 0:
		{
			return 0;
		}
		case 1:
		{
			G::UserCmd->viewangles.y = NormalizeY(G::RealAngle.y + GetMaxDelta(G::LocalPlayer) - 1);

			break;
		}
		case 2:
		{
			G::UserCmd->viewangles.y = NormalizeY(G::RealAngle.y - GetMaxDelta(G::LocalPlayer) + 1);

			break;
		}
		case 3:
		{
			static bool jitter = false; jitter = !jitter;

			if (jitter)
			{
				G::UserCmd->viewangles.y = NormalizeY(G::RealAngle.y + GetMaxDelta(G::LocalPlayer) - 1);
			}
			else
			{
				G::UserCmd->viewangles.y = NormalizeY(G::RealAngle.y - GetMaxDelta(G::LocalPlayer) + 1);
			}
			
			break;
		}
	}

	return 0;
}

bool anim_lby_update()
{
	//G::LocalPlayer->va_angles() = G::UserCmd->viewangles;
	//G::LocalPlayer->UpdateClientSideAnimation();

	CBaseAnimState* animstate = G::LocalPlayer->GetAnimState();

	float servertime = G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick;
	static float flNextLBYUpdate = servertime;

	//if (animstate->m_flUnknownVelocityLean > 0.1f || abs(animstate->flUpVelocity) > 100.0f) {
	//	flNextLBYUpdate = servertime + 0.22;
	//	return true;
	//}
	//else if (servertime > flNextLBYUpdate && std::abs(M::NormalizeYaw(G::UserCmd->viewangles.y - animstate->m_flGoalFeetYaw)) > 35.0f) {
	//	flNextLBYUpdate = servertime + 1.1;
	//	return true;
	//}

	return false;
}

void Rage::AntiAims::RageAA()
{
	if (!(G::UserCmd->buttons & IN_USE) && G::LocalPlayer->GetMoveType() != MOVETYPE_LADDER && G::LocalPlayer->GetMoveType() != MOVETYPE_NOCLIP && G::LocalPlayer && G::LocalPlayer->GetAlive())
	{
		BYTE mode = 0;

		if (!(G::LocalPlayer->GetFlags() & FL_ONGROUND)) mode = 1;
		else if (G::LocalPlayer->GetVelocity().Length() > 0.1f) mode = 2;
		else mode = 0;

		static bool swith = false;
		swith = !swith;
		G::SendPacket = swith;

		if (!G::SendPacket && G::LocalPlayer && G::LocalPlayer->GetAlive())
		{
			DoYaw(Opts.RageBot.AntiAims.DesyncType[mode]);
		}
		
		if (Opts.RageBot.AntiAims.CustomAngles)
		{
			if (G::SendPacket || Opts.RageBot.AntiAims.DesyncType[mode] == 0)
			{
				G::UserCmd->viewangles.x = Opts.RageBot.AntiAims.Custom[mode * 2];
				G::UserCmd->viewangles.y = Opts.RageBot.AntiAims.Custom[mode * 2 + 1];
			}
		}
		else
		{
			if (G::SendPacket || Opts.RageBot.AntiAims.DesyncType[mode] == 0)
			{
				DoRealYaw();
			}
			
			switch (Opts.RageBot.AntiAims.Real[mode * 2])
			{
			case AA_PITCH_None: break;
			case AA_PITCH_Zero: G::UserCmd->viewangles.x = 0.f; break;
			case AA_PITCH_EMOTION: G::UserCmd->viewangles.x = 89.00f; break;
			case AA_PITCH_RANDOM: G::UserCmd->viewangles.x = RandomInt(-89, 89); break;
			case AA_PITCH_UP: G::UserCmd->viewangles.x = -89.00f; break;
			}
		}
	}
	else
	{
		G::SendPacket = true;
	}
}