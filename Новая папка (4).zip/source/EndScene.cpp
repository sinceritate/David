﻿#include "Cheat.h"
#include "Chars.h"
#include "NewChams.h"
#include "Fonts.h"
#include "Skins.h"
#include <thread>
#include "Parser.h"

#include "Radio.h"
std::vector < std::string > radioStreams;

#include "Radar.h"
#include "SpectatorList.h"
#include "PreviewESP.h"

int current_last_esp_preview_id = 0;
int current_active_esp_preview_id = 0;

#include "Menus.h"

bool panic_key_time = true;

std::vector <paint_kits> skinPaints;
std::vector <paint_kits> stickerPaints;
std::vector <paint_kits> KnifesPaints;

bool Eng = true;

ImFont* font_std = nullptr;
ImFont* font_big = nullptr;
ImFont* font_cherry = nullptr;
ImFont* font_undefeated = nullptr;

EndSceneFn oEndScene;
long __stdcall Hooks::EndScene(IDirect3DDevice9* pDevice)
{
	if (!G::d3dinit)
		D3Dinit(pDevice);
	
	if (G::PressedKeys[Opts.Menu.PanicKey] && panic_key_time)
		UnloadCheat();

	if (Opts.Visuals.Players.Global.ScreenShotBypass && I::Engine->IsTakingScreenshot())
		return oEndScene(pDevice);

	ImGui::GetIO().MouseDrawCursor = Opts.Menu.Opened;

	ImGui_ImplDX9_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();

	if (Opts.Menu.Opened)
	{
		int pX, pY;
		I::InputSystem->GetCursorPosition(&pX, &pY);
	
		ImGuiIO& io = ImGui::GetIO();
		io.MousePos.x = (float)(pX);
		io.MousePos.y = (float)(pY);
		
		switch (Opts.Menu.Style)
		{
		case 0:
			MenuV1();
			break;
		case 1:
			MenuV2();
			break;
		case 2:
			MenuV3();
			break;
		default:
			MenuV1();
			break;
		}
	}

	if (Opts.Visuals.Radar.Type == 2)
	{
		DrawRadar();
	}

	if (Opts.Visuals.Other.SpectatorList)
	{
		DrawSpectatorList();
	}

	ImGui::EndFrame();
	ImGui::Render();
	
	return oEndScene(pDevice);
}

ResetFn oReset;
long __stdcall Hooks::Reset(IDirect3DDevice9* pDevice, D3DPRESENT_PARAMETERS* pPresentationParameters)
{
	if (!G::d3dinit) return oReset(pDevice, pPresentationParameters);

	ImGui_ImplDX9_InvalidateDeviceObjects();

	auto hr = oReset(pDevice, pPresentationParameters);
	ImGui_ImplDX9_CreateDeviceObjects();

	return hr;
}

LockCursorFn oLockCursor;
void __stdcall Hooks::LockCursor()
{
	if (Opts.Menu.Opened)
	{
		I::Surface->UnlockCursor();
		I::InputSystem->EnableInput(false);
		return;
	}
	else
	{
		I::InputSystem->EnableInput(true);
	}

	oLockCursor();
}