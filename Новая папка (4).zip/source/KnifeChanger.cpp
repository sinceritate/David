#include "Cheat.h"
#include <unordered_map>

HANDLE hWorldModel;
CBaseCombatWeapon* WorldModel;

void KnifeChanger(CBaseCombatWeapon* pWeapon)
{
	player_info_t localPlayerInfo;
	if (!I::Engine->GetPlayerInfo(I::Engine->GetLocalPlayer(), &localPlayerInfo)) return;

	static int ModelNameIndex = -1;
	static int ModelIndex = -1;

	static int model = -1;
	static int old_model = -1;
	static int skin = -1;

	static int wear = -1;
	static int seed = -1;

	static int stattrak_type = -1;
	static int stattrak_kills = -1;

	static bool name_enabled = -1;
	static std::string name_name = "";

	if (Opts.Misc.Changer.Skins.SettingsForTeams)
	{
		if (G::LocalPlayer->GetTeam() == 3) // if ct
		{
			model = Opts.Misc.Changer.Skins.Knifes[0].ModelIndex;
			skin = Opts.Misc.Changer.Skins.Knifes[0].SkinIndex;
			wear = Opts.Misc.Changer.Skins.Knifes[0].Wear;
			seed = Opts.Misc.Changer.Skins.Knifes[0].Seed;

			stattrak_type = Opts.Misc.Changer.Skins.Knifes[0].StatTrak.Type;
			stattrak_kills = Opts.Misc.Changer.Skins.Knifes[0].StatTrak.Kills;

			name_enabled = Opts.Misc.Changer.Skins.Knifes[0].CustomName.Enabled;
			name_name = Opts.Misc.Changer.Skins.Knifes[0].CustomName.Name;
		}
		else
		{
			model = Opts.Misc.Changer.Skins.Knifes[1].ModelIndex;
			skin = Opts.Misc.Changer.Skins.Knifes[1].SkinIndex;
			wear = Opts.Misc.Changer.Skins.Knifes[1].Wear;
			seed = Opts.Misc.Changer.Skins.Knifes[1].Seed;

			stattrak_type = Opts.Misc.Changer.Skins.Knifes[1].StatTrak.Type;
			stattrak_kills = Opts.Misc.Changer.Skins.Knifes[1].StatTrak.Kills;

			name_enabled = Opts.Misc.Changer.Skins.Knifes[1].CustomName.Enabled;
			name_name = Opts.Misc.Changer.Skins.Knifes[1].CustomName.Name;
		}
	}
	else
	{
		model = Opts.Misc.Changer.Skins.Knifes[2].ModelIndex;
		skin = Opts.Misc.Changer.Skins.Knifes[2].SkinIndex;
		wear = Opts.Misc.Changer.Skins.Knifes[2].Wear;
		seed = Opts.Misc.Changer.Skins.Knifes[2].Seed;

		stattrak_type = Opts.Misc.Changer.Skins.Knifes[2].StatTrak.Type;
		stattrak_kills = Opts.Misc.Changer.Skins.Knifes[2].StatTrak.Kills;

		name_enabled = Opts.Misc.Changer.Skins.Knifes[2].CustomName.Enabled;
		name_name = Opts.Misc.Changer.Skins.Knifes[2].CustomName.Name;
	}

	switch (model)
	{
	case 0: { return; }

	case 1: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_T.c_str()); ModelIndex = WEAPON_KNIFE_T; break; }
	case 2: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL.c_str()); ModelIndex = WEAPON_KNIFE; break; }
	case 3: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_GG.c_str()); ModelIndex = WEAPON_KNIFE_GG; break; }
	case 4: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_BAYONET.c_str()); ModelIndex = WEAPON_KNIFE_BAYONET; break; }
	case 5: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_FLIP.c_str()); ModelIndex = WEAPON_KNIFE_FLIP; break; }
	case 6: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_GUT.c_str()); ModelIndex = WEAPON_KNIFE_GUT; break; }
	case 7: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_KARAMBIT.c_str()); ModelIndex = WEAPON_KNIFE_KARAMBIT; break; }
	case 8: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_M9_BAYONET.c_str()); ModelIndex = WEAPON_KNIFE_M9_BAYONET; break; }
	case 9: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_TACTICAL.c_str()); ModelIndex = WEAPON_KNIFE_TACTICAL; break; }
	case 10: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_FALCHION.c_str()); ModelIndex = WEAPON_KNIFE_FALCHION; break; }
	case 11: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_SURVIVAL_BOWIE.c_str()); ModelIndex = WEAPON_KNIFE_SURVIVAL_BOWIE; break; }
	case 12: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_BUTTERFLY.c_str()); ModelIndex = WEAPON_KNIFE_BUTTERFLY; break; }
	case 13: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_PUSH.c_str()); ModelIndex = WEAPON_KNIFE_PUSH; break; }
	case 14: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_URSUS.c_str()); ModelIndex = WEAPON_KNIFE_URSUS; break; }
	case 15: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_GYPSY_JACKKNIFE.c_str()); ModelIndex = WEAPON_KNIFE_GYPSY_JACKKNIFE; break; }
	case 16: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_STILETTO.c_str()); ModelIndex = WEAPON_KNIFE_STILETTO; break; }
	case 17: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_WIDOWMAKER.c_str()); ModelIndex = WEAPON_KNIFE_WIDOWMAKER; break; }
	case 18: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_CSS.c_str()); ModelIndex = WEAPON_KNIFE_CSS; break; }
	case 19: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_CORD.c_str()); ModelIndex = WEAPON_KNIFE_CORD; break; }
	case 20: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_CANIS.c_str()); ModelIndex = WEAPON_KNIFE_CANIS; break; }
	case 21: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_OUTDOOR.c_str()); ModelIndex = WEAPON_KNIFE_OUTDOOR; break; }
	case 22: { ModelNameIndex = I::ModelInfo->GetModelIndex(WEAPON_KNIFE_VMODEL_SKELETON.c_str()); ModelIndex = WEAPON_KNIFE_SKELETON; break; }

	default: { return; }
	}

	*pWeapon->GetItemIDHigh() = -1;
	*pWeapon->GetAccountID() = localPlayerInfo.xuidlow;
	
	*pWeapon->GetFallbackPaintKit() = skin;
	*pWeapon->GetFallbackSeed() = seed;
	
	*pWeapon->GetEntityQuality() = 3;
	*pWeapon->GetFallbackWear() = min(1.f, wear + 0.0000000001f);
	
	*pWeapon->GetItemDefinitionIndex() = ModelIndex;
	
	//hWorldModel = pWeapon->m_hWeaponWorldModel();
	//if (hWorldModel) WorldModel = (CBaseCombatWeapon*)I::ClientEntList->GetClientEntityFromHandleknife(hWorldModel);
	
	*pWeapon->ModelIndex() = ModelNameIndex;
	//if (WorldModel) *pWeapon->ModelIndex() = ModelNameIndex + 1;
	
	((CBaseEntity*)pWeapon)->SetModelIndexVirtual(ModelNameIndex);
	((IClientEntity*)pWeapon)->PreDataUpdate(DATA_UPDATE_CREATED);
	
	if (name_enabled) std::strcpy(pWeapon->GetCustomName(), name_name.c_str());
	
	if (stattrak_type != 0)
	{
		*pWeapon->GetFallbackStatTrak() = stattrak_kills;
	
		((IClientEntity*)pWeapon)->PostDataUpdate(DATA_UPDATE_CREATED);
		((IClientEntity*)pWeapon)->OnDataChanged(DATA_UPDATE_CREATED);
	}
}