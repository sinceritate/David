#pragma once

#include <string>

class CBase64
{
public:
	std::string base64_encode(unsigned char const*, unsigned int len);
	std::string base64_decode(std::string const& s);

	std::string MultiBase64Encode(std::string szValue, int count)
	{
		for (size_t i = 0; i < count; i++)
		{
			std::string szOldValue = szValue;
			szValue = base64_encode(reinterpret_cast<const unsigned char*>(szOldValue.c_str()), szOldValue.length());
		}

		return szValue;
	}

	std::string MultiBase64Decode(std::string szValue, int count)
	{
		for (size_t i = 0; i < count; i++)
		{
			std::string szOldValue = szValue;
			szValue = base64_decode(szOldValue.c_str());
		}

		return szValue;
	}
};

extern CBase64* base64;

inline std::string Base64enc(std::string source)
{
	return base64->base64_encode(reinterpret_cast<const unsigned char*>(source.c_str()), source.size());
}

inline std::string Base64dec(std::string source)
{
	return base64->base64_decode(source);
}