#pragma once

#define square( x ) ( x * x )

namespace M
{
	extern inline void SinCos(float radians, float* sine, float* cosine);
	extern Vector ExtrapolateTick(Vector p0, Vector v0);
	extern float DotProduct(const Vector & a, const Vector & b);
	extern void AngleVectors(const Vector &angles, Vector *forward);
	extern void AngleVectors(const QAngle & angles, Vector * forward);
	extern void VectorAngles(const Vector & forward, QAngle & angles);
	extern QAngle CalcAngle(Vector src, Vector dst);
	extern float GetFov(const QAngle & viewAngle, const QAngle & aimAngle);
	extern void angleVectors(const QAngle& angles, Vector& forward);
	extern void VectorTransform(Vector& in1, matrix3x4_t& in2, Vector& out);
	extern void VectorSubtract(const Vector& a, const Vector& b, Vector& c);
	extern void NormalizeNum(Vector &vIn, Vector &vOut);
	extern float NormalizeYaw(float yaw);
	extern float YawDistance(float firstangle, float secondangle);
	extern QAngle NormalizeAngle(QAngle angle);
	extern QAngle ClampAngle(QAngle angle);
	extern Vector QAngleToVector(QAngle angle);
	extern QAngle VectorToQAngle(Vector angle);
	extern float VectorDistance(Vector v1, Vector v2);

	inline float FASTSQRT(float x)
	{
		unsigned int i = *(unsigned int*)&x;

		i += 127 << 23;
		i >>= 1;
		return *(float*)&i;
	}
}
