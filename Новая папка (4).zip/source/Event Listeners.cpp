#include "Cheat.h" 
#include "Event Listeners.h"

#include <sstream>
#include <fstream>

#pragma comment(lib, "Winmm.lib")

GetListener* Listener::Damage::WeaponFiredListener = new GetListener(Listener::Damage::WeaponFired);
GetListener* Listener::Damage::PlayerHurtListener = new GetListener(Listener::Damage::PlayerHurt);
GetListener* Listener::Damage::PlayerDeathListener = new GetListener(Listener::Damage::PlayerDeath);

GetListener* Listener::Item::PurchaseListener = new GetListener(Listener::Item::Purchase);
GetListener* Listener::Bullet::ImpactListener = new GetListener(Listener::Bullet::Impact);

GetListener* Listener::Bomb::DefusedListener = new GetListener(Listener::Bomb::Defused);
GetListener* Listener::Bomb::BeginDefuseListener = new GetListener(Listener::Bomb::BeginDefuse);
GetListener* Listener::Bomb::AbortDefuseListener = new GetListener(Listener::Bomb::AbortDefuse);
GetListener* Listener::Bomb::PlantedListener = new GetListener(Listener::Bomb::Planted);
GetListener* Listener::Bomb::ExplodedListener = new GetListener(Listener::Bomb::Exploded);

GetListener* Listener::Round::StartListener = new GetListener(Listener::Round::Start);

int BoneByEvent(int hitgroup)
{
	switch (hitgroup)
	{
	case 1: return BONE_HEAD; break;
	case 2: return BONE_UPPER_CHEST; break;
	case 3: return BONE_LOWER_CHEST; break;
	case 4: return BONE_LEFT_CUBIT; break;
	case 5: return BONE_RIGHT_CUBIT; break;
	case 6: return BONE_LEFT_KNEE; break;
	case 7: return BONE_RIGHT_KNEE; break;
	}

	return -1;
}

void Listener::Damage::WeaponFired(IGameEvent* pEvent)
{
	if (!pEvent)
		return;

	if (!(I::Engine->IsConnected() && I::Engine->IsInGame()))
		return;

	int iUser = I::Engine->GetPlayerForUserID(pEvent->GetInt("userid"));

	auto engine_local_player = I::Engine->GetLocalPlayer();

	auto local_player = I::ClientEntList->GetClientEntity(I::Engine->GetLocalPlayer());

	if (!engine_local_player || !local_player || !iUser)
		return;
	
	auto event_weapon = pEvent->GetString("weapon");

	if (!event_weapon)
		return;

	if (event_weapon == "weapon_unknown")
		return;

	auto weapon = reinterpret_cast<CBaseCombatWeapon*>(local_player->GetWeapon());

	if (!weapon)
		return;

	if (engine_local_player == iUser)
	{
		G::shots_fired[G::target]++;
	}
}

void Listener::Damage::PlayerHurt(IGameEvent* pEvent)
{
	int hitted_id = I::Engine->GetPlayerForUserID(pEvent->GetInt("userid"));
	int attacker_id = I::Engine->GetPlayerForUserID(pEvent->GetInt("attacker"));

	if (hitted_id != I::Engine->GetLocalPlayer() && attacker_id == I::Engine->GetLocalPlayer())
	{
		int DamageHP = pEvent->GetInt("dmg_health");
		int DamageArm = pEvent->GetInt("dmg_armor");

		if (Opts.Visuals.Other.HitMarker != 0)
		{
			int hitgroup = pEvent->GetInt("hitgroup");

			CBaseEntity* hitted = I::ClientEntList->GetClientEntity(hitted_id);

			Vector Bone(0, 0, 0);

			if (Opts.Visuals.Other.HitMarker == 2)
			{
				Bone = hitted->GetBonePosition(BoneByEvent(hitgroup));
			}
			else if (Opts.Visuals.Other.HitMarker == 3)
			{
				Bone = hitted->GetBonePosition(BONE_HEAD);
			}

			ESP::Misc::HitMarker::CLog hit_log(DamageHP, DamageArm, I::Globals->curtime + 3, Bone);
			ESP::Misc::HitMarker::Add(hit_log);
		}

		if (Opts.Misc.Globals.EventLog)
		{
			player_info_t Info;
			if (I::Engine->GetPlayerInfo(hitted_id, &Info))
			{
				std::string Shot = "  -  took  " + to_str(DamageHP) + "  hp dmg and  " + to_str(DamageArm) + "  armor dmg";
				G::Strings.push_back({ std::string((Info.Name) + (Shot)), I::Globals->curtime + 10.f });
			}
		}

		G::shots_hit[hitted_id]++;
	}
}

void Listener::Damage::PlayerDeath(IGameEvent* pEvent)
{
	int killer = I::Engine->GetPlayerForUserID(pEvent->GetInt("attacker"));
	int killed = I::Engine->GetPlayerForUserID(pEvent->GetInt("userid"));

	if (killer == I::Engine->GetLocalPlayer() && killed != I::Engine->GetLocalPlayer())
	{
		G::KillTimer = 100; // for legit aim


		int local_team = Opts.Misc.Changer.Skins.SettingsForTeams ? G::LocalPlayer->GetTeam() == 3 ? 0 : 1 : 2;
		int aim_index = G::LocalPlayer->GetWeapon()->GetAimIndex();

		if (aim_index != WAI_UNKNOW && Opts.Misc.Changer.Skins.EnableSkins && Opts.Misc.Changer.Skins.Weapons[local_team][aim_index].StatTrak.Type == 1)
		{
			Opts.Misc.Changer.Skins.Weapons[local_team][aim_index].StatTrak.Kills += 1;
			//Config->SaveCFG();
			Config->SaveOneIntVal(std::string("CSkins.Weapons." + std::to_string(local_team) + "." + std::to_string(aim_index) + ".StatTrak.Kills"), Opts.Misc.Changer.Skins.Weapons[local_team][aim_index].StatTrak.Kills);
		}
		else if (Opts.Misc.Changer.Skins.EnableKnife && !G::IsInDangerZone && Opts.Misc.Changer.Skins.Knifes[local_team].StatTrak.Type == 1 && G::LocalPlayer->GetWeapon()->GetType() == WT_KNIFES)
		{
			Opts.Misc.Changer.Skins.Knifes[local_team].StatTrak.Kills += 1;
			//Config->SaveCFG();
			Config->SaveOneIntVal(std::string("CSkins.Knifes." + std::to_string(local_team) + ".StatTrak.Kills"), Opts.Misc.Changer.Skins.Knifes[local_team].StatTrak.Kills);
		}

		G::shots_hit[killed] = 0;
		G::shots_missed[killed] = 0;
	}

	if (Opts.Misc.Globals.EventLog)
	{
		player_info_t Info;
		if (I::Engine->GetPlayerInfo(killed, &Info))
		{
			std::string killed_str = Info.Name;

			if (I::Engine->GetPlayerInfo(killer, &Info))
			{
				std::string Died = "  killed  ";
				G::Strings.push_back({ std::string(Info.Name + Died + killed_str), I::Globals->curtime + 10.f });
			}
		}
	}
}

void Listener::Item::Purchase(IGameEvent* pEvent)
{
	if (!Opts.Misc.Globals.EventLog)
		return;

	int ID = I::Engine->GetPlayerForUserID(pEvent->GetInt("userid"));
	std::string Weapon = strstr(pEvent->GetString("Weapon"), "weapon_") ? std::string(pEvent->GetString("Weapon")).substr(7) : strstr(pEvent->GetString("Weapon"), "item_") ? std::string(pEvent->GetString("Weapon")).substr(5) : pEvent->GetString("Weapon");

	player_info_t Info;
	if (I::Engine->GetPlayerInfo(ID, &Info))
	{
		std::string team = pEvent->GetInt("team") == TEAM_TT ? "Terrorist. " : "Counter-Terrorist. ";
		G::Strings.push_back
		(
			{
				std::string((team)+(Info.Name) + " bought " + Weapon), I::Globals->curtime + 10.f
			}
		);
	}
}

void Listener::Bullet::Impact(IGameEvent* pEvent)
{
	if (Opts.Visuals.Other.BulletTracer <= 0)
		return;

	int ID = I::Engine->GetPlayerForUserID(pEvent->GetInt("userid"));
	if (Opts.Visuals.Other.BulletTracer == 1 && ID != I::Engine->GetLocalPlayer())
		return;

	CBaseEntity* Player = I::ClientEntList->GetClientEntity(ID);

	ESP::Misc::BulletTracer::CLog new_log(Player == G::LocalPlayer ? Player->GetEyePosition() : Player->GetBonePosition(BONE_HEAD),	Vector(pEvent->GetFloat("x"), pEvent->GetFloat("y"), pEvent->GetFloat("z")), I::Globals->curtime + 2);
	ESP::Misc::BulletTracer::Add(new_log);
}

void Listener::Bomb::BeginDefuse(IGameEvent* pEvent)
{
	pBomb.Defusing = true;
}

void Listener::Bomb::AbortDefuse(IGameEvent* pEvent)
{
	pBomb.Defusing = false;
}

void Listener::Bomb::Defused(IGameEvent* pEvent)
{
	pBomb.Defusing = false;
	pBomb.Planted = false;
}

void Listener::Bomb::Planted(IGameEvent* pEvent)
{
	pBomb.Planted = true;
}

void Listener::Bomb::Exploded(IGameEvent* pEvent)
{
	pBomb.Planted = false;
}

void Listener::Round::Start(IGameEvent* pEvent)
{
	pBomb.Planted = false;
	pBomb.Defusing = false;

	G::Strings.clear();
	
	G::FlashTime = 0.f;

	ESP::Misc::BulletTracer::Log.clear();
	ESP::Misc::HitMarker::Log.clear();

	G::RestartESP = true;
	G::RestartBuyBot = true;

	G::CurrentMap = U::GetCurrentMap();
}

void Listener::Get()
{
	// damage
	I::GameEventManager->AddListener(Listener::Damage::WeaponFiredListener, "weapon_fire", false);
	I::GameEventManager->AddListener(Listener::Damage::PlayerHurtListener, "player_hurt", false);
	I::GameEventManager->AddListener(Listener::Damage::PlayerDeathListener, "player_death", false);

	// item
	I::GameEventManager->AddListener(Listener::Item::PurchaseListener, "item_purchase", false);

	// bullet
	I::GameEventManager->AddListener(Listener::Bullet::ImpactListener, "bullet_impact", false);

	// bomb
	I::GameEventManager->AddListener(Listener::Bomb::DefusedListener, "bomb_defused", false);
	I::GameEventManager->AddListener(Listener::Bomb::BeginDefuseListener, "bomb_begindefuse", false);
	I::GameEventManager->AddListener(Listener::Bomb::AbortDefuseListener, "bomb_abortdefuse", false);
	I::GameEventManager->AddListener(Listener::Bomb::PlantedListener, "bomb_planted", false);
	I::GameEventManager->AddListener(Listener::Bomb::ExplodedListener, "bomb_exploded", false);

	// round
	I::GameEventManager->AddListener(Listener::Round::StartListener, "round_start", false);
}