#include "Cheat.h"

#include "Protobuf_compiled/cstrike15_usermessages.pb.h"

DispatchUserMessageFn oDispatchUserMessage;
bool __fastcall Hooks::DispatchUserMessage(void* ecx, void* edx, int type, unsigned int a3, unsigned int length, const void* msg_data)
{
	return oDispatchUserMessage(ecx, type, a3, length, msg_data);
}