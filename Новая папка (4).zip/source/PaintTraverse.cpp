#include "Cheat.h"
#include "Backdrop.h"

template <typename T>
static constexpr auto relativeToAbsolute(int* address) noexcept
{
	return reinterpret_cast<T>(reinterpret_cast<char*>(address + 1) + *address);
}

void SkyChanger()
{
	typedef void(__fastcall tdLoadNameSky) (const char*);
	static std::add_pointer_t<tdLoadNameSky> LoadNamedSky = relativeToAbsolute<decltype(LoadNamedSky)>(U::FindPatternV3<int*>("engine", "\xE8????\x84\xC0\x74\x2D\xA1", 1));

	static bool init = false;

	if (!init)
	{
		static auto sky = I::Cvar->FindVar("r_3dsky");
		sky->SetValue(0);

		init = true;
	}

	switch (Opts.Visuals.Other.SkyChanger)
	{
	case 1: LoadNamedSky("cs_baggage_skybox_"); break;
	case 2: LoadNamedSky("cs_tibet"); break;
	case 3: LoadNamedSky("embassy"); break;
	case 4: LoadNamedSky("italy"); break;
	case 5: LoadNamedSky("jungle"); break;
	case 6: LoadNamedSky("nukeblank"); break;
	case 7: LoadNamedSky("office"); break;
	case 8: LoadNamedSky("sky_cs15_daylight01_hdr"); break;
	case 9: LoadNamedSky("sky_cs15_daylight02_hdr"); break;
	case 10: LoadNamedSky("sky_cs15_daylight03_hdr"); break;
	case 11: LoadNamedSky("sky_cs15_daylight04_hdr"); break;
	case 12: LoadNamedSky("sky_csgo_cloudy01"); break;
	case 13: LoadNamedSky("sky_csgo_night_flat"); break;
	case 14: LoadNamedSky("sky_csgo_night02"); break;
	case 15: LoadNamedSky("sky_day02_05_hdr"); break;
	case 16: LoadNamedSky("sky_day02_05"); break;
	case 17: LoadNamedSky("sky_dust"); break;
	case 18: LoadNamedSky("sky_l4d_rural02_ldr"); break;
	case 19: LoadNamedSky("sky_venice"); break;
	case 20: LoadNamedSky("vertigo_hdr"); break;
	case 21: LoadNamedSky("vertigo"); break;
	case 22: LoadNamedSky("vertigoblue_hdr"); break;
	case 23: LoadNamedSky("vietnam"); break;
	case 24: LoadNamedSky(Opts.Visuals.Other.SkyChangerName.c_str()); break;
	default: break;
	}
}


void WaterMarkAndInjected()
{
	static unsigned char injected = 1;
	if (injected != 0x0)
	{
		switch (injected)
		{
			case 0x1:
			{
				static int y = 0;

				I::Surface->DrawSetColor(Color(0, 0, 0, 255));
				I::Surface->DrawFilledRect(10, 0, 110, y);
				D::DrawString(F::Watermark, 60, y / 2, Color(255, 255, 255), FONT_CENTER, "%s", xs("Injected"));

				if (y < 45) y += 5;
				else injected <<= 1;

				return;
			}
			case 0x2:
			{
				static int y = 0;

				I::Surface->DrawSetColor(Color(0, 0, 0, 255));
				I::Surface->DrawFilledRect(10, y, 110, 45);
				D::DrawString(F::Watermark, 60, 22 + y / 2, Color(255, 255, 255), FONT_CENTER, "%s", xs("Injected"));

				if (y < 5) y += 1;
				else injected <<= 1;

				return;
			}
			case 0x4:
			{
				static int time = 0;

				I::Surface->DrawSetColor(Color(0, 0, 0, 255));
				I::Surface->DrawFilledRect(10, 5, 110, 45);
				D::DrawString(F::Watermark, 60, 25, Color(255, 255, 255), FONT_CENTER, "%s", xs("Injected"));

				if (time < 200) ++time;
				else injected <<= 1;

				return;
			}
			case 0x8:
			{
				static int x = 0;

				I::Surface->DrawSetColor(Color(0, 0, 0, 255));
				I::Surface->DrawFilledRect(10 - x, 5, 110, 45);
				D::DrawString(F::Watermark, 60 - x, 25, Color(255, 255, 255), FONT_CENTER, "%s", xs("Injected"));

				if (x < 10) x += 2;
				else injected <<= 1;

				return;
			}
			case 0x10:
			{
				static int x = 0;

				I::Surface->DrawSetColor(Color(0, 0, 0, 255));
				I::Surface->DrawFilledRect(0, 5, 110 - x, 45);
				D::DrawString(F::Watermark, 50 - x, 25, Color(255, 255, 255), FONT_CENTER, "%s", xs("Injected"));

				if (x < 110) x += 2;
				else injected <<= 1;

				return;
			}
			case 0x20:
			{
				static int x = 0;

				I::Surface->DrawSetColor(Color(0, 0, 0, 255));
				I::Surface->DrawFilledRect(0, 5, x, 45);
				D::DrawString(F::Watermark, x - 55, 25, Color(255, 255, 255), FONT_CENTER, "%s", xs("Nikitapidor.cc "));

				if (x < 110) x += 2;
				else injected <<= 1;

				return;
			}
		}
	}

	if (Opts.Visuals.Other.WaterMark)
	{
		I::Surface->DrawSetColor(Color(0, 0, 0, 255));
		I::Surface->DrawFilledRect(0, 5, 110, 45);
		D::DrawString(F::Watermark, 55, 25, Color(255, 255, 255), FONT_CENTER, "%s", xs("Nikitapidor.cc "));
	}
}

void StatusBar()
{
	I::Surface->DrawSetColor(Color::Black().DiffAlpha(170));
	I::Surface->DrawFilledRect(G::ScreenWidth - 150, 10, G::ScreenWidth - 127, 28);
	I::Surface->DrawFilledRect(G::ScreenWidth - 125, 10, G::ScreenWidth - 102, 28);
	I::Surface->DrawFilledRect(G::ScreenWidth - 100, 10, G::ScreenWidth - 78, 28);
	I::Surface->DrawFilledRect(G::ScreenWidth - 75, 10, G::ScreenWidth - 52, 28);
	I::Surface->DrawFilledRect(G::ScreenWidth - 50, 10, G::ScreenWidth - 27, 28);
	I::Surface->DrawFilledRect(G::ScreenWidth - 25, 10, G::ScreenWidth - 2, 28);

	I::Surface->DrawSetColor(Color::Outline());
	I::Surface->DrawOutlinedRect(G::ScreenWidth - 148, 12, G::ScreenWidth - 144, 26);
	I::Surface->DrawOutlinedRect(G::ScreenWidth - 123, 12, G::ScreenWidth - 119, 26);
	I::Surface->DrawOutlinedRect(G::ScreenWidth - 98, 12, G::ScreenWidth - 94, 26);
	I::Surface->DrawOutlinedRect(G::ScreenWidth - 73, 12, G::ScreenWidth - 69, 26);
	I::Surface->DrawOutlinedRect(G::ScreenWidth - 48, 12, G::ScreenWidth - 44, 26);
	I::Surface->DrawOutlinedRect(G::ScreenWidth - 23, 12, G::ScreenWidth - 19, 26);

	static BYTE enable_flags;

	// rage // legit rage // legit // visual // skins // profile

	if (Opts.RageBot.AimBot.Enabled || Opts.RageBot.AntiAims.Enabled) { if (!(enable_flags & 0x1)) enable_flags |= 0x1; }
	else if (enable_flags & 0x1) enable_flags &= ~0x1;

	if (Opts.LegitBot.AimBot.Enabled || Opts.LegitBot.RCS.Enabled || Opts.LegitBot.Trigger.Enabled) { if (!(enable_flags & 0x2)) enable_flags |= 0x2; }
	else if (enable_flags & 0x2) enable_flags &= ~0x2;

	if (Opts.LegitRageBot.Enabled) { if (!(enable_flags & 0x4)) enable_flags |= 0x4; }
	else if (enable_flags & 0x4) enable_flags &= ~0x4;

	if (Opts.Visuals.Players.Global.Enabled || Opts.Visuals.Players.Chams.Enabled || Opts.Visuals.Players.Glow.Enabled || Opts.Visuals.Weapons.Glow || Opts.Visuals.Weapons.Enabled) { if (!(enable_flags & 0x8)) enable_flags |= 0x8; }
	else if (enable_flags & 0x8) enable_flags &= ~0x8;

	if (Opts.Misc.Changer.Skins.EnableSkins || Opts.Misc.Changer.Skins.EnableKnife || Opts.Misc.Changer.Skins.EnableGlove) { if (!(enable_flags & 0x10)) enable_flags |= 0x10; }
	else if (enable_flags & 0x10) enable_flags &= ~0x10;

	if (Opts.Misc.Changer.Profile.Enabled) { if (!(enable_flags & 0x20)) enable_flags |= 0x20; }
	else if (enable_flags & 0x20) enable_flags &= ~0x20;

	if (!enable_flags) // all disable
	{
		I::Surface->DrawSetColor(Color::White());

		D::DrawString(F::Panel, G::ScreenWidth - 141, 19, Color::White(), FONT_LEFT, xs("R"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 147, 13, G::ScreenWidth - 145, 25);

		D::DrawString(F::Panel, G::ScreenWidth - 116, 19, Color::White(), FONT_LEFT, xs("L"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 122, 13, G::ScreenWidth - 120, 25);

		D::DrawString(F::Panel, G::ScreenWidth - 93, 19, Color::White(), FONT_LEFT, xs("LR"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 97, 13, G::ScreenWidth - 95, 25);

		D::DrawString(F::Panel, G::ScreenWidth - 66, 19, Color::White(), FONT_LEFT, xs("V"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 72, 13, G::ScreenWidth - 70, 25);

		D::DrawString(F::Panel, G::ScreenWidth - 41, 19, Color::White(), FONT_LEFT, xs("S"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 47, 13, G::ScreenWidth - 45, 25);

		D::DrawString(F::Panel, G::ScreenWidth - 16, 19, Color::White(), FONT_LEFT, xs("P"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 22, 13, G::ScreenWidth - 20, 25);

		return;
	}

	I::Surface->DrawSetColor(Color::Red());

	static BYTE enabled = 0;

	if (enable_flags & 0x1)
	{
		D::DrawString(F::Panel, G::ScreenWidth - 141, 19, Color::Red(), FONT_LEFT, xs("R"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 147, 13, G::ScreenWidth - 145, 25);
		enable_flags &= ~0x6;
		++enabled;
	}
	else if (enable_flags & 0x4)
	{
		D::DrawString(F::Panel, G::ScreenWidth - 93, 19, Color::Red(), FONT_LEFT, xs("LR"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 97, 13, G::ScreenWidth - 95, 25);
		enable_flags &= ~0x2;
		++enabled;
	}
	else if (enable_flags & 0x2)
	{
		D::DrawString(F::Panel, G::ScreenWidth - 116, 19, Color::Red(), FONT_LEFT, xs("L"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 122, 13, G::ScreenWidth - 120, 25);
		++enabled;
	}

	if (enable_flags & 0x8)
	{
		D::DrawString(F::Panel, G::ScreenWidth - 66, 19, Color::Red(), FONT_LEFT, xs("V"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 72, 13, G::ScreenWidth - 70, 25);
		++enabled;
	}

	if (enable_flags & 0x10)
	{
		D::DrawString(F::Panel, G::ScreenWidth - 41, 19, Color::Red(), FONT_LEFT, xs("S"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 47, 13, G::ScreenWidth - 45, 25);
		++enabled;
	}

	if (enable_flags & 0x20)
	{
		D::DrawString(F::Panel, G::ScreenWidth - 16, 19, Color::Red(), FONT_LEFT, xs("P"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 22, 13, G::ScreenWidth - 20, 25);

		if (enabled == 5)
		{
			enabled = 0;
			return;
		}
	}

	I::Surface->DrawSetColor(Color::White());

	if (!(enable_flags & 0x1))
	{
		D::DrawString(F::Panel, G::ScreenWidth - 141, 19, Color::White(), FONT_LEFT, xs("R"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 147, 13, G::ScreenWidth - 145, 25);
	}

	if (!(enable_flags & 0x2))
	{
		D::DrawString(F::Panel, G::ScreenWidth - 116, 19, Color::White(), FONT_LEFT, xs("L"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 122, 13, G::ScreenWidth - 120, 25);
	}

	if (!(enable_flags & 0x4))
	{
		D::DrawString(F::Panel, G::ScreenWidth - 93, 19, Color::White(), FONT_LEFT, xs("LR"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 97, 13, G::ScreenWidth - 95, 25);
	}

	if (!(enable_flags & 0x8))
	{
		D::DrawString(F::Panel, G::ScreenWidth - 66, 19, Color::White(), FONT_LEFT, xs("V"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 72, 13, G::ScreenWidth - 70, 25);
	}

	if (!(enable_flags & 0x10))
	{
		D::DrawString(F::Panel, G::ScreenWidth - 41, 19, Color::White(), FONT_LEFT, xs("S"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 47, 13, G::ScreenWidth - 45, 25);
	}

	if (!(enable_flags & 0x20))
	{
		D::DrawString(F::Panel, G::ScreenWidth - 16, 19, Color::White(), FONT_LEFT, xs("P"));
		I::Surface->DrawFilledRect(G::ScreenWidth - 22, 13, G::ScreenWidth - 20, 25);
	}
}

struct ASDDDDDDDDDDDD
{
	std::string name;
	int id;
};

PaintTraverseFn oPaintTraverse;
void __stdcall Hooks::PaintTraverse(unsigned int panel, bool forceRepaint, bool allowForce)
{
	std::string panel_name = I::VPanel->GetName(panel);

	static unsigned int drawPanel;
	if (!drawPanel)
	{
		if (panel_name[0] == 'M' && panel_name[2] == 't')
		{
			drawPanel = panel;
		}
	}

	if (Opts.Visuals.Players.Global.ScreenShotBypass && I::Engine->IsTakingScreenshot())
	{
		oPaintTraverse(I::VPanel, panel, forceRepaint, allowForce);
		return;
	}

#ifdef FULL_MODE
	if (panel_name == "HudZoom" && Opts.Misc.Globals.NoScope && G::LocalPlayer && G::LocalPlayer->GetHealth() > 0) return;
#endif

	if (drawPanel == panel)
	{
		I::Engine->GetScreenSize(G::ScreenWidth, G::ScreenHeight);
		G::ScreenWidthHalf = G::ScreenWidth / 2;
		G::ScreenHeightHalf = G::ScreenHeight / 2;

		static bool Key_Click = false;

		if (Opts.Visuals.Players.Global.VisualsKey != 0 && GetAsyncKeyState(Opts.Visuals.Players.Global.VisualsKey))
		{
			if (!Key_Click)
			{
				static BYTE visuals_enables = 0;

				if (Opts.Visuals.Players.Global.Enabled)
				{
					visuals_enables |= 1;
					Opts.Visuals.Players.Global.Enabled = false;
				}
				else if (visuals_enables & 1)
				{
					visuals_enables &= ~1;
					Opts.Visuals.Players.Global.Enabled = true;
				}

				if (Opts.Visuals.Players.Chams.Enabled)
				{
					visuals_enables |= 2;
					Opts.Visuals.Players.Chams.Enabled = false;
				}
				else if (visuals_enables & 2)
				{
					visuals_enables &= ~2;
					Opts.Visuals.Players.Chams.Enabled = true;
				}

				if (Opts.Visuals.Players.Glow.Enabled)
				{
					visuals_enables |= 4;
					Opts.Visuals.Players.Glow.Enabled = false;
				}
				else if (visuals_enables & 4)
				{
					visuals_enables &= ~4;
					Opts.Visuals.Players.Glow.Enabled = true;
				}
			}

			Key_Click = true;
		}
		else
			Key_Click = false;

		WaterMarkAndInjected(); // opt

		BackDrop::BackDropAndBackGround(); // opt

		if (I::Engine->IsInGame() && I::Engine->IsConnected() && G::LocalPlayer)
		{
			// Main draw
			ESP::Draw();

#ifdef FULL_MODE

			/*if (cur_sky != Opts.Visuals.Other.SkyChanger)*/ SkyChanger();

			if (G::LocalPlayer->GetAlive())
			{
				if (Opts.Misc.Globals.NoScope && G::LocalPlayer->IsScoped())
				{
					I::Surface->DrawSetColor(Color(0, 0, 0, 255));

					I::Surface->DrawLine(0, G::ScreenHeightHalf, G::ScreenWidth, G::ScreenHeightHalf);
					I::Surface->DrawLine(G::ScreenWidthHalf, 0, G::ScreenWidthHalf, G::ScreenHeight);
				}

				if (Opts.Misc.Globals.StatusBar) StatusBar();

				// other
				if (Opts.Misc.Globals.EventLog) // rewrite
				{
					int wide, tall; I::Surface->GetTextSize(F::MenuCon, L"A", wide, tall);

					for (int log_id = 0; log_id < G::Strings.size(); log_id++)
					{
						if (G::Strings.at(log_id).Time <= I::Globals->curtime)
						{
							G::Strings.erase(G::Strings.begin() + log_id);
							continue;
						}

						D::DrawString(F::MenuCon, 15, 15 + (tall * log_id), Color::White().DiffAlpha((G::Strings.at(log_id).Time - I::Globals->curtime) * (255 / 10)), FONT_LEFT, G::Strings.at(log_id).String.c_str());
					}

					if (G::Strings.size() > 10)
					{
						G::Strings.erase(G::Strings.begin());
					}
				}
				else
				{
					G::Strings.clear();
				}
			}

#endif

		}


		auto paint_traverse = LuaEventManager.GetEvents("paint_traverse");
		for (size_t i = 0; i < paint_traverse.size(); ++i)
			paint_traverse[i].func();
	}

	oPaintTraverse(I::VPanel, panel, forceRepaint, allowForce);
}