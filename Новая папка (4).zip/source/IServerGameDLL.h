#pragma once

struct ServerClass
{
	const char					*m_pNetworkName;
	void*						*m_pTable;
	ServerClass					*m_pNext;
	int							m_ClassID;
	int							m_InstanceBaselineIndex;
};

class QueryCvarCookie_t {};
class EQueryCvarValueStatus {};

class IServerGameDLL
{
public:
	// Initialize the game (one-time call when the DLL is first loaded )
	// Return false if there is an error during startup.
	virtual bool			DLLInit(CreateInterfaceFn engineFactory,
		CreateInterfaceFn physicsFactory,
		CreateInterfaceFn fileSystemFactory,
		void *pGlobals) = 0;

	// Setup replay interfaces on the server
	virtual bool			ReplayInit(CreateInterfaceFn fnReplayFactory) = 0;

	// This is called when a new game is started. (restart, map)
	virtual bool			GameInit(void) = 0;

	// Called any time a new level is started (after GameInit() also on level transitions within a game)
	virtual bool			LevelInit(char const *pMapName,
		char const *pMapEntities, char const *pOldLevel,
		char const *pLandmarkName, bool loadGame, bool background) = 0;

	// The server is about to activate
	virtual void			ServerActivate(void *pEdictList, int edictCount, int clientMax) = 0;

	// The server should run physics/think on all edicts
	virtual void			GameFrame(bool simulating) = 0;

	// Called once per simulation frame on the final tick
	virtual void			PreClientUpdate(bool simulating) = 0;

	// Called when a level is shutdown (including changing levels)
	virtual void			LevelShutdown(void) = 0;
	// This is called when a game ends (server disconnect, death, restart, load)
	// NOT on level transitions within a game
	virtual void			GameShutdown(void) = 0;

	// Called once during DLL shutdown
	virtual void			DLLShutdown(void) = 0;

	// Get the simulation interval (must be compiled with identical values into both client and game .dll for MOD!!!)
	// Right now this is only requested at server startup time so it can't be changed on the fly, etc.
	virtual float			GetTickInterval(void) const = 0;

	// Give the list of datatable classes to the engine.  The engine matches class names from here with
	//  edict_t::classname to figure out how to encode a class's data for networking
	virtual ServerClass*	GetAllServerClasses(void) = 0;

	// Returns string describing current .dll.  e.g., TeamFortress 2, Half-Life 2.  
	//  Hey, it's more descriptive than just the name of the game directory
	virtual const char     *GetGameDescription(void) = 0;

	// Let the game .dll allocate it's own network/shared string tables
	virtual void			CreateNetworkStringTables(void) = 0;

	// Save/restore system hooks
	virtual void  *SaveInit(int size) = 0;
	virtual void			SaveWriteFields(void *, const char *, void *, void *, void *, int) = 0;
	virtual void			SaveReadFields(void *, const char *, void *, void *, void *, int) = 0;
	virtual void			SaveGlobalState(void *) = 0;
	virtual void			RestoreGlobalState(void *) = 0;
	virtual void			PreSave(void *) = 0;
	virtual void			Save(void *) = 0;
	virtual void			GetSaveComment(char *comment, int maxlength, float flMinutes, float flSeconds, bool bNoTime = false) = 0;
	virtual void			WriteSaveHeaders(void *) = 0;
	virtual void			ReadRestoreHeaders(void *) = 0;
	virtual void			Restore(void *, bool) = 0;
	virtual bool			IsRestoring() = 0;

	// Returns the number of entities moved across the transition
	virtual int				CreateEntityTransitionList(void *, int) = 0;
	// Build the list of maps adjacent to the current map
	virtual void			BuildAdjacentMapList(void) = 0;

	// Retrieve info needed for parsing the specified user message
	virtual bool			GetUserMessageInfo(int msg_type, char *name, int maxnamelength, int& size) = 0;

	// Hand over the StandardSendProxies in the game DLL's module.
	virtual void*	GetStandardSendProxies() = 0;

	// Called once during startup, after the game .dll has been loaded and after the client .dll has also been loaded
	virtual void			PostInit() = 0;
	// Called once per frame even when no level is loaded...
	virtual void			Think(bool finalTick) = 0;

#ifdef _XBOX
	virtual void			GetTitleName(const char *pMapName, char* pTitleBuff, int titleBuffSize) = 0;
#endif

	virtual void			PreSaveGameLoaded(char const *pSaveName, bool bCurrentlyInGame) = 0;

	// Returns true if the game DLL wants the server not to be made public.
	// Used by commentary system to hide multiplayer commentary servers from the master.
	virtual bool			ShouldHideServer(void) = 0;

	virtual void			InvalidateMdlCache() = 0;

	// * This function is new with version 6 of the interface.
	//
	// This is called when a query from IServerPluginHelpers::StartQueryCvarValue is finished.
	// iCookie is the value returned by IServerPluginHelpers::StartQueryCvarValue.
	// Added with version 2 of the interface.
	virtual void			OnQueryCvarValueFinished(QueryCvarCookie_t iCookie, void *pPlayerEntity, EQueryCvarValueStatus eStatus, const char *pCvarName, const char *pCvarValue) = 0;

	// Called after the steam API has been activated post-level startup
	virtual void			GameServerSteamAPIActivated(void) = 0;

	// Called after the steam API has been shutdown post-level startup
	virtual void			GameServerSteamAPIShutdown(void) = 0;

	virtual void			SetServerHibernation(bool bHibernating) = 0;

	// interface to the new GC based lobby system
	virtual void *GetServerGCLobby() = 0;

	// Return override string to show in the server browser
	// "map" column, or NULL to just use the default value
	// (the map name)
	virtual const char *GetServerBrowserMapOverride() = 0;

	// Get gamedata string to send to the master serer updater.
	virtual const char *GetServerBrowserGameData() = 0;

	// Called to add output to the status command
	virtual void 			Status(void(*print) (const char *fmt, ...)) = 0;

	// Informs the game we would like to load this level, giving it a chance to prepare dynamic resources.
	//
	// - pszMapName is the name of the map we're looking for, and may be overridden to e.g. the canonical name of the
	//   map.
	//
	// - pszMapFile is the file we intend to use for this map ( e.g. maps/<mapname>.bsp ), and may be overridden to the
	//   file representing this map name. ( e.g. /path/to/steamapps/workshop/cp_mymap.ugc12345.bsp )
	//
	// This call is blocking, and may block for extended periods. See AsyncPrepareLevelResources below.
	virtual void PrepareLevelResources( /* in/out */ char *pszMapName, size_t nMapNameSize,
		/* in/out */ char *pszMapFile, size_t nMapFileSize) = 0;

	// Asynchronous version of PrepareLevelResources. Returns preparation status of map when called.
	// If passed, flProgress is filled with the current progress percentage [ 0.f to 1.f ] for the InProgress
	// result
	enum ePrepareLevelResourcesResult
	{
		// Good to go
		ePrepareLevelResources_Prepared,
		// Game DLL is async preparing (e.g. streaming resources). flProgress will be filled if passed.
		ePrepareLevelResources_InProgress
	};
	virtual ePrepareLevelResourcesResult AsyncPrepareLevelResources( /* in/out */ char *pszMapName, size_t nMapNameSize,
		/* in/out */ char *pszMapFile, size_t nMapFileSize,
		float *flProgress = NULL) = 0;

	// Ask the game DLL to evaluate what it would do with this map name were it passed to PrepareLevelResources.
	// NOTE That this is this is syncronous and non-blocking, so it is possible that async PrepareLevelResources call
	//      may be able to pull a better match than is immediately available to this call (e.g. blocking lookups of
	//      cloud maps)
	enum eCanProvideLevelResult {
		// Have no knowledge of this level name, it will be up to the engine to provide. (e.g. as maps/levelname.bsp)
		eCanProvideLevel_CannotProvide,
		// Can provide resources for this level, and pMapName has been updated to the canonical name we would provide it
		// under (as with PrepareLevelResources)
		eCanProvideLevel_CanProvide,
		// We recognize this level name as something we might be able to prepare, but without a blocking/async call to
		// PrepareLevelResources, it is not possible to say whether it is available.
		eCanProvideLevel_Possibly
	};
	virtual eCanProvideLevelResult CanProvideLevel( /* in/out */ char *pMapName, int nMapNameMax) = 0;

	// Called to see if the game server is okay with a manual changelevel or map command
	virtual bool			IsManualMapChangeOkay(const char **pszReason) = 0;
};