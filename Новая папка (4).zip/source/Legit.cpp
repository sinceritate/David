#include "Cheat.h"

// strBullet Bullets[150]; // settings bullets (aim, trigger, rcs)
// BYTE GroupNumber; // Number groups 
// BYTE Groups[150]; // Groups
// BYTE MassSize;

int Bone;
float FOV;
float Smooth;
bool Silent;
float SilentFOV;
float SilentSmooth;
bool AimbotDelay;
//bool AutoShotDelay;
float ShotDelay;
float KillDelay;

int Type;
int X;
int Y;

bool bHead;
bool bBody;
bool bMisc;
int TriggerDelay;

void UpdateSettingsLegit()
{
	if (Opts.LegitBot.SettingMode == 0)
	{
		Bone = Opts.LegitBot.All_Legit.AimBot.TargetBone;
		FOV = Opts.LegitBot.All_Legit.AimBot.Fov;
		Smooth = Opts.LegitBot.All_Legit.AimBot.Smooth;
		Silent = Opts.LegitBot.All_Legit.AimBot.pSilent;
		SilentFOV = Opts.LegitBot.All_Legit.AimBot.pSilentFov;
		AimbotDelay = Opts.LegitBot.All_Legit.AimBot.Delay;
		//AutoShotDelay = Opts.LegitBot.All_Legit.AimBot.AutoShotDelay;
		ShotDelay = Opts.LegitBot.All_Legit.AimBot.ShotDelay;
		KillDelay = Opts.LegitBot.All_Legit.AimBot.KillDelay;

		Type = Opts.LegitBot.All_Legit.RCS.Type;
		X = Opts.LegitBot.All_Legit.RCS.X;
		Y = Opts.LegitBot.All_Legit.RCS.Y;

		bHead = Opts.LegitBot.All_Legit.Trigger.Head;
		bBody = Opts.LegitBot.All_Legit.Trigger.Body;
		bMisc = Opts.LegitBot.All_Legit.Trigger.Misc;
		TriggerDelay = Opts.LegitBot.All_Legit.Trigger.Delay;
	}
	else if (Opts.LegitBot.SettingMode == 1)
	{
		int type = G::LocalPlayer->GetWeapon()->GetType() - 4;

		Bone = Opts.LegitBot.WT_Legit[type].AimBot.TargetBone;
		FOV = Opts.LegitBot.WT_Legit[type].AimBot.Fov;
		Smooth = Opts.LegitBot.WT_Legit[type].AimBot.Smooth;
		Silent = Opts.LegitBot.WT_Legit[type].AimBot.pSilent;
		SilentFOV = Opts.LegitBot.WT_Legit[type].AimBot.pSilentFov;
		AimbotDelay = Opts.LegitBot.WT_Legit[type].AimBot.Delay;
		//AutoShotDelay = Opts.LegitBot.WT_Legit[type].AimBot.AutoShotDelay;
		ShotDelay = Opts.LegitBot.WT_Legit[type].AimBot.ShotDelay;
		KillDelay = Opts.LegitBot.WT_Legit[type].AimBot.KillDelay;

		Type = Opts.LegitBot.WT_Legit[type].RCS.Type;
		X = Opts.LegitBot.WT_Legit[type].RCS.X;
		Y = Opts.LegitBot.WT_Legit[type].RCS.Y;

		bHead = Opts.LegitBot.WT_Legit[type].Trigger.Head;
		bBody = Opts.LegitBot.WT_Legit[type].Trigger.Body;
		bMisc = Opts.LegitBot.WT_Legit[type].Trigger.Misc;
		TriggerDelay = Opts.LegitBot.WT_Legit[type].Trigger.Delay;
	}
	else if(Opts.LegitBot.SettingMode == 2)
	{
		int weapon = G::LocalPlayer->GetWeapon()->GetAimIndex();

		Bone = Opts.LegitBot.EW_Legit[weapon].AimBot.TargetBone;
		FOV = Opts.LegitBot.EW_Legit[weapon].AimBot.Fov;
		Smooth = Opts.LegitBot.EW_Legit[weapon].AimBot.Smooth;
		Silent = Opts.LegitBot.EW_Legit[weapon].AimBot.pSilent;
		SilentFOV = Opts.LegitBot.EW_Legit[weapon].AimBot.pSilentFov;
		AimbotDelay = Opts.LegitBot.EW_Legit[weapon].AimBot.Delay;
		//AutoShotDelay = Opts.LegitBot.EW_Legit[weapon].AimBot.AutoShotDelay;
		ShotDelay = Opts.LegitBot.EW_Legit[weapon].AimBot.ShotDelay;
		KillDelay = Opts.LegitBot.EW_Legit[weapon].AimBot.KillDelay;

		Type = Opts.LegitBot.EW_Legit[weapon].RCS.Type;
		X = Opts.LegitBot.EW_Legit[weapon].RCS.X;
		Y = Opts.LegitBot.EW_Legit[weapon].RCS.Y;

		bHead = Opts.LegitBot.EW_Legit[weapon].Trigger.Head;
		bBody = Opts.LegitBot.EW_Legit[weapon].Trigger.Body;
		bMisc = Opts.LegitBot.EW_Legit[weapon].Trigger.Misc;
		TriggerDelay = Opts.LegitBot.EW_Legit[weapon].Trigger.Delay;
	}
	//else if (Opts.LegitBot.SettingMode == 3)
	//{
	//	int weapon = G::LocalPlayer->GetWeapon()->GetAimIndex();
	//
	//	GroupNumber = Opts.LegitBot.Bullets.GroupNumber[weapon];
	//
	//	switch (weapon)
	//	{ // Pistols
	//	case 0: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.Usps); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.Usps[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.Usps[i]; } break; }
	//	case 1: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.R8); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.R8[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.R8[i]; } break; }
	//	case 2: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.CZ75_Auto); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.CZ75_Auto[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.CZ75_Auto[i]; } break; }
	//	case 3: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.DesertEgle); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.DesertEgle[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.DesertEgle[i]; } break; }
	//	case 4: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.DualBerets); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.DualBerets[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.DualBerets[i]; } break; }
	//	case 5: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.FiveSeven); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.FiveSeven[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.FiveSeven[i]; } break; }
	//	case 6: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.Glock18); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.Glock18[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.Glock18[i]; } break; }
	//	case 7: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.P2000); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.P2000[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.P2000[i]; } break; }
	//	case 8: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.P250); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.P250[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.P250[i]; } break; }
	//	case 9: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.Tec9); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.Tec9[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.Tec9[i]; } break; }
	//			// SMG
	//	case 10: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.Mac10); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.Mac10[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.Mac10[i]; } break; }
	//	case 11: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.MP7); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.MP7[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.MP7[i]; } break; }
	//	case 12: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.MP9); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.MP9[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.MP9[i]; } break; }
	//	case 13: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.MP5_SD); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.MP5_SD[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.MP5_SD[i]; } break; }
	//	case 14: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.Bizon); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.Bizon[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.Bizon[i]; } break; }
	//	case 15: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.P90); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.P90[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.P90[i]; } break; }
	//	case 16: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.UMP_45); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.UMP_45[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.UMP_45[i]; } break; }
	//			 // Riflers
	//	case 17: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.AK_47); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.AK_47[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.AK_47[i]; } break; }
	//	case 18: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.Famas); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.Famas[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.Famas[i]; } break; }
	//	case 19: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.Galilar); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.Galilar[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.Galilar[i]; } break; }
	//	case 20: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.M4A4_S); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.M4A4_S[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.M4A4_S[i]; } break; }
	//	case 21: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.M4A4); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.M4A4[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.M4A4[i]; } break; }
	//			 // Snipers
	//	case 22: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.AWP); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.AWP[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.AWP[i]; } break; }
	//	case 23: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.S3SG1); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.S3SG1[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.S3SG1[i]; } break; }
	//	case 24: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.Scar20); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.Scar20[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.Scar20[i]; } break; }
	//	case 25: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.Ssg08); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.Ssg08[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.Ssg08[i]; } break; }
	//	case 26: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.AUG); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.AUG[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.AUG[i]; } break; }
	//	case 27: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.SG553); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.SG553[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.SG553[i]; } break; }
	//			 // Shotguns
	//	case 28: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.MAG7); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.MAG7[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.MAG7[i]; } break; }
	//	case 29: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.Nova); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.Nova[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.Nova[i]; } break; }
	//	case 30: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.SavedOff); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.SavedOff[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.SavedOff[i]; } break; }
	//	case 31: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.XM1014); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.XM1014[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.XM1014[i]; } break; }
	//			 // Machinguns
	//	case 32: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.M249); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.M249[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.M249[i]; } break; }
	//	case 33: { MassSize = ARRAYSIZE(Opts.LegitBot.Bullets.Groups.Negev); for (int i = 0; i < MassSize; i++) { Groups[i] = Opts.LegitBot.Bullets.Groups.Negev[i]; Bullets[i] = Opts.LegitBot.Bullets.Bullets.Negev[i]; } break; }
	//	}
	//}
}

void Legit::StartTrigger()
{
	if (!G::PressedKeys[Opts.LegitBot.Trigger.TriggerKey] && Opts.LegitBot.Trigger.TriggerKey != 0)
		return;

	if (Opts.LegitBot.Trigger.FlashCheck && G::LocalPlayer->IsFlashed())
		return;

	if ((Opts.LegitBot.Trigger.JumpCheck && !(G::LocalPlayer->GetFlags() & FL_ONGROUND)))
		return;
	
	long currentTime_ms = U::GetEpochTime();
	static long timeStamp = currentTime_ms;
	long oldTimeStamp;
	
	QAngle viewAngles_rcs = G::UserCmd->viewangles + G::LocalPlayer->GetPunchAngles() * 2.0f;

	Vector traceStart, traceEnd;
	trace_t tr;

	M::AngleVectors(viewAngles_rcs, &traceEnd);
	
	traceStart = G::LocalPlayer->GetEyePosition();
	traceEnd = traceStart + (traceEnd * 8192.0f);
	
	Ray_t ray;
	ray.Init(traceStart, traceEnd);
	CTraceFilter traceFilter;
	traceFilter.pSkip = G::LocalPlayer;
	I::EngineTrace->TraceRay(ray, 0x46004003, &traceFilter, &tr);
	
	oldTimeStamp = timeStamp;
	timeStamp = currentTime_ms;
	
	CBaseEntity* Player = (CBaseEntity*)tr.m_pEnt;
	if (!Player)
		return;

	if (Player->GetClientClass()->m_ClassID != CCSPlayer)
		return;

	if (Player == G::LocalPlayer || Player->GetDormant() || !Player->GetAlive() || Player->GetImmune())
		return;
	
	if (!Player->IsEnemy() && !Opts.LegitBot.Trigger.FriendlyFire)
		return;

	if (!((bHead && tr.hitgroup == HITGROUP_HEAD) || (bBody && (tr.hitgroup == HITGROUP_CHEST || tr.hitgroup == HITGROUP_STOMACH)) || (bMisc && (tr.hitgroup >= HITGROUP_LEFTARM && tr.hitgroup <= HITGROUP_RIGHTLEG))))
		return;
	
	if (Opts.LegitBot.Trigger.SmokeCheck && U::IsInSmoke(tr.endpos))
		return;

	CBaseCombatWeapon* activeWeapon = G::LocalPlayer->GetWeapon();

	if (activeWeapon->GetNextPrimaryAttack() > I::Globals->curtime)
	{
		if (*activeWeapon->GetItemDefinitionIndex() == WEAPON_REVOLVER)
		{
			G::UserCmd->buttons &= ~IN_ATTACK2;
		}
		else
		{
			G::UserCmd->buttons &= ~IN_ATTACK;
		}
	}
	else
	{
		if ((TriggerDelay > 0) && (currentTime_ms - oldTimeStamp < TriggerDelay * 100))
		{
			timeStamp = oldTimeStamp;
			return;
		}
	
		if (*activeWeapon->GetItemDefinitionIndex() == WEAPON_REVOLVER)
		{
			G::UserCmd->buttons |= IN_ATTACK2;
		}
		else
		{
			G::UserCmd->buttons |= IN_ATTACK;
		}
	}
	
	timeStamp = currentTime_ms;
}

int ClosestBone(CBaseEntity* Entity)
{
	float BestDist = G::LocalPlayer->GetShotsFired() < 1 ? FOV > SilentFOV ? FOV : SilentFOV : FOV;
	int aimbone = -1;

	static int Bones[] = { BONE_PELVIS, BONE_STOMACH, BONE_CHEST, BONE_UPPER_CHEST, BONE_NECK, BONE_HEAD };

	for (auto Bone : Bones)
	{
		Vector pPosition = Entity->GetBonePosition(Bone);

		if (pPosition.IsZero())
			continue;

		if (!Opts.RageBot.AimBot.AutoWall && !Entity->IsVisible(Bone))
			continue;

		auto thisdist = M::GetFov(G::UserCmd->viewangles, M::CalcAngle(G::LocalPlayer->GetEyePosition(), Entity->GetBonePosition(Bone)));
		if (BestDist > thisdist)
		{
			BestDist = thisdist;
			aimbone = Bone;
			continue;
		}
	}

	return aimbone;
}

int GetHitbox(int ID)
{
	switch (Bone)
	{
	case 0: return BONE_HEAD; break;
	case 1: return BONE_NECK; break;
	case 2: return BONE_CHEST; break;
	case 3: return BONE_PELVIS; break;
	case 4: return ClosestBone(I::ClientEntList->GetClientEntity(ID)); break;
	}

	return -1;
}

float fBestFOV = 20.0f;
int iBestTarget = -1;
bool silent_work = false;

bool EntityValid(int index)
{
	CBaseEntity *pEntity = I::ClientEntList->GetClientEntity(index);

	if (!pEntity)
		return false;
	if (pEntity == G::LocalPlayer)
		return false;
	if (pEntity->GetHealth() <= 0)
		return false;
	if (pEntity->GetImmune())
		return false;
	if (pEntity->GetDormant())
		return false;
	if (!pEntity->IsEnemy() && !Opts.LegitBot.AimBot.FriendlyFire)
		return false;

	if ((Opts.LegitBot.AimBot.JumpCheck && !(G::LocalPlayer->GetFlags() & FL_ONGROUND)) || (G::LocalPlayer->GetMoveType() == MOVETYPE_LADDER))
		return false;

	if (Opts.LegitBot.AimBot.FlashCheck && G::LocalPlayer->IsFlashed())
		return false;

	int Hitbox = GetHitbox(index);
	if (Hitbox == -1) return false;

	if (!pEntity->IsVisible(Hitbox) || (Opts.LegitBot.AimBot.SmokeCheck && U::IsInSmoke(pEntity->GetBonePosition(Hitbox))))
	{
		return false;
	}

	return true;
}

int target_bone = -1;

void Legit::AimBot::DropTarget()
{
	//CBaseEntity* Player = I::ClientEntList->GetClientEntity(iBestTarget);

	if (!G::PressedKeys[Opts.LegitBot.AimBot.AimBotKey] || !G::LocalPlayer->GetWeapon()->IsFiredWeaponType())
	{
		G::KillTimer = 0;
		iBestTarget = -1;
		target_bone = -1;
		G::CurBestTarget = -1;
		G::CurBestBone = -1;
		silent_work = false;
		return;
	}

	if (!EntityValid(iBestTarget))
	{
		iBestTarget = -1;
		target_bone = -1;
		G::CurBestTarget = -1;
		G::CurBestBone = -1;
		silent_work = false;
		return;
	}
}

void Legit::AimBot::FindTarget()
{
	fBestFOV = G::LocalPlayer->GetShotsFired() < 1 ? FOV > SilentFOV ? FOV : SilentFOV : FOV;

	for (int i = 0; i < 64; ++i)
	{
		if (!EntityValid(i))
			continue;

		CBaseEntity* Entity = I::ClientEntList->GetClientEntity(i);

		int Hitbox = GetHitbox(i);
		if (Hitbox == -1) continue;

		float fov = M::GetFov(G::UserCmd->viewangles, M::CalcAngle(G::LocalPlayer->GetEyePosition(), Entity->GetBonePosition(Hitbox)));
		if (fov < fBestFOV)
		{
			fBestFOV = fov;
			iBestTarget = i;
			target_bone = Hitbox;
		}
	}

	G::CurBestTarget = iBestTarget;
	G::CurBestBone = target_bone;
}

void Legit::AimBot::GoToTarget()
{
	CBaseEntity* Entity = I::ClientEntList->GetClientEntity(iBestTarget);

	static QAngle old_angles = G::UserCmd->viewangles;

	Vector predicted = Entity->GetPredicted(Entity->GetBonePosition(target_bone));
	QAngle calc_angle = new_math::angle_poin_point(G::LocalPlayer->GetEyePosition(), predicted);

	QAngle deltaSilent = calc_angle.Normalized();
	// Aiming rcs
	if (Opts.LegitBot.RCS.Enabled && (G::LocalPlayer->GetShotsFired() > 1 || G::LocalPlayer->GetWeapon()->GetType() == WT_PISTOLS))
	{
		calc_angle -= QAngle(G::LocalPlayer->GetPunchAngles().x * (X / 50.f), G::LocalPlayer->GetPunchAngles().y * (Y / 50.f), 0);
	}

	QAngle delta = G::UserCmd->viewangles - calc_angle.Normalized();

	delta.Normalized();

	calc_angle = G::UserCmd->viewangles - (delta / Smooth);
	calc_angle.Normalized();

	// Kill delay
	if (AimbotDelay && G::KillTimer > I::Globals->curtime) return;

	if (Silent && G::LocalPlayer->GetShotsFired() < 1 && fBestFOV < SilentFOV) // pSilent
	{
		old_angles = G::UserCmd->viewangles;

		G::SendPacket = false;
		G::UserCmd->viewangles = deltaSilent;

		silent_work = true;
	}
	else if (!Silent || !silent_work) // not silent
	{
		G::SendPacket = true;
		G::UserCmd->viewangles = calc_angle;
		I::Engine->SetViewAngles(G::UserCmd->viewangles);
	}
}

void Legit::StartRCS()
{
	static QAngle OldPunch = QAngle(0, 0, 0);
	
	if (G::UserCmd->buttons & IN_ATTACK && (G::LocalPlayer->GetShotsFired() > 1 || G::LocalPlayer->GetWeapon()->GetType() == WT_PISTOLS))
	{
		QAngle CurPunch = (G::LocalPlayer->GetPunchAngles() * (QAngle(X, Y, 0) / 100.f)) * 2.f;

		QAngle delta = OldPunch - CurPunch;
		QAngle BufPunch = G::UserCmd->viewangles + (delta * (min(1.f, (fabsf(powf(0.6f, 0.4f) - 1.f) / delta.Length() * 4.f))));

		G::UserCmd->viewangles = BufPunch.Clamp();
		I::Engine->SetViewAngles(G::UserCmd->viewangles);
		
		OldPunch = CurPunch;
	}
	else
	{
		OldPunch = (G::LocalPlayer->GetPunchAngles() * (QAngle(X, Y, 0) / 100.f)) * 2.f;
	}
}

void Legit::RunLegit()
{
	// Legit Desync
	//if (Opts.Misc.Globals.LegitDesync && !(G::UserCmd->buttons & (IN_ATTACK | IN_USE | IN_ATTACK2)) && G::LocalPlayer->GetMoveType() != MOVETYPE_LADDER && G::LocalPlayer->GetMoveType() != MOVETYPE_NOCLIP)
	//{
	//	Rage::FixMove::Start();
	//	Rage::AntiAim::LegitDesync();
	//	Rage::FixMove::End();
	//}
	//else
	//{
	//	G::SendPacket = true;
	//}

	if (!G::LocalPlayer->GetWeapon()->IsFiredWeaponType())
		return;

	static int old_aim_index = G::LocalPlayer->GetWeapon()->GetAimIndex();
	if (G::LocalPlayer->GetWeapon()->GetAimIndex() != old_aim_index || G::LegitUpdate) {
		UpdateSettingsLegit();
		old_aim_index = G::LocalPlayer->GetWeapon()->GetAimIndex();
		G::LegitUpdate = false;
	}

	if (Opts.Menu.Opened)
		return;

	//static int old_ammo = G::LocalPlayer->GetWeapon()->GetAmmo();
	//static CBaseCombatWeapon* old_weapon = G::LocalPlayer->GetWeapon();
	//static bool updated = false;
	//
	//if (Opts.LegitBot.SettingMode == 3 && old_ammo != G::LocalPlayer->GetWeapon()->GetAmmo() && ((G::LocalPlayer->GetWeapon()->GetNextPrimaryAttack() - (G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick)) < 0))
	//{
	//	old_ammo = G::LocalPlayer->GetWeapon()->GetAmmo();
	//	int ammo_index = MassSize - old_ammo;
	//
	//	if (old_weapon != G::LocalPlayer->GetWeapon())
	//	{
	//		updated = false;
	//		old_weapon = G::LocalPlayer->GetWeapon();
	//	}
	//
	//	int index = 0;
	//
	//	for (int i = 0; i < GroupNumber - 1; i++)
	//	{
	//		if (Groups[i] <= ammo_index)
	//		{
	//			index = Groups[i];
	//			updated = false;
	//		}
	//	}
	//
	//	if (!updated || index == 0)
	//	{
	//		Bone = Bullets[index].AimBot.TargetBone;
	//		FOV = Bullets[index].AimBot.Fov;
	//		Smooth = Bullets[index].AimBot.Smooth;
	//		Silent = Bullets[index].AimBot.pSilent;
	//		SilentFOV = Bullets[index].AimBot.pSilentFov;
	//		SilentSmooth = Bullets[index].AimBot.pSilentSmooth;
	//		AimbotDelay = Bullets[index].AimBot.Delay;
	//		ShotDelay = Bullets[index].AimBot.ShotDelay;
	//		KillDelay = Bullets[index].AimBot.KillDelay;
	//	
	//		Type = Bullets[index].RCS.Type;
	//		X = Bullets[index].RCS.X;
	//		Y = Bullets[index].RCS.Y;
	//		
	//		bHead = Bullets[index].Trigger.Head;
	//		bBody = Bullets[index].Trigger.Body;
	//		bMisc = Bullets[index].Trigger.Misc;
	//		TriggerDelay = Bullets[index].Trigger.Delay;
	//	
	//		iBestTarget = -1;
	//	
	//		updated = true;
	//	}
	//}

	if (G::KillTimer == 100) {
		G::KillTimer = I::Globals->curtime + (KillDelay / 25.f);
	}

	if (Opts.LegitBot.Trigger.Enabled) {
		Legit::StartTrigger();
	}

	if (Opts.LegitBot.AimBot.Enabled)
	{
		// ShotDelay
		if (AimbotDelay)
		{
			static float Timer = 0;

			if (!(G::UserCmd->buttons & IN_ATTACK))
			{
				Timer = I::Globals->curtime + (ShotDelay / 50.f);
			}

			if (Timer > I::Globals->curtime)
			{
				G::UserCmd->buttons &= ~IN_ATTACK;
			}
		}

		if (iBestTarget != -1)
			Legit::AimBot::DropTarget();

		if (iBestTarget == -1)
			Legit::AimBot::FindTarget();

		if (iBestTarget != -1 && G::PressedKeys[Opts.LegitBot.AimBot.AimBotKey])
			Legit::AimBot::GoToTarget();
	}
	else
	{
		G::CurBestTarget = -1;
		G::CurBestBone = -1;
	}

	if (Opts.LegitBot.RCS.Enabled && Type == 0)
	{
		Legit::StartRCS();
	}
}