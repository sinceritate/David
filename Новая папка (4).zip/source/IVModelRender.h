#pragma once

#include "IMaterial.h"

struct mstudioanimdesc_t;
struct mstudioseqdesc_t;
class IClientRenderable;
class Vector;
struct studiohdr_t;
class IMaterial;
class CStudioHdr;
struct MaterialLightingState_t;
class IMatRenderContext;

#define DECLARE_HANDLE_16BIT(Name)	typedef CIntHandle16< struct Name##__handle * > Name;
#define DECLARE_HANDLE_32BIT(Name)	typedef CIntHandle32< struct Name##__handle * > Name;
#define DECLARE_POINTER_HANDLE(Name) struct Name##__ { int unused; }; typedef struct Name##__ *Name
#define FORWARD_DECLARE_HANDLE(Name) typedef struct Name##__ *Name
#define DECLARE_DERIVED_POINTER_HANDLE( _name, _basehandle ) struct _name##__ : public _basehandle##__ {}; typedef struct _name##__ *_name
#define DECLARE_ALIASED_POINTER_HANDLE( _name, _alias ) typedef struct _alias##__ *Name
#define FORWARD_DECLARE_HANDLE(Name) typedef struct Name##__ *Name
FORWARD_DECLARE_HANDLE(LightCacheHandle_t);
DECLARE_POINTER_HANDLE(StudioDecalHandle_t);
#define STUDIORENDER_DECAL_INVALID  ( (StudioDecalHandle_t)0 )
#define IMPLEMENT_OPERATOR_EQUAL( _classname )			\
	public:												\
		_classname &operator=( const _classname &src )	\
		{												\
			memcpy( this, &src, sizeof(_classname) );	\
			return *this;								\
		}

typedef float matrix3x4[3][4];
typedef float matrix4x4[4][4];
typedef unsigned char uint8;
typedef signed char int8;

enum
{
	ADDDECAL_TO_ALL_LODS = -1
};

struct studioloddata_t
{
	// not needed - this is really the same as studiohwdata_t.m_NumStudioMeshes
	//int					m_NumMeshes; 
	void* m_pMeshData; // there are studiohwdata_t.m_NumStudioMeshes of these.
	float m_SwitchPoint;
	// one of these for each lod since we can switch to simpler materials on lower lods.
	int numMaterials;
	IMaterial** ppMaterials; /* will have studiohdr_t.numtextures elements allocated */
							 // hack - this needs to go away.
	int* pMaterialFlags; /* will have studiohdr_t.numtextures elements allocated */

						 // For decals on hardware morphing, we must actually do hardware skinning
						 // For this to work, we have to hope that the total # of bones used by
						 // hw flexed verts is < than the Max possible for the dx level we're running under
	int* m_pHWMorphDecalBoneRemap;
	int m_nDecalBoneCount;
};

struct studiohwdata_t
{
	int m_RootLOD; // Calced and clamped, nonzero for lod culling
	int m_NumLODs;
	studioloddata_t* m_pLODs;
	int m_NumStudioMeshes;

	inline float LODMetric(float unitSphereSize) const
	{
		return (unitSphereSize != 0.0f) ? (100.0f / unitSphereSize) : 0.0f;
	}

	inline int GetLODForMetric(float lodMetric) const
	{
		if (!m_NumLODs)
			return 0;

		// shadow lod is specified on the Last lod with a negative switch
		// never consider shadow lod as viable candidate
		int numLODs = (m_pLODs[m_NumLODs - 1].m_SwitchPoint < 0.0f) ? m_NumLODs - 1 : m_NumLODs;

		for (int i = m_RootLOD; i < numLODs - 1; i++)
		{
			if (m_pLODs[i + 1].m_SwitchPoint > lodMetric)
				return i;
		}

		return numLODs - 1;
	}
};

struct DrawModelInfo_t
{
	studiohdr_t* m_pStudioHdr;
	studiohwdata_t* m_pHardwareData;
	StudioDecalHandle_t m_Decals;
	int m_Skin;
	int m_Body;
	int m_HitboxSet;
	void* m_pClientEntity;
	int m_Lod;
	void* m_pColorMeshes;
	bool m_bStaticLighting;
	void* m_LightingState;

	IMPLEMENT_OPERATOR_EQUAL(DrawModelInfo_t);
};

struct StaticPropRenderInfo_t
{
	matrix3x4* pModelToWorld;
	model_t* pModel;
	IClientRenderable* pRenderable;
	Vector* pLightingOrigin;
	ModelInstanceHandle_t instance;
	uint8 skin;
	uint8 Alpha;
};

struct LightingQuery_t
{
	Vector m_LightingOrigin;
	ModelInstanceHandle_t m_InstanceHandle;
	bool m_bAmbientBoost;
};

struct StaticLightingQuery_t : public LightingQuery_t
{
	IClientRenderable* m_pRenderable;
};

struct DrawModelState_t
{
	studiohdr_t* m_pStudioHdr;
	studiohwdata_t* m_pStudioHWData;
	IClientRenderable* m_pRenderable;
	const matrix3x4* m_pModelToWorld;
	StudioDecalHandle_t m_decals;
	int m_drawFlags;
	int m_lod;
};

struct ColorMeshInfo_t
{
	// A given Color mesh can own a unique Mesh, or it can use a shared Mesh
	// (in which case it uses a sub-range defined by m_nVertOffset and m_nNumVerts)
	void* m_pMesh;
	void* m_pPooledVBAllocator;
	int m_nVertOffsetInBytes;
	int m_nNumVerts;
};

class IVModelRender
{
public:
	virtual int DrawModel(int flags, IClientRenderable* pRenderable, ModelInstanceHandle_t instance, int entity_index, const model_t* model, Vector const& origin, Vector const& angles, int skin, int Body, int hitboxset, const matrix3x4* modelToWorld = nullptr, const matrix3x4* pLightingOffset = nullptr) = 0;

	virtual void ForcedMaterialOverride(IMaterial* newMaterial, OverrideType_t nOverrideType = OverrideType_t::OVERRIDE_NORMAL, int a = NULL) = 0;

	virtual bool IsForcedMaterialOverride() = 0;

	virtual void SetViewTarget(const CStudioHdr* pStudioHdr, int nBodyIndex, const Vector& Target) = 0;

	virtual ModelInstanceHandle_t CreateInstance(IClientRenderable* pRenderable, LightCacheHandle_t* pCache = nullptr) = 0;

	virtual void DestroyInstance(ModelInstanceHandle_t handle) = 0;

	virtual void SetStaticLighting(ModelInstanceHandle_t handle, LightCacheHandle_t* pHandle) = 0;

	virtual LightCacheHandle_t GetStaticLighting(ModelInstanceHandle_t handle) = 0;

	virtual bool ChangeInstance(ModelInstanceHandle_t handle, IClientRenderable* pRenderable) = 0;

	virtual void AddDecal(ModelInstanceHandle_t handle, Ray_t const& ray, Vector const& decalUp, int decalIndex, int Body, bool noPokeThru = false, int maxLODToDecal = ADDDECAL_TO_ALL_LODS) = 0;

	virtual void RemoveAllDecals(ModelInstanceHandle_t handle) = 0;

	virtual bool ModelHasDecals(ModelInstanceHandle_t handle) = 0;

	virtual void RemoveAllDecalsFromAllModels() = 0;

	virtual matrix3x4* DrawModelShadowSetup(IClientRenderable* pRenderable, int Body, int skin, DrawModelInfo_t* pInfo, matrix3x4* pCustomBoneToWorld = nullptr) = 0;

	virtual void DrawModelShadow(IClientRenderable* pRenderable, const DrawModelInfo_t& Info, matrix3x4* pCustomBoneToWorld = nullptr) = 0;

	virtual bool RecomputeStaticLighting(ModelInstanceHandle_t handle) = 0;

	virtual void ReleaseAllStaticPropColorData() = 0;

	virtual void RestoreAllStaticPropColorData() = 0;

	virtual int DrawModelEx(ModelRenderInfo_t& pInfo) = 0;

	virtual int DrawModelExStaticProp(ModelRenderInfo_t& pInfo) = 0;

	virtual bool DrawModelSetup(ModelRenderInfo_t& pInfo, DrawModelState_t* pState, matrix3x4** ppBoneToWorldOut) = 0;

	virtual void DrawModelExecute(void* ctx, void* state, const ModelRenderInfo_t& pInfo, matrix3x4_t* pCustomBoneToWorld = NULL) = 0;

	virtual void SetupLighting(const Vector& vecCenter) = 0;

	virtual int DrawStaticPropArrayFast(StaticPropRenderInfo_t* pProps, int count, bool bShadowDepth) = 0;

	virtual void SuppressEngineLighting(bool bSuppress) = 0;

	virtual void SetupColorMeshes(int nTotalVerts) = 0;

	virtual void SetupLightingEx(const Vector& vecCenter, ModelInstanceHandle_t handle) = 0;

	virtual bool GetBrightestShadowingLightSource(const Vector& vecCenter, Vector& lightPos, Vector& lightBrightness, bool bAllowNonTaggedLights) = 0;

	virtual void ComputeLightingState(int nCount, const LightingQuery_t* pQuery, MaterialLightingState_t* pState, ITexture** ppEnvCubemapTexture) = 0;

	virtual void GetModelDecalHandles(LPVOID* pDecals, int nDecalStride, int nCount, const ModelInstanceHandle_t* pHandles) = 0;

	virtual void ComputeStaticLightingState(int nCount, const StaticLightingQuery_t* pQuery, MaterialLightingState_t* pState, MaterialLightingState_t* pDecalState, ColorMeshInfo_t** ppStaticLighting, ITexture** ppEnvCubemapTexture, void* pColorMeshHandles) = 0;

	virtual void CleanupStaticLightingState(int nCount, void* pColorMeshHandles) = 0;

	void DrawModelExecuteEx(void* ctx, void* state, const ModelRenderInfo_t& pInfo, matrix3x4_t* pCustomBoneToWorld = NULL);
};
