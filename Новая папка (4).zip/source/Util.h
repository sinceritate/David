#pragma once

#define RandomInt(Min, Max) (rand() % (Max - Min + 1) + Min)

#define INRANGE(x,a,b)    (x >= a && x <= b)
#define getBits( x )    (INRANGE((x&(~0x20)),'A','F') ? ((x&(~0x20)) - 'A' + 0xa) : (INRANGE(x,'0','9') ? x - '0' : 0))
#define getByte( x )    (getBits(x[0]) << 4 | getBits(x[1]))

#define MakePtr (cast, ptr, addValue) ( cast )( (DWORD)( ptr ) + ( DWORD )( addValue ) )

using MsgFn = void(__cdecl*)(char const*, ...);
using ServerRankRevealAllFn = bool(__cdecl*)(float*);
using InitKeyValuesFn = void(__thiscall*)(void* thisptr, const char* Name);
using LoadFromBufferFn = void(__thiscall*)(void* thisptr, const char* resourceName, const char* pBuffer, void* pFileSystem, const char* pPathID, void* pfnEvaluateSymbolProc);
using IsReadyFn = void(__cdecl*)();
typedef bool(__fastcall* TraceToExitFn)(Vector&, trace_t&, float, float, float, float, float, float, trace_t*);
typedef bool(__fastcall* IsBreakableEntityFn) (CBaseEntity *pEntity);

namespace U
{
	extern CNetVarManager* NetVars;
	extern MsgFn PrintMessage;
	extern ServerRankRevealAllFn ServerRankRevealAllEx;
	extern InitKeyValuesFn InitKeyValuesEx;
	extern LoadFromBufferFn LoadFromBufferEx;
	extern TraceToExitFn TraceToExit;
	extern DWORD ClipTraceToPlayers;
	extern IsReadyFn IsReady;
	extern DWORD FindPattern(std::string moduleName, std::string pattern);
	extern CBaseEntity* GetLocalPlayer();
	extern bool InDangerZone();
	extern IsBreakableEntityFn IsBreakableEntity;
	extern Vector RotatePoint(Vector pointToRotate, Vector centerPoint, int posX, int posY, int sizeX, int sizeY, float angle, float Zoom, bool* viewCheck, bool angleInRadians = false);
	extern bool IsWeaponKnife(int weaponid);
	extern bool IsWeaponDefaultKnife(int weaponid);
	extern char* GetConfigName(int weaponid);
	extern wchar_t* Convert_char_to_wchar(const char* charArray);
	extern void TraceLine(const Vector& vecAbsStart, const Vector& vecAbsEnd, unsigned int mask, CBaseEntity* ignore, trace_t* ptr);
	extern void ServerRankRevealAll();
	extern void InitKeyValues(KeyValues* pKeyValues, const char* Name);
	extern void LoadFromBuffer(KeyValues* pKeyValues, const char* resourceName, const char* pBuffer, void* pFileSystem = nullptr, const char* pPathID = NULL, void* pfnEvaluateSymbolProc = nullptr);
	extern long GetEpochTime();
	extern void SetupInterfaces();
	extern bool SendCommends(int accountId);
	extern bool SendReport(int accountId);
	extern void PrecacheModel(const char* szModelName);
	extern void SetCustomModel(const char* model_name, CBaseEntity* entity);
	extern bool SendCSGOMessages();
	extern bool IsInSmoke(Vector vEndPos);
	extern void SetupHooks();
	extern void SetupOffsets();
	extern void SetupOptions();
	extern void Setup();
	extern int GetCurrentMap();
	extern std::string GetMapNameById(int id);
	extern void ForceFullUpdate();
	extern QAngle CalcAngle(Vector src, Vector dst);

	template< class T, class Y >
	T Clamp(T const& Val, Y const& minVal, Y const& maxVal)
	{
		if (Val < minVal)
		{
			return minVal;
		}		
		else if (Val > maxVal)
		{
			return maxVal;
		}	
		else
		{
			return Val;
		}	
	}
	
	template< typename T >
	T GetVFunc( void* vTable, int iIndex )
	{
		const auto vtable = *static_cast<void***>(vTable);
		return reinterpret_cast<T>(vtable[iIndex]);
	}

	template< typename T >
	T* CaptureInterface( std::string strModule, std::string strInterface )
	{
		typedef T* ( *CreateInterfaceFn )( const char* szName, int iReturn );
		CreateInterfaceFn CreateInterface = ( CreateInterfaceFn )GetProcAddress( GetModuleHandleA( strModule.c_str() ), ( "CreateInterface" ) );
		
		return CreateInterface( strInterface.c_str(), 0 );
	}

	template <typename T = uintptr_t>
	static auto FindPatternV3(const char* module, std::string_view pattern, size_t offset = 0) noexcept
	{
		MODULEINFO moduleInfo;

		if (GetModuleInformation(GetCurrentProcess(), GetModuleHandleA(module), &moduleInfo, sizeof(moduleInfo))) {
			char* begin = static_cast<char*>(moduleInfo.lpBaseOfDll);
			char* end = begin + moduleInfo.SizeOfImage - pattern.length() + 1;

			for (char* c = begin; c != end; c++) {
				bool matched = true;
				auto it = c;

				if (*(c + pattern.length() - 1) != pattern.back())
					continue;

				for (auto a : pattern) {
					if (a != '?' && *it != a) {
						matched = false;
						break;
					}
					it++;
				}
				if (matched)
					return reinterpret_cast<T>(c + offset);
			}
		}
		MessageBox(NULL, (std::ostringstream{ } << "Failed to find pattern in " << module << '!').str().c_str(), "Error", MB_OK | MB_ICONERROR);
		exit(EXIT_FAILURE);
	}
}
