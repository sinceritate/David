#pragma once

namespace LegitRage
{
	namespace Aim
	{
		extern void DropTarget();
		extern void FindTarget();
		extern void GoToTarget();
	}

	extern void RunLegitRage();
}