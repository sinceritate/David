#include "Cheat.h"

void Misc::Bhop()
{
	if (G::LocalPlayer->GetMoveType() == MOVETYPE_NOCLIP || G::LocalPlayer->GetMoveType() == MOVETYPE_LADDER || !G::LocalPlayer || !G::LocalPlayer->GetAlive())
		return;

	if (G::UserCmd->buttons & IN_JUMP && !(G::LocalPlayer->GetFlags() & FL_ONGROUND))
	{
		G::UserCmd->buttons &= ~IN_JUMP;
	}
	else if (rand() % 100 > Opts.Misc.Globals.JumpChance)
	{
		G::UserCmd->buttons &= ~IN_JUMP;
	}

	if (Opts.Misc.Globals.AutoStrafe && !(G::LocalPlayer->GetFlags() & FL_ONGROUND) && (G::UserCmd->mousedx < -1.f || G::UserCmd->mousedx > 1.f))
	{
		G::UserCmd->sidemove = G::UserCmd->mousedx < 0.f ? -400.f : 400.f;
	}
}

void Misc::AutoPistol()
{
	static bool fire = false;
	fire = !fire;

	if (G::UserCmd->buttons & IN_ATTACK)
	{
		if (fire)
		{
			G::UserCmd->buttons |= IN_ATTACK;
			G::SendPacket = true;
		}
		else
		{
			G::UserCmd->buttons &= ~IN_ATTACK;
		}
	}
}

void Misc::NameChange(const char* name)
{
	ConVar* nameConvar = I::Cvar->FindVar(xs("name"));
	*(int*)((DWORD)&nameConvar->fnChangeCallback + 0xC) = NULL;
	nameConvar->SetValue(name);
}

void Misc::DynamicClanTagChanger(std::string tag, int setting_mode)
{
	static auto pSetClanTag = reinterpret_cast<void(__fastcall*)(const char*, const char*)>(U::FindPattern(xs("engine.dll"), xs("53 56 57 8B DA 8B F9 FF 15")));

	static std::string old_tag = "";
	static int oldvalue = 0;
	static int old_setting_mode = -1;
	static int str_size = tag.size();

	if (old_setting_mode != setting_mode)
	{
		old_tag = "";
		old_setting_mode = setting_mode;
	}

	if (old_tag != tag && setting_mode > 1)
	{
		oldvalue = 0;
		old_tag = tag;
		str_size = tag.size();
	}

	int ServerTime = (float)I::Engine->GetServerTick() * I::Globals->interval_per_tick;

	switch (setting_mode)
	{
	case 0:
	{
		if (old_tag != tag)
		{
			old_tag = tag;
			pSetClanTag("", " ");
		}

		break;
	}
	case 1:
	{
		if (old_tag != tag)
		{
			old_tag = tag;
			pSetClanTag(tag.c_str(), " ");
		}

		break;
	}
	case 2:
	{
		int value = (ServerTime % (str_size * 2)) + 1;

		if (oldvalue != value)
		{
			if (value > str_size)
				value = str_size - (value - str_size);

			tag.erase(value);
			pSetClanTag(tag.c_str(), " ");
			oldvalue = value;
		}

		break;
	}
	case 3:
	{
		int value = ServerTime % str_size + 1;

		if (oldvalue != value)
		{
			std::string tag_now = "";

			tag_now.append(tag, value);

			tag.erase(value);
			tag_now += tag;

			pSetClanTag(tag_now.c_str(), " ");
			oldvalue = value;
		}

		break;
	}
	case 4:
	{
		int value = str_size - (ServerTime % str_size + 1);

		if (oldvalue != value)
		{
			std::string tag_now = "";

			tag_now.append(tag, value);

			tag.erase(value);
			tag_now += tag;

			pSetClanTag(tag_now.c_str(), " ");
			oldvalue = value;
		}

		break;
	}
	case 5:
	{
		int value = (ServerTime % (str_size * 2)) + 1;

		if (oldvalue != value)
		{
			if (value > str_size)
			{
				value -= str_size;
				tag.erase(0, value);
			}
			else
				tag.erase(value);

			pSetClanTag(tag.c_str(), " ");
			oldvalue = value;
		}

		break;
	}
	default:
		break;
	}
}

void Misc::ChatSpam()
{
	if (Opts.Misc.Secondary.chat_spam_mass_file.size() <= 0) return;

	static int oldvalue = 0;
	int value = (int)((float)I::Engine->GetServerTick() * I::Globals->interval_per_tick) % Opts.Misc.Secondary.chat_spam_mass_file.size();

	if (oldvalue != value)
	{
		oldvalue = value;
		I::Engine->ClientCmd_Unrestricted(Opts.Misc.Secondary.chat_spam_mass_file[value].c_str(), nullptr);
	}
}

void Misc::FakeCrouch()
{
	if (G::PressedKeys[Opts.Misc.Secondary.FakeCrouchKey])
	{
		auto net_channel = I::Engine->GetNetChannel();
		if (!net_channel || !G::LocalPlayer || G::LocalPlayer->GetHealth() <= 0)
		{
			G::SendPacket = true;
			return;
		}

		if (net_channel->m_nChokedPackets >= 14)
			G::SendPacket = true;
		else
			G::SendPacket = false;

		if(!Opts.Misc.Globals.InfinityCrouch)
			G::UserCmd->buttons |= IN_BULLRUSH;

		bool abuse_crouch = net_channel->m_nChokedPackets >= 7;
		if (abuse_crouch)
			G::UserCmd->buttons |= IN_DUCK;
		else
			G::UserCmd->buttons &= ~IN_DUCK;
	}
}

int LagCompBreak()
{
	if (!G::LocalPlayer || !G::LocalPlayer->GetAlive())
		return 1;

	auto velocity = G::LocalPlayer->GetVelocity();
	velocity.z = 0.f;
	auto speed = velocity.Length();
	auto distance_per_tick = speed * I::Globals->interval_per_tick;
	int choked_ticks = std::ceilf(64.f / distance_per_tick);
	return std::min<int>(choked_ticks, 14.f);
}

void FakeLag()
{
	if (!G::PressedKeys[Opts.Misc.Secondary.FakeCrouchKey])
	{
		static int choke_amount = 0;
		static int choked_amount = 0;

		//auto net_channel = I::Engine->GetNetChannel();
		if (/*!net_channel ||*/ !G::LocalPlayer || G::LocalPlayer->GetHealth() <= 0)
		{
			G::SendPacket = true;
			return;
		}

		if (G::UserCmd->buttons & IN_ATTACK || G::UserCmd->buttons & IN_ATTACK2 || (G::LocalPlayer->GetFlags() & FL_ONGROUND && G::UserCmd->buttons & IN_JUMP))
		{
			G::SendPacket = true;
			return;
		}

		if (!(G::LocalPlayer->GetFlags() & FL_ONGROUND))
		{
			switch (Opts.Misc.Secondary.FakeLagType % 2)
			{
			case 0: choke_amount = Opts.Misc.Secondary.JumpingAmount; break;
			case 1: choke_amount = LagCompBreak(); break;
			}
		}
		else if (G::LocalPlayer->GetVelocity().Length2D() > 0)
		{
			switch (Opts.Misc.Secondary.FakeLagType % 2)
			{
			case 0: choke_amount = Opts.Misc.Secondary.MovingAmount; break;
			case 1: choke_amount = LagCompBreak(); break;
			}
		}
		else if (G::LocalPlayer->GetVelocity().Length2D() == 0)
		{
			switch (Opts.Misc.Secondary.FakeLagType % 2)
			{
			case 0: choke_amount = Opts.Misc.Secondary.StandingAmount; break;
			case 1: choke_amount = LagCompBreak(); break;
			}
		}
		else
		{
			G::SendPacket = true;
			return;
		}

		G::SendPacket = choked_amount >= min(14, choke_amount);

		if (/*net_channel->m_nChokedPackets*/ G::SendPacket)
			choked_amount = 0;
		else
			++choked_amount;
	}
}

inline float FastSqrt(float x)
{
	unsigned int i = *(unsigned int*)&x;
	i += 127 << 23;
	i >>= 1;
	return *(float*)&i;
}

void RealAhead()
{
	auto net_channel = I::Engine->GetNetChannel();
	if (!net_channel) return;

	bool abuse = I::Engine->GetNetChannel()->m_nChokedPackets >= Opts.Misc.Secondary.StandingAmount / 2 + 1;
	//bool aaabuse = false;
	//
	//if (aaabuse)
	//{
		if (abuse)
		{
			//G::UserCmd->forwardmove = speed;
			G::UserCmd->sidemove = -450;
			//G::UserCmd->buttons |= IN_LEFT;
			//G::UserCmd->buttons &= ~IN_RIGHT;
		}
		else
		{
			G::UserCmd->sidemove = 450;
			//aaabuse = false;
			//G::UserCmd->buttons |= IN_RIGHT;
			//G::UserCmd->buttons &= ~IN_LEFT;
		}
	//}
	//else
	//{
	//	if (abuse)
	//	{
	//		//G::UserCmd->forwardmove = speed;
	//		G::UserCmd->sidemove = -450;
	//		//G::UserCmd->buttons |= IN_LEFT;
	//		//G::UserCmd->buttons &= ~IN_RIGHT;
	//	}
	//	else
	//	{
	//		G::UserCmd->sidemove = 450;
	//		aaabuse = true;
	//		//G::UserCmd->buttons |= IN_RIGHT;
	//		//G::UserCmd->buttons &= ~IN_LEFT;
	//	}
	//}
}

#define Sqrt( x ) ( x * x )

void SlowWalk(float Speed)
{
	//if (!c_config::get().fake_walk)
	//	return;

	//if (Speed <= 0.f)
	//	return;
	//
	//float min_speed = (float)(FastSqrt(Sqrt(G::UserCmd->forwardmove) + Sqrt(G::UserCmd->sidemove) + Sqrt(G::UserCmd->upmove)));
	//
	//if (min_speed <= 0.f)
	//	return;
	//
	//if (G::UserCmd->buttons & IN_DUCK)
	//	Speed *= 2.94117647f;
	//
	//if (min_speed <= Speed)
	//	return;
	// 
	//float speed = Speed / min_speed;
	//
	//auto local_player = G::LocalPlayer;
	//
	//if (G::LocalPlayer->GetFlags() & FL_ONGROUND) {
	//	int movetype = G::LocalPlayer->GetMoveType();
	//	if (!(movetype == 8 || movetype == 9)) {
	//		//if (GetAsyncKeyState(c_config::get().fake_walk_key)) {
	//			auto net_channel = I::Engine->GetNetChannel();
	//			if (!net_channel || !G::LocalPlayer || G::LocalPlayer->GetHealth() <= 0)
	//			{
	//				G::SendPacket = true;
	//				return;
	//			}
	//
	//			int choked = net_channel->m_nChokedPackets;
	//			choked = choked > 7 ? 0 : choked + 1;
	//			G::UserCmd->forwardmove = choked < 2 || choked > 5 ? 0 : G::UserCmd->forwardmove * speed;
	//			G::UserCmd->sidemove = choked < 2 || choked > 5 ? 0 : G::UserCmd->sidemove* speed;
	//			G::UserCmd->upmove = choked < 2 || choked > 5 ? 0 : G::UserCmd->upmove * speed;
	//			G::SendPacket = choked < 1;
	//		//}
	//	}
	//}

	if (Speed <= 0.f)
		return;
	
	float min_speed = (float)(FastSqrt(Sqrt(G::UserCmd->forwardmove) + Sqrt(G::UserCmd->sidemove) + Sqrt(G::UserCmd->upmove)));
	
	if (min_speed <= 0.f)
		return;
	
	if (G::UserCmd->buttons & IN_DUCK)
		Speed *= 2.94117647f;
	
	if (min_speed <= Speed)
		return;
	 
	float speed = Speed / min_speed;
	 
	G::UserCmd->forwardmove *= speed;
	G::UserCmd->sidemove *= speed;
	G::UserCmd->upmove *= speed;
	
	G::SendPacket = true;
}

void AutoKnife(CBaseEntity* pEntity)
{
	float dist = M::VectorDistance(G::LocalPlayer->GetOrigin(), pEntity->GetOrigin());

	if (dist > 80.5f) return;

	QAngle dst = M::CalcAngle(G::LocalPlayer->GetEyePosition(), pEntity->GetPredicted(pEntity->GetBonePosition(5)));

	G::UserCmd->viewangles = dst.Normalized();
	
	int hp = pEntity->GetHealth();
	bool armored = pEntity->GetArmor() > 0 ? true : false;

	if (hp <= 65 && !armored && dist <= 63.5)
	{
		G::UserCmd->buttons |= IN_ATTACK2;
		G::SendPacket = true;
	}
	else if (hp <= 55 && armored && dist <= 63.5)
	{
		G::UserCmd->buttons |= IN_ATTACK2;
		G::SendPacket = true;
	}
	else
	{
		G::UserCmd->buttons |= IN_ATTACK;
		G::SendPacket = true;
	}
}

void AutoZeus(CBaseEntity* pEntity)
{
	float dist = M::VectorDistance(G::LocalPlayer->GetOrigin(), pEntity->GetOrigin());
	
	if (dist > 170.f) return;

	QAngle dst = M::CalcAngle(G::LocalPlayer->GetEyePosition(), pEntity->GetPredicted(pEntity->GetBonePosition(5)));

	G::UserCmd->viewangles = dst.Normalized();

	static bool fired = false;

	if (!fired)
	{
		G::UserCmd->buttons |= IN_ATTACK;
		fired = true;
	}
	else if (fired)
	{
		G::UserCmd->buttons &= ~IN_ATTACK;
		fired = false;
	}
}

void AutomaticStart()
{
	for (int i = 0; i < 64; ++i)
	{
		CBaseEntity* pEntity = I::ClientEntList->GetClientEntity(i);

		if (!pEntity || pEntity->GetHealth() <= 0 || pEntity->GetDormant() || pEntity == G::LocalPlayer)
			continue;
		if (!pEntity->IsEnemy() || !pEntity->IsVisible(BONE_CHEST))
			continue;

		if (Opts.Misc.Globals.AutoKnife && G::LocalPlayer->GetWeapon()->IsKnife())
			AutoKnife(pEntity);
		else if (Opts.Misc.Globals.AutoZeus && ((*G::LocalPlayer->GetWeapon()->GetItemDefinitionIndex()) == WEAPON_ZEUSX27))
			AutoZeus(pEntity);
	}
}

#define WALK_DIST 250
#define MIN_VELOCITY 200
#define WALK_CHECK_ANGLES 45
#define WALK_MAX_ANGLES 180 // 360 / 2
#define WALK_ANGLE_PLUS 4
#define ANGLE_CLAMP_VALUE 2 // ����� �������� ��������� ���� �� ���?

void WalkBot()
{
	static Vector vec_massive = Vector(100, 100, 100);
	static Vector old_vector;
	static int current_num = 0;


	//QAngle viewangle = G::UserCmd->viewangles;
	//Vector vecEyePos = G::LocalPlayer->GetEyePosition();

	//Vector forward;
	//QAngle viewangle = G::UserCmd->viewangles;
	//
	//float flVelocity = G::LocalPlayer->GetVelocity().Length();
	//
	//for (int i = -1; i <= 1; i += 1)
	//{
	//	G::UserCmd->viewangles = viewangle + QAngle(0, WALK_CHECK_ANGLES * i, 0);
	//	Vector vecEyePos = G::LocalPlayer->GetEyePosition();
	//
	//	M::AngleVectors(viewangle + QAngle(0, WALK_CHECK_ANGLES * i, 0), &forward);
	//
	//	trace_t tr;
	//	U::TraceLine(vecEyePos, vecEyePos + (forward * WALK_DIST), MASK_SOLID, G::LocalPlayer, &tr);
	//
	//	if (tr.startsolid) continue;
	//
	//	if (tr.fraction < 1.00f)
	//	{
	//		//// �������� CHECK_ANGLE ����� �� CHECK_MAX_ANGLE ��������, ��� �� ������ ���� ����� ������������
	//		//for (float j = 0; j < WALK_MAX_ANGLES; j += WALK_ANGLE_PLUS)
	//		//{
	//		//	static bool bSwap = false; bSwap = !bSwap;
	//		//	float angTemp = bSwap ? j : -j;
	//		//
	//		//	trace_t tr1;
	//		//	U::TraceLine(vecEyePos, vecEyePos + (forward * WALK_DIST) + Vector(0, angTemp, 0), MASK_SOLID, G::LocalPlayer, &tr);
	//		//	if (tr1.startsolid || tr1.fraction < 1.f)
	//		//		continue;
	//		//
	//		//	// ��� �� �� ������ �������� ��� ����� ������ ����������
	//		//	if (j > ANGLE_CLAMP_VALUE)
	//		//		angTemp = angTemp < 0 ? -ANGLE_CLAMP_VALUE : ANGLE_CLAMP_VALUE;
	//		//
	//		//	// ������ ������ � ������� � ������� ��������
	//		//	G::UserCmd->sidemove = bSwap ? 450 : -450;
	//		//	G::UserCmd->viewangles.y += angTemp;
	//
	//		for (int j = 0; j < WALK_MAX_ANGLES; j += WALK_ANGLE_PLUS)
	//		{
	//			//static bool pm = false; // false = - true = +
	//
	//			trace_t tr2;
	//
	//			M::AngleVectors(viewangle + QAngle(0, j, 0), &forward);
	//			U::TraceLine(vecEyePos, vecEyePos + (forward * WALK_DIST), MASK_SOLID, G::LocalPlayer, &tr2);
	//
	//			float angTemp = j;
	//
	//			if (tr2.startsolid || tr2.fraction < 1.00f)
	//			{
	//				M::AngleVectors(viewangle + QAngle(0, -j, 0), &forward);
	//				U::TraceLine(vecEyePos, vecEyePos + (forward * WALK_DIST), MASK_SOLID, G::LocalPlayer, &tr2);
	//
	//				if (tr2.startsolid || tr2.fraction < 1.00f) continue;
	//
	//
	//				if (j > ANGLE_CLAMP_VALUE)
	//					angTemp = angTemp < 0 ? -ANGLE_CLAMP_VALUE : ANGLE_CLAMP_VALUE;
	//
	//				G::UserCmd->sidemove = -450;
	//				G::UserCmd->viewangles.y -= angTemp;
	//				I::Engine->SetViewAngles(G::UserCmd->viewangles);
	//				break;
	//			}
	//
	//			if (j > ANGLE_CLAMP_VALUE)
	//				angTemp = angTemp < 0 ? -ANGLE_CLAMP_VALUE : ANGLE_CLAMP_VALUE;
	//
	//			G::UserCmd->sidemove = 450;
	//			G::UserCmd->viewangles.y += angTemp;
	//			I::Engine->SetViewAngles(G::UserCmd->viewangles);
	//			break;
	//		}
	//
	//		//	break;
	//		//}
	//	}
	//}

	// ���� �������� ������ MIN_VELOCITY, ����� �� ����������/��������, � �����������
	//if (flVelocity < MIN_VELOCITY)
	//{
	//	G::UserCmd->buttons |= IN_FORWARD;
	//	G::UserCmd->forwardmove = 250;
	//
	//	return;
	//}
	//else
	//{
	//	// �������
	//	if (G::LocalPlayer->GetFlags() & FL_ONGROUND)
	//	{
	//		G::UserCmd->buttons |= IN_JUMP;
	//	}
	//	else if (G::UserCmd->buttons & IN_JUMP && !(G::LocalPlayer->GetFlags() & FL_ONGROUND))
	//	{
	//		G::UserCmd->buttons &= ~IN_JUMP;
	//	}
	//
	//	// ����-��������
	//	static bool bSwapStrafe = false; bSwapStrafe = !bSwapStrafe;
	//
	//	if (bSwapStrafe) {
	//		G::UserCmd->viewangles.y += 2;
	//		G::UserCmd->sidemove = 450;
	//	} else {
	//		G::UserCmd->viewangles.y -= 2;
	//		G::UserCmd->sidemove = -450;
	//	}
	//}
}
	
void Misc::Start()
{
	if (G::LocalPlayer && G::LocalPlayer->GetAlive() && I::Engine->IsInGame())
	{
		if (Opts.Misc.Secondary.FakeLag && !G::PressedKeys[Opts.Misc.Secondary.SlowWalkKey])
		{
			FakeLag();
		}

		if (Opts.Misc.Globals.BunnyHop)
		{
			Misc::Bhop();
		}

		if (Opts.Misc.Globals.AutoPistol && (G::LocalPlayer->GetWeapon()->GetType() == WT_PISTOLS && *G::LocalPlayer->GetWeapon()->GetItemDefinitionIndex() != WEAPON_REVOLVER))
		{
			Misc::AutoPistol();
		}

		if (Opts.Misc.Globals.FlashAlpha != 255)
		{
			G::LocalPlayer->ModulateFlashAlpha() = (float)Opts.Misc.Globals.FlashAlpha;
		}

		if (GetAsyncKeyState(VK_TAB) && Opts.Misc.Globals.RankReveal)
		{
			U::ServerRankRevealAll();
		}

		//WalkBot();

		//static bool Once = false;
		//if (G::LocalPlayer->GetFlashDuration() > 0.f)
		//{
		//	if (!Once)
		//	{
		//		G::FlashTime = I::Globals->curtime + G::LocalPlayer->GetFlashDuration();
		//		Once = true;
		//	}
		//}
		//else
		//{
		//	Once = false;
		//}

		if (Opts.Misc.Secondary.FakeCrouch)
		{
			FakeCrouch();
		}

		if (Opts.Misc.Globals.AutoKnife || Opts.Misc.Globals.AutoZeus)
		{
			FixMovement::Start();
			AutomaticStart();
			FixMovement::End();
		}

		if (Opts.Misc.Secondary.SlowWalk && G::PressedKeys[Opts.Misc.Secondary.SlowWalkKey])
		{
			SlowWalk(Opts.Misc.Secondary.SlowWalkSpeed);
		}

		if (Opts.Misc.Globals.InfinityCrouch)
		{
			G::UserCmd->buttons |= IN_BULLRUSH;
		}

		if (Opts.Misc.Secondary.ChatSpam && I::Engine->IsInGame() && G::LocalPlayer)
		{
			Misc::ChatSpam();
		}

		Misc::DynamicClanTagChanger(Opts.Misc.Secondary.ClanTag, Opts.Misc.Secondary.ClanTagMode);

		static BYTE hads_changed = 0;
		if (Opts.Misc.Globals.HadsChanger)
		{
			int weapon_type = G::LocalPlayer->GetWeapon()->GetType();

			if (weapon_type != WT_KNIFES && hads_changed != 1)
			{
				std::string temp_str = Opts.Misc.Globals.HadsChangerOverride ? "cl_righthand 0" : "cl_righthand 1";
				I::Engine->ClientCmd_Unrestricted(temp_str.c_str(), nullptr);
				hads_changed = 1;
			}
			else if (weapon_type == WT_KNIFES && hads_changed == 1)
			{
				std::string temp_str = Opts.Misc.Globals.HadsChangerOverride ? "cl_righthand 1" : "cl_righthand 0";
				I::Engine->ClientCmd_Unrestricted(temp_str.c_str(), nullptr);
				hads_changed = 2;
			}
		}

		static bool walls_enabled = false;
		static Color old_walls_color = 0;

		if (!Opts.Visuals.Other.WallsColored)
		{
			if (walls_enabled)
			{
				for (unsigned short i = I::MaterialSystem->FirstMaterial(); i != I::MaterialSystem->InvalidMaterial(); i = I::MaterialSystem->NextMaterial(i))
				{
					IMaterial *pMaterial = I::MaterialSystem->GetMaterial(i);
					if (!pMaterial) continue;

					if (strstr(pMaterial->GetTextureGroupName(), "World"))
					{
						pMaterial->AlphaModulate(1);
						pMaterial->ColorModulate(1, 1, 1);
					}
				}

				old_walls_color = 0;
				walls_enabled = false;
			}
		}
		else
		{
			if (old_walls_color != Opts.Colors.Misc.Walls)
			{
				for (unsigned short i = I::MaterialSystem->FirstMaterial(); i != I::MaterialSystem->InvalidMaterial(); i = I::MaterialSystem->NextMaterial(i))
				{

					IMaterial *pMaterial = I::MaterialSystem->GetMaterial(i);

					if (!pMaterial)
						continue;

					if (strstr(pMaterial->GetTextureGroupName(), "World"))
					{
						pMaterial->AlphaModulate(Opts.Colors.Misc.Walls.aBase());
						pMaterial->ColorModulate(Opts.Colors.Misc.Walls.rBase(), Opts.Colors.Misc.Walls.gBase(), Opts.Colors.Misc.Walls.bBase());
					}
				}

				old_walls_color = Opts.Colors.Misc.Walls;
				walls_enabled = true;
			}
		}

		static bool sky_enabled = false;
		static Color old_sky_color = 0;

		if (!Opts.Visuals.Other.SkyColored)
		{
			if (sky_enabled)
			{
				for (unsigned short i = I::MaterialSystem->FirstMaterial(); i != I::MaterialSystem->InvalidMaterial(); i = I::MaterialSystem->NextMaterial(i))
				{
					IMaterial *pMaterial = I::MaterialSystem->GetMaterial(i);
					if (!pMaterial) continue;

					if (strstr(pMaterial->GetTextureGroupName(), "SkyBox"))
					{
						pMaterial->AlphaModulate(1);
						pMaterial->ColorModulate(1, 1, 1);
					}
				}

				old_sky_color = 0;
				sky_enabled = false;
			}
		}
		else
		{
			if (old_sky_color != Opts.Colors.Misc.Sky)
			{
				for (unsigned short i = I::MaterialSystem->FirstMaterial(); i != I::MaterialSystem->InvalidMaterial(); i = I::MaterialSystem->NextMaterial(i))
				{

					IMaterial *pMaterial = I::MaterialSystem->GetMaterial(i);

					if (!pMaterial)
						continue;

					if (strstr(pMaterial->GetTextureGroupName(), "SkyBox"))
					{
						pMaterial->AlphaModulate(Opts.Colors.Misc.Sky.aBase());
						pMaterial->ColorModulate(Opts.Colors.Misc.Sky.rBase(), Opts.Colors.Misc.Sky.gBase(), Opts.Colors.Misc.Sky.bBase());
					}
				}

				old_sky_color = Opts.Colors.Misc.Sky;
				sky_enabled = true;
			}
		}

		static bool prop_enabled = false;
		static Color old_prop_color = 0;

		if (!Opts.Visuals.Other.PropColored)
		{
			if (prop_enabled)
			{
				for (unsigned short i = I::MaterialSystem->FirstMaterial(); i != I::MaterialSystem->InvalidMaterial(); i = I::MaterialSystem->NextMaterial(i))
				{
					IMaterial *pMaterial = I::MaterialSystem->GetMaterial(i);
					if (!pMaterial) continue;

					if (strstr(pMaterial->GetTextureGroupName(), "StaticProp"))
					{
						pMaterial->AlphaModulate(1);
						pMaterial->ColorModulate(1, 1, 1);
					}
				}
			}

			old_prop_color = 0;
			prop_enabled = false;
		}
		else
		{
			if (old_prop_color != Opts.Colors.Misc.Prop)
			{
				for (unsigned short i = I::MaterialSystem->FirstMaterial(); i != I::MaterialSystem->InvalidMaterial(); i = I::MaterialSystem->NextMaterial(i))
				{
					IMaterial *pMaterial = I::MaterialSystem->GetMaterial(i);

					if (!pMaterial)
						continue;

					if (strstr(pMaterial->GetTextureGroupName(), "StaticProp"))
					{
						pMaterial->AlphaModulate(Opts.Colors.Misc.Prop.aBase());
						pMaterial->ColorModulate(Opts.Colors.Misc.Prop.rBase(), Opts.Colors.Misc.Prop.gBase(), Opts.Colors.Misc.Prop.bBase());
					}
				}

				prop_enabled = true;
			}
		}
	}
	//if (Opts.Misc.Globals.FastSwitch)
	//{
	//	int index = G::LocalPlayer->GetWeapon()->GetAimIndex();
	//
	//	static bool unk1 = false;
	//
	//	if ((index == 27 || index == 22) && G::LocalPlayer->GetWeapon()->GetNextPrimaryAttack() > 0)
	//	{
	//		G::UserCmd->buttons |= IN_WEAPON2;
	//
	//		unk1 = true;
	//	}
	//	else if (unk1)
	//	{
	//		G::UserCmd->buttons |= IN_WEAPON1;
	//
	//		unk1 = false;
	//	}
	//}

	if (Opts.Misc.Other.BuyBot.Enable && !G::IsInDangerZone)
	{
		if (G::RestartBuyBot && G::LocalPlayer && G::LocalPlayer->GetHealth() > 0)
		{
			switch (Opts.Misc.Other.BuyBot.Weapon)
			{
			case 1: I::Engine->ClientCmd_Unrestricted("buy galilar", nullptr); break;
			case 2: I::Engine->ClientCmd_Unrestricted("buy ak47", nullptr); break;
			case 3: I::Engine->ClientCmd_Unrestricted("buy ssg08", nullptr); break;
			case 4: I::Engine->ClientCmd_Unrestricted("buy sg556", nullptr); break;
			case 5: I::Engine->ClientCmd_Unrestricted("buy awp", nullptr); break;
			case 6: I::Engine->ClientCmd_Unrestricted("buy g3sg1", nullptr); break;
			case 7: I::Engine->ClientCmd_Unrestricted("buy mac10", nullptr); break;
			case 8: I::Engine->ClientCmd_Unrestricted("buy mp7", nullptr); break;
			case 9: I::Engine->ClientCmd_Unrestricted("buy ump45", nullptr); break;
			case 10: I::Engine->ClientCmd_Unrestricted("buy p90", nullptr); break;
			case 11: I::Engine->ClientCmd_Unrestricted("buy bizon", nullptr); break;
			case 12: I::Engine->ClientCmd_Unrestricted("buy nova", nullptr); break;
			case 13: I::Engine->ClientCmd_Unrestricted("buy xm1014", nullptr); break;
			case 14: I::Engine->ClientCmd_Unrestricted("buy mag7", nullptr); break;
			case 15: I::Engine->ClientCmd_Unrestricted("buy m249", nullptr); break;
			case 16: I::Engine->ClientCmd_Unrestricted("buy negev", nullptr); break;
			default: break;
			}

			switch (Opts.Misc.Other.BuyBot.Pistol)
			{
			case 1: I::Engine->ClientCmd_Unrestricted("buy glock", nullptr); break;
			case 2: I::Engine->ClientCmd_Unrestricted("buy elite", nullptr); break;
			case 3: I::Engine->ClientCmd_Unrestricted("buy p250", nullptr); break;
			case 4: I::Engine->ClientCmd_Unrestricted("buy tec9", nullptr); break;
			case 5: I::Engine->ClientCmd_Unrestricted("buy deagle", nullptr); break;
			default: break;
			}

			switch (Opts.Misc.Other.BuyBot.grenade_1)
			{
			case 1: I::Engine->ClientCmd_Unrestricted("buy molotov", nullptr); break;
			case 2: I::Engine->ClientCmd_Unrestricted("buy decoy", nullptr); break;
			case 3: I::Engine->ClientCmd_Unrestricted("buy flashbang", nullptr); break;
			case 4: I::Engine->ClientCmd_Unrestricted("buy hegrenade", nullptr); break;
			case 5: I::Engine->ClientCmd_Unrestricted("buy smokegrenade", nullptr); break;
			default: break;
			}

			switch (Opts.Misc.Other.BuyBot.grenade_2)
			{
			case 1: I::Engine->ClientCmd_Unrestricted("buy molotov", nullptr); break;
			case 2: I::Engine->ClientCmd_Unrestricted("buy decoy", nullptr); break;
			case 3: I::Engine->ClientCmd_Unrestricted("buy flashbang", nullptr); break;
			case 4: I::Engine->ClientCmd_Unrestricted("buy hegrenade", nullptr); break;
			case 5: I::Engine->ClientCmd_Unrestricted("buy smokegrenade", nullptr); break;
			default: break;
			}

			switch (Opts.Misc.Other.BuyBot.grenade_3)
			{
			case 1: I::Engine->ClientCmd_Unrestricted("buy molotov", nullptr); break;
			case 2: I::Engine->ClientCmd_Unrestricted("buy decoy", nullptr); break;
			case 3: I::Engine->ClientCmd_Unrestricted("buy flashbang", nullptr); break;
			case 4: I::Engine->ClientCmd_Unrestricted("buy hegrenade", nullptr); break;
			case 5: I::Engine->ClientCmd_Unrestricted("buy smokegrenade", nullptr); break;
			default: break;
			}

			switch (Opts.Misc.Other.BuyBot.grenade_4)
			{
			case 1: I::Engine->ClientCmd_Unrestricted("buy molotov", nullptr); break;
			case 2: I::Engine->ClientCmd_Unrestricted("buy decoy", nullptr); break;
			case 3: I::Engine->ClientCmd_Unrestricted("buy flashbang", nullptr); break;
			case 4: I::Engine->ClientCmd_Unrestricted("buy hegrenade", nullptr); break;
			case 5: I::Engine->ClientCmd_Unrestricted("buy smokegrenade", nullptr); break;
			default: break;
			}

			switch (Opts.Misc.Other.BuyBot.Armor)
			{
			case 1: I::Engine->ClientCmd_Unrestricted("buy vest", nullptr); break;
			case 2: I::Engine->ClientCmd_Unrestricted("buy vesthelm", nullptr); break;
			default: break;
			}

			if (Opts.Misc.Other.BuyBot.zeus) I::Engine->ClientCmd_Unrestricted("buy taser", nullptr);
			if (Opts.Misc.Other.BuyBot.defuse_kit) I::Engine->ClientCmd_Unrestricted("buy defuser", nullptr);
			
			G::RestartBuyBot = false;
		}
	}

	// convars

	static bool initiolize = false;
	static int convar_flags = 0;

	if (!initiolize)
	{
		G::ZoomSensitivityRatioConVar = I::Cvar->FindVar(rxs("zoom_sensitivity_ratio_mouse"));
		G::OldZoomSensitivityRatio = -G::ZoomSensitivityRatioConVar->GetFloat();

		G::RagdollGravityConVar = I::Cvar->FindVar(rxs("cl_ragdoll_gravity"));
		G::OldRagdollGravity = -G::RagdollGravityConVar->GetFloat();

		G::PostProcessingDisable = *(bool**)(U::FindPattern(rxs("client_panorama.dll"), rxs("80 3D ? ? ? ? ? 53 56 57 0F 85")) + 0x2);
		G::OldPostProcessingDisable = *G::PostProcessingDisable;

		G::viewmodel_offset_convar_x = I::Cvar->FindVar(rxs("viewmodel_offset_x"));
		G::viewmodel_offset_convar_y = I::Cvar->FindVar(rxs("viewmodel_offset_y"));
		G::viewmodel_offset_convar_z = I::Cvar->FindVar(rxs("viewmodel_offset_z"));
		*(int*)((DWORD)&G::viewmodel_offset_convar_x->fnChangeCallback + 0xC) = NULL;
		*(int*)((DWORD)&G::viewmodel_offset_convar_y->fnChangeCallback + 0xC) = NULL;
		*(int*)((DWORD)&G::viewmodel_offset_convar_z->fnChangeCallback + 0xC) = NULL;
		G::old_viewmodel_offset_x = -G::viewmodel_offset_convar_x->GetFloat();
		G::old_viewmodel_offset_y = -G::viewmodel_offset_convar_y->GetFloat();
		G::old_viewmodel_offset_z = -G::viewmodel_offset_convar_z->GetFloat();

		G::r_modelAmbientMin_convar = I::Cvar->FindVar(rxs("r_modelAmbientMin")); // white players 0 - 10
		G::mat_force_tonemap_scale_convar = I::Cvar->FindVar(rxs("mat_force_tonemap_scale")); // dark map
		G::old_r_modelAmbientMin = -G::r_modelAmbientMin_convar->GetFloat();
		G::old_mat_force_tonemap_scale = -G::mat_force_tonemap_scale_convar->GetFloat();

		initiolize = true;
	}

	if (Opts.Misc.Globals.FixSensivityInScope && !(convar_flags & 0x1))
	{
		G::ZoomSensitivityRatioConVar->SetValue(0);
		convar_flags |= 0x1;
	}
	else if (!Opts.Misc.Globals.FixSensivityInScope && (convar_flags & 0x1))
	{
		G::ZoomSensitivityRatioConVar->SetValue(-G::OldZoomSensitivityRatio);
		convar_flags &= ~0x1;
	}

	if (Opts.Misc.Secondary.ForceRagDoll && !(convar_flags & 0x2))
	{
		G::RagdollGravityConVar->SetValue(-1000);
		convar_flags |= 0x2;
	}
	else if (!Opts.Misc.Secondary.ForceRagDoll && (convar_flags & 0x2))
	{
		G::RagdollGravityConVar->SetValue(-G::OldRagdollGravity);
		convar_flags &= ~0x2;
	}

	if (Opts.Misc.Globals.FPSBoost && !(convar_flags & 0x4))
	{
		*G::PostProcessingDisable = true;
		convar_flags |= 0x4;
	}
	else if (!Opts.Misc.Globals.FPSBoost && (convar_flags & 0x4))
	{
		*G::PostProcessingDisable = false;
		convar_flags &= ~0x4;
	}

	if (G::LocalPlayer && G::LocalPlayer->GetAlive() && I::Engine->IsInGame())
	{
		if (Opts.Misc.Globals.RealAiming)
		{
			static bool Key_Click = false, in_aim = false;

			if (!Key_Click && GetAsyncKeyState(Opts.Misc.Globals.RealAimingKey))
			{
				if (!Key_Click)
					in_aim = !in_aim;

				Key_Click = true;
			}
			else if (!GetAsyncKeyState(Opts.Misc.Globals.RealAimingKey))
				Key_Click = false;

			static int old_weapon = 0;

			static bool aiming = false;

			if (old_weapon != G::LocalPlayer->GetWeapon()->GetAimIndex())
			{
				in_aim = false;
				aiming = false;
				old_weapon = G::LocalPlayer->GetWeapon()->GetAimIndex();
			}

			static bool old_duck = false;

			if (old_duck != (G::UserCmd->buttons & IN_DUCK))
			{
				aiming = false;
				old_duck = G::UserCmd->buttons & IN_DUCK;
			}

			if (in_aim)
			{
				if (!aiming)
				{
					Vector position = Vector(0, 0, 0);

					int cur_weapon = G::LocalPlayer->GetWeapon()->GetAimIndex();

					switch (cur_weapon)
					{

					// Pistols
					case 3: position = Vector(-3.810f, 2.000f, 0.550f); break; // DEAGLE
					case 8: position = Vector(-2.800f, 2.000f, 1.100f); break; // P250
					case 0: position = Vector(-2.830f, 2.000f, 1.300f); break; // USPS
					case 7: position = Vector(-2.800f, 2.000f, 1.100f); break; // P2000
					case 6: position = Vector(-2.820f, 2.000f, 1.130f); break; // GLOCK
					case 5: position = Vector(-2.780f, 2.000f, 0.900f); break; // FIVESEVEN
					case 9: position = Vector(-5.145f, 2.000f, 2.675f); break; // TEC9
					case 1: position = Vector(-3.740f, 2.000f, 0.777f); break; // REVOLVER
					case 2: position = Vector(-2.820f, 2.000f, 1.100f); break; // CZ75

					// SMG
					case 12: position = Vector(-4.740f, 2.000f, 0.860f); break; // MP9
					case 11: position = Vector(-5.270f, 2.000f, 1.000f); break; // MP7
					case 13: position = Vector(-5.200f, 2.000f, 1.680f); break; // MP5SD
					case 16: position = Vector(-5.095f, 2.000f, 1.400f); break; // UMP45
					case 14: position = Vector(-5.096f, 2.000f, 0.967f); break; // BIZON
					case 15: position = Vector(-5.168f, 2.000f, -0.35f); break; // P90
					case 10: position = Vector(-6.130f, 2.000f, 2.130f); break; // MAC10

					// riflers
					case 17: position = Vector(-5.010f, 4.000f, 1.190f); break; // AK47
					case 21: position = Vector(-5.141f, 4.000f, 0.853f); break; // M4A1
					case 20: position = Vector(-5.230f, 4.000f, 0.470f); break; // M4A1S
					case 19: position = Vector(-5.330f, 4.000f, 1.650f); break; // GALIL
					case 18: position = Vector(-6.240f, 4.000f, 1.235f); break; // FAMAS

					// heavy
					case 30: position = Vector(-4.322f, 4.000f, 1.967f); break; // SAWEDOFF
					case 31: position = Vector(-4.300f, 4.000f, 2.875f); break; // XM1014
					case 28: position = Vector(-6.379f, 4.000f, 3.295f); break; // MAG7
					case 29: position = Vector(-4.265f, 4.000f, 2.640f); break; // NOVA
					case 32: position = Vector(-7.600f, 4.000f, 1.600f); break; // M249
					case 33: position = Vector(-7.800f, 4.000f, 2.161f); break; // NEGEV

					default:
						if (Opts.Misc.Changer.View.bViewModel)
							position = Vector(Opts.Misc.Changer.View.fViewModelX, Opts.Misc.Changer.View.fViewModelY, Opts.Misc.Changer.View.fViewModelZ);
						else
							position = Vector(-G::old_viewmodel_offset_x, -G::old_viewmodel_offset_y, -G::old_viewmodel_offset_z);
						
						break;
					}

					// 4 + 2 heavy
					// 2 + 2 + 1 + 1 + 1 pp
					// 2 + 3 rifle

					if (G::UserCmd->buttons & IN_DUCK)
					{
						switch (cur_weapon)
						{
						
						// Pistols
						case 3: position = Vector(-3.500f, 2.000f, 0.700f); break; // DEAGLE
						case 8: position = Vector(-2.450f, 2.000f, 1.080f); break; // P250
						case 0: position = Vector(-2.650f, 2.000f, 1.460f); break; // USPS
						case 7: position = Vector(-2.630f, 2.000f, 1.150f); break; // P2000
						case 6: position = Vector(-2.620f, 2.000f, 1.500f); break; // GLOCK
						case 5: position = Vector(-2.450f, 2.000f, 1.050f); break; // FIVESEVEN
						case 9: position = Vector(-4.950f, 2.000f, 2.712f); break; // TEC9
						case 1: position = Vector(-3.510f, 2.000f, 0.900f); break; // REVOLVER
						case 2: position = Vector(-2.410f, 2.000f, 1.310f); break; // CZ75

						// SMG
						case 12: position = Vector(-4.252f, 2.000f, 1.070f); break; // MP9
						case 11: position = Vector(-4.750f, 2.000f, 1.250f); break; // MP7
						case 13: position = Vector(-4.645f, 2.000f, 1.965f); break; // MP5SD
						case 16: position = Vector(-4.580f, 2.000f, 1.678f); break; // UMP45
						case 14: position = Vector(-4.516f, 2.000f, 1.290f); break; // BIZON
						case 15: position = Vector(-4.645f, 2.000f, -0.097f); break; // P90
						case 10: position = Vector(-5.645f, 2.000f, 2.387f); break; // MAC10

						// riflers
						case 17: position = Vector(-4.750f, 4.000f, 1.340f); break; // AK47
						case 21: position = Vector(-5.020f, 4.000f, 0.891f); break; // M4A1
						case 20: position = Vector(-5.120f, 4.000f, 0.520f); break; // M4A1S
						case 19: position = Vector(-5.015f, 4.000f, 1.802f); break; // GALIL
						case 18: position = Vector(-6.240f, 4.000f, 1.235f); break; // FAMAS

						// heavy
						case 30: position = Vector(-4.064f, 4.000f, 2.161f); break; // SAWEDOFF
						case 31: position = Vector(-4.047f, 4.000f, 3.000f); break; // XM1014
						case 28: position = Vector(-6.129f, 4.000f, 3.387f); break; // MAG7
						case 29: position = Vector(-4.010f, 4.000f, 2.809f); break; // NOVA
						case 32: position = Vector(-7.100f, 4.000f, 1.742f); break; // M249
						case 33: position = Vector(-7.410f, 4.000f, 2.354f); break; // NEGEV

						default:
							if (Opts.Misc.Changer.View.bViewModel)
								position = Vector(Opts.Misc.Changer.View.fViewModelX, Opts.Misc.Changer.View.fViewModelY, Opts.Misc.Changer.View.fViewModelZ);
							else
								position = Vector(-G::old_viewmodel_offset_x, -G::old_viewmodel_offset_y, -G::old_viewmodel_offset_z);
							
							break;
						}
					}

					G::viewmodel_offset_convar_x->SetValue(position.x);
					G::viewmodel_offset_convar_y->SetValue(position.y);
					G::viewmodel_offset_convar_z->SetValue(position.z);

					aiming = true;
				}
			}
			else if (Opts.Misc.Changer.View.bViewModel)
			{
				G::viewmodel_offset_convar_x->SetValue(Opts.Misc.Changer.View.fViewModelX);
				G::viewmodel_offset_convar_y->SetValue(Opts.Misc.Changer.View.fViewModelY);
				G::viewmodel_offset_convar_z->SetValue(Opts.Misc.Changer.View.fViewModelZ);
				aiming = false;
			}
			else
			{
				G::viewmodel_offset_convar_x->SetValue(-G::old_viewmodel_offset_x);
				G::viewmodel_offset_convar_y->SetValue(-G::old_viewmodel_offset_y);
				G::viewmodel_offset_convar_z->SetValue(-G::old_viewmodel_offset_z);
				aiming = false;
			}
		}
		else
		{
			if (Opts.Misc.Changer.View.bViewModel)
			{
				G::viewmodel_offset_convar_x->SetValue(Opts.Misc.Changer.View.fViewModelX);
				G::viewmodel_offset_convar_y->SetValue(Opts.Misc.Changer.View.fViewModelY);
				G::viewmodel_offset_convar_z->SetValue(Opts.Misc.Changer.View.fViewModelZ);
			}
			else
			{
				G::viewmodel_offset_convar_x->SetValue(-G::old_viewmodel_offset_x);
				G::viewmodel_offset_convar_y->SetValue(-G::old_viewmodel_offset_y);
				G::viewmodel_offset_convar_z->SetValue(-G::old_viewmodel_offset_z);
			}
		}
	}

real_aiming_break:

	if (Opts.Misc.Globals.NightMode)
	{
		G::r_modelAmbientMin_convar->SetValue(Opts.Misc.Globals.PlayerBright);
		G::mat_force_tonemap_scale_convar->SetValue(Opts.Misc.Globals.MapBright);
		convar_flags |= 0x10;
	}
	else if (!Opts.Misc.Globals.NightMode && (convar_flags & 0x10))
	{
		G::r_modelAmbientMin_convar->SetValue(-G::old_r_modelAmbientMin);
		G::mat_force_tonemap_scale_convar->SetValue(-G::old_mat_force_tonemap_scale);
		convar_flags &= ~0x10;
	}
}