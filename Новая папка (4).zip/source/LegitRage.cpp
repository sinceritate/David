#include "Cheat.h"

int Bone_Legit_Rage;
float FOV_Legit_Rage;
bool Silent_Legit_Rage;
float HitChance_Legit_Rage;
float MinDamage_Legit_Rage;

void UpdateSettingsLegitRage()
{
	if (Opts.LegitBot.SettingMode == 0)
	{
		Bone_Legit_Rage = Opts.LegitRageBot.All_Legit.AimBot.TargetBone;
		FOV_Legit_Rage = Opts.LegitRageBot.All_Legit.AimBot.Fov;
		Silent_Legit_Rage = Opts.LegitRageBot.All_Legit.AimBot.pSilent;
		HitChance_Legit_Rage = Opts.LegitRageBot.All_Legit.AimBot.HitChance;
		MinDamage_Legit_Rage = Opts.LegitRageBot.All_Legit.AimBot.MinDamage;
	}
	else if (Opts.LegitBot.SettingMode == 1)
	{
		int type = G::LocalPlayer->GetWeapon()->GetType() - 4;

		Bone_Legit_Rage = Opts.LegitRageBot.WT_Legit[type].AimBot.TargetBone;
		FOV_Legit_Rage = Opts.LegitRageBot.WT_Legit[type].AimBot.Fov;
		Silent_Legit_Rage = Opts.LegitRageBot.WT_Legit[type].AimBot.pSilent;
		HitChance_Legit_Rage = Opts.LegitRageBot.WT_Legit[type].AimBot.HitChance;
		MinDamage_Legit_Rage = Opts.LegitRageBot.WT_Legit[type].AimBot.MinDamage;
	}
	else if (Opts.LegitBot.SettingMode == 2)
	{
		int weapon = G::LocalPlayer->GetWeapon()->GetAimIndex();

		Bone_Legit_Rage = Opts.LegitRageBot.EW_Legit[weapon].AimBot.TargetBone;
		FOV_Legit_Rage = Opts.LegitRageBot.EW_Legit[weapon].AimBot.Fov;
		Silent_Legit_Rage = Opts.LegitRageBot.EW_Legit[weapon].AimBot.pSilent;
		HitChance_Legit_Rage = Opts.LegitRageBot.EW_Legit[weapon].AimBot.HitChance;
		MinDamage_Legit_Rage = Opts.LegitRageBot.EW_Legit[weapon].AimBot.MinDamage;
	}
}

int ClosestBoneLR(CBaseEntity* Entity)
{
	float BestDist = FOV_Legit_Rage;
	int aimbone = -1;

	static int Bones[] = { BONE_HEAD, BONE_NECK, BONE_LOWER_NECK, BONE_UPPER_CHEST, BONE_CHEST, BONE_PELVIS, BONE_STOMACH };

	for (auto Bone : Bones)
	{
		Vector pPosition = Entity->GetBonePosition(Bone);

		if (pPosition.IsZero())
			continue;

		if (!Opts.RageBot.AimBot.AutoWall && !Entity->IsVisible(Bone))
			continue;

		auto thisdist = M::GetFov(G::UserCmd->viewangles, M::CalcAngle(G::LocalPlayer->GetEyePosition(), Entity->GetBonePosition(Bone)));
		if (BestDist > thisdist)
		{
			BestDist = thisdist;
			aimbone = Bone;
			continue;
		}
	}

	return aimbone;
}

int GetHitboxLR(int ID)
{
	switch (Bone_Legit_Rage)
	{
		case 0: return BONE_HEAD; break;
		case 1: return BONE_NECK; break;
		case 2: return BONE_CHEST; break;
		case 3: return BONE_PELVIS; break;
		case 4: return ClosestBoneLR(I::ClientEntList->GetClientEntity(ID)); break;
	}

	return -1;
}

int TargetBoneLR = 0;
float fBestFOVLR = 0;
float fBestDamage = 0;

bool EntityValidLR(int index)
{
	CBaseEntity *pEntity = I::ClientEntList->GetClientEntity(index);

	if (!pEntity)
		return false;
	if (pEntity == G::LocalPlayer)
		return false;
	if (pEntity->GetHealth() <= 0)
		return false;
	if (pEntity->GetImmune())
		return false;
	if (pEntity->GetDormant())
		return false;
	if (!pEntity->IsEnemy() && !Opts.LegitRageBot.AimBot.FriendlyFire)
		return false;

	if (Opts.LegitRageBot.AimBot.JumpCheck && !(G::LocalPlayer->GetFlags() & FL_ONGROUND))
		return false;

	if (Opts.LegitRageBot.AimBot.FlashCheck && G::FlashTime - I::Globals->curtime > 2.f)
		return false;

	int Hitbox = GetHitboxLR(index);
	if (Hitbox == -1) return false;

	float fov = M::GetFov(G::UserCmd->viewangles, M::CalcAngle(G::LocalPlayer->GetEyePosition(), pEntity->GetBonePosition(TargetBoneLR)));
	if (FOV_Legit_Rage < fov) return false;

	float pDamage = Autowall::GetDamage(pEntity->GetBonePosition(TargetBoneLR), G::LocalPlayer);
	if (MinDamage_Legit_Rage > pDamage) return false;

	if ((!Opts.LegitRageBot.AimBot.AutoWall && !pEntity->IsVisible(Hitbox)) || (Opts.LegitRageBot.AimBot.SmokeCheck && U::IsInSmoke(pEntity->GetBonePosition(Hitbox))))
	{
		if (Bone_Legit_Rage != 0 && Bone_Legit_Rage != 4)
			return false;
	
		if ((!Opts.LegitRageBot.AimBot.AutoWall && !pEntity->IsVisible(BONE_UPPER_HEAD)) || (Opts.LegitRageBot.AimBot.SmokeCheck && U::IsInSmoke(pEntity->GetBonePosition(BONE_UPPER_HEAD))))
			return false;
	
		//Hitbox = BONE_UPPER_HEAD;
	}

	return true;
}

int iBestTargetLR = -1;

void LegitRage::Aim::DropTarget()
{
	CBaseEntity* Player = I::ClientEntList->GetClientEntity(iBestTargetLR);

	if (!G::PressedKeys[Opts.LegitRageBot.AimBotAutoFireKey] && Opts.LegitRageBot.AimBotAutoFireOnKey)
	{
		iBestTargetLR = -1;
		return;
	}

	if (!EntityValidLR(iBestTargetLR))
		iBestTargetLR = -1;
}

void LegitRage::Aim::FindTarget()
{
	fBestFOVLR = FOV_Legit_Rage;
	fBestDamage = MinDamage_Legit_Rage;

	for (int i = 0; i < 64; ++i)
	{
		if (!EntityValidLR(i))
			continue;

		CBaseEntity* Entity = I::ClientEntList->GetClientEntity(i);

		int Hitbox = GetHitboxLR(i);
		if (Hitbox == -1) continue;

		float fov = M::GetFov(G::UserCmd->viewangles, M::CalcAngle(G::LocalPlayer->GetEyePosition(), Entity->GetBonePosition(Hitbox)));
		float pDamage = Autowall::GetDamage(Entity->GetBonePosition(Hitbox), G::LocalPlayer);
		if (fov < fBestFOVLR && pDamage > fBestDamage)
		{
			fBestDamage = pDamage;
			fBestFOVLR = fov;
			iBestTargetLR = i;
			TargetBoneLR = Hitbox;
		}
	}
}

int autoRevolerDelayLR = 0;

void AutoShootLegit(CBaseEntity* player, CUserCmd* cmd)
{
	CBaseEntity* localplayer = (CBaseEntity*)I::ClientEntList->GetClientEntity(I::Engine->GetLocalPlayer());
	CBaseCombatWeapon* activeWeapon = localplayer->GetWeapon();

	if (!player || !activeWeapon)
		return;

	float nextPrimaryAttack = activeWeapon->GetNextPrimaryAttack();

	if ((nextPrimaryAttack - (G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick)) > 0)
	{
		cmd->buttons &= ~IN_ATTACK;
	}
	else
	{
		if (Opts.LegitRageBot.AimBot.AutoScope && localplayer->GetWeapon()->IsSniper() && !localplayer->IsScoped())
		{
			cmd->buttons |= IN_ATTACK2;
		}
		if (Rage::AimBot::HitChance(HitChance_Legit_Rage))
		{
			//cmd->buttons &= ~IN_ATTACK2;

			if (*G::LocalPlayer->GetWeapon()->GetItemDefinitionIndex() == WEAPON_REVOLVER)
			{
				if (autoRevolerDelayLR == 15)
				{
					G::UserCmd->buttons |= IN_ATTACK;
					autoRevolerDelayLR -= 1;
				}
			}
			else if (G::LocalPlayer->GetWeapon()->GetType() != WT_PISTOLS)
			{
				static bool fire = false;
				fire = !fire;

				if (fire)
				{
					G::UserCmd->buttons |= IN_ATTACK;
				}
				else
				{
					G::UserCmd->buttons &= ~IN_ATTACK;
				}
			}
			else
			{
				static int fire = 0;
			
				if (fire <= 2)
				{
					G::UserCmd->buttons |= IN_ATTACK;
					fire += 1;
				}
				else
				{
					G::UserCmd->buttons &= ~IN_ATTACK;
					fire = 0;
				}
			}
		}
	}
}

inline float FastSqrtLR(float x)
{
	unsigned int i = *(unsigned int*)&x;
	i += 127 << 23;
	i >>= 1;
	return *(float*)&i;
}

void LegitRage::Aim::GoToTarget()
{
	CBaseEntity* Player = I::ClientEntList->GetClientEntity(iBestTargetLR);

	if (Opts.LegitRageBot.AimBot.AutoStop && !G::LocalPlayer->GetWeapon()->IsEmpty() && !G::LocalPlayer->GetWeapon()->IsReloading() && G::LocalPlayer->GetWeapon()->GetNextPrimaryAttack() - (G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick) > 0)
	{
		int Speed = 40;

		float min_speed = (float)(FastSqrtLR(G::UserCmd->forwardmove * G::UserCmd->forwardmove + G::UserCmd->sidemove * G::UserCmd->sidemove + G::UserCmd->upmove * G::UserCmd->upmove));

		if (min_speed <= 0.f)
			return;

		if (G::UserCmd->buttons & IN_DUCK)
			Speed *= 2.94117647f;

		if (min_speed <= Speed)
			return;

		float speed = Speed / min_speed;

		G::UserCmd->forwardmove *= speed;
		G::UserCmd->sidemove *= speed;
		G::UserCmd->upmove *= speed;

		FixMovement::OldForward = G::UserCmd->forwardmove;
		FixMovement::OldSideMove = G::UserCmd->sidemove;

		if (G::LocalPlayer->GetVelocity().Length() > Speed)
			G::UserCmd->buttons &= ~IN_ATTACK;
	}

	QAngle Calced = M::CalcAngle(G::LocalPlayer->GetEyePosition(), Player->GetPredicted(Player->GetBonePosition(TargetBoneLR)));
	if ((G::LocalPlayer->GetWeapon()->GetNextPrimaryAttack() - (G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick)) < 0)
	{
		AutoShootLegit(Player, G::UserCmd);

		if (G::UserCmd->buttons & IN_ATTACK)
		{
			G::SendPacket = !Silent_Legit_Rage;

			ConVar* recoil_scale = I::Cvar->FindVar("weapon_recoil_scale");
			Calced -= G::LocalPlayer->GetPunchAngles() * recoil_scale->GetFloat();

			G::UserCmd->viewangles = Calced.Normalized();
			if (!Silent_Legit_Rage)
				I::Engine->SetViewAngles(G::UserCmd->viewangles);
		}
	}
}

void LegitRage::RunLegitRage()
{
	//if (Opts.Misc.Globals.LegitDesync && !(G::UserCmd->buttons & (IN_ATTACK | IN_USE | IN_ATTACK2)) && G::LocalPlayer->GetMoveType() != MOVETYPE_LADDER && G::LocalPlayer->GetMoveType() != MOVETYPE_NOCLIP)
	//{
	//	Rage::FixMove::Start();
	//	Rage::AntiAim::LegitDesync();
	//	Rage::FixMove::End();
	//}
	//else
	//{
	//	G::SendPacket = true;
	//}

	if (!G::LocalPlayer->GetWeapon()->IsFiredWeaponType())
		return;

	if (*G::LocalPlayer->GetWeapon()->GetItemDefinitionIndex() == WEAPON_REVOLVER && Opts.LegitRageBot.AimBot.AutoRevolver)
	{
		autoRevolerDelayLR += 1;

		if (autoRevolerDelayLR <= 15) G::UserCmd->buttons |= IN_ATTACK;
		else autoRevolerDelayLR = 0;
	}

	if (!G::LocalPlayer->GetWeapon()->IsFiredWeaponType() || Opts.Menu.Opened)
		return;

	static int old_aim_index = G::LocalPlayer->GetWeapon()->GetAimIndex();
	if (G::LocalPlayer->GetWeapon()->GetAimIndex() != old_aim_index || G::LegitRageUpdate) {
		UpdateSettingsLegitRage();
		old_aim_index = G::LocalPlayer->GetWeapon()->GetAimIndex();
		G::LegitRageUpdate = false;
	}

	FixMovement::Start();

	if (iBestTargetLR != -1)
		LegitRage::Aim::DropTarget();

	if (iBestTargetLR == -1)
		LegitRage::Aim::FindTarget();

	if (iBestTargetLR != -1 && (G::PressedKeys[Opts.LegitRageBot.AimBotAutoFireKey] || !Opts.LegitRageBot.AimBotAutoFireOnKey))
		LegitRage::Aim::GoToTarget();

	FixMovement::End();
}