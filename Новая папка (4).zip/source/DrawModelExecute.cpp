#include <intrin.h>

#include "Cheat.h"
#include "NewChams.h"

void NoSmoke()
{
	static DWORD linegoesthrusmoke = U::FindPattern(rxs("client_panorama.dll"), rxs("55 8B EC 83 EC 08 8B 15 ?? ?? ?? ?? 0F 57 C0"));
	static std::vector<const char*> vistasmoke_wireframe = { rxs("particle/vistasmokev1/vistasmokev1_smokegrenade") };
	static std::vector<const char*> vistasmoke_nodraw = { rxs("particle/vistasmokev1/vistasmokev1_fire"), rxs("particle/vistasmokev1/vistasmokev1_emods"), rxs("particle/vistasmokev1/vistasmokev1_emods_impactdust") };

	for (auto mat_s : vistasmoke_wireframe)
	{
		IMaterial* mat = I::MaterialSystem->FindMaterial(mat_s, TEXTURE_GROUP_OTHER);
		mat->SetMaterialVarFlag(MATERIAL_VAR_WIREFRAME, Opts.Misc.Globals.NoSmokeWireFrame && Opts.Misc.Globals.NoSmoke);
		mat->SetMaterialVarFlag(MATERIAL_VAR_NO_DRAW, Opts.Misc.Globals.NoSmoke && !Opts.Misc.Globals.NoSmokeWireFrame);
	}

	for (auto mat_n : vistasmoke_nodraw)
	{
		IMaterial* mat = I::MaterialSystem->FindMaterial(mat_n, TEXTURE_GROUP_OTHER);
		mat->SetMaterialVarFlag(MATERIAL_VAR_NO_DRAW, Opts.Misc.Globals.NoSmoke);
	}

	static auto smokecout = *(DWORD*)(linegoesthrusmoke + 0x8);
	if (Opts.Misc.Globals.NoSmoke && !Opts.Misc.Globals.NoSmokeWireFrame)
		*(int*)(smokecout) = 0;
}

void MaterialChanger(int iMaterial, Color cMaterial)
{
	IMaterial* material = nullptr;

	switch (iMaterial)
	{
	case 2: { material = Materials::materialFlat; break; }
	case 3: { material = Materials::materialTexture; break; }
	case 4: { material = Materials::materialWireFrame; break; }
	case 5: { material = Materials::materialMetalic; break; }
	case 6: { material = Materials::materialAnimated; break; }
	case 7: { material = Materials::materialPlatinum; break; }
	case 8: { material = Materials::materialGlass; break; }
	case 9: { material = Materials::materialCrystal; break; }
	case 10: { material = Materials::materialChrome; break; }
	case 11: { material = Materials::materialSilver; break; }
	case 12: { material = Materials::materialGold; break; }
	case 13: { material = Materials::materialPlastic; break; }
	case 14: { material = Materials::materialGlowOverlay; break; }
	case 15: { material = Materials::materialdog_tags_lightray; break; }
	case 16: { material = Materials::materialdog_dogtags_outline; break; }
	case 17: { material = Materials::materialdog_dreamhack_star_blur; break; }
	case 18: { material = Materials::materialdog_crystal_blue; break; }
	case 19: { material = Materials::materialdog_fishing_net01; break; }
	case 20: { material = Materials::materialdog_contributor_charset_color; break; }
	case 21: { material = Materials::materialdog_urban_tree03_branches; break; }
	case 22: { material = Materials::materialdog_speech_info; break; }
	case 23: { material = Materials::materialdog_mp3_detail; break; }
	default: { return; }
	}

	material->ColorModulate(cMaterial.rBase(), cMaterial.gBase(), cMaterial.bBase());
	I::RenderView->SetBlend(cMaterial.aBase());

	I::ModelRender->ForcedMaterialOverride(material);
}

DrawModelExecuteFn oDrawModelExecute;
void __fastcall Hooks::DrawModelExecute(void* ecx, void* edx, IMatRenderContext* context, const DrawModelState_t& state, const ModelRenderInfo_t& render_info, matrix3x4_t* matrix)
{
	if (Opts.Visuals.Players.Global.ScreenShotBypass && I::Engine->IsTakingScreenshot())
	{
		oDrawModelExecute(ecx, context, state, render_info, matrix);
		return;
	}

	static bool mat_init = false;
	if (!mat_init)
	{
		Materials::InitializationMaterials();
		mat_init = true;
	}

	bool forced_mat = I::ModelRender->IsForcedMaterialOverride();

	if (I::Engine->IsInGame() && G::LocalPlayer && !forced_mat)
	{
		NoSmoke();

		if (render_info.pModel)
		{
			if (G::LocalPlayer->GetAlive())
			{
				std::string modelName = I::ModelInfo->GetModelName(render_info.pModel);

				if (Opts.Misc.Changer.View.RemoveLocalPlayer && Opts.Misc.Changer.View.ThirdPerson)
				{
					CBaseEntity* Entity = I::ClientEntList->GetClientEntity(render_info.entity_index);
					if (Entity == G::LocalPlayer)
						return;
				}

				if (modelName.find(xs("sleeve")) != std::string::npos)
				{
					if (Opts.Misc.Changer.View.iSleeves == 1) return;
					if (Opts.Misc.Changer.View.iSleeves != 0)
					{
						MaterialChanger(Opts.Misc.Changer.View.iSleeves, Opts.Colors.Misc.ChamsSleeves);

						oDrawModelExecute(I::ModelRender, context, state, render_info, matrix);
						I::ModelRender->ForcedMaterialOverride(nullptr);

						return;
					}
				}
				else if (modelName.find(xs("arms")) != std::string::npos)
				{
					if (Opts.Misc.Changer.View.iHands == 1) return;
					if (Opts.Misc.Changer.View.iHands != 0)
					{
						MaterialChanger(Opts.Misc.Changer.View.iHands, Opts.Colors.Misc.ChamsHands);

						oDrawModelExecute(I::ModelRender, context, state, render_info, matrix);
						I::ModelRender->ForcedMaterialOverride(nullptr);

						return;
					}
				}
				else if (modelName.find(xs("weapon")) != std::string::npos && !G::LocalPlayer->IsScoped())
				{
					if (Opts.Misc.Changer.View.iWeapons == 1) return;
					if (Opts.Misc.Changer.View.iWeapons != 0)
					{
						MaterialChanger(Opts.Misc.Changer.View.iWeapons, Opts.Colors.Misc.ChamsWeapons);

						oDrawModelExecute(I::ModelRender, context, state, render_info, matrix);
						I::ModelRender->ForcedMaterialOverride(nullptr);

						return;
					}
				}
			}
		}
	}

	oDrawModelExecute(ecx, context, state, render_info, matrix);

	if (!forced_mat)
		I::ModelRender->ForcedMaterialOverride(nullptr);
}

struct RenderableInfo_t
{
	IClientRenderable* m_pRenderable;
	void* m_pAlphaProperty;
	int m_EnumCount;
	int m_nRenderFrame;
	unsigned short m_FirstShadow;
	unsigned short m_LeafList;
	short m_Area;
	uint16_t m_Flags;   // 0x0016
	uint16_t m_Flags2; // 0x0018
	Vector m_vecBloatedAbsMins;
	Vector m_vecBloatedAbsMaxs;
	Vector m_vecAbsMins;
	Vector m_vecAbsMaxs;
	int pad;
};

ListLeavesInBox oListLeavesInBox;
int __fastcall Hooks::ListLeavesInBox(void* bsp, void* edx, Vector& mins, Vector& maxs, unsigned short* pList, int listMax)
{
	// occulusion getting updated on player movement/angle change,
	// in RecomputeRenderableLeaves ( https://github.com/pmrowla/hl2sdk-csgo/blob/master/game/client/clientleafsystem.cpp#L674 );
	// check for return in CClientLeafSystem::InsertIntoTree
	//static DWORD listLeaves = U::FindPattern(xs("client_panorama.dll"), xs("56 52 FF 50 18")) + 0x5;
	//
	//if (!Opts.Visuals.Players.Chams.Enabled || !I::Engine->IsInGame() || !G::LocalPlayer)
	//	return oListLeavesInBox(bsp, mins, maxs, pList, listMax);
	//
	//// get current renderable info from stack ( https://github.com/pmrowla/hl2sdk-csgo/blob/master/game/client/clientleafsystem.cpp#L1470 )
	//auto info = *(RenderableInfo_t**)((uintptr_t)_AddressOfReturnAddress() + 0x14);
	//if (!info || !info->m_pRenderable)
		return oListLeavesInBox(bsp, mins, maxs, pList, listMax);
	
	/////////// check if disabling occulusion for players ( https://github.com/pmrowla/hl2sdk-csgo/blob/master/game/client/clientleafsystem.cpp#L1491 )
	//auto base_entity = info->m_pRenderable->GetIClientUnknown()->GetBaseEntity();
	//if (!base_entity)
	//	return oListLeavesInBox(bsp, mins, maxs, pList, listMax);
	//
	//// extend world space bounds to maximum ( https://github.com/pmrowla/hl2sdk-csgo/blob/master/game/client/clientleafsystem.cpp#L707 )
	//static const Vector map_min = Vector(-32768.0f, -32768.0f, -32768.0f);
	//static const Vector map_max = Vector(32768.0f, 32768.0f, 32768.0f);
	//auto count = oListLeavesInBox(bsp, map_min, map_max, pList, listMax);
	//return count;
}