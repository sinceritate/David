#pragma once

inline void DrawRadar()
{
	if (I::Engine->IsInGame() && G::LocalPlayer && G::LocalPlayer->GetHealth() > 0)
	{
		static bool radar_init = false;

		ImVec2 Position = ImVec2(Opts.Visuals.Radar.Pos.x, Opts.Visuals.Radar.Pos.y);
		ImVec2 Size = ImVec2(Opts.Visuals.Radar.Size.x, Opts.Visuals.Radar.Size.y);

		if (!radar_init || G::RadarUpdate)
		{
			ImGui::SetNextWindowPos(Position);
			ImGui::SetNextWindowSize(Size);
			radar_init = true;
			G::RadarUpdate = false;
		}

		Size.y += 19;

		ImGui::SetNextWindowBgAlpha((float)Opts.Visuals.Radar.Alpha / 255.f);

		if (ImGui::Begin(xs("Radar"), nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoNav))
		{
			Position = ImGui::GetWindowPos();

			static ImDrawList* DrawList = ImGui::GetWindowDrawList();

			ImVec2 center_pos = ImVec2(Position.x + Size.x / 2, Position.y + Size.y / 2);

			DrawList->AddLine(ImVec2(Position.x + Size.x / 2, Position.y), ImVec2(Position.x + Size.x / 2, Position.y + Size.y), ImColor(1.0f, 1.0f, 1.0f, 1.0f));
			DrawList->AddLine(ImVec2(Position.x, Position.y + Size.y / 2), ImVec2(Position.x + Size.x, Position.y + Size.y / 2), ImColor(1.0f, 1.0f, 1.0f, 1.0f));

			DrawList->AddLine(ImVec2(center_pos.x - 20, center_pos.y - 20), ImVec2(center_pos.x, center_pos.y), ImColor(1.0f, 1.0f, 1.0f, 1.0f));
			DrawList->AddLine(ImVec2(center_pos.x + 20, center_pos.y - 20), ImVec2(center_pos.x, center_pos.y), ImColor(1.0f, 1.0f, 1.0f, 1.0f));

			Vector Local_origin = G::LocalPlayer->GetOrigin();

			QAngle local_angle;
			I::Engine->GetViewAngles(local_angle);

			for (int i = 0; i < 64; ++i)
			{
				CBaseEntity* entity = I::ClientEntList->GetClientEntity(i);

				if (!entity || entity->GetHealth() <= 0 || G::LocalPlayer == entity || entity->GetDormant()) continue;

				bool is_enemy = entity->IsEnemy();

				if (Opts.Visuals.Radar.EnemyOnly && !is_enemy) continue;

				Vector Entity_origin = entity->GetOrigin();

				float r_1, r_2;
				float x_1, y_1;

				r_1 = -(Entity_origin.y - Local_origin.y);
				r_2 = Entity_origin.x - Local_origin.x;
				float local_yaw = (local_angle.y - 90.0f) * (M_PI / 180.0F);

				x_1 = (r_2 * cos(local_yaw) - r_1 * sin(local_yaw)) / 10;
				y_1 = (r_2 * sin(local_yaw) + r_1 * cos(local_yaw)) / 10;

				x_1 *= Opts.Visuals.Radar.Zoom / 2;
				y_1 *= Opts.Visuals.Radar.Zoom / 2;

				ImVec2 correct_pos = ImVec2(center_pos.x + x_1, center_pos.y + y_1);

				Color pColor = !is_enemy ?
					entity->IsVisible(BONE_CHEST) && !U::IsInSmoke(entity->GetBonePosition(BONE_CHEST)) ? Opts.Colors.Visuals.RadarTeammateVisible : Opts.Colors.Visuals.RadarTeammateInvisible :
					entity->IsVisible(BONE_CHEST) && !U::IsInSmoke(entity->GetBonePosition(BONE_CHEST)) ? Opts.Colors.Visuals.RadarEnemyVisible : Opts.Colors.Visuals.RadarEnemyInvisible;

				ImColor player_color = ImColor(pColor.rBase(), pColor.gBase(), pColor.bBase(), pColor.aBase());


				DrawList->AddRectFilled(ImVec2(correct_pos.x - Opts.Visuals.Radar.PointSize, correct_pos.y - Opts.Visuals.Radar.PointSize), ImVec2(correct_pos.x + Opts.Visuals.Radar.PointSize, correct_pos.y + Opts.Visuals.Radar.PointSize), player_color);
			}

			Size = ImGui::GetWindowSize();

			Opts.Visuals.Radar.Pos.x = Position.x;
			Opts.Visuals.Radar.Pos.y = Position.y;
			Opts.Visuals.Radar.Size.x = Size.x;
			Opts.Visuals.Radar.Size.y = Size.y;

			ImGui::End();
		}
	}
	else if (Opts.Menu.Opened)
	{
		static bool radar_init = false;

		ImVec2 Position = ImVec2(Opts.Visuals.Radar.Pos.x, Opts.Visuals.Radar.Pos.y);
		ImVec2 Size = ImVec2(Opts.Visuals.Radar.Size.x, Opts.Visuals.Radar.Size.y);

		if (!radar_init || G::RadarUpdate)
		{
			ImGui::SetNextWindowPos(Position);
			ImGui::SetNextWindowSize(Size);
			radar_init = true;
			G::RadarUpdate = false;
		}

		Size.y += 19;

		ImGui::SetNextWindowBgAlpha((float)Opts.Visuals.Radar.Alpha / 255.f);

		if (ImGui::Begin(xs("Radar"), nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoNav))
		{
			Position = ImGui::GetWindowPos();

			static ImDrawList* DrawList = ImGui::GetWindowDrawList();

			ImVec2 center_pos = ImVec2(Size.x / 2, Size.y / 2);

			DrawList->AddLine(ImVec2(Position.x + center_pos.x, Position.y), ImVec2(Position.x + center_pos.x, Position.y + Size.y), ImColor(1.0f, 1.0f, 1.0f, 1.0f));
			DrawList->AddLine(ImVec2(Position.x, Position.y + center_pos.y), ImVec2(Position.x + Size.x, Position.y + center_pos.y), ImColor(1.0f, 1.0f, 1.0f, 1.0f));

			Size = ImGui::GetWindowSize();

			Opts.Visuals.Radar.Pos.x = Position.x;
			Opts.Visuals.Radar.Pos.y = Position.y;
			Opts.Visuals.Radar.Size.x = Size.x;
			Opts.Visuals.Radar.Size.y = Size.y;

			ImGui::End();
		}
	}
}