#include <math.h>

#include "Cheat.h"
#include "NewMath.h"

QAngle new_math::angle_to_point(Vector point_pos)
{
	QAngle ang;

	ang.x = RAD_TO_DEG(atan2(-point_pos.z, point_pos.Length2D()));
	ang.y = RAD_TO_DEG(atan2(point_pos.y, point_pos.x));
	ang.z = 0;

	return ang;
}

QAngle new_math::angle_poin_point(Vector lpos, Vector epos)
{
	return new_math::angle_to_point(epos - lpos);
}

void new_math::sin_cos(float ang, float* _sin, float* _cos)
{
	ang = DEG_TO_RAD(ang);
	*_sin = sin(ang);
	*_cos = cos(ang);
}

Vector new_math::rotate_point(QAngle ang, Vector point_pos)
{

}

float new_math::FastSQRT(float float_for_fast)
{
	unsigned int i = *(unsigned int*)&float_for_fast;
	i += 127 << 23;
	i >>= 1;
	return *(float*)&i;
}