#pragma once

namespace Misc
{
	extern void Bhop();
	extern void AutoPistol();
	extern void NameChange(const char* name);
	extern void DynamicClanTagChanger(std::string tag, int setting_mode);
	extern void ChatSpam();
	extern void FakeCrouch();

	extern void Start();
}
