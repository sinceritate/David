#pragma once

#include "IBaseClientDLL.h"
#include "IClientEntityList.h"
#include "IClientModeShared.h"
#include "ICClientState.h"
#include "ICvar.h"
#include "IEngineClient.h"
#include "IEngineTrace.h"
#include "IGlobalVarsBase.h"
#include "IInputSystem.h"
#include "Interfaces.h"
#include "ISurface.h"
#include "IVPanel.h"
#include "IVModelInfo.h"
#include "IVModelRender.h"
#include "IMaterialSystem.h"
#include "IMaterial.h"
#include "IRenderView.h"
#include "IPrediction.h"
#include "VPhysics.h"
#include "IVDebugOverlay.h"
#include "IStudioRender.h"
#include "IGameMovement.h"
#include "IGameEvent.h"
#include "IEngineSound.h"
#include "ISteamClient.h"
#include "Input.h"
#include "ILocalize.h"
#include "IMDLCache.h"
#include "IGameRules.h"
#include "IServerGameDLL.h"

class CNetworkStringTableContainer
{
public:
	INetworkStringTable* FindTable(const char* tableName);
};

class CUtlVectorSimple
{
public:
	unsigned memory;
	char pad[8];
	unsigned int count;
	inline void* Retrieve(int index, unsigned sizeofdata)
	{
		return (void*)((*(unsigned*)this) + (sizeofdata * index));
	}
};

namespace I 
{
	extern IBaseClientDll* Client;
	extern IClientModeShared* ClientMode;
	extern IClientEntityList* ClientEntList;
	extern IServerGameDLL* Server;
	extern ICVar* Cvar;
	extern IInputSystem* InputSystem;
	extern IEngineClient* Engine;
	extern IEngineTrace* EngineTrace;
	extern IEngineSound* EngineSound;
	extern IGlobalVarsBase* Globals;
	extern ISurface* Surface;
	extern IVPanel* VPanel;
	extern IVModelRender* ModelRender;
	extern IVModelInfo* ModelInfo;
	extern IMaterialSystem* MaterialSystem;
	extern IMaterial* Material;
	extern IVRenderView* RenderView;
	extern IPrediction* Prediction;
	extern IPhysicsSurfaceProps* Physprops;
	extern IVDebugOverlay* DebugOverlay;
	extern IStudioRender* StudioRender;
	extern IGameMovement* GameMovement;
	extern IGameEventManager* GameEventManager;
	extern ISteamClient* SteamClient;
	extern ISteamHTTP* SteamHTTP;
	extern ISteamUser* SteamUser;
	extern ISteamFriends* SteamFriends;
	extern ISteamInventory* SteamInventory;
	extern ISteamGameCoordinator* SteamGameCoordinator;
	extern CInput* Input;
	extern Localize* pLocalize;
	extern CNetworkStringTableContainer* ClientStringTableContainer;
	extern IMDLCache* ModelCache;
	extern CPrediction* pPrediction;
	extern IMoveHelper* pMoveHelper;
	extern CUtlVectorSimple* g_ClientSideAnimationList;
	extern CClientState* ClientState;
	extern CGameRules* GameRules;
}
