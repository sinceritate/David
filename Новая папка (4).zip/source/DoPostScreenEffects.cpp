#include "Cheat.h"
#include "GlowManager.h"

void DrawGlow()
{
	static CGlowObjectManager* GlowObjectManager = (CGlowObjectManager*)offsets.GlowManager;

	for (int i = 0; i < GlowObjectManager->size; ++i)
	{
		CGlowObjectManager::GlowObjectDefinition_t& glowEntity = GlowObjectManager->m_GlowObjectDefinitions[i];
		CBaseEntity* Entity = glowEntity.m_hEntity;

		if (!Entity)
			continue;

		ClientClass* ClientClass = Entity->GetClientClass();
		int ClassID = ClientClass->m_ClassID;

		if (ClassID == CCSPlayer)
		{
			if (!Opts.Visuals.Players.Glow.Enabled || Entity == G::LocalPlayer) continue;

			static bool player_visible = false;
			player_visible = Entity->IsVisible(BONE_CHEST) && !U::IsInSmoke(Entity->GetBonePosition(BONE_CHEST));

			static Color player_color = Color(0, 0, 0, 0);

			if (Entity->IsEnemy())
			{
				if (player_visible)
				{
					player_color = Opts.Colors.Visuals.PlayersGlowEnemyVisible;
				}
				else if (!Opts.Visuals.Players.Glow.VisibleOnly)
				{
					player_color = Opts.Colors.Visuals.PlayersGlowEnemyInvisible;
				}
				else
				{
					continue;
				}
			}
			else if (!Opts.Visuals.Players.Glow.EnemyOnly)
			{
				if (player_visible)
				{
					player_color = Opts.Colors.Visuals.PlayersGlowTeammateVisible;
				}
				else if (!Opts.Visuals.Players.Glow.VisibleOnly)
				{
					player_color = Opts.Colors.Visuals.PlayersGlowTeammateInvisible;
				}
				else
				{
					continue;
				}
			}
			else
			{
				continue;
			}

			glowEntity.m_vGlowColor = Vector(player_color.rBase(), player_color.gBase(), player_color.bBase());
			glowEntity.m_flGlowAlpha = player_color.aBase();
			glowEntity.m_bRenderWhenOccluded = true;
			glowEntity.m_bRenderWhenUnoccluded = false;
			glowEntity.m_nGlowStyle = Opts.Visuals.Players.Glow.Type;

			continue;
		}

#ifdef FULL_MODE

		if (Opts.Visuals.Weapons.Glow)
		{
			if (strstr(ClientClass->m_pNetworkName, "CWeapon") || ClassID == CDEagle || ClassID == CAK47)
			{
				if (!Opts.Visuals.Weapons.Weapons) continue;

				glowEntity.set(Opts.Colors.Visuals.WeaponGlowWeapons);
				glowEntity.m_nGlowStyle = Opts.Visuals.Weapons.GlowType;

				continue;
			}
			if (ClassID == CC4 || ClassID == CPlantedC4)
			{
				if (!Opts.Visuals.Weapons.Bomb) continue;

				glowEntity.set(Opts.Colors.Visuals.WeaponGlowBomb);
				glowEntity.m_nGlowStyle = Opts.Visuals.Weapons.GlowType;

				continue;
			}
			if (ClassID == CHEGrenade || ClassID == CSmokeGrenade || ClassID == CFlashbang || ClassID == CMolotovGrenade || ClassID == CIncendiaryGrenade || ClassID == CDecoyGrenade)
			{
				if (!Opts.Visuals.Weapons.Grenades) continue;

				glowEntity.set(Opts.Colors.Visuals.WeaponGlowGrenades);
				glowEntity.m_nGlowStyle = Opts.Visuals.Weapons.GlowType;

				continue;
			}
		}

#endif

	}
}

DoPostscreenEffectsFn oDoPostscreenEffects;
int __stdcall Hooks::DoPostscreenEffects(int unk1)
{
	if (Opts.Visuals.Players.Global.ScreenShotBypass && I::Engine->IsTakingScreenshot())
	{
		return oDoPostscreenEffects(I::ClientMode, unk1);
	}

	if (I::Engine->IsInGame() && G::LocalPlayer)
	{
		DrawGlow();
	}

	return oDoPostscreenEffects(I::ClientMode, unk1);
}