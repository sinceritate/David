#include "Desync.h"
#include "EnginePrediction.h"

template<class T>
void Normalize3(T& vec) {
	for (auto i = 0; i < 2; ++i) {
		while (vec[i] < -180.0f) vec[i] += 360.0f;
		while (vec[i] > 180.0f) vec[i] -= 360.0f;
	}
	vec[2] = 0.f;
}

void ClampAngles(QAngle& angles) {
	if (angles.x > 89.0f) angles.x = 89.0f;
	else if (angles.x < -89.0f) angles.x = -89.0f;

	if (angles.y > 180.0f) angles.y = 180.0f;
	else if (angles.y < -180.0f) angles.y = -180.0f;

	angles.z = 0;
}

void FixAngles(QAngle& angles) {
	Normalize3(angles);
	ClampAngles(angles);
}

bool cDesync::is_enabled()
{
	if (!G::LocalPlayer || !G::LocalPlayer->GetAlive())
		return false;

	if (!Opts.Misc.Globals.LegitDesync || (G::UserCmd->buttons & IN_USE))
		return false;

	auto* channel_info = I::Engine->GetNetChannelInfo();
	if (channel_info && (channel_info->GetAvgLoss(1) > 0.f || channel_info->GetAvgLoss(0) > 0.f))
		return false;

	if (G::LocalPlayer->GetImmune() || G::LocalPlayer->GetFlags() & FL_FROZEN)
		return false;

	if (G::LocalPlayer->GetMoveType() == MOVETYPE_LADDER || G::LocalPlayer->GetMoveType() == MOVETYPE_NOCLIP)
		return false;

	return true;
}

bool cDesync::is_firing()
{
	auto weapon = G::LocalPlayer->GetWeapon();
	if (!weapon)
		return false;

	if (weapon->IsGrenade())
	{
		return true;
	}
	else if (weapon->IsKnife())
	{
		if (G::UserCmd->buttons & IN_ATTACK || G::UserCmd->buttons & IN_ATTACK2)
			return true;
	}
	else if (*weapon->GetItemDefinitionIndex() == WEAPON_REVOLVER)
	{
		if (G::UserCmd->buttons & IN_ATTACK && weapon->CanFire())
			return true;

		if (G::UserCmd->buttons & IN_ATTACK2)
			return true;
	}
	else if (G::UserCmd->buttons & IN_ATTACK && weapon->CanFire() && *weapon->GetItemDefinitionIndex() != WEAPON_C4)
		return true;

	return false;
}

float AngleDiff(float destAngle, float srcAngle) {
	float delta;

	delta = fmodf(destAngle - srcAngle, 360.0f);
	if (destAngle > srcAngle) {
		if (delta >= 180)
			delta -= 360;
	}
	else {
		if (delta <= -180)
			delta += 360;
	}
	return delta;
}

int max_choke_ticks = 14;
float static_side = 1.0f;
float balance_side = 1.0f;
CBaseAnimState g_AnimState;
bool broke_lby = false;
float next_lby = 0.0f;

void cDesync::handle()
{
	if (!is_enabled())
		return;

	if (is_firing())
		return;

	static bool Key_Click = false;

	if (Opts.Misc.Globals.LegitDesyncFlipKey != 0 && GetAsyncKeyState(Opts.Misc.Globals.LegitDesyncFlipKey))
	{
		if (!Key_Click)
			static_side = -static_side;

		Key_Click = true;
	}
	else
		Key_Click = false;

	FixMovement::Start();

	//prediction->run_prediction();
	//{
		if (std::fabsf(G::LocalPlayer->m_flSpawnTime() - I::Globals->curtime) > 1.0f)
		{
			if (Opts.Misc.Globals.LegitDesyncType == 0) // static
			{
				float minimal_move = 2.0f;
				if (G::LocalPlayer->GetFlags() & FL_DUCKING)
					minimal_move *= 3.f;

				if (G::UserCmd->buttons & IN_WALK)
					minimal_move *= 3.f;

				bool should_move = G::LocalPlayer->GetVelocity().Length2D() <= 0.0f
					|| std::fabsf(G::LocalPlayer->GetVelocity().z) <= 100.0f;

				if ((G::UserCmd->command_number % 2) == 1) {
					G::UserCmd->viewangles.y += 120.0f * static_side;
					if (should_move)
						G::UserCmd->sidemove -= minimal_move;
					G::SendPacket = false;
				}
				else if (should_move) {
					G::UserCmd->sidemove += minimal_move;
				}
			}
			else if (Opts.Misc.Globals.LegitDesyncType == 1) // balance
			{
				if (next_lby >= I::Globals->curtime)
				{
					if (!broke_lby && G::SendPacket && I::ClientState->chokedcommands > 0)
						return;

					broke_lby = false;
					G::SendPacket = false;
					G::UserCmd->viewangles.y += 120.0f * balance_side;
				}
				else
				{
					broke_lby = true;
					G::SendPacket = false;
					G::UserCmd->viewangles.y += 120.0f * -balance_side;
				}
			}
			FixAngles(G::UserCmd->viewangles);
			FixMovement::End();
		}

		FixAngles(G::UserCmd->viewangles);
		G::UserCmd->viewangles.y = std::remainderf(G::UserCmd->viewangles.y, 360.0f);

		if (I::ClientState->chokedcommands >= max_choke_ticks) {
			G::SendPacket = true;
			G::UserCmd->viewangles = I::ClientState->viewangles;
		}

		// from aimware dmp
		static ConVar* m_yaw = m_yaw = I::Cvar->FindVar("m_yaw");
		static ConVar* m_pitch = m_pitch = I::Cvar->FindVar("m_pitch");
		static ConVar* sensitivity = sensitivity = I::Cvar->FindVar("sensitivity");

		static QAngle m_angOldViewangles = I::ClientState->viewangles;

		float delta_x = std::remainderf(G::UserCmd->viewangles.x - m_angOldViewangles.x, 360.0f);
		float delta_y = std::remainderf(G::UserCmd->viewangles.y - m_angOldViewangles.y, 360.0f);

		if (delta_x != 0.0f) {
			float mouse_y = -((delta_x / m_pitch->GetFloat()) / sensitivity->GetFloat());
			short mousedy;
			if (mouse_y <= 32767.0f) {
				if (mouse_y >= -32768.0f) {
					if (mouse_y >= 1.0f || mouse_y < 0.0f) {
						if (mouse_y <= -1.0f || mouse_y > 0.0f)
							mousedy = static_cast<short>(mouse_y);
						else
							mousedy = -1;
					}
					else {
						mousedy = 1;
					}
				}
				else {
					mousedy = 0x8000u;
				}
			}
			else {
				mousedy = 0x7FFF;
			}

			G::UserCmd->mousedy = mousedy;
		}

		if (delta_y != 0.0f) {
			float mouse_x = -((delta_y / m_yaw->GetFloat()) / sensitivity->GetFloat());
			short mousedx;
			if (mouse_x <= 32767.0f) {
				if (mouse_x >= -32768.0f) {
					if (mouse_x >= 1.0f || mouse_x < 0.0f) {
						if (mouse_x <= -1.0f || mouse_x > 0.0f)
							mousedx = static_cast<short>(mouse_x);
						else
							mousedx = -1;
					}
					else {
						mousedx = 1;
					}
				}
				else {
					mousedx = 0x8000u;
				}
			}
			else {
				mousedx = 0x7FFF;
			}

			G::UserCmd->mousedx = mousedx;
		}

		auto anim_state = G::LocalPlayer->GetAnimState();
		if (anim_state) {
			auto anim_state_backup = *anim_state;
			*anim_state = g_AnimState;
			*G::LocalPlayer->GetVAngles() = G::UserCmd->viewangles;
			G::LocalPlayer->UpdateClientSideAnimation();

			if (anim_state->speed_2d > 0.1f || std::fabsf(anim_state->flUpVelocity)) {
				next_lby = I::Globals->curtime + 0.22f;
			}
			else if (I::Globals->curtime > next_lby) {
				if (std::fabsf(AngleDiff(anim_state->m_flGoalFeetYaw, anim_state->m_flEyeYaw)) > 35.0f) {
					next_lby = I::Globals->curtime + 1.1f;
				}
			}

			g_AnimState = *anim_state;
			*anim_state = anim_state_backup;
		}

		if (G::SendPacket)
		{
			G::RealAngle = QAngle(G::UserCmd->viewangles.x, g_AnimState.m_flGoalFeetYaw, 0); 
			G::FakeAngle = QAngle(G::UserCmd->viewangles.x, g_AnimState.m_flEyeYaw, 0);
		}
	//}
	//prediction->end_prediction();

	FixAngles(G::UserCmd->viewangles);

	/*if (!G::SendPacket)
		return;

	static float yaw_offset;

	static bool flip_yaw = false;
	static bool flip_packet = false;

	if (!is_enabled())
	{
		yaw_offset = 0.f;
		return;
	}
	
	if (is_firing())
		return;
	
	auto anim_state = G::LocalPlayer->GetAnimState();
	
	//assert(anim_state);
	
	yaw_offset = Rage::AntiAims::GetMaxDelta(G::LocalPlayer);
	
	FixMovement::Start();
	
	flip_packet = !flip_packet;
	G::SendPacket = flip_packet;
	if (!flip_packet)
	{
		//if (!g_Options.yaw_flip && InputSys::Get().WasKeyPressed(g_Options.binds_desync))
		//	flip_yaw = !flip_yaw;
		//if (g_Options.yaw_flip)
		//	flip_yaw = !flip_yaw;
	}
	
	static float last_lby = 0.f;
	static float last_update = 0.f;
	
	float current_lby = G::LocalPlayer->GetLBY();
	float current_time = G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick;
	
	float delta = ceilf((current_time - last_update) * 100) / 100;
	float next_delta = ceilf((delta + I::Globals->interval_per_tick) * 100) / 100;
	
	if (G::LocalPlayer->GetVelocity().Length2D() <= 0.f)
	{
		if (current_lby != 180.f && last_lby != current_lby)
		{
			//console::print("lby updated after %.4f", delta);
	
			last_lby = current_lby;
			last_update = current_time - I::Globals->interval_per_tick;
		}
		else if (next_delta >= 1.1f)
		{
			//console::print("curr: %.4f; next: %.4f", delta, next_delta);
	
			G::SendPacket = flip_packet = true;
	
			last_update = current_time;
		}
	}
	else
	{
		last_lby = current_lby;
		last_update = current_time;
	}
	
	if (G::SendPacket)
	{
		anim_state->m_flGoalFeetYaw += flip_yaw ? yaw_offset : -yaw_offset;
		G::DesyncRealAngle.y = G::UserCmd->viewangles.y;
		G::DesyncFakeAngle.y = anim_state->m_flGoalFeetYaw;
	}
	else
	{
		G::UserCmd->buttons &= ~(IN_FORWARD | IN_BACK | IN_MOVERIGHT | IN_MOVELEFT);
	
		G::UserCmd->viewangles.y += flip_yaw ? 180.f : -180.f;
		G::UserCmd->viewangles.Normalized();
		FixMovement::End();
	}*/
}

cDesync* Desync;