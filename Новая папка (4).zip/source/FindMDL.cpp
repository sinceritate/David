#include "Cheat.h"

FindMdlFn oFindMdl;

bool all_init[MODEL_TYPE_MAX] = { false };


MDLHandle_t __fastcall Hooks::FindMdl(void* ecx, void* edx, char* szFilePath)
{
	if (Opts.Misc.Changer.Models.Enable && !Opts.Misc.Changer.Models.FastChange)
	{
		std::string FilePath = szFilePath;

	}

	return oFindMdl(ecx, szFilePath);
}