#include "Cheat.h"

float Autowall::GetDamage(const Vector &vecPoint, CBaseEntity* entity)
{
	float damage = 0.f;
	Vector dst = vecPoint;
	FireBulletData data;
	//auto entity = I::ClientEntList->GetClientEntity(I::Engine->GetLocalPlayer());
	data.src = entity->GetEyePosition();
	data.filter.pSkip = entity;

	QAngle angles = M::CalcAngle(data.src, dst);
	M::AngleVectors(angles, &data.direction);

	data.direction.Normalize();

	auto weap = entity->GetWeapon();

	if (SimulateFireBullet(weap, data, entity))
	{
		damage = data.current_damage;
	}

	return damage;
}

bool Autowall::SimulateFireBullet(CBaseCombatWeapon *weap, FireBulletData &data, CBaseEntity* entity)
{
	data.penetrate_count = 4;
	data.trace_length = 0.0f;
	//auto local_player = I::ClientEntList->GetClientEntity(I::Engine->GetLocalPlayer());

	auto weaponData = weap->get_full_info();

	if (weaponData == NULL)
		return false;

	data.current_damage = (float)weaponData->m_Damage;

	while ((data.penetrate_count > 0) && (data.current_damage >= 1.0f))
	{
		data.trace_length_remaining = weaponData->m_Range - data.trace_length;

		Vector end = data.src + data.direction * data.trace_length_remaining;

		U::TraceLine(data.src, end, MASK_SHOT | CONTENTS_GRATE, entity, &data.enter_trace);
		ClipTraceToPlayers(data.src, end + data.direction * 40.f, 0x4600400B, &data.filter, &data.enter_trace);

		if (data.enter_trace.fraction == 1.0f)
			break;

		if ((data.enter_trace.hitgroup <= 7) && (data.enter_trace.hitgroup > 0) && (data.enter_trace.m_pEnt->IsEnemy() || Opts.RageBot.AimBot.FriendlyFire))
		{
			data.trace_length += data.enter_trace.fraction * data.trace_length_remaining;
			data.current_damage *= pow(weaponData->m_RangeModifier, data.trace_length * 0.002);

			ScaleDamage(data.enter_trace.hitgroup, data.enter_trace.m_pEnt, weaponData->m_ArmorRatio, data.current_damage);

			return true;
		}

		if (!HandleBulletPenetration(weaponData, data))
			break;
	}

	return false;
}

bool Autowall::HandleBulletPenetration(CSWeaponInfo *wpn_data, FireBulletData &data)
{

	surfacedata_t *enter_surface_data = I::Physprops->GetSurfaceData(data.enter_trace.surface.surfaceProps);
	int enter_material = enter_surface_data->game.material;
	float enter_surf_penetration_mod = *(float*)((DWORD)enter_surface_data + 80);

	data.trace_length += data.enter_trace.fraction * data.trace_length_remaining;
	data.current_damage *= pow((wpn_data->m_RangeModifier), (data.trace_length * 0.002));

	if ((data.trace_length > 3000.f) || (enter_surf_penetration_mod < 0.1f))
		data.penetrate_count = 0;

	if (data.penetrate_count <= 0)
		return false;

	Vector dummy;
	trace_t trace_exit;
	if (!TraceToExit(dummy, data.enter_trace, data.enter_trace.endpos.x, data.enter_trace.endpos.y, data.enter_trace.endpos.z, data.direction.x, data.direction.y, data.direction.z, &trace_exit))
		return false;

	surfacedata_t *exit_surface_data = I::Physprops->GetSurfaceData(trace_exit.surface.surfaceProps);
	int exit_material = exit_surface_data->game.material;

	float exit_surf_penetration_mod = *(float*)((DWORD)exit_surface_data + 76);
	float final_damage_modifier = 0.16f;
	float combined_penetration_modifier = 0.0f;

	if (((data.enter_trace.contents & CONTENTS_GRATE) != 0) || (enter_material == 89) || (enter_material == 71))
	{
		combined_penetration_modifier = 3.0f;
		final_damage_modifier = 0.05f;
	}
	else
	{
		combined_penetration_modifier = (enter_surf_penetration_mod + exit_surf_penetration_mod) * 0.5f;
	}

	if (enter_material == exit_material)
	{
		if (exit_material == 87 || exit_material == 85)
			combined_penetration_modifier = 3.0f;
		else if (exit_material == 76)
			combined_penetration_modifier = 2.0f;
	}

	float v34 = fmaxf(0.f, 1.0f / combined_penetration_modifier);
	float v35 = (data.current_damage * final_damage_modifier) + v34 * 3.0f * fmaxf(0.0f, (3.0f / wpn_data->m_Penetration) * 1.25f);
	float thickness = (trace_exit.endpos - data.enter_trace.endpos).Length();

	thickness *= thickness;
	thickness *= v34;
	thickness /= 24.0f;

	float lost_damage = fmaxf(0.0f, v35 + thickness);

	if (lost_damage > data.current_damage)
		return false;

	if (lost_damage >= 0.0f)
		data.current_damage -= lost_damage;

	if (data.current_damage < 1.0f)
		return false;

	data.src = trace_exit.endpos;
	data.penetrate_count--;

	return true;
}

bool Autowall::TraceToExit(Vector& end, trace_t& tr, float x, float y, float z, float x2, float y2, float z2, trace_t* trace)
{
	typedef bool(__fastcall* TraceToExitFn)(Vector&, trace_t&, float, float, float, float, float, float, trace_t*);
	static TraceToExitFn TraceToExit = (TraceToExitFn)U::FindPattern("client_panorama.dll", "55 8B EC 83 EC 30 F3 0F 10 75");
	if (!TraceToExit)
	{
		return false;
	}//(Vector&, trace_t&, float, float, float, float, float, float, trace_t*);
	_asm
	{
		push trace
		push z2
		push y2
		push x2
		push z
		push y
		push x
		mov edx, tr
		mov ecx, end
		call TraceToExit
		add esp, 0x1C
	}
}

void Autowall::ClipTraceToPlayers(const Vector &vecAbsStart, const Vector &vecAbsEnd, unsigned int mask, ITraceFilter *filter, trace_t *tr)
{
	static DWORD ClipTraceToPlayersAdd = (DWORD)U::FindPattern("client_panorama.dll", "53 8B DC 83 EC 08 83 E4 F0 83 C4 04 55 8B 6B 04 89 6C 24 04 8B EC 81 EC ? ? ? ? 8B 43 10");
	if (!ClipTraceToPlayersAdd)
		return;

	_asm
	{
		MOV     EAX, filter
		LEA     ECX, tr
		PUSH    ECX
		PUSH    EAX
		PUSH    mask
		LEA     EDX, vecAbsEnd
		LEA     ECX, vecAbsStart
		CALL    ClipTraceToPlayersAdd
		ADD     ESP, 0xC
	}
}

float GetHitgroupDamageMultiplier(int iHitGroup)
{
	switch (iHitGroup)
	{
		case HITGROUP_HEAD:
			return 4.0f;

		case HITGROUP_CHEST:
		case HITGROUP_LEFTARM:
		case HITGROUP_RIGHTARM:
			return 1.0f;

		case HITGROUP_STOMACH:
			return 1.25f;

		case HITGROUP_LEFTLEG:
		case HITGROUP_RIGHTLEG:
			return 0.75f;
	}

	return 1.0f;
}


void Autowall::ScaleDamage(int hitgroup, CBaseEntity *player, float weapon_armor_ratio, float &current_damage)
{
	current_damage *= GetHitgroupDamageMultiplier(hitgroup);

	int armor = player->GetArmor();
	int helmet = player->HasHelmet();

	if (IsArmored(player, hitgroup))
	{
		if (hitgroup == HITGROUP_HEAD)
		{
			if (helmet)
				current_damage *= (weapon_armor_ratio * .5f);
		}
		else
		{
			current_damage *= (weapon_armor_ratio * .5f);
		}
	}
}

bool Autowall::IsArmored(CBaseEntity *player, int hitgroup)
{
	switch (hitgroup)
	{
		case HITGROUP_HEAD:
			return player->HasHelmet();

		case HITGROUP_GENERIC:
		case HITGROUP_CHEST:
		case HITGROUP_STOMACH:
		case HITGROUP_LEFTARM:
		case HITGROUP_RIGHTARM:
			return player->GetArmor() > 0 ? true : false;
	}
}