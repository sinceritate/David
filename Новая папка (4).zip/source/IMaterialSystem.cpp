#include "SDK.h"

int created = 0;

IMaterial* IMaterialSystem::CreateMaterial(bool flat, bool ignorez, bool wireframed)
{
	std::string Type = (flat) ? ("UnlitGeneric") : ("VertexLitGeneric");

	std::string matdata = ("\"") + Type + ("\"\n{\n\t\"$basetexture\" \"vgui/white_additive\"\n\t\"$envmap\"  \"\"\n\t\"$model\" \"1\"\n\t\"$flat\" \"1\"\n\t\"$nocull\"  \"0\"\n\t\"$selfillum\" \"1\"\n\t\"$halflambert\" \"1\"\n\t\"$nofog\"  \"0\"\n\t\"$znearer\" \"0\"\n\t\"$wireframe\" \"") + to_str(wireframed) + ("\"\n\t\"$ignorez\" \"") + to_str(ignorez) + ("\"\n}\n");

	std::string matname = ("custom_") + to_str(created);
	++created;

	KeyValues* pKeyValues = new KeyValues(matname.c_str());
	U::InitKeyValues(pKeyValues, Type.c_str());
	U::LoadFromBuffer(pKeyValues, matname.c_str(), matdata.c_str());

	typedef IMaterial*(__thiscall* OriginalFn)(void*, const char* pMaterialName, KeyValues* pVMTKeyValues);
	IMaterial* createdMaterial = U::GetVFunc< OriginalFn >(this, 83)(this, matname.c_str(), pKeyValues);

	createdMaterial->IncrementReferenceCount();

	return createdMaterial;
}

IMaterial* IMaterialSystem::FindMaterial(char const* pMaterialName, const char* pTextureGroupName, bool complain, const char* pComplainPrefix)
{
	typedef IMaterial*(__thiscall* OriginalFn)(void*, char const* pMaterialName, const char* pTextureGroupName, bool complain, const char* pComplainPrefix);
	return U::GetVFunc< OriginalFn >(this, 84)(this, pMaterialName, pTextureGroupName, complain, pComplainPrefix);
}
