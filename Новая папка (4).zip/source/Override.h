#pragma once

struct entity_info
{
	float old_lby = 0;
	float move_lby = 0;
	float jump_lby = 0;
	float step_lby = 0;
	float new_lby = 0;

	float old_yaw = 0;
	float move_yaw = 0;
	float jump_yaw = 0;
	float step_yaw = 0;
	float new_yaw = 0;

	CBaseAnimState* old_anim = 0;
	CBaseAnimState* new_anim = 0;

	bool on_ground = false;
	bool in_step = false;

	float send_true = 0;
	float send_false = 0;
	bool using_fakes = false;
};

class entity_resolver
{
public:
	void resolver(CBaseEntity* entity);
	void override_entity(CBaseEntity* entity);

private:
	entity_info ent_info[64];
};

extern entity_resolver Resolver;