#pragma once

#include "AutoWall.h"

namespace Rage
{
	namespace AntiAims
	{
		extern float GetMaxDelta(CBaseEntity* entity);
		extern void RageAA();
		extern void LegitDesync();
		extern int DoYaw(int type);
	};

	namespace AimBot
	{
		extern float BestDMG;
		extern int PlayerID;
		extern std::vector <int> hitbox_list;
		extern bool baim_work;

		extern void HitboxList(CBaseEntity* Entity);
		extern int GetHitbox(int ID);
		extern bool HitChance(float flHitChance);

		extern bool DropTarget();
		extern void FindTarget();
		extern void GoToTarget();

		extern bool CheckTarget(CBaseEntity* entity);

		extern void Start();

		extern int current_weapon_index;
		extern int old_weapon_index;
		extern int current_weapon_type;
		extern int old_weapon_type;

		extern int target_player;
	}

	extern void UpdateRageSettings();

	extern void Start();
};