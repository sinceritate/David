#include "LuaManager.h"

void LuaManager::SetUpSettings()
{
	char path[512];
	SHGetFolderPathA(NULL, CSIDL_APPDATA, NULL, 0, path);
	path_to_folder = std::string(path) + "\\NoNameHack\\Cheat\\Luas\\";

	CreateDirectory(path_to_folder.c_str(), 0);
}

void LuaManager::UpdateLuaList()
{
	WIN32_FIND_DATA FindFileData;
	HANDLE file_handle;

	static std::string first_file = path_to_folder + "*";
	file_handle = FindFirstFile(first_file.c_str(), &FindFileData);

	Opts.Menu.MassLuas.clear();
	if (file_handle != INVALID_HANDLE_VALUE)
	{
		do
		{
			std::string file = FindFileData.cFileName;
			if (file.rfind(".lua") != std::string::npos)
				Opts.Menu.MassLuas.push_back(file);

		} while (FindNextFile(file_handle, &FindFileData) != 0);

		FindClose(file_handle);
	}
}

void LuaManager::LoadLua(std::string lua_name)
{
	size_t idx = ExpLua.GetScriptId(lua_name);
	if (idx == std::string::npos)
	{
		ExpLua.scripts.push_back(lua_name);
		ExpLua.enabled.push_back(true);

		ExpLua.lua.script_file(path_to_folder + lua_name, [](lua_State*, sol::protected_function_result result) {
			if (!result.valid()) {
				sol::error err = result;
				I::Cvar->ConsoleColorPrintf(Color(255, 0, 0, 255), err.what());
			}

			return result;
		});
	}
	else if (idx != std::string::npos && !ExpLua.enabled[idx])
	{
		ExpLua.enabled[idx] = true;

		ExpLua.lua.script_file(path_to_folder + lua_name, [](lua_State*, sol::protected_function_result result) {
			if (!result.valid()) {
				sol::error err = result;
				I::Cvar->ConsoleColorPrintf(Color(255, 0, 0, 255), err.what());
			}

			return result;
		});
	}
}

void LuaManager::ReloadLua(std::string lua_name)
{
	UnloadLua(lua_name);
	LoadLua(lua_name);
}

void LuaManager::UnloadLua(std::string lua_name)
{
	size_t idx = ExpLua.GetScriptId(lua_name);
	if (idx == std::string::npos)
		return;

	if (!ExpLua.enabled[idx])
		return;

	LuaEventManager.RemoveScriptEvents(idx);

	ExpLua.enabled[idx] = false;
}

void LuaManager::UnloadAllScripts()
{
	for (size_t i = 0; i < ExpLua.scripts.size(); ++i)
	{
		if (!ExpLua.enabled[i])
			continue;

		LuaEventManager.RemoveScriptEvents(i);
		ExpLua.enabled[i] = false;
	}
}

LuaManager LManager;