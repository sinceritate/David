#include "SDK.h"

bool IBaseClientDll::DispatchUserMessage(int messageType, int arg, int arg1, void* data)
{
	using DispatchUserMessage_t = bool* (__thiscall*)(void*, int, int, int, void*);
	return U::GetVFunc<DispatchUserMessage_t>(this, 38)(this, messageType, arg, arg1, data);
}