#include "Cheat.h"

Player_t pPlayer[65];
Bomb_t   pBomb;

std::deque< ESP::Misc::BulletTracer::CLog > ESP::Misc::BulletTracer::Log;
std::deque< ESP::Misc::HitMarker::CLog > ESP::Misc::HitMarker::Log;

CSoundEsp ESP::Misc::SoundESP::Sound;

void CSoundEsp::AddEntity(Vector vOrigin, int iEntIndex)
{
	LastSoundInfo Sound_Entry;

	Sound_Entry.Time = GetTickCount64() + 800;
	Sound_Entry.EntityIndex = iEntIndex;
	Sound_Entry.Origin = vOrigin;
	Sound_Entry.Radius = 10.0f;

	Sounds.push_back(Sound_Entry);
}

void DrawWave(Vector origin, float radius, Color color)
{
	static float Step = M_PI * 3.0f / 50;

	Vector start = { 0, 0, 0 };
	Vector end = { 0, 0, 0 };

	I::Surface->DrawSetColor(color);

	for (float lat = 0; lat <= M_PI * 4.0f; lat += Step)
	{
		if (D::WorldToScreen(origin + Vector(-sin(lat) * radius, cos(lat) * radius, 0), end))
		{
			if (lat > 0.000)
			{
				I::Surface->DrawLine(start.x, start.y, end.x, end.y);
			}
		}
		start = end;
	}
}

void CSoundEsp::DrawSoundEsp()
{
	for (size_t i = 0; i < Sounds.size(); ++i)
	{
		if (Sounds[i].Time <= GetTickCount64()) Sounds.erase(Sounds.begin() + i);

		DrawWave(Sounds[i].Origin, Sounds[i].Radius, Color(255, 255, 255, 255));
		Sounds[i].Radius += 0.2f;
	}
}

void GrenadeHelper()
{
	for (int i = 0; i < Opts.Visuals.GrenadeHelper.OptMass.size(); ++i)
	{
		D::DrawCircle3D(Opts.Visuals.GrenadeHelper.OptMass[i].org_pos, 50, 10, Color(255, 255, 255, 255));

		if (Opts.Visuals.GrenadeHelper.OptMass[i].org_pos.DistTo(G::LocalPlayer->GetOrigin()) < 100)
		{
			float sy, cy, sx, cx;
			SinCos(DEG2RAD(Opts.Visuals.GrenadeHelper.OptMass[i].ang.y), sy, cy);
			SinCos(DEG2RAD(Opts.Visuals.GrenadeHelper.OptMass[i].ang.x), sx, cx);

			Vector origin = Opts.Visuals.GrenadeHelper.OptMass[i].eye_pos + Vector(cy * cx * 100, sy * cx * 100, sx * -100);

			Vector end = Vector(0, 0, 0);
			if (D::WorldToScreen(origin, end))
			{
				I::Surface->DrawSetColor(Color(255, 255, 255, 255));
				I::Surface->DrawOutlinedCircle(end.x, end.y, 10, 32);
			}
		}
	}
}

RECT GetRectBox(CBaseEntity* Entity)
{
	RECT rect;
	ICollideable* collideable = Entity->GetCollideable();
	if (!collideable) return rect;

	Vector min = collideable->OBBMins();
	Vector max = collideable->OBBMaxs();

	Vector points[] = {
		Vector(min.x, min.y, min.z),
		Vector(min.x, max.y, min.z),
		Vector(max.x, max.y, min.z),
		Vector(max.x, min.y, min.z),
		Vector(max.x, max.y, max.z),
		Vector(min.x, max.y, max.z),
		Vector(min.x, min.y, max.z),
		Vector(max.x, min.y, max.z) };

	matrix3x4_t& trans = Entity->m_rgflCoordinateFrame();

	Vector pointsTransformed[8];
	Vector screen_points[8];

	bool init = false;

	for (int i = 0; i < 8; i++)
	{
		M::VectorTransform(points[i], trans, pointsTransformed[i]);

		if (!D::WorldToScreen(pointsTransformed[i], screen_points[i]))
			return rect;

		if (!init)
		{
			rect.left = screen_points[0].x;
			rect.top = screen_points[0].y;
			rect.right = screen_points[0].x;
			rect.bottom = screen_points[0].y;
			init = true;
		}
		else
		{
			if (rect.left > screen_points[i].x)
				rect.left = screen_points[i].x;
			if (rect.bottom < screen_points[i].y)
				rect.bottom = screen_points[i].y;
			if (rect.right < screen_points[i].x)
				rect.right = screen_points[i].x;
			if (rect.top > screen_points[i].y)
				rect.top = screen_points[i].y;
		}
	}

	return rect;
}

/*
box, skeleton, weapon, distance
*/

void ESP::Box::Default(RECT Data, Color pColor)
{
	I::Surface->DrawSetColor(pColor);
	I::Surface->DrawOutlinedRect(Data.left, Data.top, Data.right, Data.bottom);
}

void ESP::Box::Corner(RECT Data, Color Col)
{
	int x = (Data.right - Data.left) / 3;
	int y = (Data.bottom - Data.top) / 3;

	I::Surface->DrawSetColor(Col);
	I::Surface->DrawLine(Data.left, Data.top, Data.left + x, Data.top); // top left
	I::Surface->DrawLine(Data.right - x, Data.top, Data.right, Data.top); // top right
	I::Surface->DrawLine(Data.right, Data.top, Data.right, Data.top + y); // right top
	I::Surface->DrawLine(Data.right, Data.bottom - y, Data.right, Data.bottom); // right bottom
	I::Surface->DrawLine(Data.right, Data.bottom, Data.right - x, Data.bottom); // bottom left
	I::Surface->DrawLine(Data.left + x, Data.bottom, Data.left, Data.bottom); // bottom right
	I::Surface->DrawLine(Data.left, Data.bottom, Data.left, Data.bottom - y); // left bottom
	I::Surface->DrawLine(Data.left, Data.top + y, Data.left, Data.top); // left top
}

void ESP::Box::Bracket(RECT Data, Color pColor)
{
	int x = (Data.right - Data.left) / 3;
	int y = (Data.bottom - Data.top) / 3;

	I::Surface->DrawSetColor(pColor);
	I::Surface->DrawLine(Data.left, Data.top, Data.left + x, Data.top); // top left
	I::Surface->DrawLine(Data.right - x, Data.top, Data.right, Data.top); // top right
	I::Surface->DrawLine(Data.right, Data.top, Data.right, Data.bottom); // right
	I::Surface->DrawLine(Data.right, Data.bottom, Data.right - x, Data.bottom); // bottom left
	I::Surface->DrawLine(Data.left + x, Data.bottom, Data.left, Data.bottom); // bottom right
	I::Surface->DrawLine(Data.left, Data.bottom, Data.left, Data.top); // left
}

void ESP::Box::InvertedBracket(RECT Data, Color pColor)
{
	int x = (Data.right - Data.left) / 3;
	int y = (Data.bottom - Data.top) / 3;

	I::Surface->DrawSetColor(pColor);
	I::Surface->DrawLine(Data.left, Data.top, Data.right, Data.top); // top
	I::Surface->DrawLine(Data.right, Data.top, Data.right, Data.top + y); // right top
	I::Surface->DrawLine(Data.right, Data.bottom - y, Data.right, Data.bottom); // right bottom
	I::Surface->DrawLine(Data.right, Data.bottom, Data.left, Data.bottom); // bottom
	I::Surface->DrawLine(Data.left, Data.bottom, Data.left, Data.bottom - y); // left bottom
	I::Surface->DrawLine(Data.left, Data.top + y, Data.left, Data.top); // left top
}

void ESP::Box::Filled(RECT Data, Color pColor)
{
	I::Surface->DrawSetColor(pColor);
	I::Surface->DrawFilledRect(Data.left, Data.top, Data.right, Data.bottom);
}

RECT Outline(RECT rect)
{
	rect.left -= 1;
	rect.right += 1;
	rect.top -= 1;
	rect.bottom += 1;
	return rect;
}

RECT Inline(RECT rect)
{
	rect.left += 1;
	rect.right -= 1;
	rect.top += 1;
	rect.bottom -= 1;
	return rect;
}

void ESP::Player::Draw(int index)
{
	CBaseEntity* entity = I::ClientEntList->GetClientEntity(index);

	bool is_enemy = entity->IsEnemy();

	if (!is_enemy && Opts.Visuals.Players.Global.EnemyOnly)
		return;

	bool Visible = entity->IsVisible(BONE_CHEST) && !U::IsInSmoke(entity->GetBonePosition(BONE_CHEST));

	if (!Visible && Opts.Visuals.Players.Global.VisibleOnly)
		return;


	// QAngle local_view;
	// I::Engine->GetViewAngles(local_view);
	// 
	// Vector local_pos = G::LocalPlayer->GetOrigin() + G::LocalPlayer->GetVecViewOffset();
	// 
	// float rot = DEG2RAD(local_view.y - U::CalcAngle(local_pos, entity->GetBonePosition(BONE_UPPER_CHEST)).y - 270.f);
	// 
	// std::vector<Vertex_t> vertices;
	// 
	// vertices.push_back(Vertex_t(Vector2D(G::ScreenWidthHalf + cosf(rot) * 480.f, G::ScreenHeightHalf + sinf(rot) * 480.f)));
	// vertices.push_back(Vertex_t(Vector2D(G::ScreenWidthHalf + cosf(rot + DEG2RAD(2)) * (480.f - 20), G::ScreenHeightHalf + sinf(rot + DEG2RAD(2)) * (480.f - 20))));
	// vertices.push_back(Vertex_t(Vector2D(G::ScreenWidthHalf + cosf(rot - DEG2RAD(2)) * (480.f - 20), G::ScreenHeightHalf + sinf(rot - DEG2RAD(2)) * (480.f - 20))));
	// 
	// static int texture_id = I::Surface->CreateNewTextureID(true); // 
	// static unsigned char buf[4] = { 255, 255, 255, 255 };
	// I::Surface->DrawSetTextureRGBA(texture_id, buf, 1, 1); //
	// 
	// I::Surface->DrawSetColor(pColor); //
	// I::Surface->DrawSetTexture(texture_id); //
	// I::Surface->DrawTexturedPolygon(3, vertices.data());

	//OutOfScreen(entity);

	Vector Pos, Top;
	if (!D::WorldToScreen(entity->GetOrigin(), Pos) || !D::WorldToScreen(entity->GetOrigin() + Vector(0, 0, entity->GetCollideable()->OBBMaxs().z), Top))
		return;

	Color pColor;

	if (Opts.Visuals.Players.Global.SnipeLine)
	{
		if (is_enemy)
			pColor = Visible ? Opts.Colors.Visuals.PlayersSnipeLineEnemyVisible : Opts.Colors.Visuals.PlayersSnipeLineEnemyInvisible;
		else
			pColor = Visible ? Opts.Colors.Visuals.PlayersSnipeLineTeammateVisible : Opts.Colors.Visuals.PlayersSnipeLineTeammateInvisible;

		I::Surface->DrawSetColor(pColor);
		I::Surface->DrawLine(G::ScreenWidthHalf, G::ScreenHeight - 1, Pos.x, Pos.y);
	}

	if (is_enemy)
		pColor = Visible ? Opts.Colors.Visuals.PlayersGlobalEnemyVisible : Opts.Colors.Visuals.PlayersGlobalEnemyInvisible;
	else
		pColor = Visible ? Opts.Colors.Visuals.PlayersGlobalTeammateVisible : Opts.Colors.Visuals.PlayersGlobalTeammateInvisible;

	int Height = Pos.y - Top.y;
	int Width = Height / 4;

	float Left = Top.x - Width;
	float Right = Top.x + Width;
	float Up = Top.y;
	float Down = Top.y + Height;
	int HCenter = Top.y + (Height / 2);
	int WCenter = Top.x;

	RECT rect;
	rect.bottom = Pos.y;
	rect.top = Top.y;
	rect.right = Right;
	rect.left = Left;

	if (rect.top < -64  || rect.top > G::ScreenHeight + 64 || rect.left < -64 || rect.left > G::ScreenWidth + 64)
		return;
	if (rect.bottom < -64 || rect.bottom > G::ScreenHeight + 64 || rect.right < -64 || rect.right > G::ScreenWidth + 64)
		return;

	if (Opts.Visuals.Players.Global.Skeleton)
		ESP::Player::Skeleton(entity);

	int w22, TextH; I::Surface->GetTextSize(F::ESP, L"A", w22, TextH);

	switch (Opts.Visuals.Players.Global.BoxMode)
	{
	case 1: {
		Box::Default(rect, pColor);

		if (Opts.Visuals.Players.Global.Outline) {
			Box::Default(Outline(rect), Color(0, 0, 0));
			Box::Default(Inline(rect), Color(0, 0, 0));
		}
		break;
	}
	case 2: {
		if (Opts.Visuals.Players.Global.Outline) {
			int x = (Right - Left) / 3;
			int y = (Down - Up) / 3;

			I::Surface->DrawSetColor(Color(0, 0, 0));

			// out
			I::Surface->DrawLine(Left - 1, Up - 1, Left + x + 1, Up - 1); // top left
			I::Surface->DrawLine(Right - x - 1, Up - 1, Right + 1, Up - 1); // top right
			I::Surface->DrawLine(Right + 1, Up - 1, Right + 1, Up + y + 1); // right top
			I::Surface->DrawLine(Right + 1, Down - y - 1, Right + 1, Down + 1); // right bottom
			I::Surface->DrawLine(Right + 1, Down + 1, Right - x - 1, Down + 1); // bottom left
			I::Surface->DrawLine(Left + x + 1, Down + 1, Left - 1, Down + 1); // bottom right
			I::Surface->DrawLine(Left - 1, Down + 1, Left - 1, Down - y - 1); // left bottom
			I::Surface->DrawLine(Left - 1, Up + y + 1, Left - 1, Up - 1); // left top
			// in
			I::Surface->DrawLine(Left + 1, Up + 1, Left + x + 1, Up + 1); // top left
			I::Surface->DrawLine(Right - x - 1, Up + 1, Right - 1, Up + 1); // top right
			I::Surface->DrawLine(Right - 1, Up + 1, Right - 1, Up + y + 1); // right top
			I::Surface->DrawLine(Right - 1, Down - y - 1, Right - 1, Down - 1); // right bottom
			I::Surface->DrawLine(Right - 1, Down - 1, Right - x - 1, Down - 1); // bottom left
			I::Surface->DrawLine(Left + x + 1, Down - 1, Left + 1, Down - 1); // bottom right
			I::Surface->DrawLine(Left + 1, Down - 1, Left + 1, Down - y - 1); // left bottom
			I::Surface->DrawLine(Left + 1, Up + y + 1, Left + 1, Up + 1); // left top
			// middle
			I::Surface->DrawLine(Left + x, Up, Left + x + 1, Up); // top left
			I::Surface->DrawLine(Right - x, Up, Right - x - 1, Up); // top right
			I::Surface->DrawLine(Right - x, Down, Right - x - 1, Down); // bottom left
			I::Surface->DrawLine(Left + x, Down, Left + x + 1, Down); // bottom right
			I::Surface->DrawLine(Right, Up + y, Right, Up + y + 1); // right top
			I::Surface->DrawLine(Right, Down - y, Right, Down - y - 1); // right bottom
			I::Surface->DrawLine(Left, Up + y, Left, Up + y + 1); // left bottom
			I::Surface->DrawLine(Left, Down - y, Left, Down - y - 1); // left top
		}

		Box::Corner(rect, pColor);
		break;
	}
	case 3: {
		if (Opts.Visuals.Players.Global.Outline) {
			int x = (Right - Left) / 3;
			int y = (Down - Up) / 3;

			I::Surface->DrawSetColor(Color(0, 0, 0));

			// out
			I::Surface->DrawLine(Left - 1, Up - 1, Left + x + 1, Up - 1); // top left
			I::Surface->DrawLine(Right - x - 1, Up - 1, Right + 1, Up - 1); // top right
			I::Surface->DrawLine(Right + 1, Up - 1, Right + 1, Down + 1); // right
			I::Surface->DrawLine(Right + 1, Down + 1, Right - x - 1, Down + 1); // bottom left
			I::Surface->DrawLine(Left + x + 1, Down + 1, Left - 1, Down + 1); // bottom right
			I::Surface->DrawLine(Left - 1, Down + 1, Left - 1, Up - 1); // left
			// in
			I::Surface->DrawLine(Left + 1, Up + 1, Left + x + 1, Up + 1); // top left
			I::Surface->DrawLine(Right - x - 1, Up + 1, Right - 1, Up + 1); // top right
			I::Surface->DrawLine(Right - 1, Up + 1, Right - 1, Down - 1); // right
			I::Surface->DrawLine(Right - 1, Down - 1, Right - x - 1, Down - 1); // bottom left
			I::Surface->DrawLine(Left + x + 1, Down - 1, Left + 1, Down - 1); // bottom right
			I::Surface->DrawLine(Left + 1, Down - 1, Left + 1, Up + 1); // left
			// middle
			I::Surface->DrawLine(Left + x, Up, Left + x + 1, Up); // top left
			I::Surface->DrawLine(Right - x, Up, Right - x - 1, Up); // top right
			I::Surface->DrawLine(Right - x, Down, Right - x - 1, Down); // bottom left
			I::Surface->DrawLine(Left + x, Down, Left + x + 1, Down); // bottom right
		}

		Box::Bracket(rect, pColor);

		break;
	}
	case 4: {
		if (Opts.Visuals.Players.Global.Outline) {
			int x = (Right - Left) / 3;
			int y = (Down - Up) / 3;

			I::Surface->DrawSetColor(Color(0, 0, 0));

			// out
			I::Surface->DrawLine(Left - 1, Up - 1, Right + 1, Up - 1); // top
			I::Surface->DrawLine(Right + 1, Up - 1, Right + 1, Up + y + 1); // right top
			I::Surface->DrawLine(Right + 1, Down - y - 1, Right + 1, Down + 1); // right bottom
			I::Surface->DrawLine(Right + 1, Down + 1, Left - 1, Down + 1); // bottom
			I::Surface->DrawLine(Left - 1, Down + 1, Left - 1, Down - y - 1); // left bottom
			I::Surface->DrawLine(Left - 1, Up + y + 1, Left - 1, Up - 1); // left top
			// in
			I::Surface->DrawLine(Left + 1, Up + 1, Right - 1, Up + 1); // top
			I::Surface->DrawLine(Right - 1, Up + 1, Right - 1, Up + y + 1); // right top
			I::Surface->DrawLine(Right - 1, Down - y - 1, Right - 1, Down - 1); // right bottom
			I::Surface->DrawLine(Right - 1, Down - 1, Left + 1, Down - 1); // bottom
			I::Surface->DrawLine(Left + 1, Down - 1, Left + 1, Down - y - 1); // left bottom
			I::Surface->DrawLine(Left + 1, Up + y + 1, Left + 1, Up + 1); // left top
			// middle
			I::Surface->DrawLine(Right, Up + y, Right, Up + y + 1); // right top
			I::Surface->DrawLine(Right, Down - y, Right, Down - y - 1); // right bottom
			I::Surface->DrawLine(Left, Up + y, Left, Up + y + 1); // left bottom
			I::Surface->DrawLine(Left, Down - y, Left, Down - y - 1); // left top
		}
		Box::InvertedBracket(rect, pColor);

		break;
	}
	case 5: {
		Box::Default(rect, pColor);
		Box::Filled(Inline(rect), pColor.DiffAlpha(60));

		if (Opts.Visuals.Players.Global.Outline) {
			Box::Default(Inline(rect), Color(0, 0, 0));
			Box::Default(Outline(rect), Color(0, 0, 0));
		}
		break;
	}
	case 6: {
		ICollideable* coll = entity->GetCollideable();

		Vector min = coll->OBBMins();
		Vector max = coll->OBBMaxs();

		Vector corners[8] =
		{
			Vector(min.x,min.y,min.z + 7),
			Vector(min.x,max.y,min.z + 7),
			Vector(max.x,max.y,min.z + 7),
			Vector(max.x,min.y,min.z + 7),
			Vector(min.x,min.y,max.z + 7),
			Vector(min.x,max.y,max.z + 7),
			Vector(max.x,max.y,max.z + 7),
			Vector(max.x,min.y,max.z + 7)
		};

		float ang = entity->GetEyeAngles().y;
		Vector _corners[8];
		Vector bufCorners;

		for (int i = 0; i <= 7; i++)
		{
			corners[i].Rotate2D(ang);

			Vector Orig = entity->GetOrigin();
			Orig.z -= 7;
			if (D::WorldToScreen(Orig + corners[i], bufCorners))
				if (D::WorldToScreen(Orig + corners[i], bufCorners))
				{
					_corners[i] = bufCorners;
				}

			if (_corners[i].x < -64 || _corners[i].y < -64 || _corners[i].x > G::ScreenWidth + 64 || _corners[i].y > G::ScreenHeight + 64)
				continue;
		}

		for (int i = 1; i <= 4; i++)
		{
			if (Opts.Visuals.Players.Global.Outline)
			{
				I::Surface->DrawSetColor(Color(0, 0, 0));

				I::Surface->DrawLine((float)(_corners[i - 1].x), (float)(_corners[i - 1].y) + 1, (float)(_corners[i % 4].x), (float)(_corners[i % 4].y) + 1);// bottom
				I::Surface->DrawLine((float)(_corners[i - 1].x), (float)(_corners[i - 1].y) - 1, (float)(_corners[i % 4].x), (float)(_corners[i % 4].y) - 1);// bottom

				I::Surface->DrawLine((float)(_corners[i + 3].x), (float)(_corners[i + 3].y) - 1, (float)(_corners[i % 4 + 4].x), (float)(_corners[i % 4 + 4].y) - 1);// top
				I::Surface->DrawLine((float)(_corners[i + 3].x), (float)(_corners[i + 3].y) + 1, (float)(_corners[i % 4 + 4].x), (float)(_corners[i % 4 + 4].y) + 1);// top

				I::Surface->DrawLine((float)(_corners[i - 1].x) - 1, (float)(_corners[i - 1].y), (float)(_corners[i + 3].x) - 1, (float)(_corners[i + 3].y));// centityer
				I::Surface->DrawLine((float)(_corners[i - 1].x) + 1, (float)(_corners[i - 1].y), (float)(_corners[i + 3].x) + 1, (float)(_corners[i + 3].y));// centityer
			}

			I::Surface->DrawSetColor(pColor);

			I::Surface->DrawLine((_corners[i - 1].x), (_corners[i - 1].y), (_corners[i % 4].x), (_corners[i % 4].y));// bottom

			I::Surface->DrawLine((_corners[i + 3].x), (_corners[i + 3].y), (_corners[i % 4 + 4].x), (_corners[i % 4 + 4].y));// top

			I::Surface->DrawLine((_corners[i - 1].x), (_corners[i - 1].y), (_corners[i + 3].x), (_corners[i + 3].y)); // centityer
		}

		break;
	}
	default:
		break;
	}

	if (Opts.Visuals.Players.Global.Health.Enable)
	{
		float px_fix_x = float(Height) / 300.f;
		float px_fix_y = float(Width) / 75.f;
		ImVec4 position_fixed = ImVec4(Opts.Visuals.Players.Global.Health.DefaulPos.x * px_fix_x, Opts.Visuals.Players.Global.Health.DefaulPos.y * px_fix_y, Opts.Visuals.Players.Global.Health.DefaulPos.z * px_fix_x, Opts.Visuals.Players.Global.Health.DefaulPos.w * px_fix_y);
		ImVec4 position_fixed2 = ImVec4(Opts.Visuals.Players.Global.Health.DefaulPos2.x * px_fix_x, Opts.Visuals.Players.Global.Health.DefaulPos2.y * px_fix_y, Opts.Visuals.Players.Global.Health.DefaulPos2.z * px_fix_x, Opts.Visuals.Players.Global.Health.DefaulPos2.w * px_fix_y);

		// y1 = (x1 * y) / x
		// y1 = ((x + x1) * y) / (x * 2)

		vector2d Start = vector2d(Left + position_fixed.x, Up + position_fixed.y);
		vector2d End = vector2d(Left + position_fixed.z, Down + position_fixed.w);

		char width_hp = Opts.Visuals.Players.Global.Health.Width;
		char height_hp = Opts.Visuals.Players.Global.Health.Height;

		if (Opts.Visuals.Players.Global.Health.Type == 0)
		{
			if (Opts.Visuals.Players.Global.Health.Outline)
			{
				I::Surface->DrawSetColor(Opts.Visuals.Players.Global.Health.Outline_Color);
				I::Surface->DrawOutlinedRect(Left - width_hp + position_fixed.x - 2, Up - height_hp + position_fixed.y - 1, Left + position_fixed.x + 2, Down + position_fixed.y + 1);
			}

			float HealthPercentity = (Height * (float)(entity->GetHealth() / 100.f));

			I::Surface->DrawSetColor(Opts.Visuals.Players.Global.Health.Health_Color);
			I::Surface->DrawFilledRect(Left - width_hp + position_fixed.x - 1, Down - height_hp + position_fixed.y - HealthPercentity, Left + position_fixed.x + 1, Down + position_fixed.y);

			if (Opts.Visuals.Players.Global.Health.Background)
			{
				I::Surface->DrawSetColor(Opts.Visuals.Players.Global.Health.Background_Color);
				I::Surface->DrawFilledRect(Left - width_hp + position_fixed.x - 1, Up - height_hp + position_fixed.y, Left + position_fixed.x + 1, Down - height_hp + position_fixed.y - HealthPercentity);
			}

			if (Opts.Visuals.Players.Global.Health.Division > 0)
			{
				float divisions = (Up - height_hp - Down) / (Opts.Visuals.Players.Global.Health.Division);

				for (int i = 1; i < Opts.Visuals.Players.Global.Health.Division; ++i)
				{
					I::Surface->DrawSetColor(Color(0, 0, 0, 255));
					I::Surface->DrawOutlinedRect(Left - width_hp + position_fixed.x - 1, Up - height_hp + position_fixed.y - divisions * i, Left + position_fixed.x + 1, Up - height_hp + position_fixed.y - divisions * i);
				}
			}
		}
		else if (Opts.Visuals.Players.Global.Health.Type == 1)
		{
			if (Opts.Visuals.Players.Global.Health.Outline)
			{
				I::Surface->DrawSetColor(Opts.Visuals.Players.Global.Health.Outline_Color);
				I::Surface->DrawOutlinedRect(Left - width_hp + position_fixed2.x - 1, Down - height_hp + position_fixed2.y - 2, Right + position_fixed2.x + 2, Down + position_fixed2.y + 2);
			}

			float HealthPercentity = (2 * Width * (float)(entity->GetHealth() / 100.f));

			I::Surface->DrawSetColor(Opts.Visuals.Players.Global.Health.Health_Color);
			I::Surface->DrawFilledRect(Left + position_fixed2.x - width_hp, Down - height_hp + position_fixed2.y - 1, Left + position_fixed2.x + 1 + HealthPercentity, Down + position_fixed2.y + 1);

			if (Opts.Visuals.Players.Global.Health.Background)
			{
				I::Surface->DrawSetColor(Opts.Visuals.Players.Global.Health.Background_Color);
				I::Surface->DrawFilledRect(Left + position_fixed2.x + HealthPercentity, Down - height_hp + position_fixed2.y - 1, Right + position_fixed2.x, Down + position_fixed2.y + 1);
			}

			if (Opts.Visuals.Players.Global.Health.Division > 0)
			{
				float divisions = (Left - width_hp - Right) / (Opts.Visuals.Players.Global.Health.Division);

				for (int i = 1; i < Opts.Visuals.Players.Global.Health.Division; ++i)
				{
					I::Surface->DrawSetColor(Color(0, 0, 0, 255));
					I::Surface->DrawOutlinedRect(Left - width_hp + position_fixed2.x - 1 - divisions * i, Down - height_hp + position_fixed2.y - 1, Left - width_hp + position_fixed2.x + 1 - divisions * i, Down + position_fixed2.y + 1);
				}
			}
		}

	}

	if (Opts.Visuals.Players.Global.HeadDot)
	{
		Vector in2, out2;
		in2 = entity->GetBonePosition(BONE_HEAD);

		if (!in2.IsZero())
		{
			if (D::WorldToScreen(in2, out2))
			{
				I::Surface->DrawSetColor(Color::White());
				I::Surface->DrawOutlinedRect(out2.x - 2, out2.y - 2, out2.x + 2, out2.y + 2);
			}
		}
	}

	if (Opts.Visuals.Players.Global.Name)
	{
		player_info_t pinfo;
		I::Engine->GetPlayerInfo(index, &pinfo);
		D::DrawString(F::ESP, WCenter, Up - 6, Color::White(), FONT_CENTER, pinfo.Name);
	}

	int indentity = 0;

	if (Opts.Visuals.Players.Global.Money)
	{
		D::DrawString(F::ESP, Right + 6, Up + 6 + (indentity++ * (TextH - 2)), Color::Green(), FONT_LEFT, xs("%d $"), entity->GetMoney());
	}

	if (Opts.Visuals.Players.Global.Info)
	{
		if (entity->IsScoped())
		{
			D::DrawString(F::ESP, Right + 6, Up + 6 + (indentity++ * (TextH - 2)), Color::Red(), FONT_LEFT, xs("Scoped"));
		}

		if (entity->GetArmor() > 0)
		{
			if (entity->HasHelmet())
			{
				D::DrawString(F::ESP, Right + 6, Up + 6 + (indentity++ * (TextH - 2)), Color(255, 140, 0), FONT_LEFT, xs("Helmet"));
			}
			else
			{
				D::DrawString(F::ESP, Right + 6, Up + 6 + (indentity++ * (TextH - 2)), Color(255, 255, 0), FONT_LEFT, xs("Armor"));
			}
		}

		if (entity->GetWeapon()->IsReloading())
		{
			D::DrawString(F::ESP, Right + 6, Up + 6 + (indentity++ * (TextH - 2)), Color::Green(), FONT_LEFT, xs("Reload"));
		}

		if (entity->IsFlashed())
		{
			D::DrawString(F::ESP, Right + 6, Up + 6 + (indentity++ * (TextH - 2)), Color::Grey(), FONT_LEFT, xs("Flashed"));
		}
	}

	if (Opts.Visuals.Players.Global.Distance)
	{
		D::DrawString(F::ESP, Right + 6, Up + 6 + (indentity++ * (TextH - 2)), Color::White(), FONT_LEFT, xs("%.0fm"), Vector(G::LocalPlayer->GetOrigin() - entity->GetOrigin()).Length() * 0.04445f);
	}

	if (Opts.Visuals.Players.Global.Weapon)
	{
		//if (Cvar.ESP.Player.HPType == 0)
		//{
			D::DrawString(F::ESP, WCenter, Down + 6, Color::White(), FONT_CENTER, entity->GetWeapon()->GetWeaponName().c_str());
		//}
		//else if (Cvar.ESP.Player.HPType == 1)
		//{
		//	if (Cvar.ESP.Player.HPStyle == 1)
		//	{
		//		D::DrawString(F::ESP, WCenter, Down + (6 * 2), Color::White(), FONT_CENTER, Ent->GetWeapon()->GetWeaponName().c_str());
		//	}
		//	else if (Cvar.ESP.Player.HPStyle == 2 || Cvar.ESP.Player.HPStyle == 3)
		//	{
		//		D::DrawString(F::ESP, WCenter, Down + (6 * 2.6), Color::White(), FONT_CENTER, Ent->GetWeapon()->GetWeaponName().c_str());
		//	}
		//	else
		//	{
		//		D::DrawString(F::ESP, WCenter, Down + 6, Color::White(), FONT_CENTER, Ent->GetWeapon()->GetWeaponName().c_str());
		//	}
		//}
	}
}

void ESP::World::Draw(int ID)
{
	CBaseEntity* Ent = I::ClientEntList->GetClientEntity(ID);

	if (!Ent || Ent->GetOrigin().IsZero()) return;
	const model_t* Model = Ent->GetModel();
	if (!Model) return;
	studiohdr_t* hdr = I::ModelInfo->GetStudioModel(Ent->GetModel());
	if (!hdr) return;

	if (Opts.Misc.Globals.StatusBar && Opts.Visuals.Weapons.Bomb && strstr(Ent->GetClientClass()->m_pNetworkName, ("CPlantedC4")))
	{
		if (Ent->GetBombTimer() > 0 && Ent->BombTicking() && pBomb.Planted)
		{
			I::Surface->DrawSetColor(Color::Black().DiffAlpha(150));
			I::Surface->DrawFilledRect(G::ScreenWidth - 120, 10, G::ScreenWidth - 77, 28);

			I::Surface->DrawSetColor(Color::Outline());
			I::Surface->DrawOutlinedRect(G::ScreenWidth - 118, 12, G::ScreenWidth - 114, 26);

			I::Surface->DrawSetColor(Color::Red());
			I::Surface->DrawFilledRect(G::ScreenWidth - 117, 13, G::ScreenWidth - 115, 25);

			D::DrawString(F::Panel, G::ScreenWidth - 120 + 21.5, 19, Color::White(), FONT_CENTER, xs("%.1f"), Ent->GetBombTimer());
		}
	}

	Vector Pos, Top;
	if (!D::WorldToScreen(Ent->GetOrigin(), Pos) || !D::WorldToScreen(Ent->GetOrigin() + Vector(0, 0, Ent->GetCollideable()->OBBMaxs().z), Top))
		return;

	int Height = (Pos.y - Top.y) + 10;
	int Width = (Height / 4) + 10;

	int Left = Top.x - Width;
	int Right = Top.x + Width;
	int Up = Top.y;
	int Down = Top.y + Height;
	int HCenter = Top.y + (Height / 2);
	int WCenter = Top.x;

	auto Name = Ent->GetClientClass()->m_pNetworkName;

	if (Opts.Visuals.Weapons.Weapons)
	{
		if (strstr(Name, "CAK47") || strstr(Name, "CDEagle") || strstr(Name, "CWeapon"))
		{
			if (Opts.Visuals.Weapons.BoxMode != 0)
			{
				if (strstr(Name, "CDEagle"))
				{
					D::DrawString(F::ESP, WCenter, Up - 6, Color::White(), FONT_CENTER, xs("Deagle"));
				}
				else if (strstr(Name, "CAK47"))
				{
					D::DrawString(F::ESP, WCenter, Up - 6, Color::White(), FONT_CENTER, xs("AK-47"));
				}
				else
				{
					D::DrawString(F::ESP, WCenter, Up - 6, Color::White(), FONT_CENTER, std::string(Name).substr(7).c_str());
				}
			}

			if (Opts.Visuals.Weapons.BoxMode == 0)
			{
				if (strstr(Name, "CDEagle"))
				{
					D::DrawString(F::ESP, WCenter, Up, Color::White(), FONT_CENTER, xs("Deagle"));
				}
				else if (strstr(Name, "CAK47"))
				{
					D::DrawString(F::ESP, WCenter, Up, Color::White(), FONT_CENTER, xs("AK-47"));
				}
				else
				{
					D::DrawString(F::ESP, WCenter, Up, Color::White(), FONT_CENTER, std::string(Name).substr(7).c_str());
				}
			}
			else if (Opts.Visuals.Weapons.BoxMode == 1)
			{
				RECT rect = GetRectBox(Ent);

				Box::Default(rect, Color::White());
				if (Opts.Visuals.Weapons.Outline)
				{
					Box::Default(Outline(rect), Color(0, 0, 0));
					Box::Default(Inline(rect), Color(0, 0, 0));
				}
			}
			else if (Opts.Visuals.Weapons.BoxMode == 2)
			{
				RECT rect = GetRectBox(Ent);

				Box::Corner(rect, Color::White());
				if (Opts.Visuals.Weapons.Outline)
				{
					int x = (rect.right - rect.left) / 3;
					int y = (rect.bottom - rect.top) / 3;

					I::Surface->DrawSetColor(Color(0, 0, 0));

					// out
					I::Surface->DrawLine(rect.left - 1, rect.top - 1, rect.left + x + 1, rect.top - 1); // top left
					I::Surface->DrawLine(rect.right - x - 1, rect.top - 1, rect.right + 1, rect.top - 1); // top right
					I::Surface->DrawLine(rect.right + 1, rect.top - 1, rect.right + 1, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right + 1, rect.bottom - y - 1, rect.right + 1, rect.bottom + 1); // right bottom
					I::Surface->DrawLine(rect.right + 1, rect.bottom + 1, rect.right - x - 1, rect.bottom + 1); // bottom left
					I::Surface->DrawLine(rect.left + x + 1, rect.bottom + 1, rect.left - 1, rect.bottom + 1); // bottom right
					I::Surface->DrawLine(rect.left - 1, rect.bottom + 1, rect.left - 1, rect.bottom - y - 1); // left bottom
					I::Surface->DrawLine(rect.left - 1, rect.top + y + 1, rect.left - 1, rect.top - 1); // left top
					// in
					I::Surface->DrawLine(rect.left + 1, rect.top + 1, rect.left + x + 1, rect.top + 1); // top left
					I::Surface->DrawLine(rect.right - x - 1, rect.top + 1, rect.right - 1, rect.top + 1); // top right
					I::Surface->DrawLine(rect.right - 1, rect.top + 1, rect.right - 1, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right - 1, rect.bottom - y - 1, rect.right - 1, rect.bottom - 1); // right bottom
					I::Surface->DrawLine(rect.right - 1, rect.bottom - 1, rect.right - x - 1, rect.bottom - 1); // bottom left
					I::Surface->DrawLine(rect.left + x + 1, rect.bottom - 1, rect.left + 1, rect.bottom - 1); // bottom right
					I::Surface->DrawLine(rect.left + 1, rect.bottom - 1, rect.left + 1, rect.bottom - y - 1); // left bottom
					I::Surface->DrawLine(rect.left + 1, rect.top + y + 1, rect.left + 1, rect.top + 1); // left top
					// middle
					I::Surface->DrawLine(rect.left + x, rect.top, rect.left + x + 1, rect.top); // top left
					I::Surface->DrawLine(rect.right - x, rect.top, rect.right - x - 1, rect.top); // top right
					I::Surface->DrawLine(rect.right, rect.top + y, rect.right, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right, rect.bottom - y, rect.right, rect.bottom - y - 1); // right bottom
					I::Surface->DrawLine(rect.right - x, rect.bottom, rect.right - x - 1, rect.bottom); // bottom left
					I::Surface->DrawLine(rect.left + x, rect.bottom, rect.left + x + 1, rect.bottom); // bottom right
					I::Surface->DrawLine(rect.left, rect.top + y, rect.left, rect.top + y + 1); // left bottom
					I::Surface->DrawLine(rect.left, rect.bottom - y, rect.left, rect.bottom - y - 1); // left top
				}
			}
			else if (Opts.Visuals.Weapons.BoxMode == 3)
			{
				RECT rect = GetRectBox(Ent);

				Box::Bracket(rect, Color::White());
				if (Opts.Visuals.Weapons.Outline)
				{
					int x = (rect.right - rect.left) / 3;
					int y = (rect.bottom - rect.top) / 3;

					I::Surface->DrawSetColor(Color(0, 0, 0));

					// out
					I::Surface->DrawLine(rect.left - 1, rect.top - 1, rect.left + x + 1, rect.top - 1); // top left
					I::Surface->DrawLine(rect.right - x - 1, rect.top - 1, rect.right + 1, rect.top - 1); // top right
					I::Surface->DrawLine(rect.right + 1, rect.top - 1, rect.right + 1, rect.bottom + 1); // right
					I::Surface->DrawLine(rect.right + 1, rect.bottom + 1, rect.right - x - 1, rect.bottom + 1); // bottom left
					I::Surface->DrawLine(rect.left + x + 1, rect.bottom + 1, rect.left - 1, rect.bottom + 1); // bottom right
					I::Surface->DrawLine(rect.left - 1, rect.bottom + 1, rect.left - 1, rect.top - 1); // left
					// in
					I::Surface->DrawLine(rect.left + 1, rect.top + 1, rect.left + x + 1, rect.top + 1); // top left
					I::Surface->DrawLine(rect.right - x - 1, rect.top + 1, rect.right - 1, rect.top + 1); // top right
					I::Surface->DrawLine(rect.right - 1, rect.top + 1, rect.right - 1, rect.bottom - 1); // right
					I::Surface->DrawLine(rect.right - 1, rect.bottom - 1, rect.right - x - 1, rect.bottom - 1); // bottom left
					I::Surface->DrawLine(rect.left + x + 1, rect.bottom - 1, rect.left + 1, rect.bottom - 1); // bottom right
					I::Surface->DrawLine(rect.left + 1, rect.bottom - 1, rect.left + 1, rect.top + 1); // left
					// middle
					I::Surface->DrawLine(rect.left + x, rect.top, rect.left + x + 1, rect.top); // top left
					I::Surface->DrawLine(rect.right - x, rect.top, rect.right - x - 1, rect.top); // top right
					I::Surface->DrawLine(rect.right - x, rect.bottom, rect.right - x - 1, rect.bottom); // bottom left
					I::Surface->DrawLine(rect.left + x, rect.bottom, rect.left + x + 1, rect.bottom); // bottom right
				}
			}
			else if (Opts.Visuals.Weapons.BoxMode == 4)
			{
				RECT rect = GetRectBox(Ent);

				Box::InvertedBracket(rect, Color::White());
				if (Opts.Visuals.Weapons.Outline)
				{
					int x = (rect.right - rect.left) / 3;
					int y = (rect.bottom - rect.top) / 3;

					I::Surface->DrawSetColor(Color(0, 0, 0));

					// out
					I::Surface->DrawLine(rect.left - 1, rect.top - 1, rect.right + 1, rect.top - 1); // top
					I::Surface->DrawLine(rect.right + 1, rect.top - 1, rect.right + 1, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right + 1, rect.bottom - y - 1, rect.right + 1, rect.bottom + 1); // right bottom
					I::Surface->DrawLine(rect.right + 1, rect.bottom + 1, rect.left - 1, rect.bottom + 1); // bottom
					I::Surface->DrawLine(rect.left - 1, rect.bottom + 1, rect.left - 1, rect.bottom - y - 1); // left bottom
					I::Surface->DrawLine(rect.left - 1, rect.top + y + 1, rect.left - 1, rect.top - 1); // left top
					// in
					I::Surface->DrawLine(rect.left + 1, rect.top + 1, rect.right - 1, rect.top + 1); // top
					I::Surface->DrawLine(rect.right - 1, rect.top + 1, rect.right - 1, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right - 1, rect.bottom - y - 1, rect.right - 1, rect.bottom - 1); // right bottom
					I::Surface->DrawLine(rect.right - 1, rect.bottom - 1, rect.left + 1, rect.bottom - 1); // bottom
					I::Surface->DrawLine(rect.left + 1, rect.bottom - 1, rect.left + 1, rect.bottom - y - 1); // left bottom
					I::Surface->DrawLine(rect.left + 1, rect.top + y + 1, rect.left + 1, rect.top + 1); // left top
					// middle
					I::Surface->DrawLine(rect.right, rect.top + y, rect.right, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right, rect.bottom - y, rect.right, rect.bottom - y - 1); // right bottom
					I::Surface->DrawLine(rect.left, rect.top + y, rect.left, rect.top + y + 1); // left bottom
					I::Surface->DrawLine(rect.left, rect.bottom - y, rect.left, rect.bottom - y - 1); // left top
				}
			}
			else if (Opts.Visuals.Weapons.BoxMode == 5)
			{
				RECT rect = GetRectBox(Ent);

				Box::Filled(rect, Color::White().DiffAlpha(120));
				if (Opts.Visuals.Weapons.Outline)
				{
					Box::Default(Outline(rect), Color::White());
					//Box::Default(Inline(rect), pColor);
				}
			}
		}
	}

	if (Opts.Visuals.Weapons.Bomb && strstr(Ent->GetClientClass()->m_pNetworkName, ("CPlantedC4")))
	{
		float BombTimer = Ent->GetBombTimer();

		if (BombTimer > 0 && Ent->BombTicking() && pBomb.Planted)
		{
			if (Opts.Visuals.Weapons.BoxMode == 1)
			{
				RECT rect = GetRectBox(Ent);

				Box::Default(rect, Color::White());
				if (Opts.Visuals.Weapons.Outline)
				{
					Box::Default(Outline(rect), Color(0, 0, 0));
					Box::Default(Inline(rect), Color(0, 0, 0));
				}
			}
			else if (Opts.Visuals.Weapons.BoxMode == 2)
			{
				RECT rect = GetRectBox(Ent);

				Box::Corner(rect, Color::White());
				if (Opts.Visuals.Weapons.Outline)
				{
					int x = (rect.right - rect.left) / 3;
					int y = (rect.bottom - rect.top) / 3;

					I::Surface->DrawSetColor(Color(0, 0, 0));

					// out
					I::Surface->DrawLine(rect.left - 1, rect.top - 1, rect.left + x + 1, rect.top - 1); // top left
					I::Surface->DrawLine(rect.right - x - 1, rect.top - 1, rect.right + 1, rect.top - 1); // top right
					I::Surface->DrawLine(rect.right + 1, rect.top - 1, rect.right + 1, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right + 1, rect.bottom - y - 1, rect.right + 1, rect.bottom + 1); // right bottom
					I::Surface->DrawLine(rect.right + 1, rect.bottom + 1, rect.right - x - 1, rect.bottom + 1); // bottom left
					I::Surface->DrawLine(rect.left + x + 1, rect.bottom + 1, rect.left - 1, rect.bottom + 1); // bottom right
					I::Surface->DrawLine(rect.left - 1, rect.bottom + 1, rect.left - 1, rect.bottom - y - 1); // left bottom
					I::Surface->DrawLine(rect.left - 1, rect.top + y + 1, rect.left - 1, rect.top - 1); // left top
					// in
					I::Surface->DrawLine(rect.left + 1, rect.top + 1, rect.left + x + 1, rect.top + 1); // top left
					I::Surface->DrawLine(rect.right - x - 1, rect.top + 1, rect.right - 1, rect.top + 1); // top right
					I::Surface->DrawLine(rect.right - 1, rect.top + 1, rect.right - 1, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right - 1, rect.bottom - y - 1, rect.right - 1, rect.bottom - 1); // right bottom
					I::Surface->DrawLine(rect.right - 1, rect.bottom - 1, rect.right - x - 1, rect.bottom - 1); // bottom left
					I::Surface->DrawLine(rect.left + x + 1, rect.bottom - 1, rect.left + 1, rect.bottom - 1); // bottom right
					I::Surface->DrawLine(rect.left + 1, rect.bottom - 1, rect.left + 1, rect.bottom - y - 1); // left bottom
					I::Surface->DrawLine(rect.left + 1, rect.top + y + 1, rect.left + 1, rect.top + 1); // left top
					// middle
					I::Surface->DrawLine(rect.left + x, rect.top, rect.left + x + 1, rect.top); // top left
					I::Surface->DrawLine(rect.right - x, rect.top, rect.right - x - 1, rect.top); // top right
					I::Surface->DrawLine(rect.right, rect.top + y, rect.right, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right, rect.bottom - y, rect.right, rect.bottom - y - 1); // right bottom
					I::Surface->DrawLine(rect.right - x, rect.bottom, rect.right - x - 1, rect.bottom); // bottom left
					I::Surface->DrawLine(rect.left + x, rect.bottom, rect.left + x + 1, rect.bottom); // bottom right
					I::Surface->DrawLine(rect.left, rect.top + y, rect.left, rect.top + y + 1); // left bottom
					I::Surface->DrawLine(rect.left, rect.bottom - y, rect.left, rect.bottom - y - 1); // left top
				}
			}
			else if (Opts.Visuals.Weapons.BoxMode == 3)
			{
				RECT rect = GetRectBox(Ent);

				Box::Bracket(rect, Color::White());
				if (Opts.Visuals.Weapons.Outline)
				{
					int x = (rect.right - rect.left) / 3;
					int y = (rect.bottom - rect.top) / 3;

					I::Surface->DrawSetColor(Color(0, 0, 0));

					// out
					I::Surface->DrawLine(rect.left - 1, rect.top - 1, rect.left + x + 1, rect.top - 1); // top left
					I::Surface->DrawLine(rect.right - x - 1, rect.top - 1, rect.right + 1, rect.top - 1); // top right
					I::Surface->DrawLine(rect.right + 1, rect.top - 1, rect.right + 1, rect.bottom + 1); // right
					I::Surface->DrawLine(rect.right + 1, rect.bottom + 1, rect.right - x - 1, rect.bottom + 1); // bottom left
					I::Surface->DrawLine(rect.left + x + 1, rect.bottom + 1, rect.left - 1, rect.bottom + 1); // bottom right
					I::Surface->DrawLine(rect.left - 1, rect.bottom + 1, rect.left - 1, rect.top - 1); // left
					// in
					I::Surface->DrawLine(rect.left + 1, rect.top + 1, rect.left + x + 1, rect.top + 1); // top left
					I::Surface->DrawLine(rect.right - x - 1, rect.top + 1, rect.right - 1, rect.top + 1); // top right
					I::Surface->DrawLine(rect.right - 1, rect.top + 1, rect.right - 1, rect.bottom - 1); // right
					I::Surface->DrawLine(rect.right - 1, rect.bottom - 1, rect.right - x - 1, rect.bottom - 1); // bottom left
					I::Surface->DrawLine(rect.left + x + 1, rect.bottom - 1, rect.left + 1, rect.bottom - 1); // bottom right
					I::Surface->DrawLine(rect.left + 1, rect.bottom - 1, rect.left + 1, rect.top + 1); // left
					// middle
					I::Surface->DrawLine(rect.left + x, rect.top, rect.left + x + 1, rect.top); // top left
					I::Surface->DrawLine(rect.right - x, rect.top, rect.right - x - 1, rect.top); // top right
					I::Surface->DrawLine(rect.right - x, rect.bottom, rect.right - x - 1, rect.bottom); // bottom left
					I::Surface->DrawLine(rect.left + x, rect.bottom, rect.left + x + 1, rect.bottom); // bottom right
				}
			}
			else if (Opts.Visuals.Weapons.BoxMode == 4)
			{
				RECT rect = GetRectBox(Ent);

				Box::InvertedBracket(rect, Color::White());
				if (Opts.Visuals.Weapons.Outline)
				{
					int x = (rect.right - rect.left) / 3;
					int y = (rect.bottom - rect.top) / 3;

					I::Surface->DrawSetColor(Color(0, 0, 0));

					// out
					I::Surface->DrawLine(rect.left - 1, rect.top - 1, rect.right + 1, rect.top - 1); // top
					I::Surface->DrawLine(rect.right + 1, rect.top - 1, rect.right + 1, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right + 1, rect.bottom - y - 1, rect.right + 1, rect.bottom + 1); // right bottom
					I::Surface->DrawLine(rect.right + 1, rect.bottom + 1, rect.left - 1, rect.bottom + 1); // bottom
					I::Surface->DrawLine(rect.left - 1, rect.bottom + 1, rect.left - 1, rect.bottom - y - 1); // left bottom
					I::Surface->DrawLine(rect.left - 1, rect.top + y + 1, rect.left - 1, rect.top - 1); // left top
					// in
					I::Surface->DrawLine(rect.left + 1, rect.top + 1, rect.right - 1, rect.top + 1); // top
					I::Surface->DrawLine(rect.right - 1, rect.top + 1, rect.right - 1, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right - 1, rect.bottom - y - 1, rect.right - 1, rect.bottom - 1); // right bottom
					I::Surface->DrawLine(rect.right - 1, rect.bottom - 1, rect.left + 1, rect.bottom - 1); // bottom
					I::Surface->DrawLine(rect.left + 1, rect.bottom - 1, rect.left + 1, rect.bottom - y - 1); // left bottom
					I::Surface->DrawLine(rect.left + 1, rect.top + y + 1, rect.left + 1, rect.top + 1); // left top
					// middle
					I::Surface->DrawLine(rect.right, rect.top + y, rect.right, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right, rect.bottom - y, rect.right, rect.bottom - y - 1); // right bottom
					I::Surface->DrawLine(rect.left, rect.top + y, rect.left, rect.top + y + 1); // left bottom
					I::Surface->DrawLine(rect.left, rect.bottom - y, rect.left, rect.bottom - y - 1); // left top
				}
			}
			else if (Opts.Visuals.Weapons.BoxMode == 5)
			{
				RECT rect = GetRectBox(Ent);

				Box::Filled(rect, Color::White().DiffAlpha(120));
				if (Opts.Visuals.Weapons.Outline)
				{
					Box::Default(Outline(rect), Color::White());
					//Box::Default(Inline(rect), pColor);
				}
			}

			float YPos = Down;

			if (Opts.Visuals.Weapons.BoxMode == 0)
			{
				D::DrawString(F::ESP, WCenter, Down - 6, Color::White(), FONT_CENTER, xs("Bomb : %.1f"), BombTimer);
			}	
			else
			{
				D::DrawString(F::ESP, WCenter, Up - 6, Color::White(), FONT_CENTER, xs("Bomb : %.1f"), BombTimer);
			}
			
			float TimerPercent = ((Right - Left) * (float)(BombTimer / Ent->BombTimerLength()));

			vector2d Start = vector2d(Left, YPos + 4);
			vector2d End = vector2d(Right - TimerPercent, YPos + 6);
			I::Surface->DrawSetColor(Color::Outline());
			I::Surface->DrawOutlinedRect(Left - 1, YPos + 3, Right + 1, YPos + 7);
			I::Surface->DrawSetColor(Color::Green());
			I::Surface->DrawFilledRect(Left, YPos + 4, Right, YPos + 6);
			I::Surface->DrawSetColor(Color::Red());
			I::Surface->DrawFilledRect(Start.x, Start.y, End.x, End.y);

			float flDamage = 0.f;

			if (G::LocalPlayer->GetAlive())
			{
				float flArmor = G::LocalPlayer->GetArmor();
				float flDistance = G::LocalPlayer->GetOrigin().DistTo(Ent->GetOrigin());
				float a = 450.7f;
				float b = 75.68f;
				float c = 789.2f;
				float d = ((flDistance - b) / c);

				float flDmg = a * exp(-d * d);

				flDamage = flDmg;

				if (flArmor > 0)
				{
					float flNew = flDmg * 0.5f;
					float flArmor = (flDmg - flNew) * 0.5f;

					if (flArmor > static_cast<float>(flArmor))
					{
						flArmor = static_cast<float>(flArmor) * (1.f / 0.5f);
						flNew = flDmg - flArmor;
					}

					flDamage = flNew;
				}
			}

			float DefuseTime = (Ent->BombDefuseCountdown() - I::Globals->curtime);

			if (DefuseTime > 0.f && (Ent->BombDefuseLength() == 5.f || Ent->BombDefuseLength() == 10.f) && pBomb.Defusing)
			{
				float DefusePercent = ((Right - Left) * (float)(DefuseTime / Ent->BombDefuseLength()));

				vector2d Start = vector2d(Left, YPos + 10);
				vector2d End = vector2d(Right - DefusePercent, YPos + 12);
				I::Surface->DrawSetColor(Color::Outline());
				I::Surface->DrawOutlinedRect(Left - 1, YPos + 9, Right + 1, YPos + 13);
				I::Surface->DrawSetColor(Color::Blue());
				I::Surface->DrawFilledRect(Left, YPos + 10, Right, YPos + 12);
				I::Surface->DrawSetColor(Color::Grey());
				I::Surface->DrawFilledRect(Start.x, Start.y, End.x, End.y);

				if (flDamage > 0.f)
				{
					D::DrawString(F::ESP, WCenter, YPos + 20, flDamage >= G::LocalPlayer->GetHealth() ? Color::Red() : Color((flDamage * 2.55), (255 - (flDamage * 2.55)), 0), FONT_CENTER, flDamage >= G::LocalPlayer->GetHealth() ? ("100 HP") : ("%.0f HP"), flDamage);
				}
			}
			else if (flDamage > 0.f)
			{
				D::DrawString(F::ESP, WCenter, YPos + 14, flDamage >= G::LocalPlayer->GetHealth() ? Color::Red() : Color((flDamage * 2.55), (255 - (flDamage * 2.55)), 0), FONT_CENTER, flDamage >= G::LocalPlayer->GetHealth() ? ("100 HP") : ("%.0f HP"), flDamage);
			}
		}
	}
	else if (strstr(Name, "CC4"))
	{
		D::DrawString(F::ESP, WCenter, Up - 6, Color::White(), FONT_CENTER, xs("Bomb"));

		//if (Opts.Visuals.Weapons.BoxMode == 1)
		//{
		//	DrawData Data(Left, Up, Right, Down);
		//	Box::Default(Data, Color::White());
		//
		//	if (Opts.Visuals.Weapons.Outline)
		//	{
		//		Box::Default(Data.Outline(), Color::Outline());
		//		Box::Default(Data.Inline(), Color::Outline());
		//	}
		//}
		//else if (Opts.Visuals.Weapons.BoxMode == 2)
		//{
		//	DrawData Data(Height, Width, Left, Up, Right, Down);
		//	Box::Corner(Data, Color::White());
		//
		//	if (Opts.Visuals.Weapons.Outline)
		//	{
		//		Box::Corner(Data.Outline(), Color::Outline());
		//		Box::Corner(Data.Inline(), Color::Outline());
		//	}
		//}
		//else if (Opts.Visuals.Weapons.BoxMode == 3)
		//{
		//	DrawData Data(Left, Up, Right, Down);
		//	Box::Filled(Data, Color::White().DiffAlpha(120));
		//
		//	if (Opts.Visuals.Weapons.Outline)
		//	{
		//		Box::Default(Data.Outline(), Color::Outline());
		//	}
		//}
	}

	if (Opts.Visuals.Weapons.Grenades)
	{
		Color NadeColor(0, 0, 0);
		std::string NadeName = "";

		if (strstr(hdr->Name, "thrown") || strstr(hdr->Name, "dropped"))
		{
			if (strstr(hdr->Name, "decoy"))
			{
				NadeColor = Color::Purple();
				NadeName = "Decoy";
			}
			else if (strstr(hdr->Name, "fraggrenade") || strstr(hdr->Name, "incendiarygrenade") || strstr(hdr->Name, "molotov"))
			{
				NadeColor = Color::Red();

				if (strstr(hdr->Name, "fraggrenade"))
				{
					NadeName = "HE Grenade";
				}
				else
				{
					NadeName = "Molotov";
				}
			}
			else if (strstr(hdr->Name, "flashbang"))
			{
				NadeColor = Color(255, 255, 0);
				NadeName = "Flashbang";
			}
			else if (strstr(hdr->Name, "smokegrenade"))
			{
				NadeColor = Color::Grey();
				NadeName = "Smoke";
			}
		}

		if (NadeColor != Color(0, 0, 0) && NadeName != "")
		{
			//if (Opts.Visuals.Weapons.BoxMode == 1)
			//{
			//	DrawData Data(Left, Up, Right, Down);
			//	Box::Default(Data, Color::White());
			//
			//	if (Opts.Visuals.Weapons.Outline)
			//	{
			//		Box::Default(Data.Outline(), Color::Outline());
			//		Box::Default(Data.Inline(), Color::Outline());
			//	}
			//}
			//else if (Opts.Visuals.Weapons.BoxMode == 2)
			//{
			//	DrawData Data(Height, Width, Left, Up, Right, Down);
			//	Box::Corner(Data, Color::White());
			//
			//	if (Opts.Visuals.Weapons.Outline)
			//	{
			//		Box::Corner(Data.Outline(), Color::Outline());
			//		Box::Corner(Data.Inline(), Color::Outline());
			//	}
			//}
			//else if (Opts.Visuals.Weapons.BoxMode == 3)
			//{
			//	DrawData Data(Left, Up, Right, Down);
			//	Box::Filled(Data, Color::White().DiffAlpha(120));
			//
			//	if (Opts.Visuals.Weapons.Outline)
			//	{
			//		Box::Default(Data.Outline(), Color::Outline());
			//	}
			//}
			if (Opts.Visuals.Weapons.BoxMode == 1)
			{
				RECT rect = GetRectBox(Ent);

				Box::Default(rect, Color::White());
				if (Opts.Visuals.Weapons.Outline)
				{
					Box::Default(Outline(rect), Color(0, 0, 0));
					Box::Default(Inline(rect), Color(0, 0, 0));
				}
			}
			else if (Opts.Visuals.Weapons.BoxMode == 2)
			{
				RECT rect = GetRectBox(Ent);

				Box::Corner(rect, Color::White());
				if (Opts.Visuals.Weapons.Outline)
				{
					int x = (rect.right - rect.left) / 3;
					int y = (rect.bottom - rect.top) / 3;

					I::Surface->DrawSetColor(Color(0, 0, 0));

					// out
					I::Surface->DrawLine(rect.left - 1, rect.top - 1, rect.left + x + 1, rect.top - 1); // top left
					I::Surface->DrawLine(rect.right - x - 1, rect.top - 1, rect.right + 1, rect.top - 1); // top right
					I::Surface->DrawLine(rect.right + 1, rect.top - 1, rect.right + 1, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right + 1, rect.bottom - y - 1, rect.right + 1, rect.bottom + 1); // right bottom
					I::Surface->DrawLine(rect.right + 1, rect.bottom + 1, rect.right - x - 1, rect.bottom + 1); // bottom left
					I::Surface->DrawLine(rect.left + x + 1, rect.bottom + 1, rect.left - 1, rect.bottom + 1); // bottom right
					I::Surface->DrawLine(rect.left - 1, rect.bottom + 1, rect.left - 1, rect.bottom - y - 1); // left bottom
					I::Surface->DrawLine(rect.left - 1, rect.top + y + 1, rect.left - 1, rect.top - 1); // left top
					// in
					I::Surface->DrawLine(rect.left + 1, rect.top + 1, rect.left + x + 1, rect.top + 1); // top left
					I::Surface->DrawLine(rect.right - x - 1, rect.top + 1, rect.right - 1, rect.top + 1); // top right
					I::Surface->DrawLine(rect.right - 1, rect.top + 1, rect.right - 1, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right - 1, rect.bottom - y - 1, rect.right - 1, rect.bottom - 1); // right bottom
					I::Surface->DrawLine(rect.right - 1, rect.bottom - 1, rect.right - x - 1, rect.bottom - 1); // bottom left
					I::Surface->DrawLine(rect.left + x + 1, rect.bottom - 1, rect.left + 1, rect.bottom - 1); // bottom right
					I::Surface->DrawLine(rect.left + 1, rect.bottom - 1, rect.left + 1, rect.bottom - y - 1); // left bottom
					I::Surface->DrawLine(rect.left + 1, rect.top + y + 1, rect.left + 1, rect.top + 1); // left top
					// middle
					I::Surface->DrawLine(rect.left + x, rect.top, rect.left + x + 1, rect.top); // top left
					I::Surface->DrawLine(rect.right - x, rect.top, rect.right - x - 1, rect.top); // top right
					I::Surface->DrawLine(rect.right, rect.top + y, rect.right, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right, rect.bottom - y, rect.right, rect.bottom - y - 1); // right bottom
					I::Surface->DrawLine(rect.right - x, rect.bottom, rect.right - x - 1, rect.bottom); // bottom left
					I::Surface->DrawLine(rect.left + x, rect.bottom, rect.left + x + 1, rect.bottom); // bottom right
					I::Surface->DrawLine(rect.left, rect.top + y, rect.left, rect.top + y + 1); // left bottom
					I::Surface->DrawLine(rect.left, rect.bottom - y, rect.left, rect.bottom - y - 1); // left top
				}
			}
			else if (Opts.Visuals.Weapons.BoxMode == 3)
			{
				RECT rect = GetRectBox(Ent);

				Box::Bracket(rect, Color::White());
				if (Opts.Visuals.Weapons.Outline)
				{
					int x = (rect.right - rect.left) / 3;
					int y = (rect.bottom - rect.top) / 3;

					I::Surface->DrawSetColor(Color(0, 0, 0));

					// out
					I::Surface->DrawLine(rect.left - 1, rect.top - 1, rect.left + x + 1, rect.top - 1); // top left
					I::Surface->DrawLine(rect.right - x - 1, rect.top - 1, rect.right + 1, rect.top - 1); // top right
					I::Surface->DrawLine(rect.right + 1, rect.top - 1, rect.right + 1, rect.bottom + 1); // right
					I::Surface->DrawLine(rect.right + 1, rect.bottom + 1, rect.right - x - 1, rect.bottom + 1); // bottom left
					I::Surface->DrawLine(rect.left + x + 1, rect.bottom + 1, rect.left - 1, rect.bottom + 1); // bottom right
					I::Surface->DrawLine(rect.left - 1, rect.bottom + 1, rect.left - 1, rect.top - 1); // left
					// in
					I::Surface->DrawLine(rect.left + 1, rect.top + 1, rect.left + x + 1, rect.top + 1); // top left
					I::Surface->DrawLine(rect.right - x - 1, rect.top + 1, rect.right - 1, rect.top + 1); // top right
					I::Surface->DrawLine(rect.right - 1, rect.top + 1, rect.right - 1, rect.bottom - 1); // right
					I::Surface->DrawLine(rect.right - 1, rect.bottom - 1, rect.right - x - 1, rect.bottom - 1); // bottom left
					I::Surface->DrawLine(rect.left + x + 1, rect.bottom - 1, rect.left + 1, rect.bottom - 1); // bottom right
					I::Surface->DrawLine(rect.left + 1, rect.bottom - 1, rect.left + 1, rect.top + 1); // left
					// middle
					I::Surface->DrawLine(rect.left + x, rect.top, rect.left + x + 1, rect.top); // top left
					I::Surface->DrawLine(rect.right - x, rect.top, rect.right - x - 1, rect.top); // top right
					I::Surface->DrawLine(rect.right - x, rect.bottom, rect.right - x - 1, rect.bottom); // bottom left
					I::Surface->DrawLine(rect.left + x, rect.bottom, rect.left + x + 1, rect.bottom); // bottom right
				}
			}
			else if (Opts.Visuals.Weapons.BoxMode == 4)
			{
				RECT rect = GetRectBox(Ent);

				Box::InvertedBracket(rect, Color::White());
				if (Opts.Visuals.Weapons.Outline)
				{
					int x = (rect.right - rect.left) / 3;
					int y = (rect.bottom - rect.top) / 3;

					I::Surface->DrawSetColor(Color(0, 0, 0));

					// out
					I::Surface->DrawLine(rect.left - 1, rect.top - 1, rect.right + 1, rect.top - 1); // top
					I::Surface->DrawLine(rect.right + 1, rect.top - 1, rect.right + 1, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right + 1, rect.bottom - y - 1, rect.right + 1, rect.bottom + 1); // right bottom
					I::Surface->DrawLine(rect.right + 1, rect.bottom + 1, rect.left - 1, rect.bottom + 1); // bottom
					I::Surface->DrawLine(rect.left - 1, rect.bottom + 1, rect.left - 1, rect.bottom - y - 1); // left bottom
					I::Surface->DrawLine(rect.left - 1, rect.top + y + 1, rect.left - 1, rect.top - 1); // left top
					// in
					I::Surface->DrawLine(rect.left + 1, rect.top + 1, rect.right - 1, rect.top + 1); // top
					I::Surface->DrawLine(rect.right - 1, rect.top + 1, rect.right - 1, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right - 1, rect.bottom - y - 1, rect.right - 1, rect.bottom - 1); // right bottom
					I::Surface->DrawLine(rect.right - 1, rect.bottom - 1, rect.left + 1, rect.bottom - 1); // bottom
					I::Surface->DrawLine(rect.left + 1, rect.bottom - 1, rect.left + 1, rect.bottom - y - 1); // left bottom
					I::Surface->DrawLine(rect.left + 1, rect.top + y + 1, rect.left + 1, rect.top + 1); // left top
					// middle
					I::Surface->DrawLine(rect.right, rect.top + y, rect.right, rect.top + y + 1); // right top
					I::Surface->DrawLine(rect.right, rect.bottom - y, rect.right, rect.bottom - y - 1); // right bottom
					I::Surface->DrawLine(rect.left, rect.top + y, rect.left, rect.top + y + 1); // left bottom
					I::Surface->DrawLine(rect.left, rect.bottom - y, rect.left, rect.bottom - y - 1); // left top
				}
			}
			else if (Opts.Visuals.Weapons.BoxMode == 5)
			{
				RECT rect = GetRectBox(Ent);

				Box::Filled(rect, Color::White().DiffAlpha(120));
				if (Opts.Visuals.Weapons.Outline)
				{
					Box::Default(Outline(rect), Color::White());
					//Box::Default(Inline(rect), pColor);
				}
			}

			D::DrawString(F::ESP, WCenter, Up - 6, NadeColor, FONT_CENTER, NadeName.c_str());
		}
	}
}

void ESP::Misc::HitMarker::Add(HitMarker::CLog HitLog)
{
	Log.push_back(HitLog);
}

void ESP::Misc::HitMarker::Draw()
{
	int AmountHP = 0;
	int AmountArm = 0;

	for (int LogID = 0; LogID < Log.size(); LogID++)
	{
		if (((Opts.Visuals.Other.HitMarker == 2 || Opts.Visuals.Other.HitMarker == 3) && Log.at(LogID).Bone.IsZero()) || Log.at(LogID).Time <= I::Globals->curtime || ((Log.at(LogID).Time - I::Globals->curtime) > 3.1f))
		{
			Log.erase(Log.begin() + LogID);
			continue;
		}

		if (((Log.at(LogID).Time - I::Globals->curtime) < 3.1f))
		{
			AmountHP += Log.at(LogID).DamageHP;
			AmountArm += Log.at(LogID).DamageArm;
		}

		if (Opts.Visuals.Other.HitMarker == 2 && !Log.at(LogID).Bone.IsZero())
		{
			Vector Out;
			if (D::WorldToScreen(Log.at(LogID).Bone, Out) && Log.at(LogID).Time > I::Globals->curtime && ((Log.at(LogID).Time - I::Globals->curtime) < 3.1f))
			{
				XHair::MLG(2, Out, Color(220, 220, 220, (Log.at(LogID).Time - I::Globals->curtime) * (255 / 3)));
			}
		}
		else if (Opts.Visuals.Other.HitMarker == 3 && !Log.at(LogID).Bone.IsZero())
		{
			Log.at(LogID).Bone.z -= (0.1f * (I::Globals->curtime - Log.at(LogID).Time));

			Vector Out;
			if (D::WorldToScreen(Log.at(LogID).Bone, Out) && Log.at(LogID).Time > I::Globals->curtime && ((Log.at(LogID).Time - I::Globals->curtime) < 3.1f))
			{
				D::DrawString(F::HitMarker, Out.x, Out.y, Color::Green().DiffAlpha((Log.at(LogID).Time - I::Globals->curtime) * (255 / 3)), FONT_CENTER, to_str(Log.at(LogID).DamageHP).c_str());
			}
		}
	}

	if (Opts.Visuals.Other.HitMarker != 3)
	{
		vector2d Center = vector2d(G::ScreenWidthHalf, G::ScreenHeightHalf);

		if (AmountArm > 0)
		{
			D::DrawString(F::HitMarker, Center.x - 100, Center.y, Color::Grey(), FONT_RIGHT, (to_str(AmountArm) + " Armor").c_str());
		}

		if (AmountHP > 0)
		{
			D::DrawString(F::HitMarker, Center.x + 100, Center.y, Color::Green(), FONT_LEFT, (to_str(AmountHP) + " HP").c_str());
		}
	}
}

void ESP::Misc::BulletTracer::Add(CLog NewLog)
{
	Log.push_back(NewLog);
}

void ESP::Misc::BulletTracer::Draw()
{
	Color Color = Opts.Colors.Misc.BulletTrace;

	for (int LogID = 0; LogID < Log.size(); LogID++)
	{
		if ((Log.at(LogID).Start.IsZero() || Log.at(LogID).End.IsZero()) || LogID > 10 || Log.at(LogID).Time <= I::Globals->curtime || ((Log.at(LogID).Time - I::Globals->curtime) > 2))
		{
			Log.erase(Log.begin() + LogID);
			continue;
		}

		Vector Start, End;
		if (D::WorldToScreen(Log.at(LogID).Start, Start) && D::WorldToScreen(Log.at(LogID).End, End) && Log.at(LogID).Time > I::Globals->curtime && ((Log.at(LogID).Time - I::Globals->curtime) < 2))
		{
			D::DrawLine(Start.x, Start.y, End.x, End.y, Color.DiffAlpha((Log.at(LogID).Time - I::Globals->curtime) * (255 / 2)));
		}
	}
}

void ESP::Misc::XHair::MLG(int Size, Vector Pos, Color pColor, bool Spread)
{
	float Spr = Spread ? (G::LocalPlayer->GetWeapon()->GetInaccuracy() + G::LocalPlayer->GetWeapon()->GetWeaponSpread()) * 500 : 0.f;

	I::Surface->DrawSetColor(pColor);
	I::Surface->DrawLine(Pos.x - Spr, Pos.y + Spr, Pos.x - Size, Pos.y + Size);
	I::Surface->DrawLine(Pos.x - Spr, Pos.y - Spr, Pos.x - Size, Pos.y - Size);
	I::Surface->DrawLine(Pos.x + Spr, Pos.y + Spr, Pos.x + Size, Pos.y + Size);
	I::Surface->DrawLine(Pos.x + Spr, Pos.y - Spr, Pos.x + Size, Pos.y - Size);

	if (Spread)
	{
		I::Surface->DrawSetColor(Color(pColor.r(), pColor.g(), pColor.b(), pColor.a() / 2));
		I::Surface->DrawSetColor(pColor);
		I::Surface->DrawLine(Pos.x, Pos.y, Pos.x - Size, Pos.y + Size);
		I::Surface->DrawLine(Pos.x, Pos.y, Pos.x - Size, Pos.y - Size);
		I::Surface->DrawLine(Pos.x, Pos.y, Pos.x + Size, Pos.y + Size);
		I::Surface->DrawLine(Pos.x, Pos.y, Pos.x + Size, Pos.y - Size);
	}
}


QAngle ANGLES(Vector ent_pos, Vector loc_pos)
{
	QAngle angle_to_ent;

	angle_to_ent.x = atan(ent_pos.x / ent_pos.y);
}

void ESP::Misc::GrenadePrediction::Draw()
{
	Color Color1(int(Opts.Colors.Misc.GrenadePrediction[0] * 255.f), int(Opts.Colors.Misc.GrenadePrediction[1] * 255.f), int(Opts.Colors.Misc.GrenadePrediction[2] * 255.f));
	Color �olor2 = Color::Black().DiffAlpha(0);

	const float TIMEALIVE = 4.8f;
	const float GRENADE_COEFFICIENT_OF_RESTITUTION = 0.45f;

	float fStep = 0.1f;
	//float fGravity = 600.0f / 8.f;
	static auto sv_gravity = I::Cvar->FindVar(xs("sv_gravity"));
	static auto fGravity = sv_gravity->GetFloat() / 8.0f;

	Vector vPos, vThrow, vThrow2;
	Vector vStart;

	int iCollisions = 0;

	QAngle vViewAngles;
	I::Engine->GetViewAngles(vViewAngles);

	vThrow[0] = vViewAngles[0];
	vThrow[1] = vViewAngles[1];
	vThrow[2] = vViewAngles[2];

	if (vThrow[0] < 0)
	{
		vThrow[0] = -10 + vThrow[0] * ((90 - 10) / 90.0);
	}
	else
	{
		vThrow[0] = -10 + vThrow[0] * ((90 + 10) / 90.0);
	}

	bool primary_attack = G::UserCmd->buttons & IN_ATTACK;
	bool secondary_attack = G::UserCmd->buttons & IN_ATTACK2;

	float power = 0.0f;

	if (primary_attack && secondary_attack) power = 403.0f * 0.9f * (0.475f * 0.7f + 0.3f);
	else if (primary_attack) power = 362.7f;
	else if (secondary_attack) power = 108.810126945f;

	if (power == 0) return;

	float fVel = power * 0.7f + 0.3f;

	M::AngleVectors(vThrow, &vThrow2);

	Vector vEye = G::LocalPlayer->GetEyePosition();
	vStart = vEye + (vThrow2 * 16);
	vThrow2 = (vThrow2 * power) + G::LocalPlayer->GetVelocity();

	for (float fTime = 0.0f; fTime < TIMEALIVE; fTime += fStep)
	{
		vPos = vStart + vThrow2 * fStep;

		Ray_t ray;
		trace_t tr;
		CTraceFilter loc;
		loc.pSkip = G::LocalPlayer;

		ray.Init(vStart, vPos);
		I::EngineTrace->TraceRay(ray, MASK_SOLID, &loc, &tr);

		if (tr.DidHit())
		{
			float anglez = M::DotProduct(Vector(0, 0, 1), tr.plane.normal);
			float invanglez = M::DotProduct(Vector(0, 0, -1), tr.plane.normal);
			float angley = M::DotProduct(Vector(0, 1, 0), tr.plane.normal);
			float invangley = M::DotProduct(Vector(0, -1, 0), tr.plane.normal);
			float anglex = M::DotProduct(Vector(1, 0, 0), tr.plane.normal);
			float invanglex = M::DotProduct(Vector(-1, 0, 0), tr.plane.normal);
			float scale = tr.endpos.DistTo(G::LocalPlayer->GetOrigin()) / 60;

			if (anglez > 0.5)
			{
				tr.endpos.z += 1;
				Vector startPos = tr.endpos + Vector(-scale, 0, 0);
				Vector endPos = tr.endpos + Vector(scale, 0, 0);
				Vector outStart, outEnd;

				if (D::WorldToScreen(startPos, outStart) && D::WorldToScreen(endPos, outEnd))
				{
					D::DrawLine(outStart.x, outStart.y, outEnd.x, outEnd.y, �olor2);
				}

				startPos = tr.endpos + Vector(0, -scale, 0);
				endPos = tr.endpos + Vector(0, scale, 0);

				if (D::WorldToScreen(startPos, outStart) && D::WorldToScreen(endPos, outEnd))
				{
					D::DrawLine(outStart.x, outStart.y, outEnd.x, outEnd.y, �olor2);
				}
			}
			else if (invanglez > 0.5)
			{
				tr.endpos.z += 1;
				Vector startPos = tr.endpos + Vector(-scale, 0, 0);
				Vector endPos = tr.endpos + Vector(scale, 0, 0);
				Vector outStart, outEnd;

				if (D::WorldToScreen(startPos, outStart) && D::WorldToScreen(endPos, outEnd))
				{
					D::DrawLine(outStart.x, outStart.y, outEnd.x, outEnd.y, �olor2);
				}

				startPos = tr.endpos + Vector(0, -scale, 0);
				endPos = tr.endpos + Vector(0, scale, 0);

				if (D::WorldToScreen(startPos, outStart) && D::WorldToScreen(endPos, outEnd))
				{
					D::DrawLine(outStart.x, outStart.y, outEnd.x, outEnd.y, �olor2);
				}
			}
			else if (angley > 0.5)
			{
				tr.endpos.y += 1;
				Vector startPos = tr.endpos + Vector(0, 0, -scale);
				Vector endPos = tr.endpos + Vector(0, 0, scale);
				Vector outStart, outEnd;

				if (D::WorldToScreen(startPos, outStart) && D::WorldToScreen(endPos, outEnd))
				{
					D::DrawLine(outStart.x, outStart.y, outEnd.x, outEnd.y, �olor2);
				}

				startPos = tr.endpos + Vector(-scale, 0, 0);
				endPos = tr.endpos + Vector(scale, 0, 0);

				if (D::WorldToScreen(startPos, outStart) && D::WorldToScreen(endPos, outEnd))
				{
					D::DrawLine(outStart.x, outStart.y, outEnd.x, outEnd.y, �olor2);
				}
			}
			else if (invangley > 0.5)
			{
				tr.endpos.y += 1;
				Vector startPos = tr.endpos + Vector(0, 0, -scale);
				Vector endPos = tr.endpos + Vector(0, 0, scale);
				Vector outStart, outEnd;

				if (D::WorldToScreen(startPos, outStart) && D::WorldToScreen(endPos, outEnd))
				{
					D::DrawLine(outStart.x, outStart.y, outEnd.x, outEnd.y, �olor2);
				}

				startPos = tr.endpos + Vector(-scale, 0, 0);
				endPos = tr.endpos + Vector(scale, 0, 0);

				if (D::WorldToScreen(startPos, outStart) && D::WorldToScreen(endPos, outEnd))
				{
					D::DrawLine(outStart.x, outStart.y, outEnd.x, outEnd.y, �olor2);
				}
			}
			else if (anglex > 0.5)
			{
				tr.endpos.x += 1;
				Vector startPos = tr.endpos + Vector(0, -scale, 0);
				Vector endPos = tr.endpos + Vector(0, scale, 0);
				Vector outStart, outEnd;

				if (D::WorldToScreen(startPos, outStart) && D::WorldToScreen(endPos, outEnd))
				{
					D::DrawLine(outStart.x, outStart.y, outEnd.x, outEnd.y, �olor2);
				}

				startPos = tr.endpos + Vector(0, 0, -scale);
				endPos = tr.endpos + Vector(0, 0, scale);

				if (D::WorldToScreen(startPos, outStart) && D::WorldToScreen(endPos, outEnd))
				{
					D::DrawLine(outStart.x, outStart.y, outEnd.x, outEnd.y, �olor2);
				}
			}
			else if (invanglex > 0.5)
			{
				tr.endpos.x += 1;
				Vector startPos = tr.endpos + Vector(0, -scale, 0);
				Vector endPos = tr.endpos + Vector(0, scale, 0);
				Vector outStart, outEnd;

				if (D::WorldToScreen(startPos, outStart) && D::WorldToScreen(endPos, outEnd))
				{
					D::DrawLine(outStart.x, outStart.y, outEnd.x, outEnd.y, �olor2);
				}

				startPos = tr.endpos + Vector(0, 0, -scale);
				endPos = tr.endpos + Vector(0, 0, scale);

				if (D::WorldToScreen(startPos, outStart) && D::WorldToScreen(endPos, outEnd))
				{
					D::DrawLine(outStart.x, outStart.y, outEnd.x, outEnd.y, �olor2);
				}
			}

			vThrow2 = tr.plane.normal * -2.0f * M::DotProduct(vThrow2, tr.plane.normal) + vThrow2;
			vThrow2 *= GRENADE_COEFFICIENT_OF_RESTITUTION;

			iCollisions++;
			if (iCollisions > 2)
				break;

			vPos = vStart + vThrow2 * tr.fraction * fStep;
			fTime += (fStep * (1 - tr.fraction));
		}

		Vector vOutStart, vOutEnd;

		if (D::WorldToScreen(vStart, vOutStart), D::WorldToScreen(vPos, vOutEnd))
		{
			D::DrawLine(vOutStart.x, vOutStart.y, vOutEnd.x, vOutEnd.y, Color1);
		}

		vStart = vPos;
		vThrow2.z -= fGravity * tr.fraction * fStep;
	}
}

void ESP::Player::Skeleton(CBaseEntity* Entity)
{
	studiohdr_t* pStudioModel = I::ModelInfo->GetStudioModel(Entity->GetModel());
	if (pStudioModel)
	{
		static matrix3x4_t pBoneToWorldOut[256];
		if (Entity->SetupBones(pBoneToWorldOut, 256, 256, I::Globals->curtime))
		{
			for (int i = 0; i < pStudioModel->numbones; i++)
			{
				mstudiobone_t* pBone = pStudioModel->pBone(i);
				if (!pBone || !(pBone->flags & 256) || pBone->parent == -1)
					continue;

				Vector vBonePos1;
				if (!D::WorldToScreen(Vector(pBoneToWorldOut[i][0][3], pBoneToWorldOut[i][1][3], pBoneToWorldOut[i][2][3]), vBonePos1))
					continue;

				Vector vBonePos2;
				if (!D::WorldToScreen(Vector(pBoneToWorldOut[pBone->parent][0][3], pBoneToWorldOut[pBone->parent][1][3], pBoneToWorldOut[pBone->parent][2][3]), vBonePos2))
					continue;

				D::DrawLine((int)vBonePos1.x, (int)vBonePos1.y, (int)vBonePos2.x, (int)vBonePos2.y, Color::White());
			}
		}
	}
}

void ESP::Player::OutOfScreen(CBaseEntity* Entity)
{
	Vector pos_by_local = Entity->GetOrigin() - G::LocalPlayer->GetOrigin();

	//float leng2D = pos_by_local.Length2D();

	QAngle loc_view;
	I::Engine->GetViewAngles(loc_view);
	// 
	//r_1 = -(Entity_origin.y - Local_origin.y);
	//r_2 = Entity_origin.x - Local_origin.x;
	//float local_yaw = (local_angle.y - 90.0f) * (M_PI / 180.0F);
	//
	//x_1 = (r_2 * cos(local_yaw) - r_1 * sin(local_yaw)) / 10;
	//y_1 = (r_2 * sin(local_yaw) + r_1 * cos(local_yaw)) / 10;
	
	float r_1 = -pos_by_local.y;
	float r_2 = pos_by_local.x;
	float local_yaw = DEG_TO_RAD(loc_view.y - 90.0f);
	
	float new_x = r_2 * cos(local_yaw) - r_1 * sin(local_yaw);
	float new_y = r_2 * sin(local_yaw) + r_1 * cos(local_yaw);

	//float _r_1 = cos(new_x);

	//float ang_to_point = atan2(new_y, new_x) - DEG_TO_RAD(loc_view.y + 30);
	//
	//float new_x = 100.f * cos(-ang_to_point);
	//float new_y = 100.f * sin(-ang_to_point);

	I::Surface->DrawSetColor(Color(255, 255, 255, 255));
	I::Surface->DrawFilledRect(G::ScreenWidthHalf + new_x - 5, G::ScreenHeightHalf + new_y - 5, G::ScreenWidthHalf + new_x + 5, G::ScreenHeightHalf + new_y + 5);

	D::DrawString(F::ESP, 100, 100, Color(255, 255, 255, 255), FONT_CENTER, "I'm work");
	//float unk_1 = pos_by_local.x;
}

void ESP::Draw()
{

#ifdef FULL_MODE

	//if (Opts.Visuals.Radar.Type == 2)
	//{
		//I::Surface->DrawSetColor(Color::Black().DiffAlpha(Opts.Visuals.Radar.Alpha));
		//I::Surface->DrawFilledRect(Opts.Visuals.Radar.Pos.x, Opts.Visuals.Radar.Pos.y, Opts.Visuals.Radar.Pos.x + Opts.Visuals.Radar.Size, Opts.Visuals.Radar.Pos.y + Opts.Visuals.Radar.Size);
		//
		//I::Surface->DrawSetColor(Color::Outline());
		//I::Surface->DrawOutlinedRect(Opts.Visuals.Radar.Pos.x - 5, Opts.Visuals.Radar.Pos.y - 5, Opts.Visuals.Radar.Pos.x + Opts.Visuals.Radar.Size + 5, Opts.Visuals.Radar.Pos.y + Opts.Visuals.Radar.Size + 5);
		//
		//I::Surface->DrawLine(Opts.Visuals.Radar.Pos.x - 5, Opts.Visuals.Radar.Pos.y + Opts.Visuals.Radar.Size / 2, Opts.Visuals.Radar.Pos.x + Opts.Visuals.Radar.Size + 5, Opts.Visuals.Radar.Pos.y + Opts.Visuals.Radar.Size / 2);
		//
		//I::Surface->DrawLine(Opts.Visuals.Radar.Pos.x + Opts.Visuals.Radar.Size / 2, Opts.Visuals.Radar.Pos.y - 5, Opts.Visuals.Radar.Pos.x + Opts.Visuals.Radar.Size / 2, Opts.Visuals.Radar.Pos.y + Opts.Visuals.Radar.Size + 5);
		//
		//I::Surface->DrawSetColor(Color::White());
		//I::Surface->DrawFilledRect(Opts.Visuals.Radar.Pos.x + Opts.Visuals.Radar.Size / 2 - 2, Opts.Visuals.Radar.Pos.y + Opts.Visuals.Radar.Size / 2 - 2, Opts.Visuals.Radar.Pos.x + Opts.Visuals.Radar.Size / 2 + 2, Opts.Visuals.Radar.Pos.y + Opts.Visuals.Radar.Size / 2 + 2);
		//
		//I::Surface->DrawSetColor(Color::Outline());
		//I::Surface->DrawOutlinedRect(Opts.Visuals.Radar.Pos.x + Opts.Visuals.Radar.Size / 2 - 3, Opts.Visuals.Radar.Pos.y + Opts.Visuals.Radar.Size / 2 - 3, Opts.Visuals.Radar.Pos.x + Opts.Visuals.Radar.Size / 2 + 3, Opts.Visuals.Radar.Pos.y + Opts.Visuals.Radar.Size / 2 + 3);
	//}

	if (G::LocalPlayer->GetWeapon()->IsFiredWeaponType())
	{
		if (Opts.Visuals.Other.Crosshair)
		{
			I::Surface->DrawSetColor(Color::White());
			I::Surface->DrawLine(G::ScreenWidthHalf - 5, G::ScreenHeightHalf, G::ScreenWidthHalf + 5, G::ScreenHeightHalf);
			I::Surface->DrawLine(G::ScreenWidthHalf, G::ScreenHeightHalf - 5, G::ScreenWidthHalf, G::ScreenHeightHalf + 5);
		}

		if (Opts.Visuals.Other.FovCrosshair && Opts.LegitBot.AimBot.Enabled)
		{
			static int fov, silent_fov;
			static bool silent_enable = false;

			float fov_fix = G::FOV >= 90.f ? (G::ScreenHeight / (80.f * G::FOV / 90.f) / (G::FOV / 90.f)) : (G::ScreenHeight / (80.f * G::FOV / 90.f) / (G::FOV / 80.f) * (G::FOV / 80.f));

			if (Opts.LegitBot.SettingMode == 0)
			{
				fov = Opts.LegitBot.All_Legit.AimBot.Fov * fov_fix;
				silent_fov = Opts.LegitBot.All_Legit.AimBot.pSilentFov * fov_fix;

				silent_enable = Opts.LegitBot.All_Legit.AimBot.pSilent;
			}
			else if (Opts.LegitBot.SettingMode == 1)
			{
				int type = G::LocalPlayer->GetWeapon()->GetType() - 4;

				fov = Opts.LegitBot.WT_Legit[type].AimBot.Fov * fov_fix;
				silent_fov = Opts.LegitBot.WT_Legit[type].AimBot.pSilentFov * fov_fix;

				silent_enable = Opts.LegitBot.WT_Legit[type].AimBot.pSilent;
			}
			else
			{
				int weapon = G::LocalPlayer->GetWeapon()->GetAimIndex();

				fov = Opts.LegitBot.EW_Legit[weapon].AimBot.Fov * fov_fix;
				silent_fov = Opts.LegitBot.EW_Legit[weapon].AimBot.pSilentFov * fov_fix;

				silent_enable = Opts.LegitBot.EW_Legit[weapon].AimBot.pSilent;
			}

			I::Surface->DrawSetColor(Color::White());
			I::Surface->DrawOutlinedCircle(G::ScreenWidthHalf, G::ScreenHeightHalf, fov, fov * 16);
			I::Surface->DrawOutlinedCircle(G::ScreenWidthHalf + 1, G::ScreenHeightHalf, fov, fov * 16);
			I::Surface->DrawOutlinedCircle(G::ScreenWidthHalf, G::ScreenHeightHalf + 1, fov, fov * 16);
			I::Surface->DrawOutlinedCircle(G::ScreenWidthHalf + 1, G::ScreenHeightHalf + 1, fov, fov * 16);

			if (silent_enable)
			{
				I::Surface->DrawSetColor(Color::Purple());
				I::Surface->DrawOutlinedCircle(G::ScreenWidthHalf, G::ScreenHeightHalf, silent_fov, silent_fov * 16);
				I::Surface->DrawOutlinedCircle(G::ScreenWidthHalf + 1, G::ScreenHeightHalf, silent_fov, silent_fov * 16);
				I::Surface->DrawOutlinedCircle(G::ScreenWidthHalf, G::ScreenHeightHalf + 1, silent_fov, silent_fov * 16);
				I::Surface->DrawOutlinedCircle(G::ScreenWidthHalf + 1, G::ScreenHeightHalf + 1, silent_fov, silent_fov * 16);
			}
		}

		if (Opts.Visuals.Other.ShowTargetBone && G::CurBestTarget != -1)
		{
			CBaseEntity* Entity = I::ClientEntList->GetClientEntity(G::CurBestTarget);

			if (Entity && Entity->GetAlive())
			{
				Vector on_screen;
				D::WorldToScreen(Entity->GetBonePosition(G::CurBestBone), on_screen);

				I::Surface->DrawSetColor(Color().White());
				I::Surface->DrawLine(on_screen.x - Opts.Visuals.Other.TargetBoneOutline, on_screen.y - Opts.Visuals.Other.TargetBoneOutline, on_screen.x - Opts.Visuals.Other.TargetBoneInline, on_screen.y - Opts.Visuals.Other.TargetBoneInline);
				I::Surface->DrawLine(on_screen.x + Opts.Visuals.Other.TargetBoneInline, on_screen.y + Opts.Visuals.Other.TargetBoneInline, on_screen.x + Opts.Visuals.Other.TargetBoneOutline, on_screen.y + Opts.Visuals.Other.TargetBoneOutline);
				I::Surface->DrawLine(on_screen.x - Opts.Visuals.Other.TargetBoneOutline, on_screen.y + Opts.Visuals.Other.TargetBoneOutline, on_screen.x - Opts.Visuals.Other.TargetBoneInline, on_screen.y + Opts.Visuals.Other.TargetBoneInline);
				I::Surface->DrawLine(on_screen.x + Opts.Visuals.Other.TargetBoneOutline, on_screen.y - Opts.Visuals.Other.TargetBoneOutline, on_screen.x + Opts.Visuals.Other.TargetBoneInline, on_screen.y - Opts.Visuals.Other.TargetBoneInline);
			}
		}
	}

	if (Opts.Visuals.Players.Global.SoundEsp)
	{
		ESP::Misc::SoundESP::Sound.DrawSoundEsp();
	}

	if (Opts.Visuals.GrenadeHelper.Enabled)
	{
		GrenadeHelper();
	}

	if (Opts.Visuals.Other.HitMarker > 0)
	{
		Misc::HitMarker::Draw();
	}

	if (Opts.Visuals.Other.BulletTracer > 0)
	{
		Misc::BulletTracer::Draw();
	}

	if (Opts.Visuals.Other.GrenadePrediction && G::LocalPlayer->GetWeapon()->GetType() == WT_GRENADES)
	{
		Misc::GrenadePrediction::Draw();
	}

	QAngle ang; I::Engine->GetViewAngles(ang);

	if (Opts.Visuals.Players.Global.Enabled || Opts.Visuals.Weapons.Enabled || Opts.Visuals.Radar.Type > 0)
	{
		if (!G::RestartESP)
		{
			for (int index = 0; index <= I::ClientEntList->GetHighestEntityIndex(); ++index)
			{
				CBaseEntity* Entity = I::ClientEntList->GetClientEntity(index);

				if (index < 64)
				{
					if (!Entity || Entity->GetHealth() <= 0 || Entity == G::LocalPlayer || Entity->GetDormant())
						continue;

					if (Opts.Visuals.Players.Global.Enabled)
					{
						Player::Draw(index);
					}
			
					if (Opts.Visuals.Radar.Type == 1)
					{
						if (*Entity->IsSpotted() == false) *Entity->IsSpotted() = true;
					}
					//else if (Opts.Visuals.Radar.Type == 2)
					//{
					//	Misc::Radar::Draw(Entity, ang);
					//}
				}
				else
				{
					if (Opts.Visuals.Weapons.Enabled)
					{
						World::Draw(index);
					}
				}
			}
		}
		else
		{
			static float Delay = I::Globals->curtime + 0.05f;
		
			if (fabsf(I::Globals->curtime - Delay) > 0.06f || I::Globals->curtime > Delay)
			{
				G::RestartESP = false;
			}			
		}
	}

#else

	if (Opts.Visuals.Players.Global.Enabled)
	{
		for (int index = 1; index < 65; ++index)
		{
			CBaseEntity* Entity = I::ClientEntList->GetClientEntity(index);

			if (!Entity || Entity->GetHealth() <= 0 || Entity == G::LocalPlayer || Entity->GetDormant())
				continue;

			if (Opts.Visuals.Players.Global.Enabled)
			{
				Player::Draw(Entity);
			}
		}
	}

#endif
}