#pragma once

inline void DrawSpectatorList()
{
	if (I::Engine->IsInGame() && G::LocalPlayer && G::LocalPlayer->GetHealth() > 0)
	{
		static bool spectators_init = false;

		ImVec2 Position = ImVec2(Opts.Visuals.Other.SpectatorListPos.x, Opts.Visuals.Other.SpectatorListPos.y);
		ImVec2 Size = ImVec2(200, 40);

		if (!spectators_init || G::SpecratorsUpdate)
		{
			ImGui::SetNextWindowPos(Position);
			spectators_init = true;
			G::SpecratorsUpdate = false;
		}

		static std::vector <int> entitys;
		entitys.clear();

		for (int i = 0; i < 65; ++i)
		{
			CBaseEntity* entity = I::ClientEntList->GetClientEntity(i);

			if (!entity)
				continue;
			if (entity->GetAlive() || entity->GetDormant())
				continue;

			auto Handle = entity->GetObserverTargetHandle();
			if (!Handle)
				continue;

			auto Target = I::ClientEntList->GetClientEntityFromHandle(Handle);
			if (!Target)
				continue;
			if (Target != G::LocalPlayer)
				continue;

			entitys.push_back(i);
			Size.y += 20;
		}

		ImGui::SetNextWindowSize(Size);
		ImGui::SetNextWindowBgAlpha(0.5f);

		if (ImGui::Begin(xs("Spectators"), nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoResize))
		{
			Position = ImGui::GetWindowPos();

			static ImDrawList* DrawList = ImGui::GetWindowDrawList();

			DrawList->AddText(ImVec2(Position.x + 5, Position.y + 22), ImColor(1.0f, 1.0f, 1.0f, 1.0f), "Names");

			for (int i = 0; i < entitys.size(); ++i)
			{
				player_info_t Info;
				I::Engine->GetPlayerInfo(entitys[i], &Info);

				DrawList->AddText(ImVec2(Position.x + 5, Position.y + 42 + 20 * i), ImColor(1.0f, 1.0f, 1.0f, 1.0f), Info.Name);
			}

			Opts.Visuals.Other.SpectatorListPos.x = Position.x;
			Opts.Visuals.Other.SpectatorListPos.y = Position.y;

			ImGui::End();
		}
	}
	else if (Opts.Menu.Opened)
	{
		static bool spectators_init = false;

		ImVec2 Position = ImVec2(Opts.Visuals.Other.SpectatorListPos.x, Opts.Visuals.Other.SpectatorListPos.y);
		ImVec2 Size = ImVec2(200, 40);

		if (!spectators_init || G::SpecratorsUpdate)
		{
			ImGui::SetNextWindowPos(Position);
			spectators_init = true;
			G::SpecratorsUpdate = false;
		}

		ImGui::SetNextWindowSize(Size);
		ImGui::SetNextWindowBgAlpha(0.5f);

		if (ImGui::Begin(xs("Spectators"), nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoResize))
		{
			Position = ImGui::GetWindowPos();

			Opts.Visuals.Other.SpectatorListPos.x = Position.x;
			Opts.Visuals.Other.SpectatorListPos.y = Position.y;

			ImGui::End();
		}
	}
}