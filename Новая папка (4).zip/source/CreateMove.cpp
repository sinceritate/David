﻿#include "Cheat.h"
#include <intrin.h>

#define TIME_TO_TICKS( dt )		( (int)( 0.5f + (float)(dt) / I::Globals->interval_per_tick ) )

CreateMoveFn oCreateMove;
bool __stdcall Hooks::CreateMove(float flInputSampleTime, CUserCmd* cmd)
{
	//bool* send_packet = reinterpret_cast<bool*>(reinterpret_cast<uintptr_t>(_AddressOfReturnAddress()) + 0x14);
	bool result = oCreateMove(flInputSampleTime, cmd);

	if (!cmd || !cmd->command_number)
	{
		G::SendPacket = true;
		return result;
	}

	G::IsInDangerZone = U::InDangerZone();

	DWORD* framePointer;
	__asm mov framePointer, ebp;

	G::LocalPlayer = I::ClientEntList->GetClientEntity(I::Engine->GetLocalPlayer());
	G::UserCmd = cmd;

	static int latency_ticks = 0;
	float fl_latency = I::Engine->GetNetChannelInfo()->GetLatency(FLOW_OUTGOING);
	int latency = TIME_TO_TICKS(fl_latency);
	if (I::ClientState->chokedcommands <= 0) {
		latency_ticks = latency;
	}
	else {
		latency_ticks = max(latency, latency_ticks);
	}

	if (I::GameRules->m_bIsValveDS()) {
		if (fl_latency >= I::Globals->interval_per_tick)
			max_choke_ticks = 11 - latency_ticks;
		else
			max_choke_ticks = 11;
	}
	else {
		max_choke_ticks = 13 - latency_ticks;
	}

	static float SpawnTime = 0.0f;
	if (G::LocalPlayer->m_flSpawnTime() != SpawnTime) {
		g_AnimState.pBaseEntity = G::LocalPlayer;
		G::LocalPlayer->ResetAnimationState(&g_AnimState);
		SpawnTime = G::LocalPlayer->m_flSpawnTime();
	}

	if (!I::Engine->IsInGame() || !I::Engine->IsConnected() || !G::LocalPlayer || !G::LocalPlayer->GetAlive())
	{
		G::FlashTime = 0.f;
		G::SendPacket = true;
		return false;
	}

	if (Opts.RageBot.AimBot.Enabled || Opts.RageBot.AntiAims.Enabled)
	{
		Rage::Start();
	}
	else if (Opts.LegitRageBot.Enabled)
	{
		LegitRage::RunLegitRage();
	}
	else
	{
		Legit::RunLegit();
	}
	
	Misc::Start();

	G::LastAngle = G::UserCmd->viewangles;

	if (Opts.Misc.Globals.LegitDesync)
		Desync->handle();

	*(bool*)(*framePointer - 0x1C) = G::SendPacket;

	return false;
}