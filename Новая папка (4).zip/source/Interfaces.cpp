#include "SDK.h"

INetworkStringTable* CNetworkStringTableContainer::FindTable(const char* tableName)
{
	return U::GetVFunc<INetworkStringTable*(__thiscall*)(void*, const char*)>(this, 3)(this, tableName);
}

IBaseClientDll* I::Client;
IClientModeShared* I::ClientMode;
IClientEntityList* I::ClientEntList;
IServerGameDLL* I::Server;
ICVar* I::Cvar;
IInputSystem* I::InputSystem;
IEngineClient* I::Engine;
IEngineTrace* I::EngineTrace;
IEngineSound* I::EngineSound;
IGlobalVarsBase* I::Globals;
ISurface* I::Surface;
IVPanel* I::VPanel;
IVModelRender* I::ModelRender;
IVModelInfo* I::ModelInfo;
IMaterialSystem* I::MaterialSystem;
IMaterial* I::Material;
IVRenderView* I::RenderView;
IPrediction* I::Prediction;
IPhysicsSurfaceProps* I::Physprops;
IVDebugOverlay* I::DebugOverlay;
IStudioRender* I::StudioRender;
IGameMovement* I::GameMovement;
IGameEventManager* I::GameEventManager;
ISteamClient* I::SteamClient;
ISteamHTTP* I::SteamHTTP;
ISteamUser* I::SteamUser;
ISteamFriends* I::SteamFriends;
ISteamInventory* I::SteamInventory;
ISteamGameCoordinator* I::SteamGameCoordinator;
CInput* I::Input;
Localize* I::pLocalize;
CNetworkStringTableContainer* I::ClientStringTableContainer;
IMDLCache* I::ModelCache;
CPrediction* I::pPrediction;
IMoveHelper* I::pMoveHelper;
CUtlVectorSimple* I::g_ClientSideAnimationList;
CClientState* I::ClientState;
CGameRules* I::GameRules;