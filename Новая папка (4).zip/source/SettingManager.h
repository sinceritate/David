#pragma once

// cheat status

#define XOR_ENABLE

#define CURRENT_VERSION "1.2.4"

#define FULL_MODE
//#define TEST_FULL_MODE
//#define TEST_FULL_MODE_CURRENT_VERSION "1"

//#define FREE_MODE
//#define TEST_FREE_MODE

//#define DBG_ENABLED

#ifdef DBG_ENABLED

#define WRITE_TO_CONSOLE( s ) std::cout << s << std::endl
#define PRINT_SYSTEM_COMMAND( s ) system(s)

#else

#define WRITE_TO_CONSOLE( s )
#define PRINT_SYSTEM_COMMAND( s )

#endif