#pragma once

#include "ConVar.h"

struct StringLog
{
	StringLog(std::string String, float Time)
	{
		this->String = String;
		this->Time = Time;
	}

	std::string String;
	float Time;
};

namespace G
{
	extern CBaseEntity* LocalPlayer;
	extern bool IsInDangerZone;
	extern bool Return;
	extern float KillTimer;
	extern CUserCmd* UserCmd;
	extern short Def_mousedx;
	extern bool radio_stat;

	extern HMODULE Dll;
	extern HWND Window;
	extern float FOV;
	extern bool SendPacket;
	extern bool PressedKeys[256];
	extern bool d3dinit;
	extern std::deque< StringLog > Strings;
	extern QAngle TPAngles;
	extern std::string LikeAccount;
	extern std::string ReportAccount;
	extern Vector FakeOrigin;
	extern Vector LastPosition;
	extern float FlashTime;
	extern bool RestartESP;
	extern bool RestartBuyBot;
	extern int CurrentMap;
	extern int MainTabIndex;
	extern float MenuHeight;
	extern float MenuOpacity;
	extern int ScreenWidth;
	extern int ScreenWidthHalf;
	extern int ScreenHeight;
	extern int ScreenHeightHalf;

	extern ConVar* ZoomSensitivityRatioConVar;
	extern float OldZoomSensitivityRatio;

	extern ConVar* RagdollGravityConVar;
	extern int OldRagdollGravity;

	extern bool* PostProcessingDisable;
	extern bool OldPostProcessingDisable;

	extern ConVar* viewmodel_offset_convar_x;
	extern ConVar* viewmodel_offset_convar_y;
	extern ConVar* viewmodel_offset_convar_z;
	extern int old_viewmodel_offset_x;
	extern int old_viewmodel_offset_y;
	extern int old_viewmodel_offset_z;

	extern ConVar* r_modelAmbientMin_convar;
	extern ConVar* mat_force_tonemap_scale_convar;
	extern float old_r_modelAmbientMin;
	extern float old_mat_force_tonemap_scale;

	extern int CurBestTarget;
	extern int CurBestBone;
	//extern ConVar* r_3dsky_convar = new ConVar();
	//extern float old_r_3dsky = 1000;
	//extern ConVar* r_modelAmbientMin_convar = new ConVar();
	//extern float old_r_modelAmbientMin = 1000;
	//extern ConVar* cl_csm_enabled_convar = new ConVar();
	//extern float old_cl_csm_enabled = 1000;

	extern bool using_fake_angles[65];
	extern bool full_choke;
	extern bool is_shooting;

	extern bool in_tp;
	extern bool fake_walk;

	extern int resolve_type[65];

	extern int target;
	extern int shots_fired[65];
	extern int shots_hit[65];
	extern int shots_missed[65];
	extern bool didMiss;
	extern bool didShot;
	extern int backtrack_missed[65];

	//extern bool BigSave;

	extern float tick_to_back[65];
	extern float lby_to_back[65];
	extern bool backtrack_tick[65];

	extern float lby_delta;
	extern float update_time[65];
	extern float walking_time[65];

	extern float local_update;

	extern int hitmarker_time;
	extern int random_number;

	extern bool menu_hide;

	extern int oldest_tick[65];
	extern float compensate[65][12];
	extern Vector backtrack_hitbox[65][20][12];
	extern float backtrack_simtime[65][12];

	extern QAngle RealAngle;
	extern QAngle FakeAngle;
	extern QAngle LastAngle;

	extern QAngle DesyncRealAngle;
	extern QAngle DesyncFakeAngle;

	extern bool CFGUpdate;
	extern bool LegitUpdate;
	extern bool RageUpdate;
	extern bool LegitRageUpdate;
	extern bool RadarUpdate;
	extern bool SpecratorsUpdate;

	extern bool FullUpdate;

	extern std::vector <int> PlayersIndex;

	extern std::string user_login;
}

namespace vmt
{
	extern VMTHookManager vguipanel;
	extern VMTHookManager client_mode;
	extern VMTHookManager client;
	extern VMTHookManager model_render;
	extern VMTHookManager surface;
	extern VMTHookManager sound_engine;
	extern VMTHookManager bsp_query;
	extern VMTHookManager render_view;
	extern VMTHookManager model_cache;
	extern VMTHookManager steam_game_coordinator;
	extern VMTHookManager d3d9;
	extern VMTHookManager sv_cheats;
}

#define hook_index_paint_traverse 41
#define hook_index_override_view 18
#define hook_index_create_move 24
#define hook_index_model_fov 35
#define hook_index_do_postscreen_effects 44
#define hook_index_frame_stage_notify 37
#define hook_index_dispatch_user_message 38
#define hook_index_draw_model_execute 21
#define hook_index_lock_cursor 67
#define hook_index_on_screen_size_changed 116
#define hook_index_emit_sound 5
#define hook_index_list_leaves 6
#define hook_index_scene_end 9
#define hook_index_model_cache 10
#define hook_index_send_net_msg 0
#define hook_index_retrieve_message 2
#define hook_index_reset 16
#define hook_index_end_scene 42
#define hook_index_sv_cheats 13