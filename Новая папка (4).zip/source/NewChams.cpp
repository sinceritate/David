#include "Cheat.h"
#include "NewChams.h"

IMaterial* Materials::materialFlat;
IMaterial* Materials::materialTexture;
IMaterial* Materials::materialWireFrame;
IMaterial* Materials::materialMetalic;
IMaterial* Materials::materialAnimated; 
IMaterial* Materials::materialPlatinum;
IMaterial* Materials::materialGlass;
IMaterial* Materials::materialCrystal;
IMaterial* Materials::materialChrome;
IMaterial* Materials::materialSilver;
IMaterial* Materials::materialGold;
IMaterial* Materials::materialPlastic;
IMaterial* Materials::materialGlowOverlay;
IMaterial* Materials::materialdog_tags_lightray;
IMaterial* Materials::materialdog_dogtags_outline;
IMaterial* Materials::materialdog_dreamhack_star_blur;
IMaterial* Materials::materialdog_crystal_blue;
IMaterial* Materials::materialdog_fishing_net01;
IMaterial* Materials::materialdog_contributor_charset_color;
IMaterial* Materials::materialdog_urban_tree03_branches;
IMaterial* Materials::materialdog_speech_info;
IMaterial* Materials::materialdog_mp3_detail;

void Materials::InitializationMaterials()
{
	std::ofstream("csgo\\materials\\materialFlat.vmt") << R"#("UnlitGeneric" 
{ 
"$basetexture" "vgui/white_additive" 
"$ignorez" "0" 
"$envmap" "" 
"$nofog" "1" 
"$model" "1" 
"$nocull" "0" 
"$selfillum" "1" 
"$halflambert" "1" 
"$znearer" "0" 
"$flat" "1" 
} 
)#";

	std::ofstream("csgo\\materials\\materialTexture.vmt") << R"#("VertexLitGeneric" 
{ 
"$basetexture" "vgui/white_additive" 
"$ignorez" "0" 
"$envmap" ""
"$nofog" "1" 
"$model" "1" 
"$nocull" "0" 
"$selfillum" "1" 
"$halflambert" "1" 
"$znearer" "0" 
"$flat" "1" 
} 
)#";

	std::ofstream("csgo\\materials\\materialWireFrame.vmt") << R"#("VertexLitGeneric" 
{ 
"$basetexture" "vgui/white_additive" 
"$ignorez" "0" 
"$envmap" "" 
"$nofog" "1" 
"$model" "1" 
"$nocull" "0" 
"$selfillum" "1" 
"$halflambert" "1" 
"$znearer" "0" 
"$wireframe" "1" 
"$flat" "0" 
} 
)#";

	std::ofstream("csgo\\materials\\materialMetalic.vmt") << R"#("VertexLitGeneric"
{ 
"$basetexture" "vgui/white_additive"
"$ignorez"      "0"
"$envmap"       "env_cubemap"
"$normalmapalphaenvmapmask"  "1"
"$envmapcontrast"             "1"
"$nofog"        "1"
"$model"        "1"
"$nocull"       "0"
"$selfillum"    "1"
"$halflambert"  "1"
"$znearer"      "0"
"$flat"         "1"
} 
)#";
	std::ofstream("csgo\\materials\\chamsAnimated.vmt") << R"#("VertexLitGeneric"
{
"$envmap" "editor/cube_vertigo"
"$envmapcontrast" "1"
"$envmaptint" "[.7 .7 .7]"
"$basetexture" dev/zone_warning proxies { texturescroll { texturescrollvar $basetexturetransform texturescrollrate 0.6 texturescrollangle 90 } } }
)#";
	std::ofstream("csgo/materials/glowOverlay.vmt") << R"#("VertexLitGeneric"
{
"$additive" "1"
"$envmap" "models/effects/cube_white"
"$envmaptint" "[1 1 1]"
"$envmapfresnel" "1"
"$envmapfresnelminmaxexp" "[0 1 2]"
"$alpha" "0.8"
})#";
	Materials::materialFlat = I::MaterialSystem->FindMaterial(xs("materialFlat"), TEXTURE_GROUP_MODEL);
	Materials::materialTexture = I::MaterialSystem->FindMaterial(xs("materialTexture"), TEXTURE_GROUP_MODEL);
	Materials::materialWireFrame = I::MaterialSystem->FindMaterial(xs("materialWireFrame"), TEXTURE_GROUP_MODEL);
	Materials::materialMetalic = I::MaterialSystem->FindMaterial(xs("materialMetalic"), TEXTURE_GROUP_MODEL);
	Materials::materialAnimated = I::MaterialSystem->FindMaterial(xs("chamsAnimated"), TEXTURE_GROUP_MODEL);
	Materials::materialPlatinum = I::MaterialSystem->FindMaterial(xs("models/player/ct_fbi/ct_fbi_glass"), TEXTURE_GROUP_MODEL);
	Materials::materialGlass = I::MaterialSystem->FindMaterial(xs("models/inventory_items/cologne_prediction/cologne_prediction_glass"), TEXTURE_GROUP_MODEL);
	Materials::materialCrystal = I::MaterialSystem->FindMaterial(xs("models/inventory_items/trophy_majors/crystal_clear"), TEXTURE_GROUP_MODEL);
	Materials::materialChrome = I::MaterialSystem->FindMaterial(xs("models/gibs/glass/glass"), TEXTURE_GROUP_MODEL);
	Materials::materialSilver = I::MaterialSystem->FindMaterial(xs("models/inventory_items/trophy_majors/silver_plain"), TEXTURE_GROUP_MODEL);
	Materials::materialGold = I::MaterialSystem->FindMaterial(xs("models/inventory_items/trophy_majors/gold"), TEXTURE_GROUP_MODEL);
	Materials::materialPlastic = I::MaterialSystem->FindMaterial(xs("models/inventory_items/trophy_majors/gloss"), TEXTURE_GROUP_MODEL);
	Materials::materialGlowOverlay = I::MaterialSystem->FindMaterial(xs("glowOverlay"), TEXTURE_GROUP_MODEL);
	Materials::materialdog_tags_lightray = I::MaterialSystem->FindMaterial(xs("models/inventory_items/dogtags/dogtags_lightray"), TEXTURE_GROUP_MODEL);
	Materials::materialdog_dogtags_outline = I::MaterialSystem->FindMaterial(xs("models/inventory_items/dogtags/dogtags_outline"), TEXTURE_GROUP_MODEL);
	Materials::materialdog_dreamhack_star_blur = I::MaterialSystem->FindMaterial(xs("models/inventory_items/dreamhack_trophies/dreamhack_star_blur"), TEXTURE_GROUP_MODEL);
	Materials::materialdog_crystal_blue = I::MaterialSystem->FindMaterial(xs("models/inventory_items/trophy_majors/crystal_blue"), TEXTURE_GROUP_MODEL);
	Materials::materialdog_fishing_net01 = I::MaterialSystem->FindMaterial(xs("models/props_shacks/fishing_net01"), TEXTURE_GROUP_MODEL);
	Materials::materialdog_contributor_charset_color = I::MaterialSystem->FindMaterial(xs("models/inventory_items/contributor_map_tokens/contributor_charset_color"), TEXTURE_GROUP_MODEL);
	Materials::materialdog_urban_tree03_branches = I::MaterialSystem->FindMaterial(xs("models/props_foliage/urban_tree03_branches"), TEXTURE_GROUP_MODEL);
	Materials::materialdog_speech_info = I::MaterialSystem->FindMaterial(xs("models/extras/speech_info"), TEXTURE_GROUP_MODEL);
	Materials::materialdog_mp3_detail = I::MaterialSystem->FindMaterial(xs("models/inventory_items/music_kit/darude_01/mp3_detail"), TEXTURE_GROUP_MODEL);
}

void Materials::DeleteMaterials()
{
	std::remove(rxs("csgo\\materials\\materialFlat.vmt"));
	std::remove(rxs("csgo\\materials\\materialTexture.vmt"));
	std::remove(rxs("csgo\\materials\\materialWireFrame.vmt"));
	std::remove(rxs("csgo\\materials\\materialMetalic.vmt"));
	std::remove(rxs("csgo\\materials\\chamsAnimated.vmt")); 
	std::remove(rxs("csgo\\materials\\glowOverlay.vmt"));
}