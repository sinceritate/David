#pragma once

#include "Common.h"

struct COffsets
{
	DWORD m_bDormant;
	DWORD m_iHealth;
	DWORD m_iTeamNum;
	DWORD m_ArmorValue;
	DWORD m_bHasHelmet;
	DWORD m_bGunGameImmunity;
	DWORD m_lifeState;
	DWORD m_fFlags;
	DWORD m_nTickBase;
	DWORD m_angEyeAngles;
	DWORD m_flFlashDuration;
	DWORD m_viewPunchAngle;
	DWORD m_aimPunchAngle;
	DWORD m_vecOrigin;
	DWORD m_vecViewOffset;
	DWORD m_vecVelocity;
	DWORD m_hActiveWeapon;
	DWORD m_Collision;
	DWORD m_CollisionGroup;
	DWORD m_iShotsFired;
	DWORD m_nMoveType;
	DWORD m_nHitboxSet;
	DWORD m_flC4Blow;
	DWORD m_bBombTicking;
	DWORD m_flTimerLength;
	DWORD m_flDefuseLength;
	DWORD m_flDefuseCountDown;
	DWORD m_hMyWearables;
	DWORD m_flNextPrimaryAttack;
	DWORD m_nFallbackPaintKit;
	DWORD m_nFallbackSeed;
	DWORD m_flFallbackWear;
	DWORD m_nFallbackStatTrak;
	DWORD m_iItemIDHigh;
	DWORD m_iItemIDLow;
	DWORD m_iAccountID;
	DWORD m_iAccount;
	DWORD m_iEntityQuality;
	DWORD m_iClip1;
	DWORD m_OriginalOwnerXuidLow;
	DWORD m_OriginalOwnerXuidHigh;
	DWORD m_iItemDefinitionIndex;
	DWORD m_hObserverTarget;
	DWORD m_bIsDefusing;
	DWORD m_bSpotted;
	DWORD m_flFlashMaxAlpha;
	DWORD m_flLowerBodyYawTarget;
	DWORD m_angEyeAnglesX;
	DWORD m_angEyeAnglesY;
	DWORD m_vecMaxs;
	DWORD m_vecMins;
	DWORD m_iViewModelIndex;
	DWORD m_flPoseParameter;
	DWORD m_bClientSideAnimation;
	DWORD m_flSimulationTime;
	DWORD m_bIsScoped;
	DWORD m_nModelIndex;
	DWORD m_hWeaponWorldModel;
	DWORD m_szCustomName;
	DWORD m_ragPos;
	DWORD m_hMyWeapons;
	DWORD m_hOwner;
	DWORD deadflag;
	DWORD m_nSurvivalTeam;
	DWORD m_hViewModel;

	DWORD CSWpnData;
	DWORD d3d9Device;
	DWORD GlowManager;
	DWORD LoadFromBufferEx;
	DWORD InitKeyValuesEx;
	DWORD ServerRankRevealAllEx;
	DWORD IsReadyEx;
	DWORD GoesThroughSmoke;
	DWORD FullUpdate;
	//DWORD m_pChatElement;
};

extern COffsets offsets;

namespace Offsets
{
	extern void GrabOffsets();
}
