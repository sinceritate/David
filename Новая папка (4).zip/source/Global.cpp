#include "Cheat.h"

CBaseEntity* G::LocalPlayer;
bool G::IsInDangerZone = false;
bool G::Return = false;
float G::KillTimer = 0.f;

CUserCmd* G::UserCmd;
short G::Def_mousedx;
bool G::radio_stat = false;

HMODULE G::Dll;
HWND G::Window;
float G::FOV;
bool G::SendPacket = true;
bool G::PressedKeys[256] = {};
bool G::d3dinit = false;
std::deque< StringLog > G::Strings;
QAngle G::TPAngles(0, 0, 0);
std::string G::LikeAccount;
std::string G::ReportAccount;
Vector G::FakeOrigin;
Vector G::LastPosition(0, 0, 0);
float G::FlashTime = 0.f;
bool G::RestartESP = false;
bool G::RestartBuyBot = false;
int G::CurrentMap = MP_UNKNOW;

int G::MainTabIndex = 0;

int G::ScreenWidth = 0;
int G::ScreenWidthHalf = 0;
int G::ScreenHeight = 0;
int G::ScreenHeightHalf = 0;

ConVar* G::ZoomSensitivityRatioConVar = new ConVar();
float G::OldZoomSensitivityRatio = 1000;

ConVar* G::RagdollGravityConVar = new ConVar();
int G::OldRagdollGravity = 1000;

bool* G::PostProcessingDisable = new bool();
bool G::OldPostProcessingDisable = false;

ConVar* G::viewmodel_offset_convar_x = new ConVar();
ConVar* G::viewmodel_offset_convar_y = new ConVar();
ConVar* G::viewmodel_offset_convar_z = new ConVar();
int G::old_viewmodel_offset_x = 1000;
int G::old_viewmodel_offset_y = 1000;
int G::old_viewmodel_offset_z = 1000;

ConVar* G::r_modelAmbientMin_convar = new ConVar();
ConVar* G::mat_force_tonemap_scale_convar = new ConVar();
float G::old_r_modelAmbientMin = 1000;
float G::old_mat_force_tonemap_scale = 1000;

int G::CurBestTarget = -1;
int G::CurBestBone = -1;

bool G::using_fake_angles[65];
bool G::full_choke;
bool G::is_shooting;

bool G::in_tp;
bool G::fake_walk;

int G::resolve_type[65];

int G::target;
int G::shots_fired[65];
int G::shots_hit[65];
int G::shots_missed[65];
bool G::didMiss = true;
bool G::didShot = false;
int G::backtrack_missed[65];

//bool G::BigSave = false;

float G::tick_to_back[65];
float G::lby_to_back[65];
bool G::backtrack_tick[65];

float G::lby_delta;
float G::update_time[65];
float G::walking_time[65];

float G::local_update;

int G::hitmarker_time;
int G::random_number;

bool G::menu_hide;

int G::oldest_tick[65];
float G::compensate[65][12];
Vector G::backtrack_hitbox[65][20][12];
float G::backtrack_simtime[65][12];

QAngle G::RealAngle;
QAngle G::FakeAngle;
QAngle G::LastAngle;

QAngle G::DesyncRealAngle;
QAngle G::DesyncFakeAngle;

bool G::CFGUpdate = false;
bool G::LegitUpdate = true;
bool G::RageUpdate = true;
bool G::LegitRageUpdate = true;
bool G::RadarUpdate = true;
bool G::SpecratorsUpdate = true;

bool G::FullUpdate = false;

struct cPlayer {
	BYTE index;
	std::string name;
	bool teammate;
};

std::vector <int> G::PlayersIndex;

std::string G::user_login = "";

VMTHookManager vmt::vguipanel;
VMTHookManager vmt::client_mode;
VMTHookManager vmt::client;
VMTHookManager vmt::model_render;
VMTHookManager vmt::surface;
VMTHookManager vmt::sound_engine;
VMTHookManager vmt::bsp_query;
VMTHookManager vmt::render_view;
VMTHookManager vmt::model_cache;
VMTHookManager vmt::steam_game_coordinator;
VMTHookManager vmt::d3d9;
VMTHookManager vmt::sv_cheats;