#include "Cheat.h"

OverrideViewFn oOverrideView;
void __fastcall Hooks::OverrideView(void* ecx, void* edx, CViewSetup* pSetup)
{
	if (Opts.Visuals.Players.Global.ScreenShotBypass && I::Engine->IsTakingScreenshot())
	{
		oOverrideView(ecx, pSetup);
		return;
	}

	if (G::LocalPlayer && G::LocalPlayer->GetHealth() > 0)
	{
		if (Opts.Misc.Changer.View.bViewFOV && !G::LocalPlayer->IsScoped())
		{
			pSetup->fov = Opts.Misc.Changer.View.fViewFOV;
		}
		else if (Opts.Misc.Globals.NoZoom)
		{
			pSetup->fov = Opts.Misc.Changer.View.bViewFOV ? Opts.Misc.Changer.View.fViewFOV : 90.f;
		}
	}

	G::FOV = pSetup->fov;
	oOverrideView(ecx, pSetup);
}