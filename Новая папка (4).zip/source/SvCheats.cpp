#include "Cheat.h"
#include <intrin.h>

SvCheatsFn oSvCheats;
bool __fastcall Hooks::SvCheats(void* pConVar, void* edx)
{
	static DWORD pattern = U::FindPattern(rxs("client_panorama.dll"), rxs("85 C0 75 30 38 86"));

	if (!oSvCheats) return false;
	if ((DWORD)_ReturnAddress() == pattern) return true;

	return oSvCheats(pConVar);
}