#pragma once

#include "Config.h"
#include <vector>

struct strRage
{
	bool bBAimHealth = false;
	BYTE iBAimHealth = 1;

	bool bBAimMiss = false;
	BYTE iBAimMiss = 1;

	int Bone = 0;

	float HitChance = 1.00f;
	float MinDamage = 1.00f;
};

struct strLegit
{
	struct
	{
		BYTE TargetBone = 0;

		float Fov = 1.00f;
		float Smooth = 1.00f;

		bool pSilent = false;
		float pSilentFov = 0.50f;

		bool Delay = false;
		float ShotDelay = 0.00f;
		float KillDelay = 0.00f;

		float HitChance = 1.00f;
		float MinDamage = 1.00f;
	} AimBot;

	struct
	{
		BYTE Type = 0;
		int X = 0;
		int Y = 0;
	} RCS;

	struct
	{
		bool Head = false;
		bool Body = false;
		bool Misc = false;
		float Delay = 0.00f;
	} Trigger;
};

struct strGrenadeHelper
{
	std::string name;

	Vector org_pos;
	Vector eye_pos;
	QAngle ang;
	int for_map;
};

struct strOptions
{
	struct
	{
		struct
		{
			BYTE SettingMode = 0;

			bool Enabled = false;
			BYTE BAimKey = 0;

			bool FriendlyFire = false;
			bool AutoRevolver = false;

			bool Resolver = false;
			bool Override = false;
			BYTE OverrideKey = 0;

			bool AutoWall = false;
			bool AutoScope = false;
			bool AutoStop = false;

			strRage All_Rage;
			strRage WT_Rage[6]; // WT - weapon type
			strRage EW_Rage[34]; // EW - every weapon
		} AimBot;

		struct
		{
			bool Enabled = false;

			bool CustomAngles = false;
			int Custom[6] = { 0, 0, 0, 0, 0, 0 };

			BYTE Real[6] = { 0, 0, 0, 0, 0, 0 };
			BYTE ManualKey[9] = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };

			BYTE DesyncType[3] = { 0, 0, 0 };
		} AntiAims;
	} RageBot;

	struct
	{
		BYTE SettingMode = 0;

		strLegit All_Legit;
		strLegit WT_Legit[6];
		strLegit EW_Legit[34];
		//strBulletMenager Bullets;

		struct
		{
			bool Enabled = false;

			BYTE AimBotKey = 0;

			bool FriendlyFire = false;

			bool FlashCheck = false;
			bool SmokeCheck = false;
			bool JumpCheck = false;
		} AimBot;

		struct
		{
			bool Enabled = false;
		} RCS;

		struct
		{
			bool Enabled = false;

			BYTE TriggerKey = 0;

			bool FriendlyFire = false;

			bool FlashCheck = false;
			bool SmokeCheck = false;
			bool JumpCheck = false;
		} Trigger;
	} LegitBot;

	struct
	{
		bool Enabled = false;

		strLegit All_Legit;
		strLegit WT_Legit[6];
		strLegit EW_Legit[34];

		bool AimBotAutoFireOnKey = false;
		BYTE AimBotAutoFireKey = 0;

		struct
		{
			bool FriendlyFire = false;

			bool FlashCheck = false;
			bool SmokeCheck = false;
			bool JumpCheck = false;

			bool AutoRevolver = false;
			bool AutoScope = false;
			bool AutoWall = false;
			bool AutoStop = false;
		} AimBot;
	} LegitRageBot;

	struct
	{
		struct
		{
			struct
			{
				bool Enabled = false;
				BYTE VisualsKey = 0;

				bool ScreenShotBypass = false;

				bool EnemyOnly = false;
				bool VisibleOnly = false;

				bool DangerZone = false;

				BYTE BoxMode = 0;
				bool Outline = false;

				struct
				{
					bool Enable = false;
					
					bool Outline = true;
					bool Background = true;

					BYTE Type = 0;

					BYTE Division = 1;

					BYTE Width = 0;
					BYTE Height = 0;

					Color Outline_Color = Color(0, 0, 0, 255);
					Color Background_Color = Color(255, 0, 0, 255);
					Color Health_Color = Color(0, 255, 0, 255);

					ImVec4 DefaulPos = ImVec4(-5, -1, -2, +1);
					ImVec4 DefaulPos2 = ImVec4(-1, +2, +1, +6);
				} Health;

				struct
				{
					bool Enable = false;

					bool Outline = true;
					bool Background = true;

					BYTE Type = 0;

					BYTE Division = 1;

					char Width = 0;
					char Height = 0;

					Color Outline_Color = Color(0, 0, 0, 255);
					Color Background_Color = Color(255, 0, 0, 255);
					Color Armor_Color = Color(0, 255, 0, 255);

					ImVec4 DefaulPos = ImVec4(+6, +1, +2, -1);
					ImVec4 DefaulPos2 = ImVec4(+1, -2, -1, -6);
				} Armor;

				bool SoundEsp = false;

				bool HeadDot = false;
				bool Skeleton = false;

				bool Info = false;

				bool Name = false;
				bool Weapon = false;
				bool Money = false;
				bool Distance = false;
				bool SnipeLine = false;
			} Global;

			struct
			{
				bool Enabled = false;

				bool EnemyOnly = false;
				bool VisibleOnly = false;

				bool Blinking = false;
				BYTE VisType = 0;
				BYTE InvisType = 0;
			} Chams;

			struct
			{
				bool Enabled = false;

				bool EnemyOnly = false;
				bool VisibleOnly = false;

				BYTE Type = 0;
			} Glow;
		} Players;

		struct
		{
			bool Enabled = false;

			bool Glow = false;
			BYTE GlowType = 0;

			BYTE BoxMode = 0;
			bool Outline = false;

			bool Weapons = false;
			bool Grenades = false;
			bool Bomb = false;
		} Weapons;

		struct
		{
			BYTE HitMarker = 0;
			BYTE BulletTracer = 0;
			bool GrenadePrediction = false;
			bool Crosshair = false;
			bool FovCrosshair = false;
			bool ShowTargetBone = false;
			int TargetBoneOutline = 1;
			int TargetBoneInline = 0;
			bool SpectatorList = false;
			v2d SpectatorListPos = v2d(350, 30);
			BYTE SkyChanger = 0;
			std::string SkyChangerName;
			bool WallsColored = false;
			bool SkyColored = false;
			bool PropColored = false;
			bool BackGround = true;
			bool BackDrop = true;
			bool WaterMark = true;
			int BackDropMaxPoints = 10;
			float BackDropMaxDist = 150;
			int BackDropSquareSize = 1;
			int BackDropMaxSpeed = 10;
		} Other;

		struct
		{
			BYTE Type = 0;
			bool EnemyOnly = false;
			v2d Size = v2d(150, 150);
			BYTE PointSize = 3;
			float Zoom = 1.00f;
			BYTE Alpha = 150;

			v2d Pos = v2d(30, 410);
		} Radar;

		struct
		{
			int Length = 0;


		} DangerZone;

		struct
		{
			bool Enabled;

			std::vector <strGrenadeHelper> OptMass;
		} GrenadeHelper;
	} Visuals;

	struct
	{
		struct
		{
			bool RadioEnabled = false;
			int RadioCurrent = 0;
			int RadioVolume = 0;

			bool StatusBar = false;
			bool EventLog = false;
			bool RealAiming = false;
			BYTE RealAimingKey = VK_RBUTTON;

			bool BunnyHop = false;
			bool AutoStrafe = false;
			BYTE JumpChance = 80;

			bool AutoKnife = false;
			bool AutoZeus = false;

			bool AutoPistol = false;

			bool InfinityCrouch = false;
			bool RankReveal = false;
			bool AutoAccept = false;

			bool LegitDesync = false;
			BYTE LegitDesyncType = 0;
			BYTE LegitDesyncFlipKey = 0;

			bool FPSBoost = false;
			bool NightMode = false;
			float PlayerBright = 5.f;
			float MapBright = 0.55f;

			bool HadsChanger = false;
			bool HadsChangerOverride = false;

			bool FastSwitch;

			bool NoSmoke = false;
			bool NoSmokeWireFrame = false;

			bool NoScope = false;
			bool NoZoom = false;

			bool No3dSky = false;
			bool NoFog = false;
			bool NoGrass = false;
			bool NoShadows = false;

			bool FixSensivityInScope = false;

			BYTE FlashAlpha = 255;
		} Globals;

		struct
		{
			std::string ClanTag = "";
			int ClanTagMode = 0;

			bool ChatSpam = false;
			std::string ChatSpamPathToFile = "";
			std::vector <std::string> chat_spam_mass_file;

			bool FakeCrouch = false;
			BYTE FakeCrouchKey = 0;

			bool FakeLag = false;
			BYTE FakeLagType = 0;

			BYTE StandingAmount = 0;
			BYTE MovingAmount = 0;
			BYTE JumpingAmount = 0;

			bool SlowWalk = false;
			BYTE SlowWalkKey = 0;
			int SlowWalkSpeed = 0;

			bool ForceRagDoll = false;
			//bool ReadAhead;
		} Secondary;

		struct
		{
			struct
			{
				bool Enable = false;

				byte Weapon = 0;
				byte Pistol = 0;

				byte grenade_1 = 0;
				byte grenade_2 = 0;
				byte grenade_3 = 0;
				byte grenade_4 = 0;
				
				byte Armor = 0;

				bool zeus = false;
				bool defuse_kit = false;
			} BuyBot;

		} Other;

		struct
		{
			struct
			{
				bool Enable = false;
				bool FastChange = true;

				int iModelMass[MODEL_TYPE_MAX];
			} Models;

			struct
			{
				bool EnableSkins = false;
				bool AutoSelectWeapon = false;
				bool EnableGlove = false;
				bool EnableKnife = false;

				bool SettingsForTeams = true;

				struct
				{
					int SkinID = 0;
					float Wear = 0;
					int Seed = 0;

					struct
					{
						int id = 0;
						float wear = 0.f;
						float scale = 1.f;
						float rotation = 0.f;
					} Sticker[5];

					struct
					{
						int Type = 0;
						int Kills = 0;
					} StatTrak;

					struct
					{
						bool Enabled = false;
						std::string Name = "";
					} CustomName;
				} Weapons[3][34];

				struct
				{
					int ModelIndex = 0;
					int SkinIndex = 0;
					float Wear = 0;
					int Seed = 0;

					struct
					{
						int Type = 0;
						int Kills = 0;
					} StatTrak;

					struct
					{
						bool Enabled = false;
						std::string Name = "";
					} CustomName;
				} Knifes[3];

				struct
				{
					int ModelIndex = 0;
					int SkinIndex = 0;
					float Wear = 0;
					int Seed = 0;
				} Gloves[3]; // 0 - ct // 1 - tt
			} Skins;

			struct
			{
				bool Enabled = false;

				int Level = 0;
				int Experience = 0;
				int MMRank = 0;
				int MMWins = 0;
				int WMRank = 0;
				int WMWins = 0;
				int DZRank = 0;
				int DZWins = 0;
				int Friendly = 0;
				int Leader = 0;
				int Teacher = 0;

				BYTE Ban = 0;
				int BanTime = 0;
			} Profile;

			//struct
			//{
			//	bool Enabled;
			//
			//	bool medalids;
			//	std::vector<uint32_t> medals = {};
			//	bool equipped_medal_override = false;
			//	uint32_t equipped_medal = 0;
			//
			//	std::vector<k_weapon_data> weapons = {};
			//	//int Level;
			//	//int Experience;
			//	//int Rank;
			//	//int Wins;
			//	//int Friendly;
			//	//int Leader;
			//	//int Teacher;
			//	//
			//	//BYTE Ban;
			//	//int BanTime;
			//} Inventory;

			struct
			{
				bool bViewModel = false;
				float fViewModelX = 0;
				float fViewModelY = 0;
				float fViewModelZ = 0;

				bool bViewFOV = false;
				float fViewFOV = 90.0f;

				bool bModelFOV = false;
				float fModelFOV = 60.0f;

				int iHands = 0;
				int iSleeves = 0;
				int iWeapons = 0;

				bool ThirdPerson = false;
				BYTE ThirdPersonKey = 0;
				bool RemoveLocalPlayer = false;
				BYTE ThirdPersonDist = 150;

				bool NoVisualRecoil = false;
			} View;
		} Changer;
	} Misc;

	struct
	{
		struct
		{
			Color PlayersGlobalEnemyVisible = Color(255, 0, 0, 255);
			Color PlayersGlobalEnemyInvisible = Color(0, 0, 0, 255);
			Color PlayersGlobalTeammateVisible = Color(0, 255, 0, 255);
			Color PlayersGlobalTeammateInvisible = Color(0, 0, 255, 255);

			Color PlayersChamsEnemyVisible = Color(255, 0, 0, 255);
			Color PlayersChamsEnemyInvisible = Color(0, 0, 0, 255);
			Color PlayersChamsTeammateVisible = Color(0, 255, 0, 255);
			Color PlayersChamsTeammateInvisible = Color(0, 0, 255, 255);

			Color PlayersSnipeLineEnemyVisible = Color(255, 0, 0, 255);
			Color PlayersSnipeLineEnemyInvisible = Color(0, 0, 0, 255);
			Color PlayersSnipeLineTeammateVisible = Color(0, 255, 0, 255);
			Color PlayersSnipeLineTeammateInvisible = Color(0, 0, 255, 255);

			Color PlayersGlowEnemyVisible = Color(255, 0, 0, 255);
			Color PlayersGlowEnemyInvisible = Color(255, 255, 255, 255);
			Color PlayersGlowTeammateVisible = Color(0, 255, 0, 255);
			Color PlayersGlowTeammateInvisible = Color(0, 0, 255, 255);

			// Color WeaponBoxWeapons;
			// Color WeaponBoxGrenades;
			// Color WeaponBoxBomb;

			Color WeaponGlowWeapons = Color(255, 255, 255, 255);
			Color WeaponGlowGrenades = Color(255, 255, 255, 255);
			Color WeaponGlowBomb = Color(255, 255, 255, 255);

			Color RadarEnemyVisible = Color(255, 0, 0, 255);
			Color RadarEnemyInvisible = Color(0, 0, 0, 255);
			Color RadarTeammateVisible = Color(0, 255, 0, 255);
			Color RadarTeammateInvisible = Color(0, 0, 255, 255);
		} Visuals;

		struct
		{
			Color ChamsHands = Color(0, 0, 255, 255);
			Color ChamsSleeves = Color(255, 0, 0, 255);
			Color ChamsWeapons = Color(0, 0, 0, 255);

			Color BulletTrace = Color(255, 255, 0, 255);
			Color GrenadePrediction = Color(0, 255, 255, 255);

			Color Walls = Color(255, 255, 255, 255);
			Color Sky = Color(255, 255, 255, 255);
			Color Prop = Color(255, 255, 255, 255);

			Color BackGround = Color(0, 0, 0, 170);

			Color BackDropSquare = Color(255, 255, 255, 255);
			Color BackDropSquareOutLine = Color(255, 255, 255, 255);
			Color BackDropSquareLine = Color(255, 255, 255, 255);
		} Misc;
	} Colors;

	struct
	{
		bool Loads[LOAD_SETTINGS_MAX];

		bool Opened;
		int Style = 0;

		int Config;
		std::vector <std::string> MassConfigs;
		Color colors[ImGuiCol_COUNT];

		std::vector <std::string> MassLuas;

		BYTE MenuKey = VK_INSERT;
		BYTE PanicKey = VK_HOME;
	} Menu;
};

extern strOptions Opts;