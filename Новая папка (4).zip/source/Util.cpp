#include "Cheat.h"
#include "recv.h"
#include "Event Listeners.h"
#include "Protobuf_compiled/cstrike15_gcmessages.pb.h"
#include "Protobuf_compiled/gcsdk_gcmessages.pb.h"
#include "Protobuf_compiled/gcsystemmsgs.pb.h"
#include "Protobuf_compiled/cstrike15_usermessages.pb.h"
#include "Skins.h"
#include "NewChams.h"
#include "Definitions.h"

#include <chrono>
#include <Windows.h>
#include <wininet.h>

#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "ws2_32.lib")

#pragma comment(lib, "Lua.lib")
#pragma comment(lib, "lua53.lib")

using namespace std;

int WEAPON_DEAGLE;
int WEAPON_DUALBERETTA;
int WEAPON_FIVESEVEN;
int WEAPON_GLOCK;
int WEAPON_AK47;
int WEAPON_AUG;
int WEAPON_AWP;
int WEAPON_FAMAS;
int WEAPON_G3SG1;
int WEAPON_GALIL;
int WEAPON_M249;
int WEAPON_M4A4;
int WEAPON_MAC10;
int WEAPON_P90;
int WEAPON_MP5SD;
int WEAPON_UMP45;
int WEAPON_XM1014;
int WEAPON_BIZON;
int WEAPON_MAG7;
int WEAPON_NEGEV;
int WEAPON_SAWEDOFF;
int WEAPON_TEC9;
int WEAPON_ZEUSX27;
int WEAPON_P2000;
int WEAPON_MP7;
int WEAPON_MP9;
int WEAPON_NOVA;
int WEAPON_P250;
int WEAPON_SHIELD;
int WEAPON_SCAR20;
int WEAPON_SG553;
int WEAPON_SSG08;
int WEAPON_KNIFE_GG;
int WEAPON_KNIFE;
int WEAPON_FLASHBANG;
int WEAPON_HEGRENADE;
int WEAPON_SMOKEGRENADE;
int WEAPON_MOLOTOV;
int WEAPON_DECOY;
int WEAPON_INCGRENADE;
int WEAPON_C4;
int WEAPON_HEALTHSHOT;
int WEAPON_KNIFE_T;
int WEAPON_M4A1S;
int WEAPON_USPS;
int WEAPON_CZ75;
int WEAPON_REVOLVER;
int WEAPON_TAGRENADE;
int WEAPON_FISTS;
int WEAPON_BREACHCHARGE;
int WEAPON_TABLET;
int WEAPON_MELEE;
int WEAPON_AXE;
int WEAPON_HAMMER;
int WEAPON_SPANNER;
int WEAPON_KNIFE_GHOST;
int WEAPON_FIREBOMB;
int WEAPON_DIVERSION;
int WEAPON_FRAG_GRENADE;
int WEAPON_SNOWBALL;
int WEAPON_BUMPMINE;
int WEAPON_KNIFE_BAYONET;
int WEAPON_KNIFE_CSS;
int WEAPON_KNIFE_FLIP;
int WEAPON_KNIFE_GUT;
int WEAPON_KNIFE_KARAMBIT;
int WEAPON_KNIFE_M9_BAYONET;
int WEAPON_KNIFE_TACTICAL;
int WEAPON_KNIFE_FALCHION;
int WEAPON_KNIFE_SURVIVAL_BOWIE;
int WEAPON_KNIFE_BUTTERFLY;
int WEAPON_KNIFE_PUSH;
int WEAPON_KNIFE_CORD;
int WEAPON_KNIFE_CANIS;
int WEAPON_KNIFE_URSUS;
int WEAPON_KNIFE_GYPSY_JACKKNIFE;
int WEAPON_KNIFE_OUTDOOR;
int WEAPON_KNIFE_STILETTO;
int WEAPON_KNIFE_WIDOWMAKER;
int WEAPON_KNIFE_SKELETON;

std::string WEAPON_KNIFE_VMODEL_GG;
std::string WEAPON_KNIFE_VMODEL;
std::string WEAPON_KNIFE_VMODEL_T;
std::string WEAPON_KNIFE_VMODEL_BAYONET;
std::string WEAPON_KNIFE_VMODEL_CSS;
std::string WEAPON_KNIFE_VMODEL_FLIP;
std::string WEAPON_KNIFE_VMODEL_GUT;
std::string WEAPON_KNIFE_VMODEL_KARAMBIT;
std::string WEAPON_KNIFE_VMODEL_M9_BAYONET;
std::string WEAPON_KNIFE_VMODEL_TACTICAL;
std::string WEAPON_KNIFE_VMODEL_FALCHION;
std::string WEAPON_KNIFE_VMODEL_SURVIVAL_BOWIE;
std::string WEAPON_KNIFE_VMODEL_BUTTERFLY;
std::string WEAPON_KNIFE_VMODEL_PUSH;
std::string WEAPON_KNIFE_VMODEL_CORD;
std::string WEAPON_KNIFE_VMODEL_CANIS;
std::string WEAPON_KNIFE_VMODEL_URSUS;
std::string WEAPON_KNIFE_VMODEL_GYPSY_JACKKNIFE;
std::string WEAPON_KNIFE_VMODEL_OUTDOOR;
std::string WEAPON_KNIFE_VMODEL_STILETTO;
std::string WEAPON_KNIFE_VMODEL_WIDOWMAKER;
std::string WEAPON_KNIFE_VMODEL_SKELETON;

int GLOVE_BLOODHOUND;
int GLOVE_T;
int GLOVE_CT;
int GLOVE_SPORTY;
int GLOVE_SLICK;
int GLOVE_HANDWRAP;
int GLOVE_MOTOCYCLE;
int GLOVE_SPECIALIST;
int GLOVE_HYDRA;

std::string GLOVE_VMODEL_BLOODHOUND;
std::string GLOVE_VMODEL_T;
std::string GLOVE_VMODEL_CT;
std::string GLOVE_VMODEL_SPORTY;
std::string GLOVE_VMODEL_SLICK;
std::string GLOVE_VMODEL_HANDWRAP;
std::string GLOVE_VMODEL_MOTOCYCLE;
std::string GLOVE_VMODEL_SPECIALIST;
std::string GLOVE_VMODEL_HYDRA;

std::vector <std::string> items_game;



int GetIndexByName(std::string name)
{
	for (int i = 0; i < items_game.size(); ++i)
	{
		if (items_game[i].find(xs("\"name\"		\"") + name + "\"") != std::string::npos)
		{
			std::string temp_str = "";
			temp_str.append(items_game[i - 2], items_game[i - 2].find('\"') + 1, items_game[i - 2].rfind('\"') - items_game[i - 2].find('\"') - 1);
			return atoi(temp_str.c_str());
		}
	}

	return -1;
}

std::string GetVModelByName(std::string name)
{
	bool find_name = false;
	for (int i = 0; i < items_game.size(); ++i)
	{
		if (items_game[i].find(("\"name\"		\"") + name + "\"") != std::string::npos)
		{
			find_name = true;
		}

		if (find_name && items_game[i].find(("\"model_player\"		\"")) != std::string::npos)
		{
			std::string temp_str = "";
			temp_str.append(items_game[i], items_game[i].find("models/"), items_game[i].rfind('\"') - items_game[i].find("models/"));
			return temp_str;
		}
	}
}

void ItemIndexInitiolize()
{
	std::ifstream items_game_file(xs("csgo/scripts/items/items_game.txt"));

	if (items_game_file.is_open())
	{
		std::string temp_str;
		while (getline(items_game_file, temp_str))
		{
			items_game.push_back(temp_str);
		}

		items_game_file.close();
	}
	else
	{
		MessageBox(0, xs("items_game.txt not found"), xs("Error 404"), 0);

		__asm
		{
			MOV eax, 0
			DIV ebx
		}
	}

	WEAPON_DEAGLE = GetIndexByName("weapon_deagle");
	WEAPON_DUALBERETTA = GetIndexByName("weapon_elite");
	WEAPON_FIVESEVEN = GetIndexByName("weapon_fiveseven");
	WEAPON_GLOCK = GetIndexByName("weapon_glock");
	WEAPON_AK47 = GetIndexByName("weapon_ak47");
	WEAPON_AUG = GetIndexByName("weapon_aug");
	WEAPON_AWP = GetIndexByName("weapon_awp");
	WEAPON_FAMAS = GetIndexByName("weapon_famas");
	WEAPON_G3SG1 = GetIndexByName("weapon_g3sg1");
	WEAPON_GALIL = GetIndexByName("weapon_galilar");
	WEAPON_M249 = GetIndexByName("weapon_m249");
	WEAPON_M4A4 = GetIndexByName("weapon_m4a1");
	WEAPON_MAC10 = GetIndexByName("weapon_mac10");
	WEAPON_P90 = GetIndexByName("weapon_p90");
	WEAPON_MP5SD = GetIndexByName("weapon_mp5sd");
	WEAPON_UMP45 = GetIndexByName("weapon_ump45");
	WEAPON_XM1014 = GetIndexByName("weapon_xm1014");
	WEAPON_BIZON = GetIndexByName("weapon_bizon");
	WEAPON_MAG7 = GetIndexByName("weapon_mag7");
	WEAPON_NEGEV = GetIndexByName("weapon_negev");
	WEAPON_SAWEDOFF = GetIndexByName("weapon_sawedoff");
	WEAPON_TEC9 = GetIndexByName("weapon_tec9");
	WEAPON_ZEUSX27 = GetIndexByName("weapon_taser");
	WEAPON_P2000 = GetIndexByName("weapon_hkp2000");
	WEAPON_MP7 = GetIndexByName("weapon_mp7");
	WEAPON_MP9 = GetIndexByName("weapon_mp9");
	WEAPON_NOVA = GetIndexByName("weapon_nova");
	WEAPON_P250 = GetIndexByName("weapon_p250");
	WEAPON_SHIELD = GetIndexByName("weapon_shield");
	WEAPON_SCAR20 = GetIndexByName("weapon_scar20");
	WEAPON_SG553 = GetIndexByName("weapon_sg556");
	WEAPON_SSG08 = GetIndexByName("weapon_ssg08");
	WEAPON_KNIFE_GG = GetIndexByName("weapon_knifegg");
	WEAPON_KNIFE_VMODEL_GG = GetVModelByName("weapon_knifegg");
	WEAPON_KNIFE = GetIndexByName("weapon_knife");
	WEAPON_KNIFE_VMODEL = GetVModelByName("weapon_knife");
	WEAPON_FLASHBANG = GetIndexByName("weapon_flashbang");
	WEAPON_HEGRENADE = GetIndexByName("weapon_hegrenade");
	WEAPON_SMOKEGRENADE = GetIndexByName("weapon_smokegrenade");
	WEAPON_MOLOTOV = GetIndexByName("weapon_molotov");
	WEAPON_DECOY = GetIndexByName("weapon_decoy");
	WEAPON_INCGRENADE = GetIndexByName("weapon_incgrenade");
	WEAPON_C4 = GetIndexByName("weapon_c4");
	WEAPON_HEALTHSHOT = GetIndexByName("weapon_healthshot");
	WEAPON_KNIFE_T = GetIndexByName("weapon_knife_t");
	WEAPON_KNIFE_VMODEL_T = GetVModelByName("weapon_knife_t");
	WEAPON_M4A1S = GetIndexByName("weapon_m4a1_silencer");
	WEAPON_USPS = GetIndexByName("weapon_usp_silencer");
	WEAPON_CZ75 = GetIndexByName("weapon_cz75a");
	WEAPON_REVOLVER = GetIndexByName("weapon_revolver");
	WEAPON_TAGRENADE = GetIndexByName("weapon_tagrenade");
	WEAPON_FISTS = GetIndexByName("weapon_fists");
	WEAPON_BREACHCHARGE = GetIndexByName("weapon_breachcharge");
	WEAPON_TABLET = GetIndexByName("weapon_tablet");
	WEAPON_MELEE = GetIndexByName("weapon_melee");
	WEAPON_AXE = GetIndexByName("weapon_axe");
	WEAPON_HAMMER = GetIndexByName("weapon_hammer");
	WEAPON_SPANNER = GetIndexByName("weapon_spanner");
	WEAPON_KNIFE_GHOST = GetIndexByName("weapon_knife_ghost");
	WEAPON_FIREBOMB = GetIndexByName("weapon_firebomb");
	WEAPON_DIVERSION = GetIndexByName("weapon_diversion");
	WEAPON_FRAG_GRENADE = GetIndexByName("weapon_frag_grenade");
	WEAPON_SNOWBALL = GetIndexByName("weapon_snowball");
	WEAPON_BUMPMINE = GetIndexByName("weapon_bumpmine");
	WEAPON_KNIFE_BAYONET = GetIndexByName("weapon_bayonet");
	WEAPON_KNIFE_VMODEL_BAYONET = GetVModelByName("weapon_bayonet");
	WEAPON_KNIFE_CSS = GetIndexByName("weapon_knife_css");
	WEAPON_KNIFE_VMODEL_CSS = GetVModelByName("weapon_knife_css");
	WEAPON_KNIFE_FLIP = GetIndexByName("weapon_knife_flip");
	WEAPON_KNIFE_VMODEL_FLIP = GetVModelByName("weapon_knife_flip");
	WEAPON_KNIFE_GUT = GetIndexByName("weapon_knife_gut");
	WEAPON_KNIFE_VMODEL_GUT = GetVModelByName("weapon_knife_gut");
	WEAPON_KNIFE_KARAMBIT = GetIndexByName("weapon_knife_karambit");
	WEAPON_KNIFE_VMODEL_KARAMBIT = GetVModelByName("weapon_knife_karambit");
	WEAPON_KNIFE_M9_BAYONET = GetIndexByName("weapon_knife_m9_bayonet");
	WEAPON_KNIFE_VMODEL_M9_BAYONET = GetVModelByName("weapon_knife_m9_bayonet");
	WEAPON_KNIFE_TACTICAL = GetIndexByName("weapon_knife_tactical");
	WEAPON_KNIFE_VMODEL_TACTICAL = GetVModelByName("weapon_knife_tactical");
	WEAPON_KNIFE_FALCHION = GetIndexByName("weapon_knife_falchion");
	WEAPON_KNIFE_VMODEL_FALCHION = GetVModelByName("weapon_knife_falchion");
	WEAPON_KNIFE_SURVIVAL_BOWIE = GetIndexByName("weapon_knife_survival_bowie");
	WEAPON_KNIFE_VMODEL_SURVIVAL_BOWIE = GetVModelByName("weapon_knife_survival_bowie");
	WEAPON_KNIFE_BUTTERFLY = GetIndexByName("weapon_knife_butterfly");
	WEAPON_KNIFE_VMODEL_BUTTERFLY = GetVModelByName("weapon_knife_butterfly");
	WEAPON_KNIFE_PUSH = GetIndexByName("weapon_knife_push");
	WEAPON_KNIFE_VMODEL_PUSH = GetVModelByName("weapon_knife_push");
	WEAPON_KNIFE_CORD = GetIndexByName("weapon_knife_cord");
	WEAPON_KNIFE_VMODEL_CORD = GetVModelByName("weapon_knife_cord");
	WEAPON_KNIFE_CANIS = GetIndexByName("weapon_knife_canis");
	WEAPON_KNIFE_VMODEL_CANIS = GetVModelByName("weapon_knife_canis");
	WEAPON_KNIFE_URSUS = GetIndexByName("weapon_knife_ursus");
	WEAPON_KNIFE_VMODEL_URSUS = GetVModelByName("weapon_knife_ursus");
	WEAPON_KNIFE_GYPSY_JACKKNIFE = GetIndexByName("weapon_knife_gypsy_jackknife");
	WEAPON_KNIFE_VMODEL_GYPSY_JACKKNIFE = GetVModelByName("weapon_knife_gypsy_jackknife");
	WEAPON_KNIFE_OUTDOOR = GetIndexByName("weapon_knife_outdoor");
	WEAPON_KNIFE_VMODEL_OUTDOOR = GetVModelByName("weapon_knife_outdoor");
	WEAPON_KNIFE_STILETTO = GetIndexByName("weapon_knife_stiletto");
	WEAPON_KNIFE_VMODEL_STILETTO = GetVModelByName("weapon_knife_stiletto");
	WEAPON_KNIFE_WIDOWMAKER = GetIndexByName("weapon_knife_widowmaker");
	WEAPON_KNIFE_VMODEL_WIDOWMAKER = GetVModelByName("weapon_knife_widowmaker");
	WEAPON_KNIFE_SKELETON = GetIndexByName("weapon_knife_skeleton");
	WEAPON_KNIFE_VMODEL_SKELETON = GetVModelByName("weapon_knife_skeleton");

	GLOVE_VMODEL_BLOODHOUND = GetVModelByName("studded_bloodhound_gloves");
	GLOVE_BLOODHOUND = GetIndexByName("studded_bloodhound_gloves");
	GLOVE_VMODEL_T = GetVModelByName("t_gloves");
	GLOVE_T = GetIndexByName("t_gloves");
	GLOVE_VMODEL_CT = GetVModelByName("ct_gloves");
	GLOVE_CT = GetIndexByName("ct_gloves");
	GLOVE_VMODEL_SPORTY = GetVModelByName("sporty_gloves");
	GLOVE_SPORTY = GetIndexByName("sporty_gloves");
	GLOVE_VMODEL_SLICK = GetVModelByName("slick_gloves");
	GLOVE_SLICK = GetIndexByName("slick_gloves");
	GLOVE_VMODEL_HANDWRAP = GetVModelByName("leather_handwraps");
	GLOVE_HANDWRAP = GetIndexByName("leather_handwraps");
	GLOVE_VMODEL_MOTOCYCLE = GetVModelByName("motorcycle_gloves");
	GLOVE_MOTOCYCLE = GetIndexByName("motorcycle_gloves");
	GLOVE_VMODEL_SPECIALIST = GetVModelByName("specialist_gloves");
	GLOVE_SPECIALIST = GetIndexByName("specialist_gloves");
	GLOVE_VMODEL_HYDRA = GetVModelByName("studded_hydra_gloves");
	GLOVE_HYDRA = GetIndexByName("studded_hydra_gloves");

	items_game.clear();
}

void ServerClassesInitiolize()
{
	//auto server_class = I::Server->GetAllServerClasses();
	//for (size_t i = 0; server_class; server_class = server_class->m_pNext, ++i)
	//{
	//	WRITE_TO_CONSOLE(server_class->m_pNetworkName << i);
	//	//if (!strcmp(server_class->m_pNetworkName, classname))
	//	//	return id;
	//}
}

MsgFn U::PrintMessage = (MsgFn)GetProcAddress(GetModuleHandleA(rXor("tier0.dll")), rXor("Msg"));
ServerRankRevealAllFn U::ServerRankRevealAllEx;
InitKeyValuesFn U::InitKeyValuesEx;
LoadFromBufferFn U::LoadFromBufferEx;
IsReadyFn U::IsReady = reinterpret_cast<void(__cdecl*)()>(U::FindPattern(rXor("client_panorama.dll"), rXor("55 8B EC 83 E4 F8 83 EC 08 56 8B 35 ? ? ? ? 57 83 BE")));
IsBreakableEntityFn U::IsBreakableEntity = reinterpret_cast<IsBreakableEntityFn>(U::FindPattern(rXor("client_panorama.dll"), rXor("55 8B EC 51 56 8B F1 85 F6 74 68 83 BE")));
TraceToExitFn U::TraceToExit = NULL;
DWORD U::ClipTraceToPlayers = U::FindPattern(rXor("client_panorama.dll"), rXor("53 8B DC 83 EC 08 83 E4 F0 83 C4 04 55 8B 6B 04 89 6C 24 04 8B EC 81 EC ? ? ? ? 8B 43 10"));

SteamUserHandle SteamUser = ((SteamUserHandle(__cdecl*)(void))GetProcAddress(GetModuleHandleA(rXor("steam_api.dll")), rXor("SteamAPI_GetHSteamUser")))();
SteamPipeHandle SteamPipe = ((SteamPipeHandle(__cdecl*)(void))GetProcAddress(GetModuleHandleA(rXor("steam_api.dll")), rXor("SteamAPI_GetHSteamPipe")))();


void U::SetupInterfaces()
{
	I::Client = U::CaptureInterface< IBaseClientDll >(rXor("client_panorama.dll"), rXor("VClient018"));
	I::ClientMode = **(IClientModeShared***)((*(DWORD**)I::Client)[10] + 0x5);
	I::ClientEntList = U::CaptureInterface< IClientEntityList >(rXor("client_panorama.dll"), rXor("VClientEntityList003"));
	I::Server = U::CaptureInterface<IServerGameDLL>("server.dll", "ServerGame");
	I::Cvar = U::CaptureInterface< ICVar >(rXor("vstdlib.dll"), rXor("VEngineCvar007"));
	I::Engine = U::CaptureInterface< IEngineClient >(rXor("engine.dll"), rXor("VEngineClient014"));
	I::EngineTrace = U::CaptureInterface< IEngineTrace >(rXor("engine.dll"), rXor("EngineTraceClient004"));
	I::InputSystem = U::CaptureInterface< IInputSystem >(rXor("inputsystem.dll"), rXor("InputSystemVersion001"));
	I::Globals = **(IGlobalVarsBase***)((*(DWORD**)I::Client)[0] + 0x1B);
	I::Surface = U::CaptureInterface< ISurface >(rXor("vguimatsurface.dll"), rXor("VGUI_Surface031"));
	I::VPanel = U::CaptureInterface< IVPanel >(rXor("vgui2.dll"), rXor("VGUI_Panel009"));
	I::RenderView = U::CaptureInterface< IVRenderView >(rXor("engine.dll"), rXor("VEngineRenderView014"));
	I::ModelRender = U::CaptureInterface< IVModelRender >(rXor("engine.dll"), rXor("VEngineModel016"));
	I::MaterialSystem = U::CaptureInterface< IMaterialSystem >(rXor("materialsystem.dll"), rXor("VMaterialSystem080"));
	I::ModelInfo = U::CaptureInterface< IVModelInfo >(rXor("engine.dll"), rXor("VModelInfoClient004"));
	I::Prediction = U::CaptureInterface< IPrediction >(rXor("client_panorama.dll"), rXor("VClientPrediction001"));
	I::Physprops = U::CaptureInterface< IPhysicsSurfaceProps >(rXor("vphysics.dll"), rXor("VPhysicsSurfaceProps001"));
	I::DebugOverlay = U::CaptureInterface< IVDebugOverlay >(rXor("engine.dll"), rXor("VDebugOverlay004"));
	I::StudioRender = U::CaptureInterface< IStudioRender >(rXor("studiorender.dll"), rXor("VStudioRender026"));
	I::GameMovement = U::CaptureInterface<IGameMovement>("client_panorama.dll", rXor("GameMovement"));
	I::GameEventManager = U::CaptureInterface<IGameEventManager>(rXor("engine.dll"), rXor("GAMEEVENTSMANAGER002"));
	I::EngineSound = U::CaptureInterface<IEngineSound>(rXor("engine.dll"), rXor("IEngineSoundClient003"));
	I::SteamClient = ((ISteamClient*(__cdecl*)(void))GetProcAddress(GetModuleHandleA(rXor("steam_api.dll")), rXor("SteamClient")))();
	I::SteamHTTP = I::SteamClient->GetISteamHTTP(SteamUser, SteamPipe, rXor("STEAMHTTP_INTERFACE_VERSION002"));
	I::SteamUser = I::SteamClient->GetISteamUser(SteamUser, SteamPipe, rXor("SteamUser019"));
	I::SteamFriends = I::SteamClient->GetISteamFriends(SteamUser, SteamPipe, rXor("SteamFriends015"));
	I::SteamInventory = I::SteamClient->GetISteamInventory(SteamUser, SteamPipe, rXor("STEAMINVENTORY_INTERFACE_V002"));
	I::SteamGameCoordinator = (ISteamGameCoordinator*)I::SteamClient->GetISteamGenericInterface(SteamUser, SteamPipe, rXor("SteamGameCoordinator001"));
	I::pPrediction = U::CaptureInterface<CPrediction>(rXor("client_panorama.dll"), rXor("VClientPrediction001"));
	I::pMoveHelper = U::CaptureInterface<IMoveHelper>(rXor("client_panorama.dll"), rXor("8B 0D ? ? ? ? 8B 46 08 68")) + 0x2;
	I::Input = *(CInput**)(U::FindPattern(rXor("client_panorama.dll"), rXor("B9 ? ? ? ? F3 0F 11 04 24 FF 50 10")) + 0x1);
	I::pLocalize = U::CaptureInterface<Localize>(rXor("localize"), rXor("Localize_001"));
	I::ClientStringTableContainer = U::CaptureInterface<CNetworkStringTableContainer>(rXor("engine.dll"), rXor("VEngineClientStringTable001"));
	I::ModelCache = U::CaptureInterface<IMDLCache>(rXor("datacache.dll"), rXor("MDLCache004"));
	I::ClientState = **(CClientState***)(U::FindPattern(rXor("engine.dll"), "A1 ? ? ? ? 8B 80 ? ? ? ? C3") + 1);
	I::GameRules = *(CGameRules**)(U::FindPattern("client_panorama.dll", "8B 0D ?? ?? ?? ?? 85 C0 74 0A 8B 01 FF 50 78 83 C0 54") + 2);
}

Vector U::RotatePoint(Vector EntityPos, Vector LocalPlayerPos, int posX, int posY, int sizeX, int sizeY, float angle, float Zoom, bool * viewCheck, bool angleInRadians)
{
	float r_1, r_2;
	float x_1, y_1;

	r_1 = -(EntityPos.y - LocalPlayerPos.y);
	r_2 = EntityPos.x - LocalPlayerPos.x;
	float Yaw = angle - 90.0f;

	float yawToRadian = Yaw * (float)(M_PI / 180.0F);
	x_1 = (float)(r_2 * (float)cos((double)(yawToRadian)) - r_1 * sin((double)(yawToRadian))) / 20;
	y_1 = (float)(r_2 * (float)sin((double)(yawToRadian)) + r_1 * cos((double)(yawToRadian))) / 20;

	*viewCheck = y_1 < 0;

	x_1 *= Zoom;
	y_1 *= Zoom;

	int sizX = sizeX / 2;
	int sizY = sizeY / 2;

	x_1 += sizX;
	y_1 += sizY;

	if (x_1 < 5)
	{
		x_1 = 5;
	}
		
	if (x_1 > sizeX - 5)
	{
		x_1 = sizeX - 5;
	}

	if (y_1 < 5)
	{
		y_1 = 5;
	}
	
	if (y_1 > sizeY - 5)
	{
		y_1 = sizeY - 5;
	}
	
	x_1 += posX;
	y_1 += posY;

	return Vector(x_1, y_1, 0);
}

DWORD U::FindPattern(std::string moduleName, std::string pattern)
{
	const char* pat = pattern.c_str();
	DWORD firstMatch = 0;
	DWORD rangeStart = (DWORD)GetModuleHandleA(moduleName.c_str());
	MODULEINFO miModInfo;
	GetModuleInformation(GetCurrentProcess(), (HMODULE)rangeStart, &miModInfo, sizeof(MODULEINFO));
	DWORD rangeEnd = rangeStart + miModInfo.SizeOfImage;
	for (DWORD pCur = rangeStart; pCur < rangeEnd; pCur++)
	{
		if (!*pat)
			return firstMatch;

		if (*(PBYTE)pat == '\?' || *(BYTE*)pCur == getByte(pat))
		{
			if (!firstMatch)
				firstMatch = pCur;

			if (!pat[2])
				return firstMatch;

			if (*(PWORD)pat == '\?\?' || *(PBYTE)pat != '\?')
				pat += 3;

			else
				pat += 2;
		}
		else
		{
			pat = pattern.c_str();
			firstMatch = 0;
		}
	}
	return NULL;
}

CBaseEntity* U::GetLocalPlayer()
{
	return I::ClientEntList->GetClientEntity(I::Engine->GetLocalPlayer());
}

bool U::InDangerZone()
{
	static ConVar* game_type = I::Cvar->FindVar(rXor("game_type"));
	static ConVar* game_mode = I::Cvar->FindVar(rXor("game_mode"));
	return ((int)game_type->GetFloat() == 6 && (int)game_mode->GetFloat() == 0);
}

int GetCurrentGameTypeMode()
{
	//enum
	//{
	//	UNKNOW_GAME_TYPE_MODE
	//	,
	//
	//	/*
	//	0 0 // casual
	//	2 1 // dm
	//	*/
	//};
	//
	//I::Server->GetAllServerClasses();

	return -1;
}

bool U::IsWeaponKnife(int weaponid)
{
	if (weaponid == WEAPON_KNIFE                || weaponid == WEAPON_KNIFE_T ||
		weaponid == WEAPON_KNIFE_BAYONET        || weaponid == WEAPON_KNIFE_BUTTERFLY ||
		weaponid == WEAPON_KNIFE_FALCHION       || weaponid == WEAPON_KNIFE_FLIP ||
		weaponid == WEAPON_KNIFE_GUT            || weaponid == WEAPON_KNIFE_KARAMBIT ||
		weaponid == WEAPON_KNIFE_M9_BAYONET     || weaponid == WEAPON_KNIFE_PUSH ||
		weaponid == WEAPON_KNIFE_SURVIVAL_BOWIE || weaponid == WEAPON_KNIFE_TACTICAL ||
		weaponid == WEAPON_KNIFE_URSUS          || weaponid == WEAPON_KNIFE_GYPSY_JACKKNIFE ||
		weaponid == WEAPON_KNIFE_STILETTO       || weaponid == WEAPON_KNIFE_WIDOWMAKER)
		return true;

	return false;
}

bool U::IsWeaponDefaultKnife(int weaponid)
{
	if (weaponid == WEAPON_KNIFE || weaponid == WEAPON_KNIFE_T)
		return true;

	return false;
}

char* U::GetConfigName(int weaponid)
{
	switch (weaponid)
	{
	case 0: { return xs("USP-S"); }
	case 1: { return xs("R8"); }
	case 2: { return xs("CZ75"); }
	case 3: { return xs("Deagle"); }
	case 4: { return xs("Berettas"); }
	case 5: { return xs("FiveSeven"); }
	case 6: { return xs("Glock"); }
	case 7: { return xs("P2000"); }
	case 8: { return xs("P250"); }
	case 9: { return xs("Tec9"); }

	case 10: { return xs("MAC10"); }
	case 11: { return xs("MP7"); }
	case 12: { return xs("MP9"); }
	case 13: { return xs("MP5SD"); }
	case 14: { return xs("Bizon"); }
	case 15: { return xs("P90"); }
	case 16: { return xs("UMP45"); }

	case 17: { return xs("AK47"); }
	case 18: { return xs("FAMAS"); }
	case 19: { return xs("Galil"); }
	case 20: { return xs("M4A1S"); }
	case 21: { return xs("M4A4"); }

	case 22: { return xs("AWP"); }
	case 23: { return xs("G3SG1"); }
	case 24: { return xs("SCAR20"); }
	case 25: { return xs("SSG08"); }
	case 26: { return xs("AUG"); }
	case 27: { return xs("SG553"); }

	case 28: { return xs("MAG7"); }
	case 29: { return xs("Nova"); }
	case 30: { return xs("SawedOff"); }
	case 31: { return xs("XM1014"); }

	case 32: { return xs("M249"); }
	case 33: { return xs("Negev"); }
	}
}

wchar_t* U::Convert_char_to_wchar(const char* charArray)
{
	wchar_t* wString = new wchar_t[4096];
	MultiByteToWideChar(CP_ACP, 0, charArray, -1, wString, 4096);
	return wString;
}

void U::TraceLine(const Vector& vecAbsStart, const Vector& vecAbsEnd, unsigned int mask, CBaseEntity* ignore, trace_t* ptr)
{
	Ray_t ray;
	ray.Init(vecAbsStart, vecAbsEnd);
	CTraceFilter filter;
	filter.pSkip = ignore;

	I::EngineTrace->TraceRay(ray, mask, &filter, ptr);
}

void U::ServerRankRevealAll()
{
	I::Client->DispatchUserMessage(50, 0, 0, nullptr); // CS_UM_RankRevealAll
}

void U::InitKeyValues(KeyValues* pKeyValues, const char* Name)
{
	U::InitKeyValuesEx = (InitKeyValuesFn)(offsets.InitKeyValuesEx);
	U::InitKeyValuesEx(pKeyValues, Name);
}

void U::LoadFromBuffer(KeyValues* pKeyValues, const char* resourceName, const char* pBuffer, void* pFileSystem, const char* pPathID, void* pfnEvaluateSymbolProc)
{
	U::LoadFromBufferEx = (LoadFromBufferFn)(offsets.LoadFromBufferEx);
	U::LoadFromBufferEx(pKeyValues, resourceName, pBuffer, pFileSystem, pPathID, pfnEvaluateSymbolProc);
}

long U::GetEpochTime()
{
	auto epoch = std::chrono::system_clock::now().time_since_epoch();
	return std::chrono::duration_cast<std::chrono::milliseconds>(epoch).count();
}

bool U::SendCommends(int accountId)
{
	PlayerCommendationInfo commend_info;
	commend_info.set_cmd_friendly(1);
	commend_info.set_cmd_teaching(2);
	commend_info.set_cmd_leader(4);

	CMsgGCCStrike15_v2_ClientCommendPlayer CommendMessage;

	CommendMessage.set_account_id(accountId);
	CommendMessage.set_match_id(8);
	CommendMessage.set_allocated_commendation(&commend_info);
	CommendMessage.set_tokens(10);

	void* alocated_memory = malloc(CommendMessage.ByteSize() + 8);

	if (!alocated_memory)
		return false;

	((uint32_t*)alocated_memory)[0] = k_EMsgGCCStrike15_v2_ClientCommendPlayer | ((DWORD)1 << 31);
	((uint32_t*)alocated_memory)[1] = 0;

	CommendMessage.SerializeToArray((void*)((DWORD)alocated_memory + 8), CommendMessage.ByteSize());

	bool result = I::SteamGameCoordinator->SendMessage_CSGO(k_EMsgGCCStrike15_v2_ClientCommendPlayer | ((DWORD)1 << 31), alocated_memory, CommendMessage.ByteSize() + 8) == k_EGCResultOK;

	free(alocated_memory);

	return result;
}

bool U::SendReport(int accountId)
{
	CMsgGCCStrike15_v2_ClientReportPlayer ReportMessage;

	ReportMessage.set_account_id(accountId);
	ReportMessage.set_rpt_aimbot(2);
	ReportMessage.set_rpt_wallhack(3);
	ReportMessage.set_rpt_speedhack(4);
	ReportMessage.set_rpt_teamharm(5);
	ReportMessage.set_rpt_textabuse(6);
	ReportMessage.set_rpt_voiceabuse(7);
	ReportMessage.set_match_id(8);

	void* alocated_memory = malloc(ReportMessage.ByteSize() + 8);

	if (!alocated_memory)
		return false;

	((uint32_t*)alocated_memory)[0] = k_EMsgGCCStrike15_v2_ClientReportPlayer | ((DWORD)1 << 31);
	((uint32_t*)alocated_memory)[1] = 0;

	ReportMessage.SerializeToArray((void*)((DWORD)alocated_memory + 8), ReportMessage.ByteSize());

	bool result = I::SteamGameCoordinator->SendMessage_CSGO(k_EMsgGCCStrike15_v2_ClientReportPlayer | ((DWORD)1 << 31), alocated_memory, ReportMessage.ByteSize() + 8) == k_EGCResultOK;

	free(alocated_memory);

	return result;
}

QAngle U::CalcAngle(Vector src, Vector dst)
{
	QAngle ret;
	M::VectorAngles(dst - src, ret);
	return ret;
}

void U::PrecacheModel(const char* szModelName)
{
	INetworkStringTable* m_pModelPrecacheTable = I::ClientStringTableContainer->FindTable("modelprecache");

	if (m_pModelPrecacheTable)
	{
		I::ModelInfo->FindOrLoadModel(szModelName);
		m_pModelPrecacheTable->AddString(false, szModelName);
	}
}

void U::SetCustomModel(const char* model_name, CBaseEntity* entity)
{
	U::PrecacheModel(model_name);
	entity->SetModelIndexVirtual(I::ModelInfo->GetModelIndex(model_name));
}

bool U::SendCSGOMessages()
{
	I::Engine->ExecuteClientCmd("econ_clear_inventory_images");

	CMsgClientHello ClientHelloMessage;
	CMsgGCCStrike15_v2_MatchmakingClient2GCHello MMHelloMessage;
	CMsgGCCStrike15_v2_ClientGCRankUpdate RankMessage;

	ClientHelloMessage.set_client_session_need(1);
	ClientHelloMessage.clear_socache_have_versions();

	RankMessage.mutable_rankings()->Add()->set_rank_type_id(7);
	RankMessage.mutable_rankings()->Add()->set_rank_type_id(10);

	void* clienthello_ptr = malloc(ClientHelloMessage.ByteSize() + 8);
	void* mmhello_ptr = malloc(MMHelloMessage.ByteSize() + 8);
	void* rank_ptr = malloc(RankMessage.ByteSize() + 8);

	if (!clienthello_ptr || !mmhello_ptr || !rank_ptr)
		return false;

	static DWORD clienthello_MsgType = k_EMsgGCClientHello | ((DWORD)1 << 31);
	((uint32_t*)clienthello_ptr)[0] = clienthello_MsgType;
	((uint32_t*)clienthello_ptr)[1] = 0;

	static DWORD mmhello_MsgType = k_EMsgGCCStrike15_v2_MatchmakingClient2GCHello | ((DWORD)1 << 31);
	((uint32_t*)mmhello_ptr)[0] = mmhello_MsgType;
	((uint32_t*)mmhello_ptr)[1] = 0;

	static DWORD rank_MsgType = k_EMsgGCCStrike15_v2_ClientGCRankUpdate | ((DWORD)1 << 31);
	((uint32_t*)rank_ptr)[0] = rank_MsgType;
	((uint32_t*)rank_ptr)[1] = 0;


	ClientHelloMessage.SerializeToArray((void*)((DWORD)clienthello_ptr + 8), ClientHelloMessage.ByteSize());
	MMHelloMessage.SerializeToArray((void*)((DWORD)mmhello_ptr + 8), MMHelloMessage.ByteSize());
	RankMessage.SerializeToArray((void*)((DWORD)rank_ptr + 8), RankMessage.ByteSize());


	bool result = I::SteamGameCoordinator->SendMessage_CSGO(clienthello_MsgType, clienthello_ptr, ClientHelloMessage.ByteSize() + 8) == k_EGCResultOK
		&& I::SteamGameCoordinator->SendMessage_CSGO(mmhello_MsgType, mmhello_ptr, MMHelloMessage.ByteSize() + 8) == k_EGCResultOK
		&& I::SteamGameCoordinator->SendMessage_CSGO(rank_MsgType, rank_ptr, RankMessage.ByteSize() + 8) == k_EGCResultOK;

	free(clienthello_ptr);
	free(mmhello_ptr);
	free(rank_ptr);

	return result;
}

typedef bool(__cdecl* GoesThroughSmoke)(Vector, Vector);
GoesThroughSmoke GoesThroughSmokeFunction = (GoesThroughSmoke)U::FindPattern(xs("client_panorama.dll"), xs("55 8B EC 83 EC 08 8B 15 ?? ?? ?? ?? 0F 57 C0"));

bool U::IsInSmoke(Vector vEndPos)
{
	if (GoesThroughSmokeFunction(G::LocalPlayer->GetEyePosition(), vEndPos))
		return true;

	return false;
}

void U::SetupHooks()
{
	SkinChanger::initializeKits(); // fix this and update
	ItemIndexInitiolize(); // item index parser

	// ----------------------------------------------------------------------------------------------------------------------------------------
	vmt::vguipanel.Initiosise(reinterpret_cast<DWORD**>(I::VPanel));
	oPaintTraverse = vmt::vguipanel.HookFunction<PaintTraverseFn>(hook_index_paint_traverse, Hooks::PaintTraverse);
	// ----------------------------------------------------------------------------------------------------------------------------------------
	vmt::client_mode.Initiosise(reinterpret_cast<DWORD**>(I::ClientMode));
	oOverrideView = vmt::client_mode.HookFunction<OverrideViewFn>(hook_index_override_view, Hooks::OverrideView);
	oCreateMove = vmt::client_mode.HookFunction<CreateMoveFn>(hook_index_create_move, Hooks::CreateMove);
	oViewModelView = vmt::client_mode.HookFunction<ViewModelViewFn>(hook_index_model_fov, Hooks::ViewModelView);
	oDoPostscreenEffects = vmt::client_mode.HookFunction<DoPostscreenEffectsFn>(hook_index_do_postscreen_effects, Hooks::DoPostscreenEffects);
	// ----------------------------------------------------------------------------------------------------------------------------------------
	vmt::client.Initiosise(reinterpret_cast<DWORD**>(I::Client));
	oFrameStageNotify = vmt::client.HookFunction<FrameStageNotifyFn>(hook_index_frame_stage_notify, Hooks::FrameStageNotify);
	oDispatchUserMessage = vmt::client.HookFunction<DispatchUserMessageFn>(hook_index_dispatch_user_message, Hooks::DispatchUserMessage);
	// ----------------------------------------------------------------------------------------------------------------------------------------
	vmt::model_render.Initiosise(reinterpret_cast<DWORD**>(I::ModelRender));
	oDrawModelExecute = vmt::model_render.HookFunction<DrawModelExecuteFn>(hook_index_draw_model_execute, Hooks::DrawModelExecute);
	// ----------------------------------------------------------------------------------------------------------------------------------------
	vmt::surface.Initiosise(reinterpret_cast<DWORD**>(I::Surface));
	oLockCursor = vmt::surface.HookFunction<LockCursorFn>(hook_index_lock_cursor, Hooks::LockCursor);
	oOnScreenSizeChanged = vmt::surface.HookFunction<OnScreenSizeChangedFn>(hook_index_on_screen_size_changed, Hooks::OnScreenSizeChanged);
	// ----------------------------------------------------------------------------------------------------------------------------------------
	vmt::sound_engine.Initiosise(reinterpret_cast<DWORD**>(I::EngineSound));
	oEmitSound = vmt::sound_engine.HookFunction<EmitSoundFn>(hook_index_emit_sound, Hooks::EmitSound);
	// ----------------------------------------------------------------------------------------------------------------------------------------
	//vmt::bsp_query.Initiosise(reinterpret_cast<DWORD**>(I::Engine->GetBSPTreeQuery()));
	//oListLeavesInBox = vmt::bsp_query.HookFunction<ListLeavesInBox>(hook_index_list_leaves, Hooks::ListLeavesInBox);
	// ----------------------------------------------------------------------------------------------------------------------------------------
	vmt::render_view.Initiosise(reinterpret_cast<DWORD**>(I::RenderView));
	oSceneEnd = vmt::render_view.HookFunction<SceneEndFn>(hook_index_scene_end, Hooks::SceneEnd);
	// ----------------------------------------------------------------------------------------------------------------------------------------
	vmt::model_cache.Initiosise(reinterpret_cast<DWORD**>(I::ModelCache));
	oFindMdl = vmt::model_cache.HookFunction<FindMdlFn>(hook_index_model_cache, Hooks::FindMdl);
	// ----------------------------------------------------------------------------------------------------------------------------------------
	vmt::steam_game_coordinator.Initiosise(reinterpret_cast<DWORD**>(I::SteamGameCoordinator));
	oSendNetMsg = vmt::steam_game_coordinator.HookFunction<SendNetMsgFn>(hook_index_send_net_msg, Hooks::SendNetMsg);
	oRetrieveMessage = vmt::steam_game_coordinator.HookFunction<RetrieveMessageFn>(hook_index_retrieve_message, Hooks::RetrieveMessage);
	// ----------------------------------------------------------------------------------------------------------------------------------------
	vmt::d3d9.Initiosise(reinterpret_cast<DWORD**>(offsets.d3d9Device));
	oReset = vmt::d3d9.HookFunction<ResetFn>(hook_index_reset, Hooks::Reset);
	oEndScene = vmt::d3d9.HookFunction<EndSceneFn>(hook_index_end_scene, Hooks::EndScene);
	// ----------------------------------------------------------------------------------------------------------------------------------------
	vmt::sv_cheats.Initiosise(reinterpret_cast<DWORD**>(I::Cvar->FindVar(rXor("sv_cheats"))));
	oSvCheats = vmt::sv_cheats.HookFunction<SvCheatsFn>(hook_index_sv_cheats, Hooks::SvCheats);
	// ----------------------------------------------------------------------------------------------------------------------------------------
}

void U::SetupOffsets()
{
	U::NetVars->Initialize();
	Offsets::GrabOffsets();
}

void U::SetupOptions()
{
	Listener::Get();
	NetvarHook();
}

void U::Setup()
{
	memset(Opts.Menu.Loads, true, LOAD_SETTINGS_MAX);

	WRITE_TO_CONSOLE("--------------------------");
	WRITE_TO_CONSOLE("start U::Setup");

	/*MD_Manager.ManagerInit(GetUrlData("/CloudManager.php?action=get_models"));
	MD_Manager.GetAllModelsSize();
	MD_Manager.InitStructs();
	MD_Manager.GetLocalPath();
	MD_Manager.CreateAllFolders();
	MD_Manager.DistributeByType();
	MD_Manager.FinishParseRequest();*/

	WRITE_TO_CONSOLE("\tstart setup interfaces");
	U::SetupInterfaces();
	WRITE_TO_CONSOLE("\tfinish setup interfaces");
	WRITE_TO_CONSOLE("\tstart setup offsets");
	U::SetupOffsets();
	WRITE_TO_CONSOLE("\tfinish setup offsets");
	WRITE_TO_CONSOLE("\tstart setup fonts");
	D::SetupFonts();
	WRITE_TO_CONSOLE("\tfinish setup fonts");
	WRITE_TO_CONSOLE("\tstart setup hooks");
	U::SetupHooks();
	WRITE_TO_CONSOLE("\tfinish setup hooks");
	WRITE_TO_CONSOLE("\tstart setup options");
	U::SetupOptions();
	WRITE_TO_CONSOLE("\tfinish setup options");

	ExpLua.Initiolize();

	WRITE_TO_CONSOLE("end U::Setup");
}

int U::GetCurrentMap()
{
	const char* map_group = I::Engine->GetMapGroupName();

	if (map_group == "mg_de_mirage")
		return MP_MIRAGE;
	if (map_group == "mg_de_inferno")
		return MP_INFERNO;
	if (map_group == "mg_de_overpass")
		return MP_OVERPASS;
	if (map_group == "mg_de_vertigo")
		return MP_VERTIGO;
	if (map_group == "mg_de_studio")
		return MP_STUDIO;
	if (map_group == "mg_de_nuke")
		return MP_NUKE;
	if (map_group == "mg_de_train")
		return MP_TRAIN;
	if (map_group == "mg_de_dust2")
		return MP_DUST2;
	if (map_group == "mg_de_cache")
		return MP_CACHE;
	if (map_group == "mg_de_breach")
		return MP_BREACH;
	if (map_group == "mg_cs_agency")
		return MP_AGENCY;
	if (map_group == "mg_cs_office")
		return MP_OFFICE;

	return MP_UNKNOW;
}

std::string U::GetMapNameById(int id)
{
	switch (id)
	{
	case MP_MIRAGE: return "Mirage";
	case MP_INFERNO: return "Inferno";
	case MP_OVERPASS: return "Overpass";
	case MP_VERTIGO: return "Vertigo";
	case MP_STUDIO: return "Studio";
	case MP_NUKE: return "Nuke";
	case MP_TRAIN: return "Train";
	case MP_DUST2: return "Dust2";
	case MP_CACHE: return "Cache";
	case MP_BREACH: return "Breach";
	case MP_AGENCY: return "Agency";
	case MP_OFFICE: return "Office";
	default: return "Unknow";
	}
}

struct hud_weapons_t {
	std::int32_t* get_weapon_count() {
		return reinterpret_cast<std::int32_t*>(std::uintptr_t(this) + 0x80);
	}
};
template<class T>
static T* Find_Hud_Element(const char* name) {
	static auto pThis = *reinterpret_cast<DWORD**>(U::FindPattern("client_panorama.dll", "B9 ? ? ? ? E8 ? ? ? ? 8B 5D 08") + 1);
	static auto find_hud_element = reinterpret_cast<DWORD(__thiscall*)(void*, const char*)>(U::FindPattern("client_panorama.dll", "55 8B EC 53 8B 5D 08 56 57 8B F9 33 F6 39 77 28"));
	return (T*)find_hud_element(pThis, name);
}

void U::ForceFullUpdate()
{
	I::ClientState->ForceFullUpdate();

	Sleep(50);

	static auto clear_fn = reinterpret_cast<int(__thiscall*)(void*, int)>(U::FindPattern(("client_panorama.dll"), "55 8B EC 51 53 56 8B 75 08 8B D9 57 6B FE 2C 89 5D FC"));
	auto dwHudWeaponSelection = Find_Hud_Element<uintptr_t*>("CCSGO_HudWeaponSelection");
	if (dwHudWeaponSelection && clear_fn) {
		auto pHudWeapons = (int*)(uintptr_t(dwHudWeaponSelection) - 0x20);
		if (pHudWeapons && (void*)(uintptr_t(dwHudWeaponSelection) - 0xA0)) {
			for (auto i = 0; i < *pHudWeapons; i++) i = clear_fn((void*)(uintptr_t(dwHudWeaponSelection) - 0xA0), i);
			*pHudWeapons = 0;
		}
	}
}

CNetVarManager* U::NetVars = new CNetVarManager;