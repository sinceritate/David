#pragma once

#include "Cheat.h"
#include "Lua/ExpLua/ExpLua.h"
#include "Lua/ExpLua/LuaEventManager.h"

class LuaManager
{
public:
	
	void SetUpSettings();
	void UpdateLuaList();

	void LoadLua(std::string lua_name);
	void ReloadLua(std::string lua_name);
	void UnloadLua(std::string lua_name);
	void UnloadAllScripts();

	std::string path_to_folder;

}; extern LuaManager LManager;