#pragma once

#define PI 3.141592f

#define DEG_TO_RAD( x ) PI / 180.f * x
#define RAD_TO_DEG( x ) 180.f / PI * x

namespace new_math
{
	QAngle angle_to_point(Vector point_pos);
	QAngle angle_poin_point(Vector lpos, Vector epos);

	void sin_cos(float ang, float* _sin, float* _cos);
	Vector rotate_point(QAngle ang, Vector point_pos);

	float FastSQRT(float float_for_fast);
}