#include "Cheat.h"

strOptions Opts;