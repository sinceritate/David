#pragma once

namespace Materials
{
	extern IMaterial* materialFlat;
	extern IMaterial* materialTexture;
	extern IMaterial* materialWireFrame;
	extern IMaterial* materialMetalic; 
	extern IMaterial* materialAnimated;
	extern IMaterial* materialPlatinum;
	extern IMaterial* materialGlass;
	extern IMaterial* materialCrystal;
	extern IMaterial* materialChrome;
	extern IMaterial* materialSilver;
	extern IMaterial* materialGold;
	extern IMaterial* materialPlastic;
	extern IMaterial* materialGlowOverlay;
	extern IMaterial* materialdog_tags_lightray;
	extern IMaterial* materialdog_dogtags_outline;
	extern IMaterial* materialdog_dreamhack_star_blur;
	extern IMaterial* materialdog_crystal_blue;
	extern IMaterial* materialdog_fishing_net01;
	extern IMaterial* materialdog_contributor_charset_color;
	extern IMaterial* materialdog_urban_tree03_branches;
	extern IMaterial* materialdog_speech_info;
	extern IMaterial* materialdog_mp3_detail;

	extern void InitializationMaterials();
	extern void DeleteMaterials();
}