#pragma once

#include "Cheat.h"

COffsets offsets;

void Offsets::GrabOffsets()
{
	offsets.m_bDormant = 0xED;
	offsets.m_iHealth = U::NetVars->GetOffset(rXor("DT_BasePlayer"), rXor("m_iHealth"));
	offsets.m_iTeamNum = U::NetVars->GetOffset(rXor("DT_BasePlayer"), rXor("m_iTeamNum"));
	offsets.m_ArmorValue = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_ArmorValue"));
	offsets.m_bHasHelmet = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_bHasHelmet"));
	offsets.m_bGunGameImmunity = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_bGunGameImmunity"));
	offsets.m_lifeState = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_lifeState"));
	offsets.m_fFlags = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_fFlags"));
	offsets.m_nTickBase = U::NetVars->GetOffset(rXor("DT_BasePlayer"), rXor("m_nTickBase"));
	offsets.m_angEyeAngles = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_angEyeAngles"));
	offsets.m_flFlashDuration = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_flFlashDuration"));
	offsets.m_viewPunchAngle = U::NetVars->GetOffset(rXor("DT_BasePlayer"), rXor("m_viewPunchAngle"));
	offsets.m_aimPunchAngle = U::NetVars->GetOffset(rXor("DT_BasePlayer"), rXor("m_aimPunchAngle"));
	offsets.m_vecOrigin = U::NetVars->GetOffset(rXor("DT_BasePlayer"), rXor("m_vecOrigin"));
	offsets.m_vecViewOffset = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_vecViewOffset[0]"));
	offsets.m_vecVelocity = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_vecVelocity[0]"));
	offsets.m_hActiveWeapon = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_hActiveWeapon"));
	offsets.m_Collision = U::NetVars->GetOffset(rXor("DT_BasePlayer"), rXor("m_Collision"));
	offsets.m_CollisionGroup = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_CollisionGroup")) - 0x30;
	offsets.m_iShotsFired = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_iShotsFired"));
	offsets.m_nMoveType = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_nRenderMode")) + 0x1;
	offsets.m_nHitboxSet = U::NetVars->GetOffset(rXor("DT_BasePlayer"), rXor("m_nHitborXoret"));
	offsets.m_flC4Blow = U::NetVars->GetOffset(rXor("DT_PlantedC4"), rXor("m_flC4Blow"));
	offsets.m_bBombTicking = U::NetVars->GetOffset(rXor("DT_PlantedC4"), rXor("m_bBombTicking"));
	offsets.m_flTimerLength = U::NetVars->GetOffset(rXor("DT_PlantedC4"), rXor("m_flTimerLength"));
	offsets.m_flDefuseLength = U::NetVars->GetOffset(rXor("DT_PlantedC4"), rXor("m_flDefuseLength"));
	offsets.m_flDefuseCountDown = U::NetVars->GetOffset(rXor("DT_PlantedC4"), rXor("m_flDefuseCountDown"));
	offsets.m_hMyWearables = U::NetVars->GetOffset(rXor("DT_BaseCombatCharacter"), rXor("m_hMyWearables"));
	offsets.m_flNextPrimaryAttack = U::NetVars->GetOffset(rXor("DT_BaseCombatWeapon"), rXor("m_flNextPrimaryAttack"));
	offsets.m_nFallbackPaintKit = U::NetVars->GetOffset(rXor("DT_BaseAttributableItem"), rXor("m_nFallbackPaintKit"));
	offsets.m_nFallbackSeed = U::NetVars->GetOffset(rXor("DT_BaseAttributableItem"), rXor("m_nFallbackSeed"));
	offsets.m_flFallbackWear = U::NetVars->GetOffset(rXor("DT_BaseAttributableItem"), rXor("m_flFallbackWear"));
	offsets.m_nFallbackStatTrak = U::NetVars->GetOffset(rXor("DT_BaseAttributableItem"), rXor("m_nFallbackStatTrak"));
	offsets.m_iItemIDHigh = U::NetVars->GetOffset(rXor("DT_BaseAttributableItem"), rXor("m_iItemIDHigh"));
	offsets.m_iItemIDLow = U::NetVars->GetOffset(rXor("DT_BaseAttributableItem"), rXor("m_iItemIDLow"));
	offsets.m_iAccountID = U::NetVars->GetOffset(rXor("DT_BaseAttributableItem"), rXor("m_iAccountID"));
	offsets.m_iAccount = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_iAccount"));
	offsets.m_iEntityQuality = U::NetVars->GetOffset(rXor("DT_BaseAttributableItem"), rXor("m_iEntityQuality"));
	offsets.m_iClip1 = U::NetVars->GetOffset(rXor("DT_BaseCombatWeapon"), rXor("m_iClip1"));
	offsets.m_OriginalOwnerXuidLow = U::NetVars->GetOffset(rXor("DT_BaseAttributableItem"), rXor("m_OriginalOwnerXuidLow"));
	offsets.m_OriginalOwnerXuidHigh = U::NetVars->GetOffset(rXor("DT_BaseAttributableItem"), rXor("m_OriginalOwnerXuidHigh"));
	offsets.m_iItemDefinitionIndex = U::NetVars->GetOffset(rXor("DT_BaseCombatWeapon"), rXor("m_iItemDefinitionIndex"));
	offsets.m_hObserverTarget = U::NetVars->GetOffset(rXor("DT_BasePlayer"), rXor("m_hObserverTarget"));
	offsets.m_bIsDefusing = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_bIsDefusing"));
	offsets.m_bSpotted = U::NetVars->GetOffset(rXor("DT_BaseEntity"), rXor("m_bSpotted"));
	offsets.m_flFlashMaxAlpha = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_flFlashMaxAlpha"));
	offsets.m_flLowerBodyYawTarget = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_flLowerBodyYawTarget"));
	offsets.m_angEyeAnglesX = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_angEyeAngles[0]"));
	offsets.m_angEyeAnglesY = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_angEyeAngles[1]"));
	offsets.m_vecMaxs = U::NetVars->GetOffset(rXor("DT_BasePlayer"), rXor("m_vecMarXor"));
	offsets.m_vecMins = U::NetVars->GetOffset(rXor("DT_BasePlayer"), rXor("m_vecMins"));
	offsets.m_iViewModelIndex = U::NetVars->GetOffset(rXor("DT_BaseCombatWeapon"), rXor("m_iViewModelIndex"));
	offsets.m_flPoseParameter = U::NetVars->GetOffset(("DT_CSPlayer"), rXor("m_flPoseParameter"));
	offsets.m_bClientSideAnimation = U::NetVars->GetOffset(rXor("DT_BaseAnimating"), rXor("m_bClientSideAnimation"));
	offsets.m_flSimulationTime = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_flSimulationTime"));
	offsets.m_bIsScoped = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_bIsScoped"));
	offsets.m_nModelIndex = U::NetVars->GetOffset(rXor("DT_BasePlayer"), rXor("m_nModelIndex"));
	offsets.m_hWeaponWorldModel = U::NetVars->GetOffset(rXor("DT_BaseCombatWeapon"), rXor("m_hWeaponWorldModel"));
	offsets.m_szCustomName = U::NetVars->GetOffset(rXor("DT_BaseAttributableItem"), rXor("m_szCustomName"));
	offsets.m_ragPos = U::NetVars->GetOffset(rXor("DT_Ragdoll"), rXor("m_ragPos"));
	offsets.m_hMyWeapons = U::NetVars->GetOffset(rXor("DT_BasePlayer"), rXor("m_hActiveWeapon")) - 0x100;
	offsets.m_hOwner = U::NetVars->GetOffset(rXor("DT_BaseViewModel"), rXor("m_hOwner"));
	offsets.deadflag = U::NetVars->GetOffset(rXor("DT_BasePlayer"), rXor("deadflag"));
	offsets.m_nSurvivalTeam = U::NetVars->GetOffset(rXor("DT_CSPlayer"), rXor("m_nSurvivalTeam"));
	offsets.m_hViewModel = U::NetVars->GetOffset(rXor("DT_BasePlayer"), rXor("m_hViewModel[0]"));
	
	offsets.CSWpnData = U::FindPattern(rXor("client_panorama.dll"), rXor("8B 81 ? ? ? ? 85 C0 0F 84 ? ? ? ? C3"));
	offsets.d3d9Device = **(DWORD**)(U::FindPattern(rXor("shaderapidx9.dll"), rXor("A1 ?? ?? ?? ?? 50 8B 08 FF 51 0C")) + 0x1);
	offsets.GlowManager = *(DWORD *)(U::FindPattern(rXor("client_panorama.dll"), rXor("0F 11 05 ?? ?? ?? ?? 83 C8 01 C7 05 ?? ?? ?? ?? 00 00 00 00")) + 0x3);
	offsets.LoadFromBufferEx = U::FindPattern(rXor("client_panorama.dll"), rXor("02 7E 4E")) - 0x3F;
	offsets.InitKeyValuesEx = U::FindPattern(rXor("client_panorama.dll"), rXor("55 8B EC 51 33 C0 C7 45"));
	offsets.ServerRankRevealAllEx = U::FindPattern(rXor("client_panorama.dll"), rXor("55 8B EC 8B 0D ? ? ? ? 85 C9 75 ? A1 ? ? ? ? 68 ? ? ? ? 8B 08 8B 01 FF 50 ? 85 C0 74 ? 8B C8 E8 ? ? ? ? 8B C8 EB ? 33 C9 89 0D ? ? ? ? 8B 45 ? FF 70 ? E8 ? ? ? ? B0 ? 5D"));
	offsets.IsReadyEx = U::FindPattern(rXor("client_panorama.dll"), rXor("55 8B EC 83 E4 F8 83 EC 08 56 8B 35 ? ? ? ? 57 8B 8E ? ? ? ?"));
	offsets.GoesThroughSmoke = U::FindPattern(rXor("client_panorama.dll"), rXor("55 8B EC 83 EC 08 8B 15 ? ? ? ? 0F"));
	offsets.FullUpdate = U::FindPattern(rXor("engine.dll"), rXor("A1 ? ? ? ? B9 ? ? ? ? 56 FF 50 14 8B 34 85"));
	//offsets.m_pChatElement = U::FindPattern(rXor("client_panorama.dll"), rXor("E8 ? ? ? ? 8B 4F ? 85 C9 74 06 51")) + 7; // Search for LevelInit
}