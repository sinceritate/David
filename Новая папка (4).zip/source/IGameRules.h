#pragma once

#define NETVAR(type, name, table, netvar)                           \
    type& name##() const {                                          \
        static int _##name = U::NetVars->GetOffset(table, netvar);     \
        return *(type*)((uintptr_t)this + _##name);                 \
    }

class CGameRules {
public:

	int& m_iMatchStats_PlayersAlive_T() const {
		static int _m_iMatchStats_PlayersAlive_T = U::NetVars->GetOffset("DT_CSGameRulesProxy", "m_iMatchStats_PlayersAlive_T");
        return *(int*)((uintptr_t)this + _m_iMatchStats_PlayersAlive_T);
	}

	NETVAR(int, m_iMatchStats_PlayersAlive_CT, "DT_CSGameRulesProxy", "m_iMatchStats_PlayersAlive_CT");
	NETVAR(int, m_iRoundTime, "DT_CSGameRulesProxy", "m_iRoundTime");
	NETVAR(bool, m_bFreezePeriod, "DT_CSGameRulesProxy", "m_bBombDropped");
	NETVAR(bool, m_bIsValveDS, "DT_CSGameRulesProxy", "m_bIsValveDS");
	NETVAR(bool, m_bBombDropped, "DT_CSGameRulesProxy", "m_bBombDropped");
	NETVAR(bool, m_bBombPlanted, "DT_CSGameRulesProxy", "m_bBombPlanted");
	NETVAR(float, m_flSurvivalStartTime, "DT_CSGameRulesProxy", "m_flSurvivalStartTime");
};