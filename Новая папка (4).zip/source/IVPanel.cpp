#include "SDK.h"

const char* IVPanel::GetName(unsigned int iIndex)
{
	typedef const char*(__thiscall* Fn)(void*, unsigned int);
	return U::GetVFunc< Fn >(this, 36)(this, iIndex);
}

void IVPanel::SetMouseInputEnabled(unsigned int iPanel, bool bState)
{
	(U::GetVFunc<void(__thiscall *)(PVOID, int, bool)>(this, 32))(this, iPanel, bState);
}