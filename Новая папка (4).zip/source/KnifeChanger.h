#pragma once
#include "Cheat.h"

extern void KnifeChanger(CBaseCombatWeapon* pWeapon);