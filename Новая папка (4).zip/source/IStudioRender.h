#pragma once

class IStudioRender;
