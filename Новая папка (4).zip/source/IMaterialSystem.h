#pragma once

class IMaterialSystem
{
public:
	IMaterial* CreateMaterial(bool flat, bool ignorez, bool wireframed);
	IMaterial* FindMaterial(char const* pMaterialName, const char* pTextureGroupName, bool complain = true, const char* pComplainPrefix = NULL);

	unsigned short FirstMaterial()
	{
		typedef unsigned short(__thiscall* FirstMaterialFn)(void*);
		return U::GetVFunc <FirstMaterialFn>(this, 86)(this);
	}

	unsigned short NextMaterial(unsigned short h)
	{
		typedef unsigned short(__thiscall* NextMaterialFn)(void*, unsigned short);
		return U::GetVFunc <NextMaterialFn>(this, 87)(this, h);
	}

	unsigned short InvalidMaterial()
	{
		typedef unsigned short(__thiscall* InvalidMaterialFn)(void*);
		return U::GetVFunc <InvalidMaterialFn>(this, 88)(this);
	}

	IMaterial* GetMaterial(unsigned short h)
	{
		typedef IMaterial*(__thiscall* GetMaterialFn)(void*, unsigned short);
		return U::GetVFunc <GetMaterialFn>(this, 89)(this, h);
	}
};
