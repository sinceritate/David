#include "BackDrop.h"

std::vector <Point> points;

void BackDrop::BackDropAndBackGround()
{
	if (Opts.Menu.Opened)
	{
		if (Opts.Visuals.Other.BackGround)
		{
			I::Surface->DrawSetColor(Opts.Colors.Misc.BackGround);
			I::Surface->DrawFilledRect(0, 0, G::ScreenWidth, G::ScreenHeight);
		}
		
		if (Opts.Visuals.Other.BackDrop)
		{
			if (points.size() < Opts.Visuals.Other.BackDropMaxPoints)
			{
				for (int i = points.size(); i < Opts.Visuals.Other.BackDropMaxPoints; ++i)
				{
					int x = 0, y = 0;
					int sp_x = 0, sp_y = 0;

					switch (rand() % 4)
					{
					case 0:
						x = rand() % G::ScreenWidth;
						sp_x = (rand() % Opts.Visuals.Other.BackDropMaxSpeed + 4) - Opts.Visuals.Other.BackDropMaxSpeed;
						sp_y = (rand() % Opts.Visuals.Other.BackDropMaxSpeed) + 1;
						break;
					case 1:
						y = rand() % G::ScreenHeight;
						sp_x = (rand() % Opts.Visuals.Other.BackDropMaxSpeed) + 1;
						sp_y = (rand() % Opts.Visuals.Other.BackDropMaxSpeed + 4) - Opts.Visuals.Other.BackDropMaxSpeed;
						break;
					case 2:
						x = rand() % G::ScreenWidth;
						y = G::ScreenHeight;
						sp_x = (rand() % Opts.Visuals.Other.BackDropMaxSpeed + 4) - Opts.Visuals.Other.BackDropMaxSpeed;
						sp_y = (rand() % Opts.Visuals.Other.BackDropMaxSpeed) - Opts.Visuals.Other.BackDropMaxSpeed;
						break;
					case 3:
						x = G::ScreenWidth;
						y = rand() % G::ScreenHeight;
						sp_x = (rand() % Opts.Visuals.Other.BackDropMaxSpeed) - Opts.Visuals.Other.BackDropMaxSpeed;
						sp_y = (rand() % Opts.Visuals.Other.BackDropMaxSpeed + 4) - Opts.Visuals.Other.BackDropMaxSpeed;
						break;
					}
					
					points.push_back(Point(x, y, sp_x, sp_y));
				}
			}

			I::Surface->DrawSetColor(Opts.Colors.Misc.BackDropSquareLine);

			for (int i = 0; i < Opts.Visuals.Other.BackDropMaxPoints; ++i)
			{
				for (int j = i; j < Opts.Visuals.Other.BackDropMaxPoints; ++j)
				{
					if (points[i].DistTo(points[j]) < Opts.Visuals.Other.BackDropMaxDist)
					{
						I::Surface->DrawLine(points[i].x, points[i].y, points[j].x, points[j].y);
					}
				}
			}

			for (int i = 0; i < Opts.Visuals.Other.BackDropMaxPoints; ++i)
			{
				I::Surface->DrawSetColor(Opts.Colors.Misc.BackDropSquare);
				I::Surface->DrawFilledRect(points[i].x - Opts.Visuals.Other.BackDropSquareSize, points[i].y - Opts.Visuals.Other.BackDropSquareSize, points[i].x + Opts.Visuals.Other.BackDropSquareSize, points[i].y + Opts.Visuals.Other.BackDropSquareSize);
				I::Surface->DrawSetColor(Opts.Colors.Misc.BackDropSquareOutLine);
				I::Surface->DrawOutlinedRect(points[i].x - (Opts.Visuals.Other.BackDropSquareSize + 1), points[i].y - (Opts.Visuals.Other.BackDropSquareSize + 1), points[i].x + Opts.Visuals.Other.BackDropSquareSize + 1, points[i].y + Opts.Visuals.Other.BackDropSquareSize + 1);
			}

			for (int i = 0; i < points.size(); ++i)
			{
				if (points[i].x > G::ScreenWidth || points[i].x < 0)
					points.erase(points.begin() + i);
				else if (points[i].y > G::ScreenHeight || points[i].y < 0)
					points.erase(points.begin() + i);
				else if (points.size() > Opts.Visuals.Other.BackDropMaxPoints)
					points.erase(points.begin() + i);
				else
				{
					points[i].x += points[i].speed_x;
					points[i].y += points[i].speed_y;
				}
			}
		}
	}
	else if (!Opts.Visuals.Other.BackDrop)
	{
		points.clear();
		return;
	}
}