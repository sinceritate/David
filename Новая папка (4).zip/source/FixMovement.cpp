#include "Cheat.h"

float FixMovement::OldForward = 0.f;
float FixMovement::OldSideMove = 0.f;

QAngle FixMovement::OldAngle = QAngle(0.f, 0.f, 0.f);

void FixMovement::Start()
{
	FixMovement::OldAngle = G::UserCmd->viewangles;
	FixMovement::OldForward = G::UserCmd->forwardmove;
	FixMovement::OldSideMove = G::UserCmd->sidemove;
}

void FixMovement::End()
{
	if (G::UserCmd->buttons & IN_DUCK && G::UserCmd->forwardmove == 0.f && G::UserCmd->sidemove == 0.f)
		return;

	float yaw_delta = G::UserCmd->viewangles.y - FixMovement::OldAngle.y;
	float f1;
	float f2;

	if (FixMovement::OldAngle.y < 0.f)
	{
		f1 = 360.0f + FixMovement::OldAngle.y;
	}
	else
	{
		f1 = FixMovement::OldAngle.y;
	}

	if (G::UserCmd->viewangles.y < 0.0f)
	{
		f2 = 360.0f + G::UserCmd->viewangles.y;
	}
	else
	{
		f2 = G::UserCmd->viewangles.y;
	}

	if (f2 < f1)
	{
		yaw_delta = abs(f2 - f1);
	}
	else
	{
		yaw_delta = 360.0f - abs(f1 - f2);
	}

	yaw_delta = 360.0f - yaw_delta;

	G::UserCmd->forwardmove = cos(DEG2RAD(yaw_delta)) * FixMovement::OldForward + cos(DEG2RAD(yaw_delta + 90.f)) * FixMovement::OldSideMove;
	G::UserCmd->sidemove = sin(DEG2RAD(yaw_delta)) * FixMovement::OldForward + sin(DEG2RAD(yaw_delta + 90.f)) * FixMovement::OldSideMove;
}