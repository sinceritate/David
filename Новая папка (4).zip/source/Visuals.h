#pragma once

#include <string>
#include <list>
#include <deque>

typedef std::string;

struct Player_t 
{
	bool Hearable = false;
};

struct Bomb_t 
{
	bool Defusing = false;
	bool Planted = false;
};

extern Player_t pPlayer[65];
extern Bomb_t	pBomb;

namespace ESP
{
	struct DrawData
	{
		DrawData(int h, int w, int l, int u, int r, int d)
		{
			Height = h;
			Width = w;
			Left = l;
			Up = u;
			Right = r;
			Down = d;
			rec_type = 1;
		}
		DrawData(int l, int u, int r, int d)
		{
			Left = l;
			Up = u;
			Right = r;
			Down = d;
			rec_type = 2;
		}
		const DrawData Outline()
		{
			if (rec_type == 1)
			{
				return DrawData(Height, Width, Left - 1, Up - 1, Right + 1, Down + 1);
			}				
			else if (rec_type == 2)
			{
				return DrawData(Left - 1, Up - 1, Right + 1, Down + 1);
			}				
		}
		const DrawData Inline()
		{
			if (rec_type == 1)
			{
				return DrawData(Height, Width, Left + 1, Up + 1, Right - 1, Down - 1);
			}			
			else if (rec_type == 2)
			{
				return DrawData(Left + 1, Up + 1, Right - 1, Down - 1);
			}			
		}

		int Height, Width, Left, Up, Right, Down, rec_type;
	};

	namespace Box
	{
		extern void Default(RECT Data, Color pColor);
		extern void Corner(RECT Data, Color pColor);
		extern void Bracket(RECT Data, Color pColor);
		extern void InvertedBracket(RECT Data, Color pColor);
		extern void Filled(RECT Data, Color pColor);
	}

	namespace Player
	{
		extern void OutOfScreen(CBaseEntity* Entity);
		extern void Skeleton(CBaseEntity* Entity);
		extern void Draw(int entity);
	}

	namespace World
	{
		extern void Draw(int ID);
	}

	namespace Misc
	{
		namespace HitMarker
		{
			struct CLog
			{
				CLog(int HP, int arm, float t, Vector b)
				{
					DamageHP = HP;
					DamageArm = arm;
					Time = t;
					Bone = b;
				}

				int DamageHP;
				int DamageArm;
				float Time;
				Vector Bone;
			};

			extern std::deque<CLog> Log;
			extern void Add(CLog HitLog);
			extern void Draw();
		}

		namespace BulletTracer
		{
			struct CLog
			{
				CLog(Vector Start, Vector End, float Time)
				{
					this->Start = Start;
					this->End = End;
					this->Time = Time;
				}

				Vector Start, End;
				float Time;
			};

			extern std::deque< CLog > Log;
			extern void Add(CLog NewLog);
			extern void Draw();
		}

		namespace XHair
		{
			extern void MLG(int Size, Vector Pos, Color pColor, bool Spread = false);
		}

		namespace GrenadePrediction
		{
			extern void Draw();
		}

		namespace SoundESP
		{
			extern CSoundEsp Sound;
		}
	}
	extern void Draw();
}