#include "Cheat.h"
#include "override.h"

void entity_resolver::override_entity(CBaseEntity* entity)
{
	auto animstate = entity->GetAnimState();
	entity->SetEyeAngles(M::QAngleToVector(M::NormalizeAngle(entity->GetEyeAngles() + QAngle(0, 180, 0))));
	animstate->m_flGoalFeetYaw = M::NormalizeYaw(animstate->m_flGoalFeetYaw + 180);
}

float AngleNormalize(float angle)
{
	angle = fmodf(angle, 360.0f);
	if (angle > 180)
	{
		angle -= 360;
	}
	if (angle < -180)
	{
		angle += 360;
	}
	return angle;
}

void entity_resolver::resolver(CBaseEntity* entity)
{
	auto animstate = entity->GetAnimState();
	auto entity_angle = entity->GetEyeAngles();

	
	switch ((G::shots_fired[entity->index] - G::shots_hit[entity->index]) % 6)
	{
		case 1:
		{
			entity_angle.y += 30.f;
			break;
		}
		case 2:
		{
			entity_angle.y -= 30.f;
			break;
		}
		case 3:
		{
			entity_angle.y += 60.f;
			break;
		}
		case 4:
		{
			entity_angle.y -= 60.f;
			break;
		}
		case 5:
		{
			entity_angle.y = entity->GetLBY();
			break;
		}

		default: break;
	}

	entity_angle.NormalizeAngle();
	animstate->m_flGoalFeetYaw = entity_angle.y;
	entity->SetEyeAngles(Vector(entity_angle.x, entity_angle.y, 0));
}

entity_resolver Resolver;