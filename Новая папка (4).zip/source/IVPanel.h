#pragma once

class IVPanel
{
public:
	const char* GetName(unsigned int iPanel);
	void SetMouseInputEnabled(unsigned int iPanel, bool bState);
};
