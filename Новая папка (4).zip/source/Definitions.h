#pragma once

#include "Color.h"
#include "Vectors.h"
#include "XorStr.h"

#include <Windows.h>
#include <deque>

typedef __int16 int16;
typedef unsigned __int16 uint16;
typedef __int32 int32;
typedef unsigned __int32 uint32;
typedef __int64 int64;
typedef unsigned __int64 uint64;

typedef unsigned char uint8;
typedef float matrix3x4[3][4];
struct bf_read;

typedef intptr_t intp;
typedef uintptr_t uintp;

#define to_str std::to_string
#define _str std::string

#define asize ARRAYSIZE

inline float BitsToFloat(uint32 i)
{
	union Convertor_t
	{
		float f;
		unsigned long ul;
	} tmp;
	tmp.ul = i;
	return tmp.f;
}

#define TEAM_TT 2
#define TEAM_CT 3

#define PlayerVisibleMask (CONTENTS_HITBOX | CONTENTS_MONSTER | CONTENTS_DEBRIS | CONTENTS_MOVEABLE | CONTENTS_SOLID | CONTENTS_WINDOW | CONTENTS_GRATE)

#define DRIVERS_ARRAY 2048

#define INVALID_EHANDLE_INDEX 0xFFFFFFFF

#define FLOAT32_NAN_BITS     (uint32)0x7FC00000	// not a Number!
#define FLOAT32_NAN          BitsToFloat( FLOAT32_NAN_BITS )

#define VEC_T_NAN FLOAT32_NAN

#define DECL_ALIGN(x)			__declspec( align( x ) )

#define ALIGN4 DECL_ALIGN(4)
#define ALIGN8 DECL_ALIGN(8)
#define ALIGN16 DECL_ALIGN(16)
#define ALIGN32 DECL_ALIGN(32)
#define ALIGN128 DECL_ALIGN(128)

//extern float( *pfSqrt )( float x );

//#define FastSqrt(x)			(*pfSqrt)(x)

#define MIN_ZERO_D    0.00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001
#define MIN_ZERO_F    0.000000000000000000000000000000000000000000001f

#define M_PI		3.1415926535897932384626433832795028841971f
#define M_RADPI		57.295779513082f
#define M_PI_F		((float)(M_PI))	// Shouldn't collide with anything.
#define RAD2DEG( x )  ( (float)(x) * (float)(180.f / M_PI_F) )
#define DEG2RAD( x )  ( (float)(x) * (float)(M_PI_F / 180.f) )

#define IN_ATTACK				(1 << 0)
#define IN_JUMP					(1 << 1)
#define IN_DUCK					(1 << 2)
#define IN_FORWARD				(1 << 3)
#define IN_BACK					(1 << 4)
#define IN_USE					(1 << 5)
#define IN_CANCEL				(1 << 6)
#define IN_LEFT					(1 << 7)
#define IN_RIGHT				(1 << 8)
#define IN_MOVELEFT				(1 << 9)
#define IN_MOVERIGHT			(1 << 10)
#define IN_ATTACK2				(1 << 11)
#define IN_RUN					(1 << 12)
#define IN_RELOAD				(1 << 13)
#define IN_ALT1					(1 << 14)
#define IN_ALT2					(1 << 15)
#define IN_SCORE				(1 << 16)
#define IN_SPEED				(1 << 17)
#define IN_WALK					(1 << 18)
#define IN_ZOOM					(1 << 19)
#define IN_WEAPON1				(1 << 20)
#define IN_WEAPON2				(1 << 21)
#define IN_BULLRUSH				(1 << 22)

#define	FL_ONGROUND				(1 << 0)
#define FL_DUCKING				(1 << 1)
#define	FL_WATERJUMP			(1 << 3)
#define FL_ONTRAIN				(1 << 4)
#define FL_INRAIN				(1 << 5)
#define FL_FROZEN				(1 << 6)
#define FL_ATCONTROLS			(1 << 7)
#define	FL_CLIENT				(1 << 8)
#define FL_FAKECLIENT			(1 << 9)
#define	FL_INWATER				(1 << 10)

#define HIDEHUD_SCOPE			(1 << 11)

#define MAX_AREA_STATE_BYTES		32
#define MAX_AREA_PORTAL_STATE_BYTES 24

#define  Assert( _exp )										((void)0)
#define  AssertAligned( ptr )								((void)0)
#define  AssertOnce( _exp )									((void)0)
#define  AssertMsg( _exp, _msg )							((void)0)
#define  AssertMsgOnce( _exp, _msg )						((void)0)
#define  AssertFunc( _exp, _f )								((void)0)
#define  AssertEquals( _exp, _expectedValue )				((void)0)
#define  AssertFloatEquals( _exp, _expectedValue, _tol )	((void)0)
#define  Verify( _exp )										(_exp)
#define  VerifyEquals( _exp, _expectedValue )           	(_exp)

#define TEXTURE_GROUP_LIGHTMAP						"Lightmaps"
#define TEXTURE_GROUP_WORLD							"World textures"
#define TEXTURE_GROUP_MODEL							"Model textures"
#define TEXTURE_GROUP_VGUI							"VGUI textures"
#define TEXTURE_GROUP_PARTICLE						"Particle textures"
#define TEXTURE_GROUP_DECAL							"Decal textures"
#define TEXTURE_GROUP_SKYBOX						"SkyBox textures"
#define TEXTURE_GROUP_CLIENT_EFFECTS				"ClientEffect textures"
#define TEXTURE_GROUP_OTHER							"Other textures"
#define TEXTURE_GROUP_PRECACHED						"Precached"				// TODO: assign texture groups to the precached materials
#define TEXTURE_GROUP_CUBE_MAP						"CubeMap textures"
#define TEXTURE_GROUP_RENDER_TARGET					"RenderTargets"
#define TEXTURE_GROUP_UNACCOUNTED					"Unaccounted textures"	// Textures that weren't assigned a texture group.
//#define TEXTURE_GROUP_STATIC_VERTEX_BUFFER		"Static Vertex"
#define TEXTURE_GROUP_STATIC_INDEX_BUFFER			"Static Indices"
#define TEXTURE_GROUP_STATIC_VERTEX_BUFFER_DISP		"Displacement Verts"
#define TEXTURE_GROUP_STATIC_VERTEX_BUFFER_COLOR	"Lighting Verts"
#define TEXTURE_GROUP_STATIC_VERTEX_BUFFER_WORLD	"World Verts"
#define TEXTURE_GROUP_STATIC_VERTEX_BUFFER_MODELS	"Model Verts"
#define TEXTURE_GROUP_STATIC_VERTEX_BUFFER_OTHER	"Other Verts"
#define TEXTURE_GROUP_DYNAMIC_INDEX_BUFFER			"Dynamic Indices"
#define TEXTURE_GROUP_DYNAMIC_VERTEX_BUFFER			"Dynamic Verts"
#define TEXTURE_GROUP_DEPTH_BUFFER					"DepthBuffer"
#define TEXTURE_GROUP_VIEW_MODEL					"ViewModel"
#define TEXTURE_GROUP_PIXEL_SHADERS					"Pixel Shaders"
#define TEXTURE_GROUP_VERTEX_SHADERS				"Vertex Shaders"
#define TEXTURE_GROUP_RENDER_TARGET_SURFACE			"RenderTarget Surfaces"
#define TEXTURE_GROUP_MORPH_TARGETS					"Morph Targets"

#define	CONTENTS_EMPTY			0		// No contents

#define	CONTENTS_SOLID			0x1		// an eye is never valid in a solid
#define	CONTENTS_WINDOW			0x2		// translucent, but not watery (glass)
#define	CONTENTS_AUX			0x4
#define	CONTENTS_GRATE			0x8		// Alpha-tested "grate" textures.  Bullets/sight pass through, but solids don't
#define	CONTENTS_SLIME			0x10
#define	CONTENTS_WATER			0x20
#define	CONTENTS_BLOCKLOS		0x40	// block AI line of sight
#define CONTENTS_OPAQUE			0x80	// things that cannot be seen through (may be non-solid though)
#define	LAST_VISIBLE_CONTENTS	CONTENTS_OPAQUE

#define ALL_VISIBLE_CONTENTS (LAST_VISIBLE_CONTENTS | (LAST_VISIBLE_CONTENTS-1))

#define CONTENTS_TESTFOGVOLUME	0x100
#define CONTENTS_UNUSED			0x200

// unused 
// NOTE: If it's Visible, grab from the Top + update LAST_VISIBLE_CONTENTS
// if not Visible, then grab from the bottom.
// CONTENTS_OPAQUE + SURF_NODRAW count as CONTENTS_OPAQUE (shadow-casting toolsblocklight textures)
#define CONTENTS_BLOCKLIGHT		0x400

#define CONTENTS_TEAM1			0x800	// per team contents used to differentiate collisions 
#define CONTENTS_TEAM2			0x1000	// between players and objects on different teams

// ignore CONTENTS_OPAQUE on surfaces that have SURF_NODRAW
#define CONTENTS_IGNORE_NODRAW_OPAQUE	0x2000

// hits entities which are MOVETYPE_PUSH (doors, plats, etc.)
#define CONTENTS_MOVEABLE		0x4000

// remaining contents are non-Visible, and don't eat brushes
#define	CONTENTS_AREAPORTAL		0x8000

#define	CONTENTS_PLAYERCLIP		0x10000
#define	CONTENTS_MONSTERCLIP	0x20000

// currents can be added to any other contents, and may be mixed
#define	CONTENTS_CURRENT_0		0x40000
#define	CONTENTS_CURRENT_90		0x80000
#define	CONTENTS_CURRENT_180	0x100000
#define	CONTENTS_CURRENT_270	0x200000
#define	CONTENTS_CURRENT_UP		0x400000
#define	CONTENTS_CURRENT_DOWN	0x800000

#define	CONTENTS_ORIGIN			0x1000000	// removed before bsping an entity

#define	CONTENTS_MONSTER		0x2000000	// should never be on a brush, only in game
#define	CONTENTS_DEBRIS			0x4000000
#define	CONTENTS_DETAIL			0x8000000	// brushes to be added after vis leafs
#define	CONTENTS_TRANSLUCENT	0x10000000	// auto set if any surface has trans
#define	CONTENTS_LADDER			0x20000000
#define CONTENTS_HITBOX			0x40000000	// use accurate hitboxes on trace

#define	MASK_SHOT	(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_MONSTER|CONTENTS_WINDOW|CONTENTS_DEBRIS|CONTENTS_HITBOX)

// NOTE: These are stored in a short in the engine now.  Don't use more than 16 bits
#define	SURF_LIGHT		0x0001		// Value will hold the light strength
#define	SURF_SKY2D		0x0002		// don't Draw, indicates we should skylight + Draw 2d sky but not Draw the 3D skybox
#define	SURF_SKY		0x0004		// don't Draw, but add to skybox
#define	SURF_WARP		0x0008		// turbulent water warp
#define	SURF_TRANS		0x0010
#define SURF_NOPORTAL	0x0020	// the surface can not have a portal placed on it
#define	SURF_TRIGGER	0x0040	// FIXME: This is an xbox hack to work around elimination of Trigger surfaces, which breaks occluders
#define	SURF_NODRAW		0x0080	// don't bother referencing the texture

#define	SURF_HINT		0x0100	// make a primary bsp splitter

#define	SURF_SKIP		0x0200	// completely ignore, allowing non-closed brushes
#define SURF_NOLIGHT	0x0400	// Don't calculate light
#define SURF_BUMPLIGHT	0x0800	// calculate three lightmaps for the surface for bumpmapping
#define SURF_NOSHADOWS	0x1000	// Don't receive shadows
#define SURF_NODECALS	0x2000	// Don't receive decals
#define SURF_NOPAINT	SURF_NODECALS	// the surface can not have paint placed on it
#define SURF_NOCHOP		0x4000	// Don't subdivide patches on this surface 
#define SURF_HITBOX		0x8000	// surface is part of a Hitbox

#define	MASK_ALL					(0xFFFFFFFF)
// everything that is normally solid
#define	MASK_SOLID					(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_WINDOW|CONTENTS_MONSTER|CONTENTS_GRATE)
// everything that blocks Player movement
#define	MASK_PLAYERSOLID			(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_PLAYERCLIP|CONTENTS_WINDOW|CONTENTS_MONSTER|CONTENTS_GRATE)
// blocks npc movement
#define	MASK_NPCSOLID				(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_MONSTERCLIP|CONTENTS_WINDOW|CONTENTS_MONSTER|CONTENTS_GRATE)
// blocks fluid movement
#define	MASK_NPCFLUID				(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_MONSTERCLIP|CONTENTS_WINDOW|CONTENTS_MONSTER)
// water physics in these contents
#define	MASK_WATER					(CONTENTS_WATER|CONTENTS_MOVEABLE|CONTENTS_SLIME)
// everything that blocks lighting
#define	MASK_OPAQUE					(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_OPAQUE)
// everything that blocks lighting, but with monsters added.
#define MASK_OPAQUE_AND_NPCS		(MASK_OPAQUE|CONTENTS_MONSTER)
// everything that blocks line of sight for AI
#define MASK_BLOCKLOS				(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_BLOCKLOS)
// everything that blocks line of sight for AI plus NPCs
#define MASK_BLOCKLOS_AND_NPCS		(MASK_BLOCKLOS|CONTENTS_MONSTER)
// everything that blocks line of sight for players
#define	MASK_VISIBLE					(MASK_OPAQUE|CONTENTS_IGNORE_NODRAW_OPAQUE)
// everything that blocks line of sight for players, but with monsters added.
#define MASK_VISIBLE_AND_NPCS		(MASK_OPAQUE_AND_NPCS|CONTENTS_IGNORE_NODRAW_OPAQUE)
// bullets see these as solid
#define	MASK_SHOT					(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_MONSTER|CONTENTS_WINDOW|CONTENTS_DEBRIS|CONTENTS_HITBOX)
// bullets see these as solid, except monsters (World+brush only)
#define MASK_SHOT_BRUSHONLY			(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_WINDOW|CONTENTS_DEBRIS)
// non-raycasted Weapons see this as solid (includes grates)
#define MASK_SHOT_HULL				(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_MONSTER|CONTENTS_WINDOW|CONTENTS_DEBRIS|CONTENTS_GRATE)
// hits solids (not grates) and passes through everything else
#define MASK_SHOT_PORTAL			(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_WINDOW|CONTENTS_MONSTER)
// everything normally solid, except monsters (World+brush only)
#define MASK_SOLID_BRUSHONLY		(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_WINDOW|CONTENTS_GRATE)
// everything normally solid for Player movement, except monsters (World+brush only)
#define MASK_PLAYERSOLID_BRUSHONLY	(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_WINDOW|CONTENTS_PLAYERCLIP|CONTENTS_GRATE)
// everything normally solid for npc movement, except monsters (World+brush only)
#define MASK_NPCSOLID_BRUSHONLY		(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_WINDOW|CONTENTS_MONSTERCLIP|CONTENTS_GRATE)
// just the World, used for route rebuilding
#define MASK_NPCWORLDSTATIC			(CONTENTS_SOLID|CONTENTS_WINDOW|CONTENTS_MONSTERCLIP|CONTENTS_GRATE)
// just the World, used for route rebuilding
#define MASK_NPCWORLDSTATIC_FLUID	(CONTENTS_SOLID|CONTENTS_WINDOW|CONTENTS_MONSTERCLIP)
// These are things that can split areaportals
#define MASK_SPLITAREAPORTAL		(CONTENTS_WATER|CONTENTS_SLIME)

// UNDONE: This is untested, any moving water
#define MASK_CURRENT				(CONTENTS_CURRENT_0|CONTENTS_CURRENT_90|CONTENTS_CURRENT_180|CONTENTS_CURRENT_270|CONTENTS_CURRENT_UP|CONTENTS_CURRENT_DOWN)

// everything that blocks corpse movement
// UNDONE: Not used yet / may be deleted
#define	MASK_DEADSOLID				(CONTENTS_SOLID|CONTENTS_PLAYERCLIP|CONTENTS_WINDOW|CONTENTS_GRATE)

#define SEQUENCE_DEFAULT_DRAW 0
#define SEQUENCE_DEFAULT_IDLE1 1
#define SEQUENCE_DEFAULT_IDLE2 2
#define SEQUENCE_DEFAULT_LIGHT_MISS1 3
#define SEQUENCE_DEFAULT_LIGHT_MISS2 4
#define SEQUENCE_DEFAULT_HEAVY_MISS1 9
#define SEQUENCE_DEFAULT_HEAVY_HIT1 10
#define SEQUENCE_DEFAULT_HEAVY_BACKSTAB 11
#define SEQUENCE_DEFAULT_LOOKAT01 12

#define SEQUENCE_BUTTERFLY_DRAW 0
#define SEQUENCE_BUTTERFLY_DRAW2 1
#define SEQUENCE_BUTTERFLY_LOOKAT01 13
#define SEQUENCE_BUTTERFLY_LOOKAT02 14
#define SEQUENCE_BUTTERFLY_LOOKAT03 15

#define SEQUENCE_FALCHION_IDLE1 1
#define SEQUENCE_FALCHION_HEAVY_MISS1 8
#define SEQUENCE_FALCHION_HEAVY_MISS1_NOFLIP 9
#define SEQUENCE_FALCHION_LOOKAT01 12
#define SEQUENCE_FALCHION_LOOKAT02 13

#define SEQUENCE_DAGGERS_IDLE1 1
#define SEQUENCE_DAGGERS_LIGHT_MISS1 2
#define SEQUENCE_DAGGERS_LIGHT_MISS5 6
#define SEQUENCE_DAGGERS_HEAVY_MISS2 11
#define SEQUENCE_DAGGERS_HEAVY_MISS1 12

#define SEQUENCE_BOWIE_IDLE1 1

struct ColorVec
{
	unsigned r, g, b, a;
};

extern int WEAPON_DEAGLE;
extern int WEAPON_DUALBERETTA;
extern int WEAPON_FIVESEVEN;
extern int WEAPON_GLOCK;
extern int WEAPON_AK47;
extern int WEAPON_AUG;
extern int WEAPON_AWP;
extern int WEAPON_FAMAS;
extern int WEAPON_G3SG1;
extern int WEAPON_GALIL;
extern int WEAPON_M249;
extern int WEAPON_M4A4;
extern int WEAPON_MAC10;
extern int WEAPON_P90;
extern int WEAPON_MP5SD;
extern int WEAPON_UMP45;
extern int WEAPON_XM1014;
extern int WEAPON_BIZON;
extern int WEAPON_MAG7;
extern int WEAPON_NEGEV;
extern int WEAPON_SAWEDOFF;
extern int WEAPON_TEC9;
extern int WEAPON_ZEUSX27;
extern int WEAPON_P2000;
extern int WEAPON_MP7;
extern int WEAPON_MP9;
extern int WEAPON_NOVA;
extern int WEAPON_P250;
extern int WEAPON_SHIELD;
extern int WEAPON_SCAR20;
extern int WEAPON_SG553;
extern int WEAPON_SSG08;
extern int WEAPON_KNIFE_GG;
extern int WEAPON_KNIFE;
extern int WEAPON_FLASHBANG;
extern int WEAPON_HEGRENADE;
extern int WEAPON_SMOKEGRENADE;
extern int WEAPON_MOLOTOV;
extern int WEAPON_DECOY;
extern int WEAPON_INCGRENADE;
extern int WEAPON_C4;
extern int WEAPON_HEALTHSHOT;
extern int WEAPON_KNIFE_T;
extern int WEAPON_M4A1S;
extern int WEAPON_USPS;
extern int WEAPON_CZ75;
extern int WEAPON_REVOLVER;
extern int WEAPON_TAGRENADE;
extern int WEAPON_FISTS;
extern int WEAPON_BREACHCHARGE;
extern int WEAPON_TABLET;
extern int WEAPON_MELEE;
extern int WEAPON_AXE;
extern int WEAPON_HAMMER;
extern int WEAPON_SPANNER;
extern int WEAPON_KNIFE_GHOST;
extern int WEAPON_FIREBOMB;
extern int WEAPON_DIVERSION;
extern int WEAPON_FRAG_GRENADE;
extern int WEAPON_SNOWBALL;
extern int WEAPON_BUMPMINE;
extern int WEAPON_KNIFE_BAYONET;
extern int WEAPON_KNIFE_CSS;
extern int WEAPON_KNIFE_FLIP;
extern int WEAPON_KNIFE_GUT;
extern int WEAPON_KNIFE_KARAMBIT;
extern int WEAPON_KNIFE_M9_BAYONET;
extern int WEAPON_KNIFE_TACTICAL;
extern int WEAPON_KNIFE_FALCHION;
extern int WEAPON_KNIFE_SURVIVAL_BOWIE;
extern int WEAPON_KNIFE_BUTTERFLY;
extern int WEAPON_KNIFE_PUSH;
extern int WEAPON_KNIFE_CORD;
extern int WEAPON_KNIFE_CANIS;
extern int WEAPON_KNIFE_URSUS;
extern int WEAPON_KNIFE_GYPSY_JACKKNIFE;
extern int WEAPON_KNIFE_OUTDOOR;
extern int WEAPON_KNIFE_STILETTO;
extern int WEAPON_KNIFE_WIDOWMAKER;
extern int WEAPON_KNIFE_SKELETON;

extern std::string WEAPON_KNIFE_VMODEL_GG;
extern std::string WEAPON_KNIFE_VMODEL;
extern std::string WEAPON_KNIFE_VMODEL_T;
extern std::string WEAPON_KNIFE_VMODEL_BAYONET;
extern std::string WEAPON_KNIFE_VMODEL_CSS;
extern std::string WEAPON_KNIFE_VMODEL_FLIP;
extern std::string WEAPON_KNIFE_VMODEL_GUT;
extern std::string WEAPON_KNIFE_VMODEL_KARAMBIT;
extern std::string WEAPON_KNIFE_VMODEL_M9_BAYONET;
extern std::string WEAPON_KNIFE_VMODEL_TACTICAL;
extern std::string WEAPON_KNIFE_VMODEL_FALCHION;
extern std::string WEAPON_KNIFE_VMODEL_SURVIVAL_BOWIE;
extern std::string WEAPON_KNIFE_VMODEL_BUTTERFLY;
extern std::string WEAPON_KNIFE_VMODEL_PUSH;
extern std::string WEAPON_KNIFE_VMODEL_CORD;
extern std::string WEAPON_KNIFE_VMODEL_CANIS;
extern std::string WEAPON_KNIFE_VMODEL_URSUS;
extern std::string WEAPON_KNIFE_VMODEL_GYPSY_JACKKNIFE;
extern std::string WEAPON_KNIFE_VMODEL_OUTDOOR;
extern std::string WEAPON_KNIFE_VMODEL_STILETTO;
extern std::string WEAPON_KNIFE_VMODEL_WIDOWMAKER;
extern std::string WEAPON_KNIFE_VMODEL_SKELETON;

extern int GLOVE_BLOODHOUND;
extern int GLOVE_T;
extern int GLOVE_CT;
extern int GLOVE_SPORTY;
extern int GLOVE_SLICK;
extern int GLOVE_HANDWRAP;
extern int GLOVE_MOTOCYCLE;
extern int GLOVE_SPECIALIST;
extern int GLOVE_HYDRA;

extern std::string GLOVE_VMODEL_BLOODHOUND;
extern std::string GLOVE_VMODEL_T;
extern std::string GLOVE_VMODEL_CT;
extern std::string GLOVE_VMODEL_SPORTY;
extern std::string GLOVE_VMODEL_SLICK;
extern std::string GLOVE_VMODEL_HANDWRAP;
extern std::string GLOVE_VMODEL_MOTOCYCLE;
extern std::string GLOVE_VMODEL_SPECIALIST;
extern std::string GLOVE_VMODEL_HYDRA;

enum WeaponAimIndex : int
{
	WAI_USPS = 0,
	WAI_REVOLVER,
	WAI_CZ75,
	WAI_DEAGLE,
	WAI_DUALBERETTA,
	WAI_FIVESEVEN,
	WAI_GLOCK,
	WAI_P2000,
	WAI_P250,
	WAI_TEC9,

	WAI_MAC10 = 10,
	WAI_MP7,
	WAI_MP9,
	WAI_MP5SD,
	WAI_BIZON,
	WAI_P90,
	WAI_UMP45,

	WAI_AK47 = 17,
	WAI_FAMAS,
	WAI_GALIL,
	WAI_M4A1S,
	WAI_M4A4,
	WAI_AUG,
	WAI_SG553,

	WAI_AWP = 24,
	WAI_G3SG1,
	WAI_SCAR20,
	WAI_SSG08,

	WAI_MAG7 = 28,
	WAI_NOVA,
	WAI_SAWEDOFF,
	WAI_XM1014,

	WAI_M249 = 32,
	WAI_NEGEV,

	WAI_TASER = 34,

	WAI_UNKNOW = 35
};

enum ModelWeaponIndex : int
{
	MT_WEAPON_USPS = 0,
	MT_WEAPON_REVOLVER,
	MT_WEAPON_CZ75,
	MT_WEAPON_DEAGLE,
	MT_WEAPON_DUALBERETTA,
	MT_WEAPON_FIVESEVEN,
	MT_WEAPON_GLOCK,
	MT_WEAPON_P2000,
	MT_WEAPON_P250,
	MT_WEAPON_TEC9,

	MT_WEAPON_MAC10 = 10,
	MT_WEAPON_MP7,
	MT_WEAPON_MP9,
	MT_WEAPON_MP5SD,
	MT_WEAPON_BIZON,
	MT_WEAPON_P90,
	MT_WEAPON_UMP45,

	MT_WEAPON_AK47 = 17,
	MT_WEAPON_FAMAS,
	MT_WEAPON_GALIL,
	MT_WEAPON_M4A1S,
	MT_WEAPON_M4A4,
	MT_WEAPON_AUG,
	MT_WEAPON_SG553,

	MT_WEAPON_AWP = 24,
	MT_WEAPON_G3SG1,
	MT_WEAPON_SCAR20,
	MT_WEAPON_SSG08,

	MT_WEAPON_MAG7 = 28,
	MT_WEAPON_NOVA,
	MT_WEAPON_SAWEDOFF,
	MT_WEAPON_XM1014,

	MT_WEAPON_M249 = 32,
	MT_WEAPON_NEGEV,

	MT_WEAPON_KNIFE = 34,

	MT_ENEMY_PLAYER = 35,
	MT_TEAM_PLAYER,
	MT_LOCAL_PLAYER,

	MODEL_TYPE_MAX
};

enum WeaponType : int
{
	WT_INVALID,
	WT_GRENADES,
	WT_KNIFES,
	WT_MISC,
	WT_PISTOLS,
	WT_SUBMACHINEGUNS,
	WT_RIFLERS,
	WT_SNIPERS,
	WT_SHOTGUNS,
	WT_MACHINEGUNS,
	WT_MAX
};

enum
{
	PITCH = 0,
	YAW,
	ROLL
};

enum AA_Pitch
{
	AA_PITCH_None,
	AA_PITCH_Zero,
	AA_PITCH_EMOTION,
	AA_PITCH_RANDOM,
	AA_PITCH_UP
};

enum AA_Yaw
{
	AA_YAW_None,
	AA_YAW_Zero,
	AA_YAW_Static,
	AA_YAW_BackWard,
	AA_YAW_Left,
	AA_YAW_Right,
	AA_YAW_Jitter,
	AA_YAW_Random, 
	AA_YAW_LBY,
	AA_YAW_LBYSmart,
	AA_YAW_SlowSpin,
	AA_YAW_FastSpin,
	AA_YAW_ManualKeys,
	AA_YAW_Auto_Direction,
};

enum FontRenderFlag_t
{
	FONT_LEFT = 0,
	FONT_RIGHT = 1,
	FONT_CENTER = 2
};

enum class StickerAttributeType_t
{
	Index,
	Wear,
	Scale,
	Rotation
};

enum DataUpdateType_t
{
	DATA_UPDATE_CREATED = 0,
	DATA_UPDATE_DATATABLE_CHANGED,
};

enum MoveType_t
{
	MOVETYPE_NONE = 0,
	MOVETYPE_ISOMETRIC,
	MOVETYPE_WALK,
	MOVETYPE_STEP,
	MOVETYPE_FLY,
	MOVETYPE_FLYGRAVITY,
	MOVETYPE_VPHYSICS,
	MOVETYPE_PUSH,
	MOVETYPE_NOCLIP,
	MOVETYPE_LADDER,
	MOVETYPE_OBSERVER,
	MOVETYPE_CUSTOM,
	MOVETYPE_LAST = MOVETYPE_CUSTOM,
	MOVETYPE_MAX_BITS = 4
};

enum CSWeaponType_t
{
	WEAPONTYPE_KNIFE = 0,
	WEAPONTYPE_PISTOL,
	WEAPONTYPE_SUBMACHINEGUN,
	WEAPONTYPE_RIFLE,
	WEAPONTYPE_SHOTGUN,
	WEAPONTYPE_SNIPER_RIFLE,
	WEAPONTYPE_MACHINEGUN,
	WEAPONTYPE_C4,
	WEAPONTYPE_GRENADE,
	WEAPONTYPE_UNKNOWN
};

enum Legit_Type : int
{
	LegitInvalid,
	LegitWType,
	LegitWeapon
};

enum Rage_Type : int
{
	RageInvalid,
	RageWType
};

struct STabInfo
{
	const char* szName;
	int index;
};

enum EMainTabs
{
	MISC = 1,
	VISUALS = 2,
	LEGIT = 3
};

struct player_info_t
{
	char __pad0[0x8];

	int xuidlow;
	int xuidhigh;

	char Name[128];
	int userid;
	char guid[33];

	char __pad1[0x17B];
};

class CUserCmd
{
public:
	virtual ~CUserCmd()
	{ };
	int command_number;
	int tick_count;
	QAngle viewangles;
	Vector aimdirection;
	float forwardmove;
	float sidemove;
	float upmove;
	int buttons;
	byte impulse;
	int weaponselect;
	int weaponsubtype;
	int random_seed;
	short mousedx;
	short mousedy;
	bool hasbeenpredicted;
	char pad_0x4C[0x18];
};

struct VMatrix
{
	float m[4][4];

	inline float* operator[](int i)
	{
		return m[i];
	}

	inline const float* operator[](int i) const
	{
		return m[i];
	}
};

struct matrix3x3_t
{
	float m_flMatVal[3][3];
};

struct matrix3x4_t
{
	matrix3x4_t()
	{}

	matrix3x4_t(
		float m00, float m01, float m02, float m03,
		float m10, float m11, float m12, float m13,
		float m20, float m21, float m22, float m23)
	{
		m_flMatVal[0][0] = m00;
		m_flMatVal[0][1] = m01;
		m_flMatVal[0][2] = m02;
		m_flMatVal[0][3] = m03;
		m_flMatVal[1][0] = m10;
		m_flMatVal[1][1] = m11;
		m_flMatVal[1][2] = m12;
		m_flMatVal[1][3] = m13;
		m_flMatVal[2][0] = m20;
		m_flMatVal[2][1] = m21;
		m_flMatVal[2][2] = m22;
		m_flMatVal[2][3] = m23;
	}

	//-----------------------------------------------------------------------------
	// Creates a matrix where the X axis = forward
	// the Y axis = Left, and the Z axis = Up
	//-----------------------------------------------------------------------------
	void Init(const Vector& xAxis, const Vector& yAxis, const Vector& zAxis, const Vector& vecOrigin)
	{
		m_flMatVal[0][0] = xAxis.x;
		m_flMatVal[0][1] = yAxis.x;
		m_flMatVal[0][2] = zAxis.x;
		m_flMatVal[0][3] = vecOrigin.x;
		m_flMatVal[1][0] = xAxis.y;
		m_flMatVal[1][1] = yAxis.y;
		m_flMatVal[1][2] = zAxis.y;
		m_flMatVal[1][3] = vecOrigin.y;
		m_flMatVal[2][0] = xAxis.z;
		m_flMatVal[2][1] = yAxis.z;
		m_flMatVal[2][2] = zAxis.z;
		m_flMatVal[2][3] = vecOrigin.z;
	}

	//-----------------------------------------------------------------------------
	// Creates a matrix where the X axis = forward
	// the Y axis = Left, and the Z axis = Up
	//-----------------------------------------------------------------------------
	matrix3x4_t(const Vector& xAxis, const Vector& yAxis, const Vector& zAxis, const Vector& vecOrigin)
	{
		Init(xAxis, yAxis, zAxis, vecOrigin);
	}

	inline void SetOrigin(Vector const& p)
	{
		m_flMatVal[0][3] = p.x;
		m_flMatVal[1][3] = p.y;
		m_flMatVal[2][3] = p.z;
	}

	inline void Invalidate(void)
	{
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 4; j++)
			{
				m_flMatVal[i][j] = VEC_T_NAN;
			}
		}
	}

	float* operator[](int i)
	{
		Assert((i >= 0) && (i < 3));
		return m_flMatVal[i];
	}

	const float* operator[](int i) const
	{
		Assert((i >= 0) && (i < 3));
		return m_flMatVal[i];
	}

	float* Base()
	{
		return &m_flMatVal[0][0];
	}

	const float* Base() const
	{
		return &m_flMatVal[0][0];
	}

	float m_flMatVal[3][4];
};

class ALIGN16 matrix3x4a_t : public matrix3x4_t
{
public:
	/*
	matrix3x4a_t() { if (((size_t)Base()) % 16 != 0) { Error( "matrix3x4a_t missaligned" ); } }
	*/
	matrix3x4a_t& operator=(const matrix3x4_t& src)
	{
		memcpy(Base(), src.Base(), sizeof(float) * 3 * 4);
		return *this;
	};
};

class ICollideable
{
public:
	virtual void pad0();
	virtual const Vector& OBBMins() const;
	virtual const Vector& OBBMaxs() const;
};

struct mstudiobbox_t
{
	int bone;
	int group; // intersection group
	Vector bbmin; // bounding Box 
	Vector bbmax;
	int hitboxnameindex; // offset to the Name of the Hitbox.
	int pad[3];
	float radius;
	int pad2[4];

	char* getHitboxName()
	{
		if (hitboxnameindex == 0)
			return "";

		return ((char*)this) + hitboxnameindex;
	}
};

class CViewSetup
{
public:
	int x, x_old;
	int y, y_old;
	int width, width_old;
	int height, height_old;
	bool m_bOrtho;
	float m_OrthoLeft;
	float m_OrthoTop;
	float m_OrthoRight;
	float m_OrthoBottom;
	bool m_bCustomViewMatrix;
	matrix3x4_t m_matCustomViewMatrix;
	char pad_0x68[0x48];
	float fov;
	float fovViewmodel;
	Vector origin;
	QAngle angles;
	float zNear;
	float zFar;
	float zNearViewmodel;
	float zFarViewmodel;
	float m_flAspectRatio;
	float m_flNearBlurDepth;
	float m_flNearFocusDepth;
	float m_flFarFocusDepth;
	float m_flFarBlurDepth;
	float m_flNearBlurRadius;
	float m_flFarBlurRadius;
	int m_nDoFQuality;
	int m_nMotionBlurMode;
	float m_flShutterTime;
	Vector m_vShutterOpenPosition;
	QAngle m_shutterOpenAngles;
	Vector m_vShutterClosePosition;
	QAngle m_shutterCloseAngles;
	float m_flOffCenterTop;
	float m_flOffCenterBottom;
	float m_flOffCenterLeft;
	float m_flOffCenterRight;
	int m_EdgeBlur;
};

enum FontDrawType_t
{
	FONT_DRAW_DEFAULT = 0,
	FONT_DRAW_NONADDITIVE,
	FONT_DRAW_ADDITIVE,
	FONT_DRAW_TYPE_COUNT = 2,
};

typedef unsigned long HFont;

struct FontVertex_t
{
	Vector2D m_Position;
	Vector2D m_TexCoord;

	FontVertex_t()
	{}

	FontVertex_t(const Vector2D& Pos, const Vector2D& coord = Vector2D(0, 0))
	{
		m_Position = Pos;
		m_TexCoord = coord;
	}

	void Init(const Vector2D& Pos, const Vector2D& coord = Vector2D(0, 0))
	{
		m_Position = Pos;
		m_TexCoord = coord;
	}
};

typedef FontVertex_t Vertex_t;

struct surfacephysicsparams_t
{
	float    friction;
	float    elasticity;
	float    density;
	float    thickness;
	float    dampening;
};

struct surfaceaudioparams_t
{
	float    reflectivity;             // like elasticity, but how much sound should be reflected by this surface
	float    hardnessFactor;           // like elasticity, but only affects impact sound choices
	float    roughnessFactor;          // like friction, but only affects scrape sound choices   
	float    roughThreshold;           // surface roughness > this causes "rough" scrapes, < this causes "smooth" scrapes
	float    hardThreshold;            // surface hardness > this causes "hard" impacts, < this causes "soft" impacts
	float    hardVelocityThreshold;    // collision velocity > this causes "hard" impacts, < this causes "soft" impacts   
	float    highPitchOcclusion;       //a value betweeen 0 and 100 where 0 is not occluded at all and 100 is silent (except for any additional reflected sound)
	float    midPitchOcclusion;
	float    lowPitchOcclusion;
};

struct surfacesoundnames_t
{
	unsigned short    walkStepLeft;
	unsigned short    walkStepRight;
	unsigned short	  runStepLeft;
	unsigned short	  runStepRight;
	unsigned short    impactSoft;
	unsigned short    impactHard;
	unsigned short    scrapeSmooth;
	unsigned short    scrapeRough;
	unsigned short    bulletImpact;
	unsigned short    rolling;
	unsigned short    breakSound;
	unsigned short    strainSound;
};

struct surfacegameprops_t
{
public:
	float maxSpeedFactor;
	float jumpFactor;
	float flPenetrationModifier;
	float flDamageModifier;
	unsigned short material;
	byte climbable;
	char pad00[0x4];

};

struct surfacedata_t
{
	surfacephysicsparams_t    physics;
	surfaceaudioparams_t    audio;
	surfacesoundnames_t        sounds;
	surfacegameprops_t        game;
};

enum ClientFrameStage_t
{
	FRAME_UNDEFINED = -1,
	FRAME_START,
	FRAME_NET_UPDATE_START,
	FRAME_NET_UPDATE_POSTDATAUPDATE_START,
	FRAME_NET_UPDATE_POSTDATAUPDATE_END,
	FRAME_NET_UPDATE_END,
	FRAME_RENDER_START,
	FRAME_RENDER_END
};

#define MAX_SPLITSCREEN_CLIENT_BITS 2
// this should == MAX_JOYSTICKS in InputEnums.h
#define MAX_SPLITSCREEN_CLIENTS	( 1 << MAX_SPLITSCREEN_CLIENT_BITS ) // 4

enum
{
	MAX_JOYSTICKS = MAX_SPLITSCREEN_CLIENTS,
	MOUSE_BUTTON_COUNT = 5,
};

enum JoystickAxis_t
{
	JOY_AXIS_X = 0,
	JOY_AXIS_Y,
	JOY_AXIS_Z,
	JOY_AXIS_R,
	JOY_AXIS_U,
	JOY_AXIS_V,
	MAX_JOYSTICK_AXES,
};

enum
{
	JOYSTICK_MAX_BUTTON_COUNT = 32,
	JOYSTICK_POV_BUTTON_COUNT = 4,
	JOYSTICK_AXIS_BUTTON_COUNT = MAX_JOYSTICK_AXES * 2,
};

#define JOYSTICK_BUTTON_INTERNAL( _joystick, _button ) ( JOYSTICK_FIRST_BUTTON + ((_joystick) * JOYSTICK_MAX_BUTTON_COUNT) + (_button) )
#define JOYSTICK_POV_BUTTON_INTERNAL( _joystick, _button ) ( JOYSTICK_FIRST_POV_BUTTON + ((_joystick) * JOYSTICK_POV_BUTTON_COUNT) + (_button) )
#define JOYSTICK_AXIS_BUTTON_INTERNAL( _joystick, _button ) ( JOYSTICK_FIRST_AXIS_BUTTON + ((_joystick) * JOYSTICK_AXIS_BUTTON_COUNT) + (_button) )

#define JOYSTICK_BUTTON( _joystick, _button ) ( (ButtonCode_t)JOYSTICK_BUTTON_INTERNAL( _joystick, _button ) )
#define JOYSTICK_POV_BUTTON( _joystick, _button ) ( (ButtonCode_t)JOYSTICK_POV_BUTTON_INTERNAL( _joystick, _button ) )
#define JOYSTICK_AXIS_BUTTON( _joystick, _button ) ( (ButtonCode_t)JOYSTICK_AXIS_BUTTON_INTERNAL( _joystick, _button ) )

enum : int
{
	MP_MIRAGE = 0,
	MP_INFERNO,
	MP_OVERPASS,
	MP_VERTIGO,
	MP_STUDIO,
	MP_NUKE,
	MP_TRAIN,
	MP_DUST2,
	MP_CACHE,
	MP_BREACH,
	MP_AGENCY,
	MP_OFFICE,
	MP_UNKNOW,
};

enum : int
{
	CAI_BaseNPC = 0,
	CAK47,
	CCSBaseAnimating,
	CBaseAnimatingOverlay,
	CBaseAttributableItem,
	CBaseButton,
	CBaseCombatCharacter,
	CCSBaseCombatWeapon,
	CBaseCSGrenade,
	CBaseCSGrenadeProjectile,
	CBaseDoor,
	CCSBaseEntity,
	CBaseFlex,
	CBaseGrenade,
	CBaseParticleEntity,
	CBasePlayer,
	CBasePropDoor,
	CBaseTeamObjectiveResource,
	CBaseTempEntity,
	CBaseToggle,
	CBaseTrigger,
	CSCBaseViewModel,
	CBaseVPhysicsTrigger,
	CBaseWeaponWorldModel,
	CBeam,
	CBeamSpotlight,
	CBoneFollower,
	CBRC4Target,
	CBreachCharge,
	CBreachChargeProjectile,
	CBreakableProp,
	CBreakableSurface,
	CBumpMine,
	CBumpMineProjectile,
	CC4,
	CCascadeLight,
	CChicken,
	CColorCorrection,
	CColorCorrectionVolume,
	CCSGameRulesProxy,
	CCSPlayer,
	CCSPlayerResource,
	CCSRagdoll,
	CCSTeam,
	CDangerZone,
	CDangerZoneController,
	CDEagle,
	CDecoyGrenade,
	CDecoyProjectile,
	CDrone,
	CDronegun,
	CDynamicLight,
	CDynamicProp,
	CEconEntity,
	CEconWearable,
	CEmbers,
	CEntityDissolve,
	CEntityFlame,
	CEntityFreezing,
	CEntityParticleTrail,
	CEnvAmbientLight,
	CEnvDetailController,
	CEnvDOFController,
	CEnvGasCanister,
	CEnvParticleScript,
	CEnvProjectedTexture,
	CEnvQuadraticBeam,
	CEnvScreenEffect,
	CEnvScreenOverlay,
	CEnvTonemapController,
	CEnvWind,
	CFEPlayerDecal,
	CFireCrackerBlast,
	CFireSmoke,
	CFireTrail,
	CFish,
	CFists,
	CFlashbang,
	CFogController,
	CFootstepControl,
	CFunc_Dust,
	CFunc_LOD,
	CFuncAreaPortalWindow,
	CFuncBrush,
	CFuncConveyor,
	CFuncLadder,
	CFuncMonitor,
	CFuncMoveLinear,
	CFuncOccluder,
	CFuncReflectiveGlass,
	CFuncRotating,
	CFuncSmokeVolume,
	CFuncTrackTrain,
	CGameRulesProxy,
	CGrassBurn,
	CHandleTest,
	CHEGrenade,
	CHostage,
	CHostageCarriableProp,
	CIncendiaryGrenade,
	CInferno,
	CInfoLadderDismount,
	CInfoMapRegion,
	CInfoOverlayAccessor,
	CItem_Healthshot,
	CItemCash,
	CItemDogtags,
	CKnife,
	CKnifeGG,
	CLightGlow,
	CMaterialModifyControl,
	CMelee,
	CMolotovGrenade,
	CMolotovProjectile,
	CMovieDisplay,
	CParadropChopper,
	CParticleFire,
	CParticlePerformanceMonitor,
	CParticleSystem,
	CPhysBox,
	CPhysBoxMultiplayer,
	CPhysicsProp,
	CPhysicsPropMultiplayer,
	CPhysMagnet,
	CPhysPropAmmoBox,
	CPhysPropLootCrate,
	CPhysPropRadarJammer,
	CPhysPropWeaponUpgrade,
	CPlantedC4,
	CPlasma,
	CPlayerPing,
	CPlayerResource,
	CPointCamera,
	CPointCommentaryNode,
	CPointWorldText,
	CPoseController,
	CPostProcessController,
	CPrecipitation,
	CPrecipitationBlocker,
	CPredictedViewModel,
	CProp_Hallucination,
	CPropCounter,
	CPropDoorRotating,
	CPropJeep,
	CPropVehicleDriveable,
	CRagdollManager,
	CRagdollProp,
	CRagdollPropAttached,
	CRopeKeyframe,
	CSCAR17,
	CSceneEntity,
	CSensorGrenade,
	CSensorGrenadeProjectile,
	CShadowControl,
	CSlideshowDisplay,
	CSmokeGrenade,
	CSmokeGrenadeProjectile,
	CSmokeStack,
	CSnowball,
	CSnowballPile,
	CSnowballProjectile,
	CSpatialEntity,
	CSpotlightEnd,
	CSprite,
	CSpriteOriented,
	CSpriteTrail,
	CStatueProp,
	CSteamJet,
	CSun,
	CSunlightShadowControl,
	CSurvivalSpawnChopper,
	CTablet,
	CTeam,
	CTeamplayRoundBasedRulesProxy,
	CTEArmorRicochet,
	CTEBaseBeam,
	CTEBeamEntPoint,
	CTEBeamEnts,
	CTEBeamFollow,
	CTEBeamLaser,
	CTEBeamPoints,
	CTEBeamRing,
	CTEBeamRingPoint,
	CTEBeamSpline,
	CTEBloodSprite,
	CTEBloodStream,
	CTEBreakModel,
	CTEBSPDecal,
	CTEBubbles,
	CTEBubbleTrail,
	CTEClientProjectile,
	CTEDecal,
	CTEDust,
	CTEDynamicLight,
	CTEEffectDispatch,
	CTEEnergySplash,
	CTEExplosion,
	CTEFireBullets,
	CTEFizz,
	CTEFootprintDecal,
	CTEFoundryHelpers,
	CTEGaussExplosion,
	CTEGlowSprite,
	CTEImpact,
	CTEKillPlayerAttachments,
	CTELargeFunnel,
	CTEMetalSparks,
	CTEMuzzleFlash,
	CTEParticleSystem,
	CTEPhysicsProp,
	CTEPlantBomb,
	CTEPlayerAnimEvent,
	CTEPlayerDecal,
	CTEProjectedDecal,
	CTERadioIcon,
	CTEShatterSurface,
	CTEShowLine,
	CTesla,
	CTESmoke,
	CTESparks,
	CTESprite,
	CTESpriteSpray,
	CTest_ProxyToggle_Networkable,
	CTestTraceline,
	CTEWorldDecal,
	CTriggerPlayerMovement,
	CTriggerSoundOperator,
	CVGuiScreen,
	CVoteController,
	CWaterBullet,
	CWaterLODControl,
	CWeaponAug,
	CWeaponAWP,
	CWeaponBaseItem,
	CWeaponBizon,
	CWeaponCSBase,
	CWeaponCSBaseGun,
	CWeaponCycler,
	CWeaponElite,
	CWeaponFamas,
	CWeaponFiveSeven,
	CWeaponG3SG1,
	CWeaponGalil,
	CWeaponGalilAR,
	CWeaponGlock,
	CWeaponHKP2000,
	CWeaponM249,
	CWeaponM3,
	CWeaponM4A4,
	CWeaponMAC10,
	CWeaponMag7,
	CWeaponMP5Navy,
	CWeaponMP7,
	CWeaponMP9,
	CWeaponNegev,
	CWeaponNOVA,
	CWeaponP228,
	CWeaponP250,
	CWeaponP90,
	CWeaponSawedoff,
	CWeaponSCAR20,
	CWeaponScout,
	CWeaponSG550,
	CWeaponSG552,
	CWeaponSG556,
	CWeaponShield,
	CWeaponSSG08,
	CWeaponTaser,
	CWeaponTec9,
	CWeaponTMP,
	CWeaponUMP45,
	CWeaponUSP,
	CWeaponXM1014,
	CWorld,
	CWorldVguiText,
	DustTrail,
	MovieExplosion,
	ParticleSmokeGrenade,
	RocketTrail,
	SmokeTrail,
	SporeExplosion,
	SporeTrail,
};

enum ButtonCode_t
{
	BUTTON_CODE_INVALID = -1,
	BUTTON_CODE_NONE = 0,

	KEY_FIRST = 0,

	KEY_NONE = KEY_FIRST,
	KEY_0,
	KEY_1,
	KEY_2,
	KEY_3,
	KEY_4,
	KEY_5,
	KEY_6,
	KEY_7,
	KEY_8,
	KEY_9,
	KEY_A,
	KEY_B,
	KEY_C,
	KEY_D,
	KEY_E,
	KEY_F,
	KEY_G,
	KEY_H,
	KEY_I,
	KEY_J,
	KEY_K,
	KEY_L,
	KEY_M,
	KEY_N,
	KEY_O,
	KEY_P,
	KEY_Q,
	KEY_R,
	KEY_S,
	KEY_T,
	KEY_U,
	KEY_V,
	KEY_W,
	KEY_X,
	KEY_Y,
	KEY_Z,
	KEY_PAD_0,
	KEY_PAD_1,
	KEY_PAD_2,
	KEY_PAD_3,
	KEY_PAD_4,
	KEY_PAD_5,
	KEY_PAD_6,
	KEY_PAD_7,
	KEY_PAD_8,
	KEY_PAD_9,
	KEY_PAD_DIVIDE,
	KEY_PAD_MULTIPLY,
	KEY_PAD_MINUS,
	KEY_PAD_PLUS,
	KEY_PAD_ENTER,
	KEY_PAD_DECIMAL,
	KEY_LBRACKET,
	KEY_RBRACKET,
	KEY_SEMICOLON,
	KEY_APOSTROPHE,
	KEY_BACKQUOTE,
	KEY_COMMA,
	KEY_PERIOD,
	KEY_SLASH,
	KEY_BACKSLASH,
	KEY_MINUS,
	KEY_EQUAL,
	KEY_ENTER,
	KEY_SPACE,
	KEY_BACKSPACE,
	KEY_TAB,
	KEY_CAPSLOCK,
	KEY_NUMLOCK,
	KEY_ESCAPE,
	KEY_SCROLLLOCK,
	KEY_INSERT,
	KEY_DELETE,
	KEY_HOME,
	KEY_END,
	KEY_PAGEUP,
	KEY_PAGEDOWN,
	KEY_BREAK,
	KEY_LSHIFT,
	KEY_RSHIFT,
	KEY_LALT,
	KEY_RALT,
	KEY_LCONTROL,
	KEY_RCONTROL,
	KEY_LWIN,
	KEY_RWIN,
	KEY_APP,
	KEY_UP,
	KEY_LEFT,
	KEY_DOWN,
	KEY_RIGHT,
	KEY_F1,
	KEY_F2,
	KEY_F3,
	KEY_F4,
	KEY_F5,
	KEY_F6,
	KEY_F7,
	KEY_F8,
	KEY_F9,
	KEY_F10,
	KEY_F11,
	KEY_F12,
	KEY_CAPSLOCKTOGGLE,
	KEY_NUMLOCKTOGGLE,
	KEY_SCROLLLOCKTOGGLE,

	KEY_LAST = KEY_SCROLLLOCKTOGGLE,
	KEY_COUNT = KEY_LAST - KEY_FIRST + 1,

	// Mouse
	MOUSE_FIRST = KEY_LAST + 1,

	MOUSE_LEFT = MOUSE_FIRST,
	MOUSE_RIGHT,
	MOUSE_MIDDLE,
	MOUSE_4,
	MOUSE_5,
	MOUSE_WHEEL_UP, // A fake button which is 'pressed' and 'released' when the wheel is moved Up 
	MOUSE_WHEEL_DOWN, // A fake button which is 'pressed' and 'released' when the wheel is moved Down

	MOUSE_LAST = MOUSE_WHEEL_DOWN,
	MOUSE_COUNT = MOUSE_LAST - MOUSE_FIRST + 1,

	// Joystick
	JOYSTICK_FIRST = MOUSE_LAST + 1,

	JOYSTICK_FIRST_BUTTON = JOYSTICK_FIRST,
	JOYSTICK_LAST_BUTTON = JOYSTICK_BUTTON_INTERNAL(MAX_JOYSTICKS - 1, JOYSTICK_MAX_BUTTON_COUNT - 1),
	JOYSTICK_FIRST_POV_BUTTON,
	JOYSTICK_LAST_POV_BUTTON = JOYSTICK_POV_BUTTON_INTERNAL(MAX_JOYSTICKS - 1, JOYSTICK_POV_BUTTON_COUNT - 1),
	JOYSTICK_FIRST_AXIS_BUTTON,
	JOYSTICK_LAST_AXIS_BUTTON = JOYSTICK_AXIS_BUTTON_INTERNAL(MAX_JOYSTICKS - 1, JOYSTICK_AXIS_BUTTON_COUNT - 1),

	JOYSTICK_LAST = JOYSTICK_LAST_AXIS_BUTTON,

	BUTTON_CODE_LAST,
	BUTTON_CODE_COUNT = BUTTON_CODE_LAST - KEY_FIRST + 1,

	// Helpers for XBox 360
	KEY_XBUTTON_UP = JOYSTICK_FIRST_POV_BUTTON, // POV buttons
	KEY_XBUTTON_RIGHT,
	KEY_XBUTTON_DOWN,
	KEY_XBUTTON_LEFT,

	KEY_XBUTTON_A = JOYSTICK_FIRST_BUTTON, // Buttons
	KEY_XBUTTON_B,
	KEY_XBUTTON_X,
	KEY_XBUTTON_Y,
	KEY_XBUTTON_LEFT_SHOULDER,
	KEY_XBUTTON_RIGHT_SHOULDER,
	KEY_XBUTTON_BACK,
	KEY_XBUTTON_START,
	KEY_XBUTTON_STICK1,
	KEY_XBUTTON_STICK2,
	KEY_XBUTTON_INACTIVE_START,

	KEY_XSTICK1_RIGHT = JOYSTICK_FIRST_AXIS_BUTTON, // XAXIS POSITIVE
	KEY_XSTICK1_LEFT, // XAXIS NEGATIVE
	KEY_XSTICK1_DOWN, // YAXIS POSITIVE
	KEY_XSTICK1_UP, // YAXIS NEGATIVE
	KEY_XBUTTON_LTRIGGER, // ZAXIS POSITIVE
	KEY_XBUTTON_RTRIGGER, // ZAXIS NEGATIVE
	KEY_XSTICK2_RIGHT, // UAXIS POSITIVE
	KEY_XSTICK2_LEFT, // UAXIS NEGATIVE
	KEY_XSTICK2_DOWN, // VAXIS POSITIVE
	KEY_XSTICK2_UP, // VAXIS NEGATIVE
};

#define MAXSTUDIOSKINS		32		// total textures
#define MAXSTUDIOBONES		128		// total bones actually used
#define MAXSTUDIOFLEXDESC	1024	// maximum Number of low level flexes (actual morph targets)
#define MAXSTUDIOFLEXCTRL	96		// maximum Number of flexcontrollers (input sliders)
#define MAXSTUDIOPOSEPARAM	24
#define MAXSTUDIOBONECTRLS	4
#define MAXSTUDIOANIMBLOCKS 256

#define BONE_CALCULATE_MASK			0x1F
#define BONE_PHYSICALLY_SIMULATED	0x01	// Bone is physically simulated when physics are active
#define BONE_PHYSICS_PROCEDURAL		0x02	// procedural when physics is active
#define BONE_ALWAYS_PROCEDURAL		0x04	// Bone is always procedurally animated
#define BONE_SCREEN_ALIGN_SPHERE	0x08	// Bone aligns to the screen, not constrained in motion.
#define BONE_SCREEN_ALIGN_CYLINDER	0x10	// Bone aligns to the screen, constrained by it's own axis.

#define BONE_USED_MASK				0x0007FF00
#define BONE_USED_BY_ANYTHING		0x0007FF00
#define BONE_USED_BY_HITBOX			0x00000100	// Bone (or child) is used by a hit Box
#define BONE_USED_BY_ATTACHMENT		0x00000200	// Bone (or child) is used by an attachment Point
#define BONE_USED_BY_VERTEX_MASK	0x0003FC00
#define BONE_USED_BY_VERTEX_LOD0	0x00000400	// Bone (or child) is used by the toplevel model via skinned vertex
#define BONE_USED_BY_VERTEX_LOD1	0x00000800
#define BONE_USED_BY_VERTEX_LOD2	0x00001000
#define BONE_USED_BY_VERTEX_LOD3	0x00002000
#define BONE_USED_BY_VERTEX_LOD4	0x00004000
#define BONE_USED_BY_VERTEX_LOD5	0x00008000
#define BONE_USED_BY_VERTEX_LOD6	0x00010000
#define BONE_USED_BY_VERTEX_LOD7	0x00020000
#define BONE_USED_BY_BONE_MERGE		0x00040000	// Bone is available for Bone merge to occur against it

#define BONE_USED_BY_VERTEX_AT_LOD(lod) ( BONE_USED_BY_VERTEX_LOD0 << (lod) )
#define BONE_USED_BY_ANYTHING_AT_LOD(lod) ( ( BONE_USED_BY_ANYTHING & ~BONE_USED_BY_VERTEX_MASK ) | BONE_USED_BY_VERTEX_AT_LOD(lod) )

#define MAX_NUM_LODS 8

#define BONE_TYPE_MASK				0x00F00000
#define BONE_FIXED_ALIGNMENT		0x00100000	// Bone can't spin 360 degrees, all interpolation is normalized around a fixed orientation

#define BONE_HAS_SAVEFRAME_POS		0x00200000	// Vector48
#define BONE_HAS_SAVEFRAME_ROT64	0x00400000	// Quaternion64
#define BONE_HAS_SAVEFRAME_ROT32	0x00800000	// Quaternion32

#define	HITGROUP_GENERIC	0
#define HITGROUP_HEAD       1
#define HITGROUP_CHEST      2
#define HITGROUP_STOMACH    3
#define HITGROUP_LEFTARM    4    
#define HITGROUP_RIGHTARM   5
#define HITGROUP_LEFTLEG    6
#define HITGROUP_RIGHTLEG   7
#define HITGROUP_GEAR       10		// alerts NPC, but doesn't do damage or bleed (1/100th damage)

struct model_t
{
	char Name[255];
};

typedef unsigned short ModelInstanceHandle_t;

struct ModelRenderInfo_t
{
	Vector origin;
	QAngle angles;
	char pad[0x4];
	void* pRenderable;
	const model_t* pModel;
	const matrix3x4_t* pModelToWorld;
	const matrix3x4_t* pLightingOffset;
	const Vector* pLightingOrigin;
	int flags;
	int entity_index;
	int skin;
	int Body;
	int hitboxset;
	ModelInstanceHandle_t instance;

	ModelRenderInfo_t()
	{
		pModelToWorld = NULL;
		pLightingOffset = NULL;
		pLightingOrigin = NULL;
	}
};

enum OverrideType_t
{
	OVERRIDE_NORMAL = 0,
	OVERRIDE_BUILD_SHADOWS,
	OVERRIDE_DEPTH_WRITE,
};

enum MaterialPropertyTypes_t
{
	MATERIAL_PROPERTY_NEEDS_LIGHTMAP = 0, // bool
	MATERIAL_PROPERTY_OPACITY, // int (enum MaterialPropertyOpacityTypes_t)
	MATERIAL_PROPERTY_REFLECTIVITY, // vec3_t
	MATERIAL_PROPERTY_NEEDS_BUMPED_LIGHTMAPS // bool
};

enum {
	CHAR_TEX_ANTLION = 'A',
	CHAR_TEX_BLOODYFLESH = 'B',
	CHAR_TEX_CONCRETE = 'C',
	CHAR_TEX_DIRT = 'D',
	CHAR_TEX_EGGSHELL = 'E',
	CHAR_TEX_FLESH = 'F',
	CHAR_TEX_GRATE = 'G',
	CHAR_TEX_ALIENFLESH = 'H',
	CHAR_TEX_CLIP = 'I',
	CHAR_TEX_PLASTIC = 'L',
	CHAR_TEX_METAL = 'M',
	CHAR_TEX_SAND = 'N',
	CHAR_TEX_FOLIAGE = 'O',
	CHAR_TEX_COMPUTER = 'P',
	CHAR_TEX_SLOSH = 'S',
	CHAR_TEX_TILE = 'T',
	CHAR_TEX_CARDBOARD = 'U',
	CHAR_TEX_VENT = 'V',
	CHAR_TEX_WOOD = 'W',
	CHAR_TEX_GLASS = 'Y',
	CHAR_TEX_WARPSHIELD = 'Z',
};

enum ImageFormat
{
	IMAGE_FORMAT_UNKNOWN = -1,
	IMAGE_FORMAT_RGBA8888 = 0,
	IMAGE_FORMAT_ABGR8888,
	IMAGE_FORMAT_RGB888,
	IMAGE_FORMAT_BGR888,
	IMAGE_FORMAT_RGB565,
	IMAGE_FORMAT_I8,
	IMAGE_FORMAT_IA88,
	IMAGE_FORMAT_P8,
	IMAGE_FORMAT_A8,
	IMAGE_FORMAT_RGB888_BLUESCREEN,
	IMAGE_FORMAT_BGR888_BLUESCREEN,
	IMAGE_FORMAT_ARGB8888,
	IMAGE_FORMAT_BGRA8888,
	IMAGE_FORMAT_DXT1,
	IMAGE_FORMAT_DXT3,
	IMAGE_FORMAT_DXT5,
	IMAGE_FORMAT_BGRX8888,
	IMAGE_FORMAT_BGR565,
	IMAGE_FORMAT_BGRX5551,
	IMAGE_FORMAT_BGRA4444,
	IMAGE_FORMAT_DXT1_ONEBITALPHA,
	IMAGE_FORMAT_BGRA5551,
	IMAGE_FORMAT_UV88,
	IMAGE_FORMAT_UVWQ8888,
	IMAGE_FORMAT_RGBA16161616F,
	IMAGE_FORMAT_RGBA16161616,
	IMAGE_FORMAT_UVLX8888,
	IMAGE_FORMAT_R32F, // Single-channel 32-bit floating Point
	IMAGE_FORMAT_RGB323232F, // NOTE: D3D9 does not have this format
	IMAGE_FORMAT_RGBA32323232F,
	IMAGE_FORMAT_RG1616F,
	IMAGE_FORMAT_RG3232F,
	IMAGE_FORMAT_RGBX8888,

	IMAGE_FORMAT_NULL, // Dummy format which takes no video memory

					   // Compressed normal map formats
					   IMAGE_FORMAT_ATI2N, // One-surface ATI2N / DXN format
					   IMAGE_FORMAT_ATI1N, // Two-surface ATI1N format

					   IMAGE_FORMAT_RGBA1010102, // 10 bit-per component render targets
					   IMAGE_FORMAT_BGRA1010102,
					   IMAGE_FORMAT_R16F, // 16 bit FP format

										  // Depth-stencil texture formats
										  IMAGE_FORMAT_D16,
										  IMAGE_FORMAT_D15S1,
										  IMAGE_FORMAT_D32,
										  IMAGE_FORMAT_D24S8,
										  IMAGE_FORMAT_LINEAR_D24S8,
										  IMAGE_FORMAT_D24X8,
										  IMAGE_FORMAT_D24X4S4,
										  IMAGE_FORMAT_D24FS8,
										  IMAGE_FORMAT_D16_SHADOW, // Specific formats for shadow mapping
										  IMAGE_FORMAT_D24X8_SHADOW, // Specific formats for shadow mapping

																	 // supporting these specific formats as non-tiled for procedural cpu access (360-specific)
																	 IMAGE_FORMAT_LINEAR_BGRX8888,
																	 IMAGE_FORMAT_LINEAR_RGBA8888,
																	 IMAGE_FORMAT_LINEAR_ABGR8888,
																	 IMAGE_FORMAT_LINEAR_ARGB8888,
																	 IMAGE_FORMAT_LINEAR_BGRA8888,
																	 IMAGE_FORMAT_LINEAR_RGB888,
																	 IMAGE_FORMAT_LINEAR_BGR888,
																	 IMAGE_FORMAT_LINEAR_BGRX5551,
																	 IMAGE_FORMAT_LINEAR_I8,
																	 IMAGE_FORMAT_LINEAR_RGBA16161616,

																	 IMAGE_FORMAT_LE_BGRX8888,
																	 IMAGE_FORMAT_LE_BGRA8888,

																	 NUM_IMAGE_FORMATS
};

enum Collision_Group_t
{
	COLLISION_GROUP_NONE = 0,
	COLLISION_GROUP_DEBRIS, // Collides with nothing but World and static stuff
	COLLISION_GROUP_DEBRIS_TRIGGER, // Same as debris, but hits triggers
	COLLISION_GROUP_INTERACTIVE_DEBRIS, // Collides with everything except other interactive debris or debris
	COLLISION_GROUP_INTERACTIVE, // Collides with everything except interactive debris or debris
	COLLISION_GROUP_PLAYER,
	COLLISION_GROUP_BREAKABLE_GLASS,
	COLLISION_GROUP_VEHICLE,
	COLLISION_GROUP_PLAYER_MOVEMENT, // For HL2, same as Collision_Group_Player, for
									 // TF2, this filters Out other players and CBaseObjects
									 COLLISION_GROUP_NPC, // Generic NPC group
									 COLLISION_GROUP_IN_VEHICLE, // for any entity inside a vehicle
									 COLLISION_GROUP_WEAPON, // for any Weapons that need collision detection
									 COLLISION_GROUP_VEHICLE_CLIP, // vehicle clip brush to restrict vehicle movement
									 COLLISION_GROUP_PROJECTILE, // Projectiles!
									 COLLISION_GROUP_DOOR_BLOCKER, // Blocks entities not permitted to get near moving doors
									 COLLISION_GROUP_PASSABLE_DOOR, // Doors that the Player shouldn't collide with
									 COLLISION_GROUP_DISSOLVING, // Things that are dissolving are in this group
									 COLLISION_GROUP_PUSHAWAY, // Nonsolid on client and server, pushaway in Player code

									 COLLISION_GROUP_NPC_ACTOR, // Used so NPCs in scripts ignore the Player.
									 COLLISION_GROUP_NPC_SCRIPTED, // USed for NPCs in scripts that should not collide with each other
									 COLLISION_GROUP_PZ_CLIP,

									 COLLISION_GROUP_DEBRIS_BLOCK_PROJECTILE, // Only collides with bullets

									 LAST_SHARED_COLLISION_GROUP
};

struct string_t
{
public:
	bool operator!() const
	{
		return (pszValue == NULL);
	}

	bool operator==(const string_t& rhs) const
	{
		return (pszValue == rhs.pszValue);
	}

	bool operator!=(const string_t& rhs) const
	{
		return (pszValue != rhs.pszValue);
	}

	bool operator<(const string_t& rhs) const
	{
		return ((void *)pszValue < (void *)rhs.pszValue);
	}

	const char* ToCStr() const
	{
		return (pszValue) ? pszValue : "";
	}

protected:
	const char* pszValue;
};

#define PHYSICS_MULTIPLAYER_AUTODETECT	0	// use multiplayer physics mode as defined in model prop Data
#define PHYSICS_MULTIPLAYER_SOLID		1	// soild, pushes Player away 
#define PHYSICS_MULTIPLAYER_NON_SOLID	2	// nonsolid, but pushed by Player
#define PHYSICS_MULTIPLAYER_CLIENTSIDE	3	// Clientside only, nonsolid 	

class IMultiplayerPhysics
{
public:
	virtual int GetMultiplayerPhysicsMode() = 0;
	virtual float GetMass() = 0;
	virtual bool IsAsleep() = 0;
};

enum propdata_interactions_t
{
	PROPINTER_PHYSGUN_WORLD_STICK, // "onworldimpact"	"stick"
	PROPINTER_PHYSGUN_FIRST_BREAK, // "onfirstimpact"	"break"
	PROPINTER_PHYSGUN_FIRST_PAINT, // "onfirstimpact"	"paintsplat"
	PROPINTER_PHYSGUN_FIRST_IMPALE, // "onfirstimpact"	"impale"
	PROPINTER_PHYSGUN_LAUNCH_SPIN_NONE, // "onlaunch"		"spin_none"
	PROPINTER_PHYSGUN_LAUNCH_SPIN_Z, // "onlaunch"		"spin_zaxis"
	PROPINTER_PHYSGUN_BREAK_EXPLODE, // "onbreak"		"explode_fire"
	PROPINTER_PHYSGUN_BREAK_EXPLODE_ICE, // "onbreak"	"explode_ice"
	PROPINTER_PHYSGUN_DAMAGE_NONE, // "damage"			"none"

	PROPINTER_FIRE_FLAMMABLE, // "flammable"			"yes"
	PROPINTER_FIRE_EXPLOSIVE_RESIST, // "explosive_resist"	"yes"
	PROPINTER_FIRE_IGNITE_HALFHEALTH, // "ignite"				"halfhealth"

	PROPINTER_PHYSGUN_CREATE_FLARE, // "onpickup"		"create_flare"

	PROPINTER_PHYSGUN_ALLOW_OVERHEAD, // "allow_overhead"	"yes"

	PROPINTER_WORLD_BLOODSPLAT, // "onworldimpact", "bloodsplat"

	PROPINTER_PHYSGUN_NOTIFY_CHILDREN, // "onfirstimpact" cause attached flechettes to explode
	PROPINTER_MELEE_IMMUNE, // "melee_immune"	"yes"

							// If we get more than 32 of these, we'll need a different system

							PROPINTER_NUM_INTERACTIONS,
};

enum mp_break_t
{
	MULTIPLAYER_BREAK_DEFAULT,
	MULTIPLAYER_BREAK_SERVERSIDE,
	MULTIPLAYER_BREAK_CLIENTSIDE,
	MULTIPLAYER_BREAK_BOTH
};

class IBreakableWithPropData
{
public:
	// Damage modifiers
	virtual void SetDmgModBullet(float flDmgMod) = 0;
	virtual void SetDmgModClub(float flDmgMod) = 0;
	virtual void SetDmgModExplosive(float flDmgMod) = 0;
	virtual float GetDmgModBullet(void) = 0;
	virtual float GetDmgModClub(void) = 0;
	virtual float GetDmgModExplosive(void) = 0;
	virtual float GetDmgModFire(void) = 0;

	// Explosive
	virtual void SetExplosiveRadius(float flRadius) = 0;
	virtual void SetExplosiveDamage(float flDamage) = 0;
	virtual float GetExplosiveRadius(void) = 0;
	virtual float GetExplosiveDamage(void) = 0;

	// Physics damage tables
	virtual void SetPhysicsDamageTable(string_t iszTableName) = 0;
	virtual string_t GetPhysicsDamageTable(void) = 0;

	// Breakable chunks
	virtual void SetBreakableModel(string_t iszModel) = 0;
	virtual string_t GetBreakableModel(void) = 0;
	virtual void SetBreakableSkin(int iSkin) = 0;
	virtual int GetBreakableSkin(void) = 0;
	virtual void SetBreakableCount(int iCount) = 0;
	virtual int GetBreakableCount(void) = 0;
	virtual void SetMaxBreakableSize(int iSize) = 0;
	virtual int GetMaxBreakableSize(void) = 0;

	// LOS blocking
	virtual void SetPropDataBlocksLOS(bool bBlocksLOS) = 0;
	virtual void SetPropDataIsAIWalkable(bool bBlocksLOS) = 0;

	// Interactions
	virtual void SetInteraction(propdata_interactions_t Interaction) = 0;
	virtual bool HasInteraction(propdata_interactions_t Interaction) = 0;

	// Multiplayer physics mode
	virtual void SetPhysicsMode(int iMode) = 0;
	virtual int GetPhysicsMode() = 0;

	// Multiplayer breakable spawn behavior
	virtual void SetMultiplayerBreakMode(mp_break_t mode) = 0;
	virtual mp_break_t GetMultiplayerBreakMode(void) const = 0;

	// Used for debugging
	virtual void SetBasePropData(string_t iszBase) = 0;
	virtual string_t GetBasePropData(void) = 0;
};

#define FCVAR_NONE				0

// Command to ConVars and ConCommands
// ConVar Systems
#define FCVAR_UNREGISTERED		(1<<0)	// If this is set, don't add to linked list, etc.
#define FCVAR_DEVELOPMENTONLY	(1<<1)	// Hidden in released products. Flag is removed automatically if ALLOW_DEVELOPMENT_CVARS is defined.
#define FCVAR_GAMEDLL			(1<<2)	// defined by the game DLL
#define FCVAR_CLIENTDLL			(1<<3)  // defined by the client DLL
#define FCVAR_HIDDEN			(1<<4)	// Hidden. Doesn't appear in find or autocomplete. Like DEVELOPMENTONLY, but can't be compiled Out.

// ConVar only
#define FCVAR_PROTECTED			(1<<5)  // It's a server Cvar, but we don't send the Data since it's a password, etc.  Sends 1 if it's not bland/zero, 0 otherwise as Value
#define FCVAR_SPONLY			(1<<6)  // This Cvar cannot be changed by clients connected to a multiplayer server.
#define	FCVAR_ARCHIVE			(1<<7)	// set to cause it to be saved to vars.rc
#define	FCVAR_NOTIFY			(1<<8)	// notifies players when changed
#define	FCVAR_USERINFO			(1<<9)	// changes the client's Info string
#define FCVAR_CHEAT				(1<<14) // Only useable in singleplayer / debug / multiplayer & sv_cheats

#define FCVAR_PRINTABLEONLY		(1<<10)  // This Cvar's string cannot contain unprintable characters ( e.g., used for Player Name etc ).
#define FCVAR_UNLOGGED			(1<<11)  // If this is a FCVAR_SERVER, don't log changes to the log File / console if we are creating a log
#define FCVAR_NEVER_AS_STRING	(1<<12)  // never try to print that Cvar

// It's a ConVar that's shared between the client and the server.
// At signon, the values of all such ConVars are sent from the server to the client (skipped for local
//  client, of course )
// If a change is requested it must come from the console (i.e., no remote client changes)
// If a Value is changed while a server is active, it's replicated to all connected clients
#define FCVAR_REPLICATED		(1<<13)	// server setting enforced on clients, TODO rename to FCAR_SERVER at some Time
#define FCVAR_DEMO				(1<<16)  // record this Cvar when starting a demo File
#define FCVAR_DONTRECORD		(1<<17)  // don't record these command in demofiles
#define FCVAR_RELOAD_MATERIALS	(1<<20)	// If this Cvar changes, it forces a material reload
#define FCVAR_RELOAD_TEXTURES	(1<<21)	// If this Cvar changes, if forces a texture reload

#define FCVAR_NOT_CONNECTED		(1<<22)	// Cvar cannot be changed by a client that is connected to a server
#define FCVAR_MATERIAL_SYSTEM_THREAD (1<<23)	// Indicates this Cvar is read from the material system thread
#define FCVAR_ARCHIVE_XBOX		(1<<24) // Cvar written to Config.CFG on the Xbox

#define FCVAR_ACCESSIBLE_FROM_THREADS	(1<<25)	// used as a debugging tool necessary to check material system thread convars

#define FCVAR_SERVER_CAN_EXECUTE	(1<<28)// the server is allowed to execute this command on clients via ClientCommand/NET_StringCmd/CBaseClientState::ProcessStringCmd.
#define FCVAR_SERVER_CANNOT_QUERY	(1<<29)// If this is set, then the server is not allowed to query this Cvar's Value (via IServerPluginHelpers::StartQueryCvarValue).
#define FCVAR_CLIENTCMD_CAN_EXECUTE	(1<<30)	// IVEngineClient::ClientCmd is allowed to execute this command. 
// Note: IVEngineClient::ClientCmd_Unrestricted can run any client command.

// #define FCVAR_AVAILABLE			(1<<15)
// #define FCVAR_AVAILABLE			(1<<18)
// #define FCVAR_AVAILABLE			(1<<19)
// #define FCVAR_AVAILABLE			(1<<20)
// #define FCVAR_AVAILABLE			(1<<21)
// #define FCVAR_AVAILABLE			(1<<23)
// #define FCVAR_AVAILABLE			(1<<26)
// #define FCVAR_AVAILABLE			(1<<27)
// #define FCVAR_AVAILABLE			(1<<31)

#define FCVAR_MATERIAL_THREAD_MASK ( FCVAR_RELOAD_MATERIALS | FCVAR_RELOAD_TEXTURES | FCVAR_MATERIAL_SYSTEM_THREAD )

struct FileHandle_t;

class KeyValues
{
public:
	//	By default, the KeyValues class uses a string table for the Key names that is
	//	limited to 4MB. The game will exit in error if this space is exhausted. In
	//	general this is preferable for game code for performance and memory fragmentation
	//	reasons.
	//
	//	If this is not acceptable, you can use this call to switch to a table that can grow
	//	arbitrarily. This call must be made before any KeyValues objects are allocated or it
	//	will result in undefined behavior. If you use the growable string table, you cannot
	//	share KeyValues pointers directly with any other module. You can serialize them across
	//	module boundaries. These limitations are acceptable in the Steam backend code 
	//	this option was written for, but may not be in other situations. Make sure to
	//	understand the implications before using this.
	static void SetUseGrowableStringTable(bool bUseGrowableTable);

	KeyValues(const char* setName)
	{}

	//
	// AutoDelete class to automatically free the keyvalues.
	// Simply construct it with the keyvalues you allocated and it will free them when falls Out of scope.
	// When you decide that keyvalues shouldn't be deleted call Assign(NULL) on it.
	// If you constructed AutoDelete(NULL) you can later assign the keyvalues to be deleted with Assign(pKeyValues).
	// You can also pass temporary KeyValues object as an argument to a function by wrapping it into KeyValues::AutoDelete
	// instance:   call_my_function( KeyValues::AutoDelete( new KeyValues( "test" ) ) )
	//
	class AutoDelete
	{
	public:
		explicit inline AutoDelete(KeyValues* pKeyValues)
			: m_pKeyValues(pKeyValues)
		{}

		explicit inline AutoDelete(const char* pchKVName)
			: m_pKeyValues(new KeyValues(pchKVName))
		{}

		inline ~AutoDelete(void)
		{
			if (m_pKeyValues)
				m_pKeyValues->deleteThis();
		}

		inline void Assign(KeyValues* pKeyValues)
		{
			m_pKeyValues = pKeyValues;
		}

		KeyValues* operator->()
		{
			return m_pKeyValues;
		}

		operator KeyValues *()
		{
			return m_pKeyValues;
		}

	private:
		AutoDelete(AutoDelete const& x); // forbid
		AutoDelete& operator=(AutoDelete const& x); // forbid
		KeyValues* m_pKeyValues;
	};

	// Quick setup constructors
	KeyValues(const char* setName, const char* firstKey, const char* firstValue);
	KeyValues(const char* setName, const char* firstKey, const wchar_t* firstValue);
	KeyValues(const char* setName, const char* firstKey, int firstValue);
	KeyValues(const char* setName, const char* firstKey, const char* firstValue, const char* secondKey, const char* secondValue);
	KeyValues(const char* setName, const char* firstKey, int firstValue, const char* secondKey, int secondValue);

	// Section Name
	const char* GetName() const;
	void SetName(const char* setName);

	// gets the Name as a unique int
	int GetNameSymbol() const
	{
		return m_iKeyName;
	}

	// File access. Set UsesEscapeSequences true, if resource File/buffer uses Escape Sequences (eg \n, \t)
	void UsesEscapeSequences(bool state); // default false
	void UsesConditionals(bool state); // default true
	bool LoadFromFile(void* filesystem, const char* resourceName, const char* pathID = NULL);
	bool SaveToFile(void* filesystem, const char* resourceName, const char* pathID = NULL, bool sortKeys = false, bool bAllowEmptyString = false);

	// Read from a buffer...  Note that the buffer must be null terminated
	bool LoadFromBuffer(char const* resourceName, const char* pBuffer, void* pFileSystem = NULL, const char* pPathID = NULL);

	// Read from a utlbuffer...
	bool LoadFromBuffer(char const* resourceName, void* buf, void* pFileSystem = NULL, const char* pPathID = NULL);

	// Find a keyValue, create it if it is not found.
	// Set bCreate to true to create the Key if it doesn't already exist (which ensures a valid pointer will be returned)
	KeyValues* FindKey(const char* keyName, bool bCreate = false);
	KeyValues* FindKey(int keySymbol) const;
	KeyValues* CreateNewKey(); // creates a new Key, with an autogenerated Name.  Name is guaranteed to be an integer, of Value 1 higher than the highest other integer Key Name
	void AddSubKey(KeyValues* pSubkey); // Adds a subkey. Make sure the subkey isn't a child of some other keyvalues
	void RemoveSubKey(KeyValues* subKey); // removes a subkey from the list, DOES NOT DELETE IT

										  // Key iteration.
										  //
										  // NOTE: GetFirstSubKey/GetNextKey will iterate keys AND values. Use the functions 
										  // below if you want to iterate over just the keys or just the values.
										  //
	KeyValues* GetFirstSubKey()
	{
		return m_pSub;
	} // returns the first subkey in the list
	KeyValues* GetNextKey()
	{
		return m_pPeer;
	} // returns the next subkey
	void SetNextKey(KeyValues* pDat);
	KeyValues* FindLastSubKey(); // returns the LAST subkey in the list.  This requires a linked list iteration to find the Key.  Returns NULL if we don't have any children

								 //
								 // These functions can be used to treat it like a true Key/values tree instead of 
								 // confusing values with keys.
								 //
								 // So if you wanted to iterate all subkeys, then all values, it would look like this:
								 //     for ( KeyValues *pKey = pRoot->GetFirstTrueSubKey(); pKey; pKey = pKey->GetNextTrueSubKey() )
								 //     {
								 //		   Msg( "Key Name: %s\n", pKey->GetName() );
								 //     }
								 //     for ( KeyValues *pValue = pRoot->GetFirstValue(); pKey; pKey = pKey->GetNextValue() )
								 //     {
								 //         Msg( "Int Value: %d\n", pValue->GetInt() );  // Assuming pValue->GetDataType() == TYPE_INT...
								 //     }
	KeyValues* GetFirstTrueSubKey();
	KeyValues* GetNextTrueSubKey();

	KeyValues* GetFirstValue(); // When you get a Value back, you can use GetX and pass in NULL to get the Value.
	KeyValues* GetNextValue();

	// Data access
	int GetInt(const char* keyName = NULL, int defaultValue = 0);
	uint64 GetUint64(const char* keyName = NULL, uint64 defaultValue = 0);
	float GetFloat(const char* keyName = NULL, float defaultValue = 0.0f);
	const char* GetString(const char* keyName = NULL, const char* defaultValue = "");
	const wchar_t* GetWString(const char* keyName = NULL, const wchar_t* defaultValue = L"");
	void* GetPtr(const char* keyName = NULL, void* defaultValue = (void*)0);
	bool GetBool(const char* keyName = NULL, bool defaultValue = false);
	Color GetColor(const char* keyName = NULL /* default Value is all black */);
	bool IsEmpty(const char* keyName = NULL);

	// Data access
	int GetInt(int keySymbol, int defaultValue = 0);
	float GetFloat(int keySymbol, float defaultValue = 0.0f);
	const char* GetString(int keySymbol, const char* defaultValue = "");
	const wchar_t* GetWString(int keySymbol, const wchar_t* defaultValue = L"");
	void* GetPtr(int keySymbol, void* defaultValue = (void*)0);
	Color GetColor(int keySymbol /* default Value is all black */);
	bool IsEmpty(int keySymbol);

	// Key writing
	void SetWString(const char* keyName, const wchar_t* Value);
	void SetString(const char* keyName, const char* Value);
	void SetInt(const char* keyName, int Value);
	void SetUint64(const char* keyName, uint64 Value);
	void SetFloat(const char* keyName, float Value);
	void SetPtr(const char* keyName, void* Value);
	void SetColor(const char* keyName, Color Value);

	void SetBool(const char* keyName, bool Value)
	{
		SetInt(keyName, Value ? 1 : 0);
	}

	// Adds a chain... if we don't find stuff in this keyvalue, we'll look
	// in the one we're chained to.
	void ChainKeyValue(KeyValues* pChain);

	void RecursiveSaveToFile(void* buf, int indentLevel, bool sortKeys = false, bool bAllowEmptyString = false);

	bool WriteAsBinary(void* buffer);
	bool ReadAsBinary(void* buffer, int nStackDepth = 0);

	// Allocate & create a new copy of the keys
	KeyValues* MakeCopy(void) const;

	// Make a new copy of all subkeys, add them all to the passed-in keyvalues
	void CopySubkeys(KeyValues* pParent) const;

	// Clear Out all subkeys, and the current Value
	void Clear(void);

	// Data Type
	enum types_t
	{
		TYPE_NONE = 0,
		TYPE_STRING,
		TYPE_INT,
		TYPE_FLOAT,
		TYPE_PTR,
		TYPE_WSTRING,
		TYPE_COLOR,
		TYPE_UINT64,
		TYPE_NUMTYPES,
	};

	types_t GetDataType(const char* keyName = NULL);

	// Virtual deletion function - ensures that KeyValues object is deleted from correct heap
	void deleteThis();

	void SetStringValue(char const* strValue);

	// unpack a Key values list into a structure
	void UnpackIntoStructure(struct KeyValuesUnpackStructure const* pUnpackTable, void* pDest, size_t DestSizeInBytes);

	// Process conditional keys for widescreen support.
	bool ProcessResolutionKeys(const char* pResString);

	// Dump keyvalues recursively into a dump context
	bool Dump(class IKeyValuesDumpContext* pDump, int nIndentLevel = 0);

	// Merge in another KeyValues, keeping "our" settings
	void RecursiveMergeKeyValues(KeyValues* baseKV);

private:
	KeyValues(KeyValues&); // prevent copy constructor being used

						   // prevent delete being called except through deleteThis()
	~KeyValues();

	KeyValues* CreateKey(const char* keyName);

	/// Create a child Key, given that we know which child is currently the Last child.
	/// This avoids the O(N^2) behaviour when adding children in sequence to KV,
	/// when CreateKey() wil have to re-locate the End of the list each Time.  This happens,
	/// for example, every Time we Load any KV File whatsoever.
	KeyValues* CreateKeyUsingKnownLastChild(const char* keyName, KeyValues* pLastChild);
	void AddSubkeyUsingKnownLastChild(KeyValues* pSubKey, KeyValues* pLastChild);

	void RecursiveCopyKeyValues(KeyValues& src);
	void RemoveEverything();
	//	void RecursiveSaveToFile( IBaseFileSystem *filesystem, void*buffer, int indentLevel );
	//	void WriteConvertedString( void*buffer, const char *pszString );

	// NOTE: If both filesystem and pBuf are non-null, it'll Save to both of them.
	// If filesystem is null, it'll ignore f.
	void RecursiveSaveToFile(void* filesystem, FileHandle_t f, void* pBuf, int indentLevel, bool sortKeys, bool bAllowEmptyString);
	void SaveKeyToFile(KeyValues* dat, void* filesystem, FileHandle_t f, void* pBuf, int indentLevel, bool sortKeys, bool bAllowEmptyString);
	void WriteConvertedString(void* filesystem, FileHandle_t f, void* pBuf, const char* pszString);

	void RecursiveLoadFromBuffer(char const* resourceName, void* buf);

	// For handling #include "filename"
	void AppendIncludedKeys(void* includedKeys);
	void ParseIncludedKeys(char const* resourceName, const char* filetoinclude,
		void* pFileSystem, const char* pPathID, void* includedKeys);

	// For handling #base "filename"
	void MergeBaseKeys(void* baseKeys);

	// NOTE: If both filesystem and pBuf are non-null, it'll Save to both of them.
	// If filesystem is null, it'll ignore f.
	void InternalWrite(void* filesystem, FileHandle_t f, void* pBuf, const void* pData, int len);

	void Init();
	const char* ReadToken(void* buf, bool& wasQuoted, bool& wasConditional);
	void WriteIndents(void* filesystem, FileHandle_t f, void* pBuf, int indentLevel);

	void FreeAllocatedValue();
	void AllocateValueBlock(int Size);

	int m_iKeyName; // keyname is a symbol defined in KeyValuesSystem

					// These are needed Out of the union because the API returns string pointers
	char* m_sValue;
	wchar_t* m_wsValue;

	// we don't delete these
	union
	{
		int m_iValue;
		float m_flValue;
		void* m_pValue;
		unsigned char m_Color[4];
	};

	char m_iDataType;
	char m_bHasEscapeSequences; // true, if while parsing this KeyValue, Escape Sequences are used (default false)
	char m_bEvaluateConditionals; // true, if while parsing this KeyValue, conditionals blocks are evaluated (default true)
	char unused[1];

	KeyValues* m_pPeer; // pointer to next Key in list
	KeyValues* m_pSub; // pointer to Start of a new sub Key list
	KeyValues* m_pChain;// Search here if it's not in our list

private:
	// Statics to implement the optional growable string table
	// Function pointers that will determine which mode we are in
	static int(*s_pfGetSymbolForString)(const char* Name, bool bCreate);
	static const char*(*s_pfGetStringForSymbol)(int symbol);
	static void* s_pGrowableStringTable;

public:
	// Functions that invoke the default behavior
	static int GetSymbolForStringClassic(const char* Name, bool bCreate = true);
	static const char* GetStringForSymbolClassic(int symbol);

	// Functions that use the growable string table
	static int GetSymbolForStringGrowable(const char* Name, bool bCreate = true);
	static const char* GetStringForSymbolGrowable(int symbol);

	// Functions to get external access to whichever of the above functions we're going to call.
	static int CallGetSymbolForString(const char* Name, bool bCreate = true)
	{
		return s_pfGetSymbolForString(Name, bCreate);
	}

	static const char* CallGetStringForSymbol(int symbol)
	{
		return s_pfGetStringForSymbol(symbol);
	}
};

struct ColorRGBExp32
{
	byte r, g, b;
	signed char exponent;
};

struct SpatializationInfo_t;

typedef unsigned long CBaseHandle;

class IHandleEntity
{
public:
	virtual ~IHandleEntity() {}
	virtual void SetRefEHandle(const CBaseHandle &handle) = 0;
	virtual const CBaseHandle& GetRefEHandle() const = 0;
};

class IClientThinkable;
class IClientAlphaProperty;
class CClientThinkHandlePtr;
typedef CClientThinkHandlePtr* ClientThinkHandle_t;
typedef unsigned short ClientShadowHandle_t;
typedef unsigned short ClientRenderHandle_t;
typedef unsigned short ModelInstanceHandle_t;
class IClientUnknown;
class IClientEntity;
class ClientClass;

struct RenderableInstance_t
{
	//uint8 m_nAlpha;
};

class IClientRenderable;
class CBaseEntity;

class IClientUnknown : public IHandleEntity
{
public:
	virtual ICollideable*              GetCollideable() = 0;
	virtual IClientNetworkable*        GetClientNetworkable() = 0;
	virtual IClientRenderable*         GetClientRenderable() = 0;
	virtual IClientEntity*             GetIClientEntity() = 0;
	virtual CBaseEntity*			   GetBaseEntity() = 0;
	virtual IClientThinkable*          GetClientThinkable() = 0;
	virtual IClientAlphaProperty*      GetClientAlphaProperty() = 0;
};

class IClientThinkable
{
public:
	virtual IClientUnknown*		GetIClientUnknown() = 0;
	virtual void				ClientThink() = 0;
	virtual ClientThinkHandle_t	GetThinkHandle() = 0;
	virtual void				SetThinkHandle(ClientThinkHandle_t hThink) = 0;
	virtual void				Release() = 0;
};

class IClientRenderable
{
public:
	virtual IClientUnknown*            GetIClientUnknown() = 0;
	virtual Vector const&              GetRenderOrigin(void) = 0;
	virtual Vector const&              GetRenderAngles(void) = 0;
	virtual bool                       ShouldDraw(void) = 0;
	virtual int                        GetRenderFlags(void) = 0; // ERENDERFLAGS_xxx
	virtual void                       Unused(void) const {}
	virtual ClientShadowHandle_t       GetShadowHandle() const = 0;
	virtual ClientRenderHandle_t&      RenderHandle() = 0;
	virtual model_t*		           GetModel() const = 0;
	virtual int                        DrawModel(int flags, const RenderableInstance_t &instance) = 0;
	virtual int                        GetBody() = 0;
	virtual void                       GetColorModulation(float* Color) = 0;
	virtual bool                       LODTest() = 0;
	virtual bool                       SetupBones(matrix3x4 *pBoneToWorldOut, int nMaxBones, int boneMask, float currentTime) = 0;
	virtual void                       SetupWeights(const matrix3x4 *pBoneToWorld, int nFlexWeightCount, float *pFlexWeights, float *pFlexDelayedWeights) = 0;
	virtual void                       DoAnimationEvents(void) = 0;
	virtual void* /*IPVSNotify*/       GetPVSNotifyInterface() = 0;
	virtual void                       GetRenderBounds(Vector& mins, Vector& maxs) = 0;
	virtual void                       GetRenderBoundsWorldspace(Vector& mins, Vector& maxs) = 0;
	virtual void                       GetShadowRenderBounds(Vector &mins, Vector &maxs, int /*ShadowType_t*/ shadowType) = 0;
	virtual bool                       ShouldReceiveProjectedTextures(int flags) = 0;
	virtual bool                       GetShadowCastDistance(float *pDist, int /*ShadowType_t*/ shadowType) const = 0;
	virtual bool                       GetShadowCastDirection(Vector *pDirection, int /*ShadowType_t*/ shadowType) const = 0;
	virtual bool                       IsShadowDirty() = 0;
	virtual void                       MarkShadowDirty(bool bDirty) = 0;
	virtual IClientRenderable*         GetShadowParent() = 0;
	virtual IClientRenderable*         FirstShadowChild() = 0;
	virtual IClientRenderable*         NextShadowPeer() = 0;
	virtual int /*ShadowType_t*/       ShadowCastType() = 0;
	virtual void                       CreateModelInstance() = 0;
	virtual ModelInstanceHandle_t      GetModelInstance() = 0;
	virtual const matrix3x4&         RenderableToWorldTransform() = 0;
	virtual int                        LookupAttachment(const char *pAttachmentName) = 0;
	virtual   bool                     GetAttachment(int Number, Vector &origin, Vector &angles) = 0;
	virtual bool                       GetAttachment(int Number, matrix3x4 &matrix) = 0;
	virtual float*                     GetRenderClipPlane(void) = 0;
	virtual int                        GetSkin() = 0;
	virtual void                       OnThreadedDrawSetup() = 0;
	virtual bool                       UsesFlexDelayedWeights() = 0;
	virtual void                       RecordToolMessage() = 0;
	virtual bool                       ShouldDrawForSplitScreenUser(int nSlot) = 0;
	virtual uint8                      OverrideAlphaModulation(uint8 nAlpha) = 0;
	virtual uint8                      OverrideShadowAlphaModulation(uint8 nAlpha) = 0;
};

class IClientEntity : public IClientUnknown, public IClientRenderable, public IClientNetworkable, public IClientThinkable
{
public:
	virtual void             Release(void) = 0;
	virtual const Vector     GetAbsOrigin(void) const = 0;
	virtual const Vector     GetAbsAngles(void) const = 0;
	virtual void*            GetMouth(void) = 0;
	virtual bool             GetSoundSpatialization(SpatializationInfo_t Info) = 0;
	virtual bool             IsBlurred(void) = 0;

	int GetModelIndex()
	{
		return *(int*)((DWORD)this + 0x254);
	}

	void SetModelIndex(int index)
	{
		*(reinterpret_cast<int*>(uintptr_t(this) + 0x254)) = index;
	}

	Vector GetOrigin()
	{
		return *(Vector*)((DWORD)this + 0x134);
	}
};

inline bool sanitize_angles(QAngle &angles)
{
	QAngle temp = angles;
	temp.NormalizeAngle();
	temp.Clamp();

	if (!isfinite(temp.x) ||
		!isfinite(temp.y) ||
		!isfinite(temp.z))
		return false;

	angles = temp;

	return true;
}